/* ═══════════════════════════════════════════════════════════════════
   LOGO
   ⚠️ KEEP YOUR EXISTING LOGO LINE:
   Replace the line below with the original line 1 of your old report.js
   (const MEDI_ELVES_LOGO_BASE64 = "data:image/png;base64,iVBOR....";)
   If you leave the placeholder, the PDF tries to load the header logo
   image instead, and falls back to "Medi Elves" text.
   ═══════════════════════════════════════════════════════════════════ */
const MEDI_ELVES_LOGO_BASE64 = "PASTE_YOUR_EXISTING_BASE64_HERE";
const DEFAULT_EMBEDDED_LOGO = MEDI_ELVES_LOGO_BASE64;
let ITEM_ID_TO_NUMBER_MAP = new Map();

const REPORT_FOOTER_LINES = [
    "CONFIDENTIAL \u2013 CONTAINS SENSITIVE HEALTH INFORMATION",
    "This document contains confidential patient and claims information and is intended only for the named recipient and authorised personnel. Unauthorised access, use, copying, forwarding or disclosure is prohibited. If you received this document in error, please notify Medi Elves immediately, delete all electronic copies and securely destroy any printed copies.",
    "Medi Elves  |  1800 956 692  |  admin@medielves.com.au"
];

let LOGO_DATA_URL = null;
let LOGO_ASPECT = 1;

/* ────────────────────────────────────────────────────────────────────
   BOTTOM SCROLLBAR SYNC
   ───────────────────────────────────────────────────────────────────── */
let _bottomScrollSyncing = false;

function initBottomScrollSync() {
    const wrapper = document.querySelector('.table-wrapper');
    const proxy = document.getElementById('bottom-scroll-proxy');
    const proxyInner = document.getElementById('bottom-scroll-proxy-inner');
    if (!wrapper || !proxy || !proxyInner) return;

    window.addEventListener('resize', updateBottomScrollWidth);

    wrapper.addEventListener('scroll', () => {
        if (_bottomScrollSyncing) return;
        _bottomScrollSyncing = true;
        proxy.scrollLeft = wrapper.scrollLeft;
        _bottomScrollSyncing = false;
    });
    proxy.addEventListener('scroll', () => {
        if (_bottomScrollSyncing) return;
        _bottomScrollSyncing = true;
        wrapper.scrollLeft = proxy.scrollLeft;
        _bottomScrollSyncing = false;
    });
}

function updateBottomScrollWidth() {
    const wrapper = document.querySelector('.table-wrapper');
    const proxyInner = document.getElementById('bottom-scroll-proxy-inner');
    if (!wrapper || !proxyInner) return;
    const table = wrapper.querySelector('table');
    if (!table) return;
    proxyInner.style.width = table.scrollWidth + 'px';
}

/* Scroll the sticky table back to the top-left (used after filter/sort/page change) */
function resetTableScroll() {
    const wrapper = document.querySelector('.table-wrapper');
    if (wrapper) wrapper.scrollTop = 0;
}

/* ────────────────────────────────────────────────────────────────────
   LOGO LOADING
   ───────────────────────────────────────────────────────────────────── */
function dataURLDimensions(dataUrl) {
    return new Promise((resolve) => {
        const probeImg = new Image();
        probeImg.onload = () => resolve({ w: probeImg.naturalWidth, h: probeImg.naturalHeight });
        probeImg.onerror = () => resolve({ w: 200, h: 200 });
        probeImg.src = dataUrl;
    });
}

async function fetchImageAsDataURL(url) {
    try {
        const resp = await fetch(url, { mode: 'cors' });
        if (!resp.ok) return null;
        const blob = await resp.blob();
        return await new Promise((resolve) => {
            const fr = new FileReader();
            fr.onload = () => resolve(fr.result);
            fr.onerror = () => resolve(null);
            fr.readAsDataURL(blob);
        });
    } catch (e) {
        return null;
    }
}

async function loadLogoDataURL() {
    if (LOGO_DATA_URL) return LOGO_DATA_URL;

    let dataUrl = null;
    if (typeof DEFAULT_EMBEDDED_LOGO === 'string' && DEFAULT_EMBEDDED_LOGO.startsWith('data:image')) {
        dataUrl = DEFAULT_EMBEDDED_LOGO;
    } else {
        const imgEl = document.querySelector('.report-logo');
        if (imgEl && imgEl.src) dataUrl = await fetchImageAsDataURL(imgEl.src);
    }
    if (!dataUrl) return null;

    const dims = await dataURLDimensions(dataUrl);
    LOGO_DATA_URL = dataUrl;
    LOGO_ASPECT = (dims.w / dims.h) || 1;
    return LOGO_DATA_URL;
}

/* ────────────────────────────────────────────────────────────────────
   BOOT
   ───────────────────────────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", function () {
    waitForZohoSDK(initWidget);
});

function waitForZohoSDK(callback, attempts = 0) {
    if (typeof ZOHO !== "undefined" &&
        ZOHO.CREATOR &&
        ZOHO.CREATOR.UTIL &&
        typeof ZOHO.CREATOR.UTIL.getQueryParams === "function") {
        callback();
        return;
    }
    if (attempts > 100) { // ~10s timeout
        console.error("Zoho Creator SDK failed to load.");
        return;
    }
    setTimeout(() => waitForZohoSDK(callback, attempts + 1), 100);
}

async function getRecords(config) {
    const PAGE_SIZE = 200;
    const MAX_PAGES = 100;              // safety cap (20,000 records)
    const byId = new Map();             // de-duplicates by record ID
    let cursor = null;
    let page = 1;

    const reportName = config.reportName || config.report_name;
    const appName = config.appName || config.app_name || "claims-management";

    for (let i = 0; i < MAX_PAGES; i++) {
        const pageConfig = {
            appName: appName,
            app_name: appName,
            appLinkName: appName,
            reportName: reportName,
            report_name: reportName,
            max_records: PAGE_SIZE,
            pageSize: PAGE_SIZE,
            page: page
        };
        if (config.criteria && config.criteria.trim() !== "") {
            pageConfig.criteria = config.criteria;
        }
        if (cursor) {
            pageConfig.record_cursor = cursor;
        }

        let resp = null;
        try {
            if (ZOHO.CREATOR.API && typeof ZOHO.CREATOR.API.getAllRecords === "function") {
                resp = await ZOHO.CREATOR.API.getAllRecords(pageConfig);
            } else if (ZOHO.CREATOR.DATA && typeof ZOHO.CREATOR.DATA.getRecords === "function") {
                resp = await ZOHO.CREATOR.DATA.getRecords(pageConfig);
            }
        } catch (callErr) {
            console.warn(`[getRecords] call error for ${reportName} (page ${page}):`, callErr);
            if (page === 1) {
                try {
                    const fallbackConfig = {
                        reportName: reportName,
                        report_name: reportName,
                        page: 1,
                        pageSize: PAGE_SIZE,
                        max_records: PAGE_SIZE
                    };
                    if (config.criteria) fallbackConfig.criteria = config.criteria;
                    if (ZOHO.CREATOR.API && typeof ZOHO.CREATOR.API.getAllRecords === "function") {
                        resp = await ZOHO.CREATOR.API.getAllRecords(fallbackConfig);
                    }
                } catch (fallbackErr) {
                    console.warn(`[getRecords] fallback for ${reportName} also failed:`, fallbackErr);
                }
            }
        }

        const data = (resp && resp.data) || (Array.isArray(resp) ? resp : []);
        if (!data.length) break;

        let added = 0;
        data.forEach(r => {
            const id = r && (r.ID || r.id);
            if (id == null) { byId.set("noid-" + byId.size, r); added++; return; }
            if (!byId.has(String(id))) { byId.set(String(id), r); added++; }
        });

        if (data.length < PAGE_SIZE) break;
        if (added === 0) break;

        cursor = (resp && (resp.record_cursor || resp.recordCursor)) ||
                 (resp && resp.headers && resp.headers.record_cursor) || null;
        page++;
    }

    console.log(`[getRecords] ${reportName}: ${byId.size} records`);
    return { data: Array.from(byId.values()) };
}

async function initWidget() {
    loadLogoDataURL();
    showLoading('Loading claims data');

    try {
        let appName = "claims-management";

        try {
            if (typeof ZOHO.CREATOR.init === "function") {
                const initData = await ZOHO.CREATOR.init();
                if (initData) {
                    if (initData.appName || initData.appLinkName) appName = initData.appName || initData.appLinkName;
                    if (initData.loginUser || initData.loginUserId || initData.user || initData.email) {
                        CURRENT_USER_EMAIL = initData.loginUser || initData.loginUserId || initData.user || initData.email;
                    }
                }
            }
        } catch (e) {
            console.log('[initWidget] ZOHO.CREATOR.init notice:', e);
        }

        try {
            const queryParams = await ZOHO.CREATOR.UTIL.getQueryParams();
            if (queryParams) {
                if (queryParams.appName || queryParams.app_name || queryParams.appLinkName) {
                    appName = queryParams.appName || queryParams.app_name || queryParams.appLinkName;
                }
                if (!CURRENT_USER_EMAIL) {
                    CURRENT_USER_EMAIL = queryParams.loginUser || queryParams.loginUserId || queryParams.user || queryParams.email || "";
                }
            }
        } catch (e) {
            console.log('[initWidget] getQueryParams notice:', e);
        }

        try {
            const initParams = await ZOHO.CREATOR.UTIL.getInitParams();
            if (initParams) {
                if (!appName && (initParams.appName || initParams.appLinkName)) {
                    appName = initParams.appName || initParams.appLinkName;
                }
                if (!CURRENT_USER_EMAIL) {
                    CURRENT_USER_EMAIL = initParams.loginUser || initParams.loginUserId || initParams.user || initParams.email || initParams.login_user || "";
                }
            }
        } catch (e) {
            console.log('[initWidget] getInitParams notice:', e);
        }

        if (!CURRENT_USER_EMAIL) {
            try {
                const urlParams = new URLSearchParams(window.location.search);
                CURRENT_USER_EMAIL = urlParams.get("loginUser") || urlParams.get("user") || urlParams.get("email") || urlParams.get("loginUserId") || "";
            } catch (e) {}
        }
        CURRENT_USER_EMAIL = String(CURRENT_USER_EMAIL || "").trim().toLowerCase();
        console.log('[initWidget] Current logged-in user email:', CURRENT_USER_EMAIL);

        // 1. Fetch My_Practice report (deluge filtered [Contact_Email == zoho.loginuserid])
        let myPractices = [];
        try {
            const myPracticeResp = await getRecords({
                appName: appName,
                reportName: "My_Practice"
            });
            myPractices = (myPracticeResp && myPracticeResp.data) || [];
            console.log('[initWidget] My_Practice records loaded:', myPractices.length);
        } catch (e) {
            console.warn('Could not load My_Practice report:', e);
        }

        // 2. Fetch Practices from Add_Practice_Report
        let practices = [];
        try {
            const practiceResp = await getRecords({
                appName: appName,
                reportName: "Add_Practice_Report"
            });
            practices = (practiceResp && practiceResp.data) || [];
            console.log('[initWidget] Add_Practice_Report loaded:', practices.length);
        } catch (e) {
            console.warn('Could not load Add_Practice_Report:', e);
        }

        // Identify practice strictly based on My_Practice / Contact_Email == loginuserid
        let matchedPractice = null;

        // Priority 1: My_Practice report is pre-filtered by Zoho Creator with [Contact_Email == zoho.loginuserid]
        if (myPractices && myPractices.length > 0) {
            if (CURRENT_USER_EMAIL) {
                matchedPractice = myPractices.find(p => {
                    const em = (p.Contact_Email || p.Email || p.contact_email || p.Contact_Email_Address || '').trim().toLowerCase();
                    return em && (em === CURRENT_USER_EMAIL || CURRENT_USER_EMAIL.includes(em) || em.includes(CURRENT_USER_EMAIL));
                }) || myPractices[0];
            } else {
                matchedPractice = myPractices[0];
            }
            if (!CURRENT_USER_EMAIL && matchedPractice.Contact_Email) {
                CURRENT_USER_EMAIL = String(matchedPractice.Contact_Email).trim().toLowerCase();
            }
        }

        // Priority 2: Match against Add_Practice_Report by Contact_Email == CURRENT_USER_EMAIL
        if (!matchedPractice && CURRENT_USER_EMAIL && practices && practices.length > 0) {
            matchedPractice = practices.find(p => {
                const em = (p.Contact_Email || p.Email || p.contact_email || p.Contact_Email_Address || '').trim().toLowerCase();
                return em && (em === CURRENT_USER_EMAIL || CURRENT_USER_EMAIL.includes(em) || em.includes(CURRENT_USER_EMAIL));
            });
        }

        if (matchedPractice) {
            const mId = String(matchedPractice.ID || matchedPractice.id || extractLookupId(matchedPractice) || '').trim();
            const mName = String(matchedPractice.Practice_Name || extractLookupName(matchedPractice, ['Practice_Name', 'Name']) || matchedPractice.zc_display_value || '').trim();
            LOGGED_IN_PRACTICE = {
                id: mId,
                name: mName,
                email: (matchedPractice.Contact_Email || CURRENT_USER_EMAIL || '').trim().toLowerCase(),
                record: matchedPractice
            };
            console.log('[initWidget] Logged in practice verified:', LOGGED_IN_PRACTICE);

            const alreadyExists = practices.some(p => (p.ID && mId && String(p.ID) === mId) || (p.Practice_Name && mName && normName(p.Practice_Name) === normName(mName)));
            if (!alreadyExists) {
                practices.push(matchedPractice);
            }
        } else {
            LOGGED_IN_PRACTICE = null;
            console.log('[initWidget] User is not linked to any practice. No records will be displayed.');
        }

        // 3. Fetch Doctor & Hospital from Doctor_Hospital_Subform_Report
        let subformRecs = [];
        try {
            const subformResp = await getRecords({
                appName: appName,
                reportName: "Doctor_Hospital_Subform_Report"
            });
            subformRecs = (subformResp && subformResp.data) || [];
        } catch (e) {
            console.warn('Could not load Doctor_Hospital_Subform_Report:', e);
        }

        if (matchedPractice && matchedPractice.Doctor_Hospital_Mapping && LOGGED_IN_PRACTICE) {
            const rawMappings = Array.isArray(matchedPractice.Doctor_Hospital_Mapping)
                ? matchedPractice.Doctor_Hospital_Mapping
                : [matchedPractice.Doctor_Hospital_Mapping];
            rawMappings.forEach(m => {
                if (m && typeof m === 'object') {
                    subformRecs.push({
                        Doctor: m.Doctor || m.Doctor_Name,
                        Hospital: m.Hospital || m.Hospital_Name,
                        Add_Practice: { ID: LOGGED_IN_PRACTICE.id, display_value: LOGGED_IN_PRACTICE.name },
                        Practice_Name: LOGGED_IN_PRACTICE.name,
                        Practice_ID: LOGGED_IN_PRACTICE.id
                    });
                }
            });
        }

        // Fallbacks if subform has no records
        let doctorsFallback = [];
        let hospitalsFallback = [];
        if (!subformRecs.length) {
            try {
                const doctorResp = await getRecords({
                    appName: appName,
                    reportName: "All_Doctors"
                });
                doctorsFallback = (doctorResp && doctorResp.data) || [];
            } catch (e) {}

            try {
                const hospResp = await getRecords({
                    appName: appName,
                    reportName: "All_Hospitals"
                });
                hospitalsFallback = (hospResp && hospResp.data) || [];
            } catch (e) {}

            try {
                const mapResp = await getRecords({
                    appName: appName,
                    reportName: "All_Doctor_Hospital_Mappings1"
                });
                buildDoctorHospitalMap((mapResp && mapResp.data) || []);
            } catch (e) {}
        }

        buildPracticeDoctorHospitalMappings(practices, subformRecs, doctorsFallback, hospitalsFallback);

        try {
            const itemsResp = await getRecords({
                appName: appName,
                reportName: "Add_Item_Report"
            });
            const itemRecs = (itemsResp && itemsResp.data) || [];
            ITEM_ID_TO_NUMBER_MAP = new Map();
            itemRecs.forEach(item => {
                const id = item.ID || item.id;
                const num = item.Item || item.Item_Number || item.Item_Name || item.Item_Code
                    || item.Name || item.name || item.zc_display_value;
                if (id && num) ITEM_ID_TO_NUMBER_MAP.set(String(id), String(num));
            });
        } catch (e) {
            console.warn('Could not load Items master report:', e);
        }

        // 4. Fetch claims data from Practice_Claims report (#Report:Practice_Claims)
        let claims = [];
        try {
            const claimsResp = await getRecords({
                appName: appName,
                reportName: "Practice_Claims"
            });
            claims = (claimsResp && claimsResp.data) || [];
            console.log('[initWidget] Practice_Claims loaded:', claims.length);
        } catch (e) {
            console.warn('Could not load Practice_Claims report:', e);
        }

        // Fallback to Add_Claim_Report only if Practice_Claims is not found or empty
        if (!claims || !claims.length) {
            try {
                const claimsResp = await getRecords({
                    appName: appName,
                    reportName: "Add_Claim_Report"
                });
                claims = (claimsResp && claimsResp.data) || [];
                console.log('[initWidget] Add_Claim_Report fallback loaded:', claims.length);
            } catch (e) {
                console.warn('Could not load Add_Claim_Report:', e);
            }
        }

        if (LOGGED_IN_PRACTICE) {
            ALL_PRACTICE_ITEMS = [{ value: LOGGED_IN_PRACTICE.id, label: LOGGED_IN_PRACTICE.name }];
            populateSSDropdown('ss-practice', ALL_PRACTICE_ITEMS, LOGGED_IN_PRACTICE.name);
            selectSSOption('ss-practice', LOGGED_IN_PRACTICE.id, LOGGED_IN_PRACTICE.name);
            lockPracticeSelect();

            if (ADJ_TYPES.length === 0) {
                const seen = new Map();
                claims.forEach(rec => {
                    const raw = probe(rec, CLAIM_FIELDS.adjustmentType,
                        ['Adj_Type', 'Adjustment Types', 'Type', 'Adjustment_Types']);
                    normalizeToStringArray(raw).forEach(v => {
                        const name = v.trim().toUpperCase();
                        if (name && !seen.has(name)) seen.set(name, true);
                    });
                });
                ADJ_TYPES = Array.from(seen.keys()).map((name, idx) => ({
                    code: idx + 1,
                    name: name,
                    badge: 'badge-other'
                }));
            }

            buildAdjOptions();

            const allRows = buildClaimsData(claims);
            allData = allRows.filter(r => r.type && r.type !== '—');
            filtered = [...allData];

            allRows.forEach(r => {
                if (r.doctor && r.doctor !== '—' && r.doctorId) {
                    if (!DOCTOR_ID_TO_NAME.has(String(r.doctorId))) {
                        DOCTOR_ID_TO_NAME.set(String(r.doctorId), r.doctor);
                        DOCTOR_NAME_TO_ID.set(normName(r.doctor), String(r.doctorId));
                    }
                }
                if (r.hospital && r.hospital !== '—' && r.hospitalId) {
                    if (!HOSPITAL_ID_TO_NAME.has(String(r.hospitalId))) {
                        HOSPITAL_ID_TO_NAME.set(String(r.hospitalId), r.hospital);
                        HOSPITAL_NAME_TO_ID.set(normName(r.hospital), String(r.hospitalId));
                    }
                }
            });

            // Populate Doctors & Hospitals for this practice
            const practiceDocs = getPracticeDoctors(LOGGED_IN_PRACTICE.id, LOGGED_IN_PRACTICE.name);
            const docSet = new Map();
            practiceDocs.forEach(d => docSet.set(String(d.value), d));
            allData.forEach(r => {
                if (r.doctor && r.doctor !== '—') {
                    const val = r.doctorId ? String(r.doctorId) : r.doctor;
                    if (!docSet.has(val)) docSet.set(val, { value: val, label: r.doctor });
                }
            });
            const finalDocs = Array.from(docSet.values()).sort((a, b) => a.label.localeCompare(b.label));
            populateSSDropdown('ss-doctor', finalDocs, 'All Doctors');

            const practiceHosps = getPracticeHospitals(LOGGED_IN_PRACTICE.id, LOGGED_IN_PRACTICE.name);
            const hospSet = new Map();
            practiceHosps.forEach(h => hospSet.set(String(h.value), h));
            allData.forEach(r => {
                if (r.hospital && r.hospital !== '—') {
                    const val = r.hospitalId ? String(r.hospitalId) : r.hospital;
                    if (!hospSet.has(val)) hospSet.set(val, { value: val, label: r.hospital });
                }
            });
            const finalHosps = Array.from(hospSet.values()).sort((a, b) => a.label.localeCompare(b.label));
            populateSSDropdown('ss-location', finalHosps, 'All Locations');

            populateStaffDropdown(allData);
            populatePatientDropdownFromClaims(allData);
        } else {
            // User does not match any practice -> show 0 records
            allData = [];
            filtered = [];
            buildAdjOptions();
            populateStaffDropdown([]);
            populateSSDropdown('ss-patient', [], 'All Patients');
            populateSSDropdown('ss-practice', [], 'No Practice Linked');
            selectSSOption('ss-practice', '', 'No Practice Linked');
            lockPracticeSelect();
            populateSSDropdown('ss-doctor', [], 'All Doctors');
            populateSSDropdown('ss-location', [], 'All Locations');
        }

        renderTable();
        initBottomScrollSync();
        hideLoading();

    } catch (err) {
        console.error('Init error:', err);
        hideLoading();
    }
}

function buildPracticeDoctorHospitalMappings(practices, subformRecs, doctorsFallback = [], hospitalsFallback = []) {
    PRACTICE_ID_TO_NAME = new Map();
    PRACTICE_NAME_TO_ID = new Map();
    DOCTOR_ID_TO_NAME = new Map();
    DOCTOR_NAME_TO_ID = new Map();
    HOSPITAL_ID_TO_NAME = new Map();
    HOSPITAL_NAME_TO_ID = new Map();

    PRACTICE_TO_DOCTORS = new Map();
    PRACTICE_TO_HOSPITALS = new Map();
    PRACTICE_DOC_TO_HOSPITALS = new Map();
    DOCTOR_TO_HOSPITALS = new Map();
    PRACTICE_DOC_HOSP_PAIRS = new Map();
    ALL_SUBFORM_ROWS = [];

    // 1. Process practices from Add_Practice_Report
    (practices || []).forEach(p => {
        const id = extractLookupId(p) || p.ID || p.id || '';
        const name = p.Practice_Name || extractLookupName(p, ['Practice_Name', 'Name']) || p.zc_display_value || id;
        if (id && name) {
            const pIdStr = String(id).trim();
            const pNameStr = String(name).replace(/\s+/g, ' ').trim();
            PRACTICE_ID_TO_NAME.set(pIdStr, pNameStr);
            PRACTICE_NAME_TO_ID.set(normName(pNameStr), pIdStr);
        }
    });

    // Process fallback doctors & hospitals
    (doctorsFallback || []).forEach(doc => {
        const dId = doc.ID || doc.id || '';
        const dName = doc.Doctor_Name || doc.Name || doc.Full_Name || doc.zc_display_value || dId;
        if (dId && dName) {
            DOCTOR_ID_TO_NAME.set(String(dId), String(dName).trim());
            DOCTOR_NAME_TO_ID.set(normName(dName), String(dId));
        }
    });

    (hospitalsFallback || []).forEach(hosp => {
        const hId = hosp.ID || hosp.id || '';
        const hName = hosp.Hospital_Name || hosp.Name || hosp.zc_display_value || hId;
        if (hId && hName) {
            HOSPITAL_ID_TO_NAME.set(String(hId), String(hName).trim());
            HOSPITAL_NAME_TO_ID.set(normName(hName), String(hId));
        }
    });

    // 2. Process subform records from Doctor_Hospital_Subform_Report
    const docMap = new Map();
    const hospMap = new Map();

    (subformRecs || []).forEach(rec => {
        // Doctor field from Doctor_Hospital_Subform_Report
        const docVal = probe(rec, 'Doctor', ['Doctor_Name', 'Doctor_Details', 'Doctors']);
        let docId = extractLookupId(docVal);
        let docName = extractLookupName(docVal, ['Doctor_Name', 'Name', 'Doctor']);
        if (!docName && docVal && typeof docVal === 'string' && !/^\d{10,}$/.test(docVal)) {
            docName = docVal.trim();
        }
        if (!docId && docVal && /^\d{10,}$/.test(String(docVal))) {
            docId = String(docVal);
        }
        if (!docName && docId && DOCTOR_ID_TO_NAME.has(String(docId))) {
            docName = DOCTOR_ID_TO_NAME.get(String(docId));
        }
        if (!docId && docName && DOCTOR_NAME_TO_ID.has(normName(docName))) {
            docId = DOCTOR_NAME_TO_ID.get(normName(docName));
        }
        if (!docId && docName) docId = docName;
        if (!docName && docId) docName = docId;

        if (docId && docName) {
            DOCTOR_ID_TO_NAME.set(String(docId), docName);
            DOCTOR_NAME_TO_ID.set(normName(docName), String(docId));
            if (!docMap.has(String(docId))) {
                docMap.set(String(docId), { value: String(docId), label: docName });
            }
        }

        // Hospital field from Doctor_Hospital_Subform_Report
        const hospVal = probe(rec, 'Hospital', ['Hospital_Name', 'Hospital_Details', 'Hospitals']);
        let hospId = extractLookupId(hospVal);
        let hospName = extractLookupName(hospVal, ['Hospital_Name', 'Name', 'Hospital']);
        if (!hospName && hospVal && typeof hospVal === 'string' && !/^\d{10,}$/.test(hospVal)) {
            hospName = hospVal.trim();
        }
        if (!hospId && hospVal && /^\d{10,}$/.test(String(hospVal))) {
            hospId = String(hospVal);
        }
        if (!hospName && hospId && HOSPITAL_ID_TO_NAME.has(String(hospId))) {
            hospName = HOSPITAL_ID_TO_NAME.get(String(hospId));
        }
        if (!hospId && hospName && HOSPITAL_NAME_TO_ID.has(normName(hospName))) {
            hospId = HOSPITAL_NAME_TO_ID.get(normName(hospName));
        }
        if (!hospId && hospName) hospId = hospName;
        if (!hospName && hospId) hospName = hospId;

        if (hospId && hospName) {
            HOSPITAL_ID_TO_NAME.set(String(hospId), hospName);
            HOSPITAL_NAME_TO_ID.set(normName(hospName), String(hospId));
            if (!hospMap.has(String(hospId))) {
                hospMap.set(String(hospId), { value: String(hospId), label: hospName });
            }
        }

        // Practice field from Doctor_Hospital_Subform_Report
        const practiceVal = probe(rec, 'Add_Practice', ['Practice', 'Practice_Name', 'Practice_ID', 'Doctor_Hospital_Mapping']);
        let pId = extractLookupId(practiceVal);
        let pName = extractLookupName(practiceVal, ['Practice_Name', 'Name']);
        if (!pId && practiceVal && /^\d{10,}$/.test(String(practiceVal))) {
            pId = String(practiceVal);
        }
        if (pId && !pName && PRACTICE_ID_TO_NAME.has(String(pId))) {
            pName = PRACTICE_ID_TO_NAME.get(String(pId));
        }
        if (pName && !pId && PRACTICE_NAME_TO_ID.has(normName(pName))) {
            pId = PRACTICE_NAME_TO_ID.get(normName(pName));
        }
        if (!pId && pName) pId = pName;
        if (!pName && pId) pName = pId;

        if (pId && pName) {
            if (!PRACTICE_ID_TO_NAME.has(String(pId))) PRACTICE_ID_TO_NAME.set(String(pId), pName);
            if (!PRACTICE_NAME_TO_ID.has(normName(pName))) PRACTICE_NAME_TO_ID.set(normName(pName), String(pId));
        }

        const pKey = String(pId || '');
        const pNameKey = normName(pName || '');
        const dKey = String(docId || '');
        const dNameKey = normName(docName || '');
        const hKey = String(hospId || '');
        const hNameKey = normName(hospName || '');

        ALL_SUBFORM_ROWS.push({
            practiceId: pKey,
            practiceName: pName || '',
            doctorId: dKey,
            doctorName: docName || '',
            hospitalId: hKey,
            hospitalName: hospName || ''
        });

        // Add to mappings
        if (pKey) {
            // Practice -> Doctors
            if (dKey && docName) {
                if (!PRACTICE_TO_DOCTORS.has(pKey)) PRACTICE_TO_DOCTORS.set(pKey, new Map());
                PRACTICE_TO_DOCTORS.get(pKey).set(dKey, { value: dKey, label: docName });

                if (pNameKey) {
                    if (!PRACTICE_TO_DOCTORS.has(pNameKey)) PRACTICE_TO_DOCTORS.set(pNameKey, new Map());
                    PRACTICE_TO_DOCTORS.get(pNameKey).set(dKey, { value: dKey, label: docName });
                }
            }

            // Practice -> Hospitals
            if (hKey && hospName) {
                if (!PRACTICE_TO_HOSPITALS.has(pKey)) PRACTICE_TO_HOSPITALS.set(pKey, new Map());
                PRACTICE_TO_HOSPITALS.get(pKey).set(hKey, { value: hKey, label: hospName });

                if (pNameKey) {
                    if (!PRACTICE_TO_HOSPITALS.has(pNameKey)) PRACTICE_TO_HOSPITALS.set(pNameKey, new Map());
                    PRACTICE_TO_HOSPITALS.get(pNameKey).set(hKey, { value: hKey, label: hospName });
                }
            }

            // Practice + Doctor -> Hospitals
            if (dKey && hKey && hospName) {
                const pdKey = `${pKey}_${dKey}`;
                if (!PRACTICE_DOC_TO_HOSPITALS.has(pdKey)) PRACTICE_DOC_TO_HOSPITALS.set(pdKey, new Map());
                PRACTICE_DOC_TO_HOSPITALS.get(pdKey).set(hKey, { value: hKey, label: hospName });

                if (dNameKey) {
                    const pdNameKey = `${pKey}_${dNameKey}`;
                    if (!PRACTICE_DOC_TO_HOSPITALS.has(pdNameKey)) PRACTICE_DOC_TO_HOSPITALS.set(pdNameKey, new Map());
                    PRACTICE_DOC_TO_HOSPITALS.get(pdNameKey).set(hKey, { value: hKey, label: hospName });
                }
            }

            // Practice Pairs for matching
            if (!PRACTICE_DOC_HOSP_PAIRS.has(pKey)) PRACTICE_DOC_HOSP_PAIRS.set(pKey, new Set());
            const pairSet = PRACTICE_DOC_HOSP_PAIRS.get(pKey);
            if (dKey && hKey) pairSet.add(`${dKey}|${hKey}`);
            if (dNameKey && hNameKey) pairSet.add(`${dNameKey}|${hNameKey}`);
            if (dKey && hNameKey) pairSet.add(`${dKey}|${hNameKey}`);
            if (dNameKey && hKey) pairSet.add(`${dNameKey}|${hKey}`);
            if (dKey) pairSet.add(`doc:${dKey}`);
            if (dNameKey) pairSet.add(`doc:${dNameKey}`);
            if (hKey) pairSet.add(`hosp:${hKey}`);
            if (hNameKey) pairSet.add(`hosp:${hNameKey}`);

            if (pNameKey) {
                if (!PRACTICE_DOC_HOSP_PAIRS.has(pNameKey)) PRACTICE_DOC_HOSP_PAIRS.set(pNameKey, pairSet);
            }
        }

        // Doctor -> Hospitals
        if (dKey && hKey && hospName) {
            if (!DOCTOR_TO_HOSPITALS.has(dKey)) DOCTOR_TO_HOSPITALS.set(dKey, new Map());
            DOCTOR_TO_HOSPITALS.get(dKey).set(hKey, { value: hKey, label: hospName });

            if (dNameKey) {
                if (!DOCTOR_TO_HOSPITALS.has(dNameKey)) DOCTOR_TO_HOSPITALS.set(dNameKey, new Map());
                DOCTOR_TO_HOSPITALS.get(dNameKey).set(hKey, { value: hKey, label: hospName });
            }

            if (!DOCTOR_HOSPITAL_MAP.has(dKey)) DOCTOR_HOSPITAL_MAP.set(dKey, new Set());
            DOCTOR_HOSPITAL_MAP.get(dKey).add(hKey);
        }
    });

    if (docMap.size > 0) {
        ALL_DOCTOR_ITEMS = Array.from(docMap.values()).sort((a, b) => a.label.localeCompare(b.label));
    } else if (doctorsFallback.length > 0) {
        ALL_DOCTOR_ITEMS = doctorsFallback.map(doc => ({
            value: doc.ID || doc.id || '',
            label: doc.Doctor_Name || doc.Name || doc.Full_Name || doc.zc_display_value || doc.ID || ''
        })).filter(i => i.value);
    }

    if (hospMap.size > 0) {
        ALL_HOSPITAL_ITEMS = Array.from(hospMap.values()).sort((a, b) => a.label.localeCompare(b.label));
    } else if (hospitalsFallback.length > 0) {
        ALL_HOSPITAL_ITEMS = hospitalsFallback.map(h => ({
            value: h.ID || h.id || '',
            label: h.Hospital_Name || h.Name || h.zc_display_value || h.ID || ''
        })).filter(i => i.value);
    }

    ALL_PRACTICE_ITEMS = Array.from(PRACTICE_ID_TO_NAME.entries()).map(([id, name]) => ({
        value: id,
        label: name
    })).sort((a, b) => a.label.localeCompare(b.label));

    _isUpdatingDropdowns = true;
    try {
        populateSSDropdown('ss-practice', ALL_PRACTICE_ITEMS, 'All Practices');
        populateSSDropdown('ss-doctor', ALL_DOCTOR_ITEMS, 'All Doctors');
        populateSSDropdown('ss-location', ALL_HOSPITAL_ITEMS, 'All Locations');
    } finally {
        _isUpdatingDropdowns = false;
    }
}


/* ─────────────────────────────────────────────────────────────────────
   PRACTICE & USER FILTER HELPERS
   ───────────────────────────────────────────────────────────────────── */
function lockPracticeSelect() {
    const ssPractice = document.getElementById('ss-practice');
    if (!ssPractice) return;
    ssPractice.classList.add('disabled');
    ssPractice.setAttribute('title', 'Locked to your practice');
    const trigger = ssPractice.querySelector('.ss-trigger');
    if (trigger) {
        trigger.setAttribute('tabindex', '-1');
    }
}

function unlockPracticeSelect() {
    const ssPractice = document.getElementById('ss-practice');
    if (!ssPractice) return;
    ssPractice.classList.remove('disabled');
    ssPractice.removeAttribute('title');
    const trigger = ssPractice.querySelector('.ss-trigger');
    if (trigger) {
        trigger.setAttribute('tabindex', '0');
    }
}

function getPracticeDoctors(pId, pName) {
    const docMap = new Map();
    const pIdStr = pId ? String(pId).trim() : '';
    const pNorm = pName ? normName(pName) : '';

    if (pIdStr && PRACTICE_TO_DOCTORS.has(pIdStr)) {
        PRACTICE_TO_DOCTORS.get(pIdStr).forEach((v, k) => docMap.set(k, v));
    }
    if (pNorm && PRACTICE_TO_DOCTORS.has(pNorm)) {
        PRACTICE_TO_DOCTORS.get(pNorm).forEach((v, k) => docMap.set(k, v));
    }
    if (ALL_SUBFORM_ROWS && ALL_SUBFORM_ROWS.length) {
        ALL_SUBFORM_ROWS.forEach(s => {
            const pMatch = (pIdStr && s.practiceId && String(s.practiceId) === pIdStr) ||
                           (pNorm && s.practiceName && normName(s.practiceName) === pNorm) ||
                           (pName && s.practiceName && isNameMatch(s.practiceName, pName));
            if (pMatch && s.doctorId && s.doctorName) {
                if (!docMap.has(String(s.doctorId))) {
                    docMap.set(String(s.doctorId), { value: String(s.doctorId), label: s.doctorName });
                }
            }
        });
    }
    return Array.from(docMap.values()).sort((a, b) => a.label.localeCompare(b.label));
}

function getPracticeHospitals(pId, pName) {
    const hospMap = new Map();
    const pIdStr = pId ? String(pId).trim() : '';
    const pNorm = pName ? normName(pName) : '';

    if (pIdStr && PRACTICE_TO_HOSPITALS.has(pIdStr)) {
        PRACTICE_TO_HOSPITALS.get(pIdStr).forEach((v, k) => hospMap.set(k, v));
    }
    if (pNorm && PRACTICE_TO_HOSPITALS.has(pNorm)) {
        PRACTICE_TO_HOSPITALS.get(pNorm).forEach((v, k) => hospMap.set(k, v));
    }
    if (ALL_SUBFORM_ROWS && ALL_SUBFORM_ROWS.length) {
        ALL_SUBFORM_ROWS.forEach(s => {
            const pMatch = (pIdStr && s.practiceId && String(s.practiceId) === pIdStr) ||
                           (pNorm && s.practiceName && normName(s.practiceName) === pNorm) ||
                           (pName && s.practiceName && isNameMatch(s.practiceName, pName));
            if (pMatch && s.hospitalId && s.hospitalName) {
                if (!hospMap.has(String(s.hospitalId))) {
                    hospMap.set(String(s.hospitalId), { value: String(s.hospitalId), label: s.hospitalName });
                }
            }
        });
    }
    return Array.from(hospMap.values()).sort((a, b) => a.label.localeCompare(b.label));
}

function claimMatchesPractice(r, pId, pName) {
    if (!pId && !pName) return true;
    const pIdStr = pId ? String(pId).trim() : '';
    const pNorm = pName ? normName(pName) : '';

    if (pIdStr && r.practiceId && String(r.practiceId).trim() === pIdStr) return true;
    if (pNorm && r.practiceName && normName(r.practiceName) === pNorm) return true;
    if (pName && r.practiceName && isNameMatch(r.practiceName, pName)) return true;

    if (ALL_SUBFORM_ROWS && ALL_SUBFORM_ROWS.length) {
        return ALL_SUBFORM_ROWS.some(s => {
            const pMatch = (pIdStr && s.practiceId && String(s.practiceId).trim() === pIdStr) ||
                           (pNorm && s.practiceName && normName(s.practiceName) === pNorm) ||
                           (pName && s.practiceName && isNameMatch(pName, s.practiceName));
            if (!pMatch) return false;

            const docMatch = (r.doctorId && s.doctorId && String(r.doctorId) === String(s.doctorId)) ||
                             (r.doctor && s.doctorName && isNameMatch(r.doctor, s.doctorName));
            const hospMatch = (r.hospitalId && s.hospitalId && String(r.hospitalId) === String(s.hospitalId)) ||
                              (r.hospital && s.hospitalName && isNameMatch(r.hospital, s.hospitalName));

            if (r.doctor && r.doctor !== '—' && r.hospital && r.hospital !== '—') {
                return docMatch && hospMatch;
            } else if (r.doctor && r.doctor !== '—') {
                return docMatch;
            } else if (r.hospital && r.hospital !== '—') {
                return hospMatch;
            }
            return false;
        });
    }
    return false;
}

function populateDoctorDropdownFromClaims(rows) {
    const seen = new Map();
    rows.forEach(r => {
        if (r.doctorId && r.doctor && !seen.has(r.doctorId))
            seen.set(r.doctorId, r.doctor);
    });
    ALL_DOCTOR_ITEMS = [];
    seen.forEach((name, id) => ALL_DOCTOR_ITEMS.push({ value: id, label: name }));
    ALL_DOCTOR_ITEMS.sort((a, b) => a.label.localeCompare(b.label));
    populateSSDropdown('ss-doctor', ALL_DOCTOR_ITEMS, 'All Doctors');
}

function populateDoctorDropdown(doctors) {
    const items = doctors.map(doc => ({
        value: doc.ID || doc.id || '',
        label: doc.Doctor_Name || doc.Name || doc.Full_Name
            || doc.name || doc.zc_display_value || doc.ID || ''
    })).filter(i => i.value);
    populateSSDropdown('ss-doctor', items, 'All Doctors');
}

function buildDoctorHospitalMap(mapRecs) {
    DOCTOR_HOSPITAL_MAP = new Map();
    mapRecs.forEach(rec => {
        if (rec.Status && String(rec.Status).toLowerCase() !== 'active') return;
        const docVal = probe(rec, 'Doctor_Name', ['Doctor', 'Doctor_Details', 'Doctors']);
        const hospVal = probe(rec, 'Hospital_Name', ['Hospital', 'Hospital_Details', 'Hospitals']);
        const docId = extractLookupId(docVal);
        const hospId = extractLookupId(hospVal);
        if (!docId || !hospId) return;
        if (!DOCTOR_HOSPITAL_MAP.has(docId)) DOCTOR_HOSPITAL_MAP.set(docId, new Set());
        DOCTOR_HOSPITAL_MAP.get(docId).add(hospId);
    });
}

function populateHospitalDropdownDirect(hosps) {
    ALL_HOSPITAL_ITEMS = hosps.map(h => ({
        value: h.ID || h.id || '',
        label: h.Hospital_Name || h.Name || h.name || h.zc_display_value || h.ID || ''
    })).filter(i => i.value);
    populateSSDropdown('ss-location', ALL_HOSPITAL_ITEMS, 'All Locations');
}

function populateHospitalDropdown(rows) {
    const seen = new Map();
    rows.forEach(r => {
        if (r.hospitalId && r.hospital && !seen.has(r.hospitalId))
            seen.set(r.hospitalId, r.hospital);
    });
    ALL_HOSPITAL_ITEMS = [];
    seen.forEach((name, id) => ALL_HOSPITAL_ITEMS.push({ value: id, label: name }));
    populateSSDropdown('ss-location', ALL_HOSPITAL_ITEMS, 'All Locations');
}

function populateStaffDropdown(rows) {
    const seen = new Set();
    rows.forEach(r => { if (r.staff) seen.add(r.staff); });
    const items = Array.from(seen).sort().map(name => ({ value: name, label: name }));
    populateSSDropdown('ss-staff', items, 'All Staff');
}

function normName(s) {
    return String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
}

function cleanHospital(s) {
    return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function matchesSubformDoctorHospital(r) {
    if (!ALL_SUBFORM_ROWS || !ALL_SUBFORM_ROWS.length) return true;

    const dId = r.doctorId ? String(r.doctorId) : '';
    const hId = r.hospitalId ? String(r.hospitalId) : '';
    const dName = r.doctor && r.doctor !== '—' ? r.doctor : '';
    const hName = r.hospital && r.hospital !== '—' ? r.hospital : '';

    for (const s of ALL_SUBFORM_ROWS) {
        const docMatch = (dId && s.doctorId && dId === s.doctorId) ||
                         (dName && s.doctorName && isNameMatch(dName, s.doctorName));
        const hospMatch = (hId && s.hospitalId && hId === s.hospitalId) ||
                          (hName && s.hospitalName && isNameMatch(hName, s.hospitalName));

        if (dName && hName) {
            if (docMatch && hospMatch) return true;
        } else if (dName && !hName) {
            if (docMatch) return true;
        } else if (!dName && hName) {
            if (hospMatch) return true;
        }
    }

    return false;
}

function cleanPerson(s) {
    return String(s || '').toLowerCase()
        .replace(/^dr\.?\s+|^prof\.?\s+|^mr\.?\s+|^ms\.?\s+|^mrs\.?\s+/i, '')
        .replace(/[^a-z0-9]/g, '');
}

function isNameMatch(a, b) {
    if (!a || !b) return false;
    const na = normName(a);
    const nb = normName(b);
    if (na === nb) return true;
    const ca = na.replace(/[^a-z0-9]/g, '');
    const cb = nb.replace(/[^a-z0-9]/g, '');
    if (ca === cb && ca.length > 0) return true;
    const pa = cleanPerson(a);
    const pb = cleanPerson(b);
    if (pa && pb && pa === pb) return true;
    if (ca && cb && (ca.includes(cb) || cb.includes(ca))) return true;
    return false;
}


function populatePatientDropdownDirect(patients) {
    PATIENT_ID_TO_NAME = new Map();
    const items = [];
    patients.forEach(p => {
        const id = p.ID || p.id || '';
        const rawName = p.Patient_Name || p.Name || p.Full_Name || p.name || p.zc_display_value;
        let name = (typeof rawName === 'object')
            ? extractLookupName(rawName, ['Patient_Name', 'Name'])
            : String(rawName || '').replace(/\s+/g, ' ').trim();
        if (!name || name === '[object Object]') name = extractLookupName(p, ['Patient_Name', 'Name']);
        if (!id || !name) return;
        PATIENT_ID_TO_NAME.set(String(id), name);
        items.push({ value: String(id), label: name });
    });
    items.sort((a, b) => a.label.localeCompare(b.label));
    populateSSDropdown('ss-patient', items, 'All Patients');
}

function populatePatientDropdownFromClaims(rows) {
    const seen = new Map();
    rows.forEach(r => {
        const key = r.patientId || normName(r.patientName);
        if (key && r.patientName && !seen.has(key)) seen.set(key, r.patientName);
    });
    PATIENT_ID_TO_NAME = new Map(seen);
    const items = Array.from(seen, ([value, label]) => ({ value, label }))
        .sort((a, b) => a.label.localeCompare(b.label));
    populateSSDropdown('ss-patient', items, 'All Patients');
}

/* ─────────────────────────────────────────────────────────────────────
   FIELD MAPPING
   ───────────────────────────────────────────────────────────────────── */
const CLAIM_FIELDS = {
    claimId: 'Claim_ID',
    hospitalLookup: 'Hospital',
    doctorLookup: 'Doctor',
    patientName: 'Patient_Name',
    adjustmentType: 'Adjustment_Types',
    adjustmentDate: 'Claim_Date',
    adjustmentAmount: 'Adjustment_Amount',
    notes: 'Notes',
    staff: 'Staff_Name',
    lines: 'Claim_Lines'
};
const LINE_FIELDS = {
    itemNumber: 'Item',
    originalAmount: 'Amount_Charged',
    adjustmentAmount: 'Allocated_Amount'
};


/* ─────────────────────────────────────────────────────────────────────
   LOOKUP EXTRACTORS
   ───────────────────────────────────────────────────────────────────── */
function extractLookupId(val) {
    if (val == null) return '';
    if (typeof val === 'object') {
        const id = val.ID || val.id;
        if (id != null && String(id).trim() !== '') return String(id).trim();
        if (val.zc_display_value && /^\d{10,}$/.test(String(val.zc_display_value).trim())) {
            return String(val.zc_display_value).trim();
        }
        return '';
    }
    const s = String(val).trim();
    return /^\d{10,}$/.test(s) ? s : '';
}

function extractLookupName(val, candidates = []) {
    if (val == null) return '';
    if (typeof val === 'string') {
        if (val.trim() === '[object Object]') return '';
        return /^\d{10,}$/.test(val) ? '' : val;
    }
    if (typeof val === 'object') {
        if (val.display_value && typeof val.display_value === 'string' && val.display_value.trim() !== '[object Object]') {
            const trimmed = val.display_value.replace(/\s+/g, ' ').trim();
            if (trimmed) return trimmed;
        }
        if (val.zc_display_value && val.zc_display_value.trim() !== '[object Object]') {
            const trimmed = val.zc_display_value.replace(/\s+/g, ' ').trim();
            if (trimmed) return trimmed;
        }

        for (const f of candidates) {
            if (val[f] && typeof val[f] === 'string' && val[f].trim() !== '[object Object]') return val[f];
        }

        const keys = Object.keys(val);
        const prefixKey = keys.find(k => k.endsWith('.prefix'));
        const firstKey = keys.find(k => k.endsWith('.first_name'));
        const lastKey = keys.find(k => k.endsWith('.last_name'));
        const suffixKey = keys.find(k => k.endsWith('.suffix'));
        if (firstKey || lastKey) {
            const parts = [
                prefixKey && val[prefixKey],
                firstKey && val[firstKey],
                lastKey && val[lastKey],
                suffixKey && val[suffixKey]
            ].filter(Boolean);
            if (parts.length) return parts.join(' ').trim();
        }

        for (const v of Object.values(val)) {
            if (typeof v === 'string' && v.trim() && v.trim() !== '[object Object]' && !/^\d{10,}$/.test(v)) return v;
        }
    }
    return '';
}


/* ─────────────────────────────────────────────────────────────────────
   DATE PARSER / FORMATTER
   ───────────────────────────────────────────────────────────────────── */
function parseZohoDate(d) {
    if (!d) return '';
    const s = String(d).trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const MONTHS = {
        Jan: '01', Feb: '02', Mar: '03', Apr: '04', May: '05', Jun: '06',
        Jul: '07', Aug: '08', Sep: '09', Oct: '10', Nov: '11', Dec: '12'
    };
    const m = s.match(/^(\d{2})-(\w{3})-(\d{4})/);
    if (m && MONTHS[m[2]]) return `${m[3]}-${MONTHS[m[2]]}-${m[1]}`;
    const dt = new Date(s);
    return isNaN(dt.getTime()) ? '' : dt.toISOString().slice(0, 10);
}

function formatDateDisplay(iso) {
    if (!iso) return '—';
    const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return iso;
    return `${m[3]}-${MONTHS[parseInt(m[2], 10) - 1]}-${m[1]}`;
}


/* ─────────────────────────────────────────────────────────────────────
   AMOUNT PARSER
   ───────────────────────────────────────────────────────────────────── */
function parseAmount(val) {
    if (val == null || val === '') return 0;
    if (typeof val === 'number') return val;
    const cleaned = String(val).replace(/[^0-9.\-]/g, '');
    return parseFloat(cleaned) || 0;
}

/* ─────────────────────────────────────────────────────────────────────
   GRAND TOTALS
   ───────────────────────────────────────────────────────────────────── */
function computeGrandTotals(data) {
    let adjAmountTotal = 0;
    let originalAmountTotal = 0;
    let allocatedAmountTotal = 0;
    let lineCount = 0;

    data.forEach(claim => {
        adjAmountTotal += claim.adjAmount || 0;
        claim.lines.forEach(line => {
            originalAmountTotal += line.originalAmount || 0;
            allocatedAmountTotal += line.adjustmentAmount || 0;
            lineCount++;
        });
    });

    return { claimCount: data.length, lineCount, adjAmountTotal, originalAmountTotal, allocatedAmountTotal };
}

function computeGrandSummaryCard(data) {
    const hospitalSet = new Set();
    const patientSet = new Set();
    let adjAmountTotal = 0;
    let originalAmountTotal = 0;
    let allocatedAmountTotal = 0;

    data.forEach(claim => {
        const hospKey = claim.hospitalId || (claim.hospital || '').trim().toLowerCase();
        if (hospKey) hospitalSet.add(hospKey);

        const patKey = (claim.patientName || '').trim().toLowerCase();
        if (patKey) patientSet.add(patKey);

        adjAmountTotal += claim.adjAmount || 0;

        claim.lines.forEach(line => {
            originalAmountTotal += line.originalAmount || 0;
            allocatedAmountTotal += line.adjustmentAmount || 0;
        });
    });

    return {
        hospitals: hospitalSet.size,
        patients: patientSet.size,
        claims: data.length,
        adjAmountTotal,
        originalAmountTotal,
        allocatedAmountTotal
    };
}

function renderGrandSummaryCard(data) {
    const s = computeGrandSummaryCard(data);
    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    };
    const fmt = v => (v < 0 ? '- $' : '$') + Math.abs(v).toFixed(2);

    setText('gs-hospitals', s.hospitals);
    setText('gs-patients', s.patients);
    setText('gs-claims', s.claims);
    setText('gs-adj-amount', fmt(s.adjAmountTotal));
    setText('gs-original-amount', '$' + s.originalAmountTotal.toFixed(2));
    setText('gs-allocated-amount', fmt(s.allocatedAmountTotal));
}

/* ─────────────────────────────────────────────────────────────────────
   STATE
   ───────────────────────────────────────────────────────────────────── */
let allData = [];
let LOGGED_IN_PRACTICE = null;
let CURRENT_USER_EMAIL = '';
let DOCTOR_HOSPITAL_MAP = new Map();
let ALL_HOSPITAL_ITEMS = [];
let ALL_DOCTOR_ITEMS = [];
let ALL_PRACTICE_ITEMS = [];
let ALL_SUBFORM_ROWS = [];

let PRACTICE_ID_TO_NAME = new Map();
let PRACTICE_NAME_TO_ID = new Map();
let DOCTOR_ID_TO_NAME = new Map();
let DOCTOR_NAME_TO_ID = new Map();
let HOSPITAL_ID_TO_NAME = new Map();
let HOSPITAL_NAME_TO_ID = new Map();

let PRACTICE_TO_DOCTORS = new Map();
let PRACTICE_TO_HOSPITALS = new Map();
let PRACTICE_DOC_TO_HOSPITALS = new Map();
let DOCTOR_TO_HOSPITALS = new Map();
let PRACTICE_DOC_HOSP_PAIRS = new Map();
let _isUpdatingDropdowns = false;

let PATIENT_ID_TO_NAME = new Map();
let filtered = [];
let currentPage = 1;
let perPage = 10;
let sortKey = 'claimId';
let sortDir = 'asc';
let searchQ = '';

let ADJ_TYPES = [];


/* ─────────────────────────────────────────────────────────────────────
   ADJUSTMENT TYPES
   ───────────────────────────────────────────────────────────────────── */
function extractAdjTypeRecord(rec, idx) {
    const name = rec.Adjustment_Type_Name || rec.Name || rec.Type_Name
        || rec.name || rec.zc_display_value || '';
    const codeRaw = rec.Code != null ? rec.Code
        : (rec.Type_Code != null ? rec.Type_Code : rec.code);
    let code = parseInt(codeRaw, 10);
    if (isNaN(code)) code = idx + 1;
    const badge = rec.Badge_Class || rec.Badge || rec.Color_Class || 'badge-other';
    return { code, name: String(name).trim().toUpperCase(), badge };
}

function resolveAdjType(raw) {
    const values = normalizeToStringArray(raw);
    if (!values.length) return { name: '—', badge: 'badge-other' };

    const resolvedNames = values.map(v => {
        const upper = v.toUpperCase();
        const asNum = parseInt(v, 10);
        if (!isNaN(asNum) && String(asNum) === v) {
            const byCode = ADJ_TYPES.find(t => t.code === asNum);
            if (byCode) return byCode.name;
        }
        const exact = ADJ_TYPES.find(t => t.name === upper);
        if (exact) return exact.name;
        const partial = ADJ_TYPES.find(t => upper.includes(t.name) || t.name.includes(upper));
        if (partial) return partial.name;
        return upper;
    });

    const uniqueNames = [...new Set(resolvedNames)];
    const firstMatch = ADJ_TYPES.find(t => t.name === uniqueNames[0]);
    return { name: uniqueNames.join(', '), badge: firstMatch ? firstMatch.badge : 'badge-other' };
}

function normalizeToStringArray(raw) {
    if (raw == null || raw === '') return [];
    if (Array.isArray(raw)) return raw.flatMap(normalizeToStringArray);
    if (typeof raw === 'object') {
        const val = raw.display_value || raw.zc_display_value || raw.name || raw.Name || '';
        return normalizeToStringArray(val);
    }
    return String(raw)
        .split(/[,;\n]+/)
        .map(s => s.trim())
        .filter(Boolean);
}


/* ─────────────────────────────────────────────────────────────────────
   FIELD PROBE
   ───────────────────────────────────────────────────────────────────── */
function probe(rec, primaryKey, alternatives = []) {
    if (rec[primaryKey] != null && rec[primaryKey] !== '') return rec[primaryKey];
    for (const k of alternatives) {
        if (rec[k] != null && rec[k] !== '') return rec[k];
    }
    return null;
}

function extractSubformLines(rec) {
    const raw = rec[CLAIM_FIELDS.lines];
    return Array.isArray(raw) ? raw : [];
}

/* ─────────────────────────────────────────────────────────────────────
   ITEM NUMBER RESOLVER
   ───────────────────────────────────────────────────────────────────── */
function extractItemNumber(raw) {
    if (raw == null || raw === '') return '—';

    const isDateLike = (v) => /\d{1,2}[-/]\w{3}[-/]\d{2,4}|\d{4}-\d{2}-\d{2}/.test(v);
    const isRecordIdLike = (v) => /^\d{10,}$/.test(v);

    if (typeof raw === 'string' || typeof raw === 'number') {
        const s = String(raw).trim();
        if (!s) return '—';
        if (isDateLike(s) || isRecordIdLike(s)) return '—';
        return s;
    }

    if (typeof raw === 'object') {
        const candidates = ['Item', 'Item_Number', 'Item_Code', 'Code', 'Number', 'Name'];
        for (const f of candidates) {
            const v = raw[f];
            if (typeof v === 'string' && v.trim()) {
                const trimmed = v.trim();
                if (!isDateLike(trimmed) && !isRecordIdLike(trimmed)) return trimmed;
            }
        }

        for (const f of ['zc_display_value', 'display_value']) {
            const v = raw[f];
            if (typeof v === 'string' && v.trim()) {
                const trimmed = v.trim();
                if (!isDateLike(trimmed) && !isRecordIdLike(trimmed)) return trimmed;
            }
        }

        for (const key of Object.keys(raw)) {
            if (/item/i.test(key) && !/id$/i.test(key)) {
                const v = raw[key];
                if (v != null && (typeof v === 'string' || typeof v === 'number')) {
                    const trimmed = String(v).trim();
                    if (trimmed && !isDateLike(trimmed) && !isRecordIdLike(trimmed)) return trimmed;
                }
            }
        }

        const excludeKeys = /^(id|added_time|modified_time|added_user|modified_user|zc_display_value|display_value)$/i;
        for (const key of Object.keys(raw)) {
            if (excludeKeys.test(key)) continue;
            const v = raw[key];
            if (typeof v === 'string') {
                const trimmed = v.trim();
                if (trimmed && trimmed.length <= 20 && !isDateLike(trimmed) && !isRecordIdLike(trimmed)) {
                    return trimmed;
                }
            }
        }

        if (raw.Item || raw.id) return String(raw.Item || raw.id);
    }

    return '—';
}

function resolveItemNumber(raw) {
    if (raw == null || raw === '') return '—';

    if (typeof raw === 'object') {
        const id = extractLookupId(raw);
        if (id && ITEM_ID_TO_NUMBER_MAP.has(id)) return ITEM_ID_TO_NUMBER_MAP.get(id);
        const textFallback = extractItemNumber(raw);
        if (textFallback !== '—') return textFallback;
        return '—';
    }

    const s = String(raw).trim();
    if (/^\d{10,}$/.test(s)) {
        if (ITEM_ID_TO_NUMBER_MAP.has(s)) return ITEM_ID_TO_NUMBER_MAP.get(s);
        return '—';
    }

    return extractItemNumber(raw);
}

/* ─────────────────────────────────────────────────────────────────────
   SUBFORM LINE ROW BUILDER
   ───────────────────────────────────────────────────────────────────── */
function buildLineRow(lineRec) {
    const itemNoRaw = probe(lineRec, LINE_FIELDS.itemNumber,
        ['Item', 'Items', 'Item_Name', 'Item_Details', 'Line_Item_Number', 'SNO', 'S_No', 'Sl_No']);
    const origRaw = probe(lineRec, LINE_FIELDS.originalAmount, ['Charged_Amount']);
    const adjRaw = probe(lineRec, LINE_FIELDS.adjustmentAmount, ['Adj_Amount']);

    const itemNumber = resolveItemNumber(itemNoRaw);
    const hasStructuredData = [itemNoRaw, origRaw, adjRaw].some(v => v != null && v !== '');

    if (hasStructuredData) {
        return {
            itemNumber: itemNumber,
            originalAmount: parseAmount(origRaw),
            adjustmentAmount: parseAmount(adjRaw),
            originalAmountRaw: (origRaw != null && origRaw !== '') ? String(origRaw) : '',
            adjustmentAmountRaw: (adjRaw != null && adjRaw !== '') ? String(adjRaw) : ''
        };
    }

    const dv = (lineRec && (lineRec.display_value || lineRec.zc_display_value)) || '';
    if (dv) {
        const itemMatch = dv.match(/^(\S+)/);
        const numberMatches = dv.match(/-?[\d,]+\.\d{2}/g) || [];

        const original = numberMatches.length > 1 ? numberMatches[1] : '';
        const adjustment = numberMatches.length > 2 ? numberMatches[numberMatches.length - 1] : '';

        const rawItemToken = itemMatch ? itemMatch[1] : '';
        const looksLikeDate = /\d{1,2}[-/]\w{3}[-/]\d{2,4}|\d{4}-\d{2}-\d{2}/.test(rawItemToken);

        return {
            itemNumber: looksLikeDate ? '—' : resolveItemNumber(rawItemToken),
            originalAmount: parseAmount(original),
            adjustmentAmount: parseAmount(adjustment),
            originalAmountRaw: original,
            adjustmentAmountRaw: adjustment
        };
    }

    return { itemNumber: '—', originalAmount: 0, adjustmentAmount: 0, originalAmountRaw: '', adjustmentAmountRaw: '' };
}

/* ─────────────────────────────────────────────────────────────────────
   ROW BUILDER
   ───────────────────────────────────────────────────────────────────── */
function buildClaimsData(invoices) {
    return (invoices || []).map(rec => {
        const hospitalVal = probe(rec, CLAIM_FIELDS.hospitalLookup,
            ['Hospital_Name', 'Hospital_Details', 'Hospitals']);
        const doctorVal = probe(rec, CLAIM_FIELDS.doctorLookup,
            ['Doctor_Name', 'Doctor_Details', 'Doctors']);
        const practiceVal = probe(rec, 'Practice',
            ['Add_Practice', 'Practice_Name', 'Practice_ID', 'Practice_Details', 'practice']);
        const patientVal = probe(rec, 'Patient', ['Patient_Name', 'patient_name', 'PatientName', 'Name']);
        const typeRaw = probe(rec, CLAIM_FIELDS.adjustmentType,
            ['Adj_Type', 'AdjustmentType', 'Type', 'Adjustment_Types']);
        const dateRaw = probe(rec, CLAIM_FIELDS.adjustmentDate,
            ['Date', 'Adj_Date', 'AdjustmentDate']);
        const claimIdRaw = probe(rec, CLAIM_FIELDS.claimId,
            ['ClaimID', 'Claim_Number', 'Claim_No']);
        const notesRaw = probe(rec, CLAIM_FIELDS.notes,
            ['Note', 'Comments', 'Remarks']);
        const staffVal = probe(rec, CLAIM_FIELDS.staff,
            ['Adjusted_By', 'Staff', 'Adjusted_Staff', 'User']);
        const adjAmountRaw = probe(rec, CLAIM_FIELDS.adjustmentAmount,
            ['Adj_Amount', 'Allocated_Amount', 'Total_Adjustment_Amount']);

        const adjMeta = resolveAdjType(typeRaw);

        const rawLines = extractSubformLines(rec);
        const lines = rawLines.length
            ? rawLines.map(buildLineRow)
            : [{ itemNumber: '—', originalAmount: 0, adjustmentAmount: 0, originalAmountRaw: '', adjustmentAmountRaw: '' }];

        let docId = extractLookupId(doctorVal);
        let docName = extractLookupName(doctorVal, ['Doctor_Name', 'Name', 'Doctor']);
        if (!docName && docId && DOCTOR_ID_TO_NAME.has(docId)) docName = DOCTOR_ID_TO_NAME.get(docId);
        if (!docId && docName && DOCTOR_NAME_TO_ID.has(normName(docName))) docId = DOCTOR_NAME_TO_ID.get(normName(docName));

        let hospId = extractLookupId(hospitalVal);
        let hospName = extractLookupName(hospitalVal, ['Hospital_Name', 'Name', 'Hospital']);
        if (!hospName && hospId && HOSPITAL_ID_TO_NAME.has(hospId)) hospName = HOSPITAL_ID_TO_NAME.get(hospId);
        if (!hospId && hospName && HOSPITAL_NAME_TO_ID.has(normName(hospName))) hospId = HOSPITAL_NAME_TO_ID.get(normName(hospName));

        let pId = extractLookupId(practiceVal);
        let pName = extractLookupName(practiceVal, ['Practice_Name', 'Name']);
        if (!pName && pId && PRACTICE_ID_TO_NAME.has(pId)) pName = PRACTICE_ID_TO_NAME.get(pId);
        if (!pId && pName && PRACTICE_NAME_TO_ID.has(normName(pName))) pId = PRACTICE_NAME_TO_ID.get(normName(pName));

        // Fallback: match practice via doctor and hospital in ALL_SUBFORM_ROWS
        if (!pId && !pName && ALL_SUBFORM_ROWS && ALL_SUBFORM_ROWS.length) {
            const subRow = ALL_SUBFORM_ROWS.find(s => {
                const docMatch = (docId && s.doctorId && String(docId) === String(s.doctorId)) ||
                                 (docName && s.doctorName && isNameMatch(docName, s.doctorName));
                const hospMatch = (hospId && s.hospitalId && String(hospId) === String(s.hospitalId)) ||
                                  (hospName && s.hospitalName && isNameMatch(hospName, s.hospitalName));
                if (docName && hospName) return docMatch && hospMatch;
                if (docName) return docMatch;
                return false;
            });
            if (subRow) {
                pId = subRow.practiceId;
                pName = subRow.practiceName;
            }
        }

        if (LOGGED_IN_PRACTICE) {
            if (!pId) pId = LOGGED_IN_PRACTICE.id;
            if (!pName) pName = LOGGED_IN_PRACTICE.name;
        }

        return {
            id: rec.ID || '',
            claimId: claimIdRaw || rec.ID || '',
            hospitalId: hospId,
            hospital: hospName || '—',
            doctorId: docId,
            doctor: docName || '—',
            practiceId: pId,
            practiceName: pName,
            patientId: extractLookupId(patientVal),
            patientName: typeof patientVal === 'string'
                ? (patientVal.trim() === '[object Object]' ? '' : patientVal)
                : extractLookupName(patientVal, ['Name']),
            type: adjMeta.name,
            typeBadge: adjMeta.badge,
            date: parseZohoDate(dateRaw),
            adjAmount: parseAmount(adjAmountRaw),
            notes: typeof notesRaw === 'string' ? notesRaw : (notesRaw ? String(notesRaw) : ''),
            staff: typeof staffVal === 'string' ? staffVal : extractLookupName(staffVal, ['Staff_Name', 'Name']),
            lines: lines
        };
    });
}


/* ─────────────────────────────────────────────────────────────────────
   ADJ-TYPE DROPDOWN
   ───────────────────────────────────────────────────────────────────── */
function buildAdjOptions() {
    const items = ADJ_TYPES.map(t => ({ value: t.name, label: t.name }));
    if (typeof populateSSDropdown === 'function') {
        populateSSDropdown('ss-adj-type', items, 'All Types');
    }
}


/* ─────────────────────────────────────────────────────────────────────
   FILTERS
   ───────────────────────────────────────────────────────────────────── */
function applyFilters() {
    if (!LOGGED_IN_PRACTICE) {
        filtered = [];
        currentPage = 1;
        renderTable();
        resetTableScroll();
        return;
    }
    const practiceEl = document.getElementById('f-practice');
    const hospEl = document.getElementById('f-location');
    const docEl = document.getElementById('f-doctor');
    const adjEl = document.getElementById('f-adj-type');
    const staffEl = document.getElementById('f-staff');
    const fromEl = document.getElementById('filter-from');
    const toEl = document.getElementById('filter-to');
    const patEl = document.getElementById('f-patient');

    const practice = practiceEl ? practiceEl.value : '';
    const hosp = hospEl ? hospEl.value : '';
    const doc = docEl ? docEl.value : '';
    const pat = patEl ? patEl.value : '';
    const patName = pat ? normName(PATIENT_ID_TO_NAME.get(pat)) : '';
    const adjType = adjEl ? adjEl.value : '';
    const staff = staffEl ? staffEl.value : '';
    const from = fromEl ? parseZohoDate(fromEl.value) || fromEl.value : '';
    const to = toEl ? parseZohoDate(toEl.value) || toEl.value : '';

    const docLabelEl = document.querySelector('#ss-doctor .ss-label');
    const docLabel = (docLabelEl && docLabelEl.textContent.trim() !== 'All Doctors') ? docLabelEl.textContent.trim() : '';
    const activeDoc = doc || docLabel;
    const activeDocName = (doc && DOCTOR_ID_TO_NAME.get(String(doc))) || docLabel;

    const hospLabelEl = document.querySelector('#ss-location .ss-label');
    const hospLabel = (hospLabelEl && hospLabelEl.textContent.trim() !== 'All Locations') ? hospLabelEl.textContent.trim() : '';
    const activeHosp = hosp || hospLabel;
    const activeHospName = (hosp && HOSPITAL_ID_TO_NAME.get(String(hosp))) || hospLabel;

    const practiceLabelEl = document.querySelector('#ss-practice .ss-label');
    const practiceLabel = (practiceLabelEl && practiceLabelEl.textContent.trim() !== 'All Practices') ? practiceLabelEl.textContent.trim() : '';
    const activePractice = practice || practiceLabel || (LOGGED_IN_PRACTICE ? LOGGED_IN_PRACTICE.name : '');
    const activePracticeName = (practice && PRACTICE_ID_TO_NAME.get(String(practice))) || practiceLabel || (LOGGED_IN_PRACTICE ? LOGGED_IN_PRACTICE.name : '');

    filtered = allData.filter(r => {
        // 1. Practice filter
        if (activePractice) {
            if (!claimMatchesPractice(r, practice, activePracticeName)) {
                return false;
            }
        }

        // 2. Doctor filter (applies normally and with practice)
        if (activeDoc) {
            const idMatch = (doc && r.doctorId && String(r.doctorId) === String(doc)) ||
                            (r.doctorId && String(r.doctorId) === String(activeDoc));
            const nameMatch = (r.doctor && activeDocName && isNameMatch(r.doctor, activeDocName)) ||
                              (r.doctor && isNameMatch(r.doctor, activeDoc));
            if (!idMatch && !nameMatch) return false;
        }

        // 3. Hospital filter (applies normally and with practice)
        if (activeHosp) {
            const idMatch = (hosp && r.hospitalId && String(r.hospitalId) === String(hosp)) ||
                            (r.hospitalId && String(r.hospitalId) === String(activeHosp));
            const nameMatch = (r.hospital && activeHospName && isNameMatch(r.hospital, activeHospName)) ||
                              (r.hospital && isNameMatch(r.hospital, activeHosp));
            if (!idMatch && !nameMatch) return false;
        }

        // 4. Adjustment Type filter
        if (adjType && r.type !== adjType) return false;

        // 5. Staff filter
        if (staff && r.staff !== staff) return false;

        // 6. Date filters
        if (from && r.date && r.date < from) return false;
        if (to && r.date && r.date > to) return false;

        // 7. Patient filter
        if (pat) {
            const idMatch = r.patientId && r.patientId === pat;
            const nameMatch = patName && normName(r.patientName) === patName;
            if (!idMatch && !nameMatch) return false;
        }

        return true;
    });

    currentPage = 1;
    renderTable();
    resetTableScroll();
}


function resetFilters() {
    if (!LOGGED_IN_PRACTICE) {
        filtered = [];
        currentPage = 1;
        renderTable();
        resetTableScroll();
        return;
    }
    _isUpdatingDropdowns = true;
    try {
        if (typeof selectSSOption === 'function') {
            if (LOGGED_IN_PRACTICE) {
                selectSSOption('ss-practice', LOGGED_IN_PRACTICE.id, LOGGED_IN_PRACTICE.name);
                lockPracticeSelect();
                const practiceDocs = getPracticeDoctors(LOGGED_IN_PRACTICE.id, LOGGED_IN_PRACTICE.name);
                const practiceHosps = getPracticeHospitals(LOGGED_IN_PRACTICE.id, LOGGED_IN_PRACTICE.name);
                if (typeof populateSSDropdown === 'function') {
                    populateSSDropdown('ss-doctor', practiceDocs, 'All Doctors');
                    populateSSDropdown('ss-location', practiceHosps, 'All Locations');
                    populatePatientDropdownFromClaims(allData);
                }
            } else {
                selectSSOption('ss-practice', '', 'All Practices');
                if (typeof populateSSDropdown === 'function') {
                    populateSSDropdown('ss-doctor', ALL_DOCTOR_ITEMS, 'All Doctors');
                    populateSSDropdown('ss-location', ALL_HOSPITAL_ITEMS, 'All Locations');
                }
            }

            selectSSOption('ss-doctor', '', 'All Doctors');
            selectSSOption('ss-location', '', 'All Locations');
            selectSSOption('ss-adj-type', '', 'All Types');
            selectSSOption('ss-patient', '', 'All Patients');
            selectSSOption('ss-staff', '', 'All Staff');
        }

        const fromEl = document.getElementById('filter-from');
        const toEl = document.getElementById('filter-to');
        if (fromEl) fromEl.value = '';
        if (toEl) toEl.value = '';

        const srchEl = document.getElementById('table-search');
        if (srchEl) srchEl.value = '';
    } finally {
        _isUpdatingDropdowns = false;
    }

    filtered = [...allData];
    searchQ = '';
    currentPage = 1;
    renderTable();
    resetTableScroll();
}

function onPracticeChange(practiceId) {
    if (_isUpdatingDropdowns) return;
    if (LOGGED_IN_PRACTICE && practiceId !== LOGGED_IN_PRACTICE.id) {
        practiceId = LOGGED_IN_PRACTICE.id;
    }
    _isUpdatingDropdowns = true;
    try {
        let docItems = [];
        let hospItems = [];

        if (practiceId) {
            docItems = getPracticeDoctors(practiceId, PRACTICE_ID_TO_NAME.get(practiceId) || practiceId);
            hospItems = getPracticeHospitals(practiceId, PRACTICE_ID_TO_NAME.get(practiceId) || practiceId);
        } else {
            docItems = ALL_DOCTOR_ITEMS;
            hospItems = ALL_HOSPITAL_ITEMS;
        }

        populateSSDropdown('ss-doctor', docItems, 'All Doctors');
        populateSSDropdown('ss-location', hospItems, 'All Locations');

        if (typeof selectSSOption === 'function') {
            selectSSOption('ss-doctor', '', 'All Doctors');
            selectSSOption('ss-location', '', 'All Locations');
        }
    } finally {
        _isUpdatingDropdowns = false;
    }

    applyFilters();
}

function onDoctorChange(doctorId) {
    if (_isUpdatingDropdowns) return;
    _isUpdatingDropdowns = true;
    try {
        const pId = LOGGED_IN_PRACTICE ? LOGGED_IN_PRACTICE.id : (document.getElementById('f-practice')?.value || '');
        const pName = LOGGED_IN_PRACTICE ? LOGGED_IN_PRACTICE.name : (document.querySelector('#ss-practice .ss-label')?.textContent || '');
        let hospItems = [];

        if (pId || (pName && pName !== 'All Practices')) {
            const activePId = pId || PRACTICE_NAME_TO_ID.get(normName(pName));
            if (doctorId) {
                const pdKey = `${activePId}_${doctorId}`;
                const docName = DOCTOR_ID_TO_NAME.get(doctorId);
                const pdNameKey = docName ? `${activePId}_${normName(docName)}` : '';

                if (PRACTICE_DOC_TO_HOSPITALS.has(pdKey)) {
                    hospItems = Array.from(PRACTICE_DOC_TO_HOSPITALS.get(pdKey).values());
                } else if (pdNameKey && PRACTICE_DOC_TO_HOSPITALS.has(pdNameKey)) {
                    hospItems = Array.from(PRACTICE_DOC_TO_HOSPITALS.get(pdNameKey).values());
                } else {
                    const subHospMap = new Map();
                    ALL_SUBFORM_ROWS.forEach(s => {
                        const pMatch = (activePId && s.practiceId && String(s.practiceId) === String(activePId)) ||
                                       (pName && s.practiceName && isNameMatch(pName, s.practiceName));
                        const dMatch = (doctorId && s.doctorId && String(s.doctorId) === String(doctorId)) ||
                                       (docName && s.doctorName && isNameMatch(docName, s.doctorName));
                        if (pMatch && dMatch && s.hospitalId && s.hospitalName) {
                            subHospMap.set(String(s.hospitalId), { value: String(s.hospitalId), label: s.hospitalName });
                        }
                    });
                    if (subHospMap.size > 0) {
                        hospItems = Array.from(subHospMap.values());
                    } else {
                        hospItems = getPracticeHospitals(activePId, pName);
                    }
                }
            } else {
                hospItems = getPracticeHospitals(activePId, pName);
            }
        } else {
            if (doctorId) {
                const docName = DOCTOR_ID_TO_NAME.get(doctorId);
                if (DOCTOR_TO_HOSPITALS.has(doctorId)) {
                    hospItems = Array.from(DOCTOR_TO_HOSPITALS.get(doctorId).values());
                } else if (docName && DOCTOR_TO_HOSPITALS.has(normName(docName))) {
                    hospItems = Array.from(DOCTOR_TO_HOSPITALS.get(normName(docName)).values());
                } else if (DOCTOR_HOSPITAL_MAP.has(doctorId)) {
                    const hIds = DOCTOR_HOSPITAL_MAP.get(doctorId);
                    hospItems = ALL_HOSPITAL_ITEMS.filter(h => hIds.has(h.value));
                }
                if (!hospItems || hospItems.length === 0) {
                    hospItems = ALL_HOSPITAL_ITEMS;
                }
            } else {
                hospItems = ALL_HOSPITAL_ITEMS;
            }
        }

        hospItems.sort((a, b) => a.label.localeCompare(b.label));
        populateSSDropdown('ss-location', hospItems, 'All Locations');

        if (typeof selectSSOption === 'function') {
            selectSSOption('ss-location', '', 'All Locations');
        }
    } finally {
        _isUpdatingDropdowns = false;
    }

    applyFilters();
}

function onHospitalChange(hospId) {
    if (_isUpdatingDropdowns) return;
    _isUpdatingDropdowns = true;
    try {
        const pId = LOGGED_IN_PRACTICE ? LOGGED_IN_PRACTICE.id : (document.getElementById('f-practice')?.value || '');
        const pName = LOGGED_IN_PRACTICE ? LOGGED_IN_PRACTICE.name : (document.querySelector('#ss-practice .ss-label')?.textContent || '');
        const curDoc = document.getElementById('f-doctor')?.value;

        if (!curDoc && (pId || (pName && pName !== 'All Practices'))) {
            const activePId = pId || PRACTICE_NAME_TO_ID.get(normName(pName));
            let docItems = [];
            if (hospId) {
                const subDocMap = new Map();
                ALL_SUBFORM_ROWS.forEach(s => {
                    const pMatch = (activePId && s.practiceId && String(s.practiceId) === String(activePId)) ||
                                   (pName && s.practiceName && isNameMatch(pName, s.practiceName));
                    const hMatch = (hospId && s.hospitalId && String(s.hospitalId) === String(hospId)) ||
                                   (s.hospitalName && isNameMatch(s.hospitalName, HOSPITAL_ID_TO_NAME.get(hospId) || ''));
                    if (pMatch && hMatch && s.doctorId && s.doctorName) {
                        subDocMap.set(String(s.doctorId), { value: String(s.doctorId), label: s.doctorName });
                    }
                });
                if (subDocMap.size > 0) {
                    docItems = Array.from(subDocMap.values());
                    docItems.sort((a, b) => a.label.localeCompare(b.label));
                    populateSSDropdown('ss-doctor', docItems, 'All Doctors');
                }
            } else {
                docItems = getPracticeDoctors(activePId, pName);
                populateSSDropdown('ss-doctor', docItems, 'All Doctors');
            }
        }
    } finally {
        _isUpdatingDropdowns = false;
    }

    applyFilters();
}

function filterHospitalsByDoctor(doctorId) {
    onDoctorChange(doctorId);
}

// Global hook called directly by selectSSOption in widget.html
window.onSSOptionSelected = function (id, value, label) {
    if (_isUpdatingDropdowns) return;
    if (id === 'ss-practice') onPracticeChange(value);
    else if (id === 'ss-doctor') onDoctorChange(value);
    else if (id === 'ss-location') onHospitalChange(value);
};

if (typeof selectSSOption === 'function') {
    const _origSelectSSOption = selectSSOption;
    window.selectSSOption = function (id, value, label) {
        _origSelectSSOption(id, value, label);
        if (!_isUpdatingDropdowns) {
            if (id === 'ss-practice') onPracticeChange(value);
            else if (id === 'ss-doctor') onDoctorChange(value);
            else if (id === 'ss-location') onHospitalChange(value);
        }
    };
}

function searchTable(q) {
    searchQ = q.toLowerCase();
    currentPage = 1;
    renderTable();
    resetTableScroll();
}

function sortTable(key) {
    if (sortKey === key) sortDir = sortDir === 'asc' ? 'desc' : 'asc';
    else { sortKey = key; sortDir = 'asc'; }
    document.querySelectorAll('thead th').forEach(th => th.classList.remove('sort-asc', 'sort-desc'));
    const idx = {
        claimId: 0, date: 1, hospital: 2, doctor: 3, staff: 4, patientName: 5,
        type: 6, adjAmount: 7, notes: 8, itemNumber: 9, originalAmount: 10, adjustmentAmount: 11
    };
    const th = document.querySelectorAll('thead th')[idx[key]];
    if (th) th.classList.add(sortDir === 'asc' ? 'sort-asc' : 'sort-desc');
    currentPage = 1;
    renderTable();
    resetTableScroll();
}


/* ─────────────────────────────────────────────────────────────────────
   RENDER
   ───────────────────────────────────────────────────────────────────── */
function getDisplayData() {
    let d = [...filtered];

    if (searchQ) {
        d = d.filter(r => {
            const claimMatch = [r.claimId, r.hospital, r.patientName, r.type, r.doctor, r.date, r.staff, r.notes, r.adjAmount]
                .some(v => String(v).toLowerCase().includes(searchQ));
            const lineMatch = r.lines.some(l =>
                [l.itemNumber, l.originalAmount, l.adjustmentAmount]
                    .some(v => String(v).toLowerCase().includes(searchQ))
            );
            return claimMatch || lineMatch;
        });
    }

    const lineKeys = ['itemNumber', 'originalAmount', 'adjustmentAmount'];
    d.sort((a, b) => {
        let va, vb;
        if (lineKeys.includes(sortKey)) {
            va = a.lines[0] ? a.lines[0][sortKey] : 0;
            vb = b.lines[0] ? b.lines[0][sortKey] : 0;
        } else {
            va = a[sortKey]; vb = b[sortKey];
        }
        if (typeof va === 'string') { va = va.toLowerCase(); vb = String(vb).toLowerCase(); }
        return va < vb ? (sortDir === 'asc' ? -1 : 1)
            : va > vb ? (sortDir === 'asc' ? 1 : -1) : 0;
    });
    return d;
}

function renderTable() {
    const data = getDisplayData();
    renderGrandSummaryCard(data);
    const total = data.length;
    const start = (currentPage - 1) * perPage;
    const end = Math.min(start + perPage, total);
    const page = data.slice(start, end);
    const tbody = document.getElementById('table-body');
    tbody.innerHTML = '';

    const noResEl = document.getElementById('no-results');
    if (!page.length) {
        if (noResEl) {
            noResEl.textContent = !LOGGED_IN_PRACTICE
                ? 'No practice linked to your login user.'
                : 'No records match the selected filters.';
            noResEl.style.display = 'block';
        }
    } else {
        if (noResEl) noResEl.style.display = 'none';

        page.forEach(claim => {
            const typeCellHtml = claim.type && claim.type !== '—'
                ? `<span class="type-badge ${claim.typeBadge}">${claim.type}</span>`
                : `<span style="color:#aaa;font-size:12px;">—</span>`;
            const adjDateStr = formatDateDisplay(claim.date);
            const adjAmountCls = claim.adjAmount < 0 ? 'amount-neg' : 'amount-pos';
            const adjAmountStr = (claim.adjAmount < 0 ? '- $' : '$') + Math.abs(claim.adjAmount).toFixed(2);

            claim.lines.forEach((line, idx) => {
                const tr = document.createElement('tr');
                tr.classList.add('claim-line-row');
                if (idx === 0) tr.classList.add('claim-group-start');
                if (idx > 0) tr.classList.add('claim-group-continued');

                const isFirstLine = idx === 0;
                const claimCellsHtml = `
        <td class="claim-repeat-cell">${isFirstLine ? claim.claimId : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? adjDateStr : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? (claim.hospital || '—') : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? (claim.doctor || '—') : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? (claim.staff || '—') : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? (claim.patientName || '—') : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? typeCellHtml : ''}</td>
        <td class="claim-repeat-cell ${isFirstLine ? adjAmountCls : ''}">${isFirstLine ? adjAmountStr : ''}</td>
        <td class="claim-repeat-cell">${isFirstLine ? (claim.notes || '—') : ''}</td>
    `;

                const origStr = line.originalAmountRaw !== '' ? line.originalAmountRaw : '—';
                const allocCls = line.adjustmentAmount < 0 ? 'amount-neg' : 'amount-pos';
                const allocStr = line.adjustmentAmountRaw !== '' ? line.adjustmentAmountRaw : '—';

                tr.innerHTML = `
    ${claimCellsHtml}
    <td style="text-align:center;">${line.itemNumber}</td>
    <td class="amount-pos">${origStr}</td>
    <td class="${allocCls}">${allocStr}</td>
`;
                tbody.appendChild(tr);
            });
        });
    }
    renderPagination(total);
    updateBottomScrollWidth();
}

function renderPagination(total) {
    const pages = Math.ceil(total / perPage) || 1;
    const pg = document.getElementById('pagination');
    pg.innerHTML = '';

    const mkBtn = (lbl, p2, disabled = false, active = false) => {
        const b = document.createElement('button');
        b.className = 'page-btn' + (active ? ' active' : '');
        b.textContent = lbl;
        b.disabled = disabled;
        b.onclick = () => { currentPage = p2; renderTable(); resetTableScroll(); };
        return b;
    };

    pg.appendChild(mkBtn('«', 1, currentPage === 1));
    pg.appendChild(mkBtn('‹', currentPage - 1, currentPage === 1));

    let s = Math.max(1, currentPage - 2), e = Math.min(pages, s + 4);
    if (e - s < 4) s = Math.max(1, e - 4);
    if (s > 1) {
        pg.appendChild(mkBtn('1', 1));
        if (s > 2) {
            const sp = document.createElement('span');
            sp.style.cssText = 'padding:0 3px;color:#aaa;font-size:11px;';
            sp.textContent = '…';
            pg.appendChild(sp);
        }
    }
    for (let i = s; i <= e; i++) pg.appendChild(mkBtn(i, i, false, i === currentPage));
    if (e < pages) {
        if (e < pages - 1) {
            const sp = document.createElement('span');
            sp.style.cssText = 'padding:0 3px;color:#aaa;font-size:11px;';
            sp.textContent = '…';
            pg.appendChild(sp);
        }
        pg.appendChild(mkBtn(pages, pages));
    }
    pg.appendChild(mkBtn('›', currentPage + 1, currentPage === pages));
    pg.appendChild(mkBtn('»', pages, currentPage === pages));
}

function changePerPage(v) { perPage = parseInt(v); currentPage = 1; renderTable(); resetTableScroll(); }


/* ─────────────────────────────────────────────────────────────────────
   MOBILE / iOS FILE DELIVERY (preview + native share sheet)
   ───────────────────────────────────────────────────────────────────── */
function isIOSDevice() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); // iPadOS
}
function isMobileDevice() {
    return isIOSDevice() || /Android/i.test(navigator.userAgent);
}

let _deliverUrl = null;

function deliverFile(blob, fileName) {
    if (!isMobileDevice()) {
        // Desktop: normal download
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        return;
    }
    showFileSheet(blob, fileName);
}

function showFileSheet(blob, fileName) {
    closeFileSheet(true);
    _deliverUrl = URL.createObjectURL(blob);

    let file = null;
    let canShareFile = false;
    try {
        file = new File([blob], fileName, { type: blob.type });
        canShareFile = !!(navigator.canShare && navigator.canShare({ files: [file] }));
    } catch (e) {
        canShareFile = false;
    }
    const isPdf = blob.type === 'application/pdf';

    const overlay = document.createElement('div');
    overlay.id = 'file-sheet-overlay';
    overlay.className = 'file-sheet-overlay';
    overlay.innerHTML = `
      <div class="file-sheet" role="dialog" aria-modal="true">
        <div class="file-sheet-handle"></div>
        <div class="file-sheet-title">${isPdf ? 'PDF ready' : 'Excel file ready'}</div>
        <div class="file-sheet-name">${fileName}</div>
        ${canShareFile ? '<button class="fs-btn fs-primary" id="fs-share">Share / Save to Files</button>' : ''}
        <a class="fs-btn ${canShareFile ? 'fs-secondary' : 'fs-primary'}" id="fs-open"
           href="${_deliverUrl}" target="_blank" rel="noopener">${isPdf ? 'Open Preview' : 'Open File'}</a>
        ${!canShareFile ? '<div class="fs-hint">In the preview, tap the Share icon to save, print, Mail, WhatsApp or AirDrop it.</div>' : ''}
        <button class="fs-btn fs-cancel" id="fs-cancel">Close</button>
      </div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('show'));

    overlay.addEventListener('click', e => { if (e.target === overlay) closeFileSheet(); });
    document.getElementById('fs-cancel').onclick = () => closeFileSheet();

    const shareBtn = document.getElementById('fs-share');
    if (shareBtn) {
        shareBtn.onclick = async () => {
            try {
                await navigator.share({ files: [file], title: fileName });
                closeFileSheet();
            } catch (err) {
                // AbortError = user cancelled the share sheet; anything else → open preview instead
                if (err && err.name !== 'AbortError') window.open(_deliverUrl, '_blank');
            }
        };
    }
}

function closeFileSheet(immediate) {
    const overlay = document.getElementById('file-sheet-overlay');
    if (overlay) {
        overlay.classList.remove('show');
        setTimeout(() => overlay.remove(), immediate ? 0 : 250);
    }
    if (_deliverUrl) {
        const url = _deliverUrl;
        _deliverUrl = null;
        setTimeout(() => URL.revokeObjectURL(url), 60000); // keep alive for an opened preview tab
    }
}

function exportDateStamp() {
    return new Date().toISOString().split('T')[0];
}


/* ─────────────────────────────────────────────────────────────────────
   EXPORT EXCEL
   ───────────────────────────────────────────────────────────────────── */
function exportExcel() {
    showLoading('Generating Excel...');
    setTimeout(() => {
        try {
            const data = getDisplayData();
            const meta = getReportMeta();

            const headers = [
                'Claim ID', 'Claim Date', 'Hospital', 'Doctor', 'Staff', 'Patient',
                'Adjustment Type', 'Adjustment Amount', 'Notes',
                'Item Number', 'Original Amount', 'Allocated Amount'
            ];
            const colCount = headers.length;

            const rows = [];
            const rowGroupIndex = [];
            const claimColMergeSpans = [];

            data.forEach((r, gIdx) => {
                const lineCount = r.lines.length || 1;
                claimColMergeSpans.push({ startRow: rows.length, lineCount });

                r.lines.forEach((line, li) => {
                    if (li === 0) {
                        rows.push([
                            r.claimId, formatDateDisplay(r.date), r.hospital || '—', r.doctor || '—',
                            r.staff || '—', r.patientName || '—', r.type || '—', r.adjAmount,
                            r.notes || '—', line.itemNumber, line.originalAmount, line.adjustmentAmount
                        ]);
                    } else {
                        rows.push([
                            '', '', '', '', '', '', '', '',
                            '', line.itemNumber, line.originalAmount, line.adjustmentAmount
                        ]);
                    }
                    rowGroupIndex.push(gIdx);
                });
            });

            const cardSummary = computeGrandSummaryCard(data);

            const aoa = [];
            aoa.push(['ADJUSTMENT REPORT', ...Array(colCount - 1).fill('')]);
            aoa.push(Array(colCount).fill(''));
            aoa.push(['DOCTOR', '', '', 'HOSPITAL', '', '', 'REPORT PERIOD', '', '', 'GENERATED ON', '', '']);
            aoa.push([meta.doctorName, '', '', meta.hospitalName, '', '', meta.period, '', '', meta.generatedOn, '', '']);
            aoa.push(Array(colCount).fill(''));
            aoa.push(headers);
            rows.forEach(r => aoa.push(r));

            const dataStartRow = 6;
            const gsSpacerRow = dataStartRow + rows.length;
            const gsTitleRow = gsSpacerRow + 1;
            const gsLabelsRow = gsTitleRow + 1;
            const gsValuesRow = gsLabelsRow + 1;

            aoa.push(Array(colCount).fill(''));
            aoa.push(['GRAND SUBMISSION SUMMARY', ...Array(colCount - 1).fill('')]);
            aoa.push(['HOSPITALS', '', 'PATIENTS', '', 'CLAIMS', '', 'TOTAL ORIGINAL AMOUNT', '', 'TOTAL ALLOCATED AMOUNT', '', 'TOTAL ADJUSTMENT AMOUNT', '']);
            aoa.push([
                cardSummary.hospitals, '',
                cardSummary.patients, '',
                cardSummary.claims, '',
                '$' + cardSummary.originalAmountTotal.toFixed(2), '',
                (cardSummary.allocatedAmountTotal < 0 ? '- $' : '$') + Math.abs(cardSummary.allocatedAmountTotal).toFixed(2), '',
                (cardSummary.adjAmountTotal < 0 ? '- $' : '$') + Math.abs(cardSummary.adjAmountTotal).toFixed(2), ''
            ]);

            const ws = XLSX.utils.aoa_to_sheet(aoa);

            ws['!cols'] = [
                { wch: 14 }, { wch: 14 }, { wch: 26 }, { wch: 16 }, { wch: 16 }, { wch: 20 },
                { wch: 20 }, { wch: 18 }, { wch: 26 }, { wch: 12 }, { wch: 16 }, { wch: 16 }
            ];

            ws['!rows'] = [{ hpt: 26 }, { hpt: 6 }, { hpt: 16 }, { hpt: 20 }, { hpt: 6 }, { hpt: 22 }];

            ws['!merges'] = [
                { s: { r: 0, c: 0 }, e: { r: 0, c: colCount - 1 } },
                { s: { r: 2, c: 0 }, e: { r: 2, c: 2 } }, { s: { r: 3, c: 0 }, e: { r: 3, c: 2 } },
                { s: { r: 2, c: 3 }, e: { r: 2, c: 5 } }, { s: { r: 3, c: 3 }, e: { r: 3, c: 5 } },
                { s: { r: 2, c: 6 }, e: { r: 2, c: 8 } }, { s: { r: 3, c: 6 }, e: { r: 3, c: 8 } },
                { s: { r: 2, c: 9 }, e: { r: 2, c: 11 } }, { s: { r: 3, c: 9 }, e: { r: 3, c: 11 } }
            ];

            const CLAIM_LEVEL_COLS = [0, 1, 2, 3, 4, 5, 6, 7, 8];
            claimColMergeSpans.forEach(({ startRow, lineCount }) => {
                if (lineCount <= 1) return;
                const rTop = dataStartRow + startRow;
                const rBottom = dataStartRow + startRow + lineCount - 1;
                CLAIM_LEVEL_COLS.forEach(c => {
                    ws['!merges'].push({ s: { r: rTop, c }, e: { r: rBottom, c } });
                });
            });

            // ── STICKY (frozen) header in Excel: rows 1–6 stay visible while scrolling,
            //    Claim ID column stays visible while scrolling sideways ──
            ws['!freeze'] = { xSplit: 1, ySplit: dataStartRow };
            ws['!views'] = [{ state: 'frozen', xSplit: 1, ySplit: dataStartRow, topLeftCell: 'B7', activePane: 'bottomRight' }];

            const NAVY = 'FF15234B';
            const LABEL_COLOR = 'FF3A5A8A';
            const VALUE_COLOR = 'FF232830';
            const HEADER_BG = 'FF3A5A8A';
            const ZEBRA_BG = 'FFF8F9FB';
            const BORDER_LT = 'FFD2D5DC';
            const DARK_GREEN = 'FF1B5E2D';
            const CARD_BG = 'FFF8F9FB';

            const titleStyle = { font: { bold: true, sz: 16, color: { rgb: NAVY } }, alignment: { horizontal: 'left', vertical: 'center' } };
            const labelStyle = { font: { bold: true, sz: 9, color: { rgb: LABEL_COLOR } }, alignment: { horizontal: 'left', vertical: 'center' } };
            const valueStyle = { font: { bold: true, sz: 11, color: { rgb: VALUE_COLOR } }, alignment: { horizontal: 'left', vertical: 'center' } };
            const headerStyle = {
                font: { bold: true, sz: 10, color: { rgb: 'FFFFFFFF' } },
                fill: { patternType: 'solid', fgColor: { rgb: HEADER_BG } },
                alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
                border: {
                    top: { style: 'thin', color: { rgb: 'FFB0B8C4' } }, bottom: { style: 'thin', color: { rgb: 'FFB0B8C4' } },
                    left: { style: 'thin', color: { rgb: 'FFB0B8C4' } }, right: { style: 'thin', color: { rgb: 'FFB0B8C4' } }
                }
            };
            const dataBorder = {
                top: { style: 'thin', color: { rgb: BORDER_LT } }, bottom: { style: 'thin', color: { rgb: BORDER_LT } },
                left: { style: 'thin', color: { rgb: BORDER_LT } }, right: { style: 'thin', color: { rgb: BORDER_LT } }
            };

            const setCellStyle = (r, c, style) => {
                const addr = XLSX.utils.encode_cell({ r, c });
                if (!ws[addr]) ws[addr] = { t: 's', v: '' };
                ws[addr].s = style;
            };

            for (let c = 0; c < colCount; c++) setCellStyle(0, c, titleStyle);
            for (let c = 0; c < colCount; c++) setCellStyle(2, c, labelStyle);
            for (let c = 0; c < colCount; c++) setCellStyle(3, c, valueStyle);
            for (let c = 0; c < colCount; c++) setCellStyle(5, c, headerStyle);

            const alignMap = { 1: 'center', 7: 'right', 9: 'center', 10: 'right', 11: 'right' };
            const dataBorderTop = {
                top: { style: 'medium', color: { rgb: NAVY } }, bottom: { style: 'thin', color: { rgb: BORDER_LT } },
                left: { style: 'thin', color: { rgb: BORDER_LT } }, right: { style: 'thin', color: { rgb: BORDER_LT } }
            };
            rows.forEach((row, i) => {
                const r = dataStartRow + i;
                const groupIdx = rowGroupIndex[i];
                const isNewGroup = i === 0 || groupIdx !== rowGroupIndex[i - 1];
                row.forEach((val, c) => {
                    const style = {
                        alignment: { horizontal: alignMap[c] || 'left', vertical: 'center' },
                        border: isNewGroup ? dataBorderTop : dataBorder
                    };
                    if (groupIdx % 2 === 1) {
                        style.fill = { patternType: 'solid', fgColor: { rgb: ZEBRA_BG } };
                    }
                    setCellStyle(r, c, style);
                });
            });

            const gsTitleStyle = {
                font: { bold: true, sz: 13, color: { rgb: NAVY } },
                alignment: { horizontal: 'center', vertical: 'center' },
                fill: { patternType: 'solid', fgColor: { rgb: CARD_BG } },
                border: { top: { style: 'medium', color: { rgb: NAVY } }, left: { style: 'thin', color: { rgb: BORDER_LT } }, right: { style: 'thin', color: { rgb: BORDER_LT } } }
            };
            const gsLabelStyle = {
                font: { bold: true, sz: 8.5, color: { rgb: 'FF6E7680' } },
                alignment: { horizontal: 'center', vertical: 'center' },
                fill: { patternType: 'solid', fgColor: { rgb: CARD_BG } },
                border: { left: { style: 'thin', color: { rgb: BORDER_LT } }, right: { style: 'thin', color: { rgb: BORDER_LT } } }
            };
            const gsValueStyle = {
                font: { bold: true, sz: 14, color: { rgb: DARK_GREEN } },
                alignment: { horizontal: 'center', vertical: 'center' },
                fill: { patternType: 'solid', fgColor: { rgb: CARD_BG } },
                border: { left: { style: 'thin', color: { rgb: BORDER_LT } }, right: { style: 'thin', color: { rgb: BORDER_LT } }, bottom: { style: 'medium', color: { rgb: NAVY } } }
            };

            for (let c = 0; c < colCount; c++) setCellStyle(gsTitleRow, c, gsTitleStyle);
            for (let c = 0; c < colCount; c++) setCellStyle(gsLabelsRow, c, gsLabelStyle);
            for (let c = 0; c < colCount; c++) setCellStyle(gsValuesRow, c, gsValueStyle);

            ws['!merges'].push(
                { s: { r: gsTitleRow, c: 0 }, e: { r: gsTitleRow, c: colCount - 1 } },
                { s: { r: gsLabelsRow, c: 0 }, e: { r: gsLabelsRow, c: 1 } },
                { s: { r: gsLabelsRow, c: 2 }, e: { r: gsLabelsRow, c: 3 } },
                { s: { r: gsLabelsRow, c: 4 }, e: { r: gsLabelsRow, c: 5 } },
                { s: { r: gsLabelsRow, c: 6 }, e: { r: gsLabelsRow, c: 7 } },
                { s: { r: gsLabelsRow, c: 8 }, e: { r: gsLabelsRow, c: 9 } },
                { s: { r: gsLabelsRow, c: 10 }, e: { r: gsLabelsRow, c: 11 } },
                { s: { r: gsValuesRow, c: 0 }, e: { r: gsValuesRow, c: 1 } },
                { s: { r: gsValuesRow, c: 2 }, e: { r: gsValuesRow, c: 3 } },
                { s: { r: gsValuesRow, c: 4 }, e: { r: gsValuesRow, c: 5 } },
                { s: { r: gsValuesRow, c: 6 }, e: { r: gsValuesRow, c: 7 } },
                { s: { r: gsValuesRow, c: 8 }, e: { r: gsValuesRow, c: 9 } },
                { s: { r: gsValuesRow, c: 10 }, e: { r: gsValuesRow, c: 11 } }
            );

            ws['!ref'] = XLSX.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: gsValuesRow, c: colCount - 1 } });

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Adjustment Report');
            wb.Workbook = { Views: [{ RTL: false }] };

            const xlsxOut = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
            deliverFile(
                new Blob([xlsxOut], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
                'Adjustment_Report_' + exportDateStamp() + '.xlsx'
            );

            hideLoading();
            showToast(isMobileDevice() ? '✓ Excel ready' : '✓ Excel exported successfully');
        } catch (e) { hideLoading(); showToast('Export failed: ' + e.message); }
    }, 80);
}


/* ─────────────────────────────────────────────────────────────────────
   EXPORT PDF
   ───────────────────────────────────────────────────────────────────── */
async function exportPDF() {
    showLoading('Generating PDF...');

const LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA4QAAAFNCAYAAABYNqFuAAEAAElEQVR4nNT9ebxuWVUeCo+x9j6nGqqvQihREVAEaVUaUbpC2hJphCojGlFUTNBIrr3JJYifJhrRmMTcqzHcoDESC5XYomisAkVQMYrSRIjYoLTVn6pTp87Ze43vjzmeZq53480v0ch9oc7ee71rzTnaZzRzrrUyIqKqHvXLv/6Gb3jnn7/38285ceJgXQ/31/UwqiqqIiLGz6qIqIhlyYjMyIjIzKiqiPF/nstPRmT/uiwZuSyRGZGxjC+jImqNda1YMUiOcW2IWKui1oqy8cfvFZnJ/5bM2FuW6foiBWPwakrnGZp68jvOqurz0k6NtGuj+S+OW5UcMTFejvPG5ePqhGwyx8A+V58fazOrk2PBvAm5g8Mkl9XXZUbk0royqlfIsenLjKieI0FHZKzZQqiQ7KH7SQZjVPyxtjwypJt0Y2gaqYvMJkV/a5KiUNL+wmcvMyKGXQ1S11hj0BC1RlROPGfbWSXsYNjzktmyStHUfEcNm2ijF1k95lprwOwzW6UV8gUn2PVfTcGyxLJk7C0ZS+6RprXWqHWNgzqMOqxY14KpyCQm+97opH0JaozWCY0Il7ctVFSs69p6Gee6de3OJP+rliVcDz5Y9OsWTM+VOY+kEWNyPPlf7pxfHGemC6cPdQ2soR4jhuBLJ0FGGAPYAhlkzDiCs6WH3FBXxC3IEz5JWkhfBv4Hp6wcrg+aMyJqMT1kRuYSFRELbC1qeOC6UlPA2sqC6UZUxeEKTK+YZTqIWpzf8cfA/XA5DXsctm86pgJgD5L9GK5tJLdSS0h+YPkyeFyWNtY1ouowDte1Y1OJvgD+L+ajG502HsCnV9hCCJfBYcKAGk+GnSXNF/8O/wjSIp+EpHKyCf5bk9P1BUtElrCShA8881GIRRB1xxDEQAs+Jtu1MbHHQcxqeS2puAk1DhsZ8xdEHQMnF9Jp8bOnlYzXYY5VEUtNtg5tR6Tk5//ksJWAVXhscJmb7Kj3BteqiFg7FgDVWu/Z+LgsyxQjq30E0lug49XsHPElh1SWzDFO60ExWlpT3jJsKsotlCyLN/ixwp8LyMQOoG86zAhHbDqMFeZypF2Irmz/Iz4zkG2Qt22HOYHngMgj0kJLTZNQp4vz4x/DVMhD8SRIDPwvgac03P7h8dpzSvqxMlFcVh04c9HJHqqAHWQYdoa4BpY6LkpwOeGD6wicrVltF86GYTRkC2/M4Z8Uq0EpItfsL2sUaRj4miCisjFx2DlkhmgHmoj3AXkvloMHdQyfrXUAwoq8cPLbIWdXG2JxVvJ35sgRkWm4RSV37DNDg20OGoKf1WjPjFhAf1vTZNNNqaHbpBXl55N3tB30dZvvKmPQkx4uTQ9RcViIcTxEvBqaHflixhLHjx+rm0/ecOdjH/m4sx9xyQP/7ife9eN/7Nq6dv+KvOKAc1btvTpeHU+67UmPvei8ix7zr6/9sbPfe9NffPPe4V7kshenTp9cHvPQx8T+X974wUdHxJNf++Y3rq/46Z+O228/GbWfEctCJx+ROOTZEJRHDX4swJtxTkC2PdVzgiOGmZBl+6kjLlRE7r9L8+iLMATT337dlkCC44YYodZm3C1Dds6CoSekDyGKjQnE4PkYb/UT7XiDhdM2EVSbsbZ8bI7V5osJfdqqnU7nE4McNTYP2DgTopaQexszduxmq4/JgIwXm3NCIafT7dfooty2fByl7833nUzv8OFyYQA+IkB+hMR9lvPW7z6Cfo/6+HcMYrV7Tm6Y35rddP5W6U3zWjHJwm30I8nxI9kPadoSE7M/bi/6SHr4SDJy/DpK/9P0NZl1OBlZG3r/X3wQ9ui2inHcBnyu3MjB6d7hsUzXG/62ct3aE76b/OoI2To/k58alhKHN348zbm1D/djzPuRsCY312/omPx885l0iHNtrAmjtrJ3PM95+NzyE3GkbUyYupGH07jlMT+CLnZ4D8P4/rmA9q1NhIUX4yerw1HuYtJqv0+DYd76K2g9QieTLozPZWMDGA9J2xYqnSc//ygfhH37+fgD/DFPqfl75wVjLhvd78S3CTTsvI0i3H88fmB+p3s7nM/vDUKnafJtXGc62bHtMh0chW8bX9/xuR1BGK9bn/hI15ketseOxDK3PRPUlGv5ucB3L9iPwqaNTbuOpiFdnu1ctZGvr0xMZLm/HeVDNePT1jcrd06fCpgJg91pQr8jViybr/2zhvB+S4P7ylEYkJtfKob/kKzU2Dyhx6stz6nv66/QQ8TM5vZgzafu1gRHCcL15Pa/mYQyb2A57F8PI+JwHbweRuS6F1lR6+HN+djHPPHsB334wT9+z/t+3GuuuuaqvSviikPOWpWZuX7oQx+6+0V3veizv/dX/91VP/i6H3nge/7oz9c8OKz1onXviQ9/8sEzzrryDftLHj8WEbede/55ec4lF8fBOWeNLmsLDt2iHR238yM2VLqisTYUJvdqXnPCDhwN74wkri6bbraUYmB2UWqtzJcO5A8bME2b334LO8Zp1ojV5zrS143m0jwVWpVcpuRhe/38+27ca7nU6IZkH4uA6dToZhIDsMLT422wa1yP7j3mQPx0Ay2tZDUna88BtWfUjn9teRk5hk5Cl9tXOKm2GrwVaMmKytHNK0uAPZ+oFpav8k0g2CfXEbLhig9xBC0cdanRXUdtt+1FuNimfN1kUBmRa8+e4cs7EPYsemBaeMwuxseBxc2LySBatxNOzlrlcR4DDYss0Wt8ErRj7b2CNS3VDaXMvinshxkU6HO33DqWfU0FWHysnQKo/161Wlk+f7i9zLKg+PsfrerbSct2Jg0y/EFHuVJAPciXIor+Q5mArnawdIIxEOhyE6eBFW1CujM5ZHAVY4ScmnhIzJExE5Tq0E/6SP09OcQu1A4amTz3QS1mBuOATwK2WlaDHEmfOUaLKNlp271eGNd6WrFaDF64FmRMYGB1m5P6wPwpXM3qWik1L8RA7BOOT6GgBUod2LEgD0nML49bgBHsGkmtUq19DF38qYFAWQsJQeMUh9JwctsNJ9BlQ9NqeBaSXehSx8Nlmsg+lhe7OsL0RgtPyWW1CxxLgD0drahL+lweIZaMyJp3PS20wV6ZKSLTZDLTxCaSaaWZqyU5x7OKqIWjcg7Q7sjTlhjElvTzXNb4nqgwn7UNFkf5Qsimdz70eV//BaD7XOKXMBONm4ad5GxZ+D3yg4Qyp0bGasKfDWrmomVN/oxngDYvNZy2gbLliWNZ4tf9meI2uW/jbvV8vG5Jk2NoJ1UvgtdGfpEmWVMjx3dYnqFx+CYOYAjOjwuUBwtD4c9JeWdqBX6wgdX2VSHFQcBoKvBDvc500meaDuhRK5lhjs91biDa0JXRPqaA//cuqLRryiJBruZjwJEZuymej+QaxOej3KzjTvt/5sDvTMyTA4MOKnKtiIM19mIvDk8frHtLLV/8xBfc/p3P+aZXX3bsnHedPHnyQddcdc1vjSmHoF953XVnnT59+hEfOnbiT77033/z83/q13/2k+48deeZ5fz9vQsvu2zvm676h3/6TZ/9d38oM79r//KLL762qh53cFDrweEaBwdr7LHwaKdJMSr4EEeHMZTuClSB1yCNONKIRbefHG9kBzQKFzUNt+bzc1aKhIzv5X1LKBaaZoOWaB6/jVGuxDko9pkcdEPfxrAnQ8jYTOSO3cm8j4ctjgVTVuGMZJP85TAijDVEZzQDoLKhunbngZ4IualLJaWGJ35ZAigDT9hQHcVXRFStTFQZDsxxcWAtFB8hB2MUjjHJYZAvT9AlX+NxZ3tGMFgwSLvNgOttpTSxIx4IMBsdFER9KP34cDufjDgEMaZryGmSZ/sZN3oc1andTuj2e2jfezDZFAQMPsb2kb64nbNimq/4RejL7WqUy/tw/lrN0yMObvxPxnyETNJ/ml+7eWH+rdtPJ4iVdVOsautTEjOtqyKJVMu7v6upwE6TkZVHO4m+/Hy7BT9CWDTrCgLz+TafrVwNFydPM3xj0DdcP9IqxczAirDrthHX9UVwXjl/NN7M7NXmYvyaEXmwQ89k55x/9u8glePnat1hr+vKAJQwccRn60M7ZmUNH5yARF/b2gdFBUyGc2Yoed3aCWPv+H0U4UdKxLBRODqfNfwYzY/tJhOPp1tspQxWxzWB8IQXrDCTP48W66YYiaDPzfJFsy4Ve6yQqqo4rFBkdL4wbG7msdmVyHt5tEFB5CIrCNs1GN9COex8E6RwOvVqsyVom0u7RLa6y9IRtujxbSdQzKFlwoctn6CjeIYzUFG9dXYTrkrxeaZr5puYYTGW8TtkNpNtrDowimht8Z+73jJIJvQb4c22OOQrzGw5HYbxHxrHAmtyBX6mlyNvFj9GIWE21xdJRvLbNIKHvDeDh+so6BtOay7GKYdWXslGWtQEwYprAsrJNxgbob/GWvhnjjG90JUtTBYTGylP+DdnuvCv2ORYGcyrq7aQ19fZfCV90o8YC31sLD7IJrHVOSIils6Zl4o8XON47cXJE7ccnH+X8/e/9blf+6FvfcoLn5uZv/6Lb37zBZ90ySV33ve+962qyl4ZzC+74opTj/7Anz3mK//jt77yTX/5tnvtn3XuwZmTJ+LTPvWhy5d/zpf97Fc/6jn/5MTtJx5x7Z9ce/b+L775zRdERO3nMu7tQEIPsCyJcRJx35NS01Kpdy/Rwe7rpoq6dlRFgAh0gdLGHAayQIkEaqkzazMmQC9RYY9+nvYkg2zcuybscEYV21uLloS57tXAp9nLGGDkbQVjmKLsVNDAiNodmmGWz0gOMW5fIlBMMeJgaJ80Nragg5s/xmrTOHEBGKB70jRgz/XajrMbONC9MSdL05E58ALjh24adCVuu3/AAHIOAAgQc7dsB5XLafX96dV6NGAt0Ql9W643yxX0xQwkR33QzVZ9LtTRKoB4S/Oxo2I++TqiM5oWxEh/zzGZOvx2M0Fuf3FFH1E0rNtk1U7fHmHHzWOJoiW/m+oc8LPBnGpjlv7s/s8dfqwrioBCL2v7xtdY3cg8agQmZpOr9TF05CugAtk/AgyKuDSjwWov2Z0YSGFVzNdFBBOYSaZ+OVvsJCpUvNmZO4WABcUxkOmqNj88XhhetQEWkoIUdgsQyJnRbCMxORBOKoe1/nzZtc4KE333sYqODrPQ6Cthdp7klXGDhtmXGgRrVd/SZlPq1GQpRqPNSqThC2yrmwTzPUrC9TQiJ02aYUlXf/VnssFJnnnEl0G7oowCGKZzSAbVXTxvu6PBrQkMSTVLaH+MXbM133KZaHV9+LbkoKKoou8uCqTCS3TMizUql7HrE4mj2QlXcdHUcF0yHCkA8j43+P9GJfKO3Z1TGgTCxhy78Wi6p3trGxDoRvCz3k35ldqZ4YcDNiy89PiiAbN3QWznTGGF05E7kwTzi62PF6gwvPVzZkClw4JO+U8EdhzQxzmPzQGVEAt6LsMFiq+Uu0y5ROka7B7QHLaNwr/PCO6UO+qD3NFpQn4XItqxEGFgXk2WIRw5k8s1q7HyiDPhvsjzJzlBFpaXANp2YpHLouawxSV2DLi1UQHP4LXs/Jh7sxWmo20LJRnb/bNwsmXjLzHZNb+qmAPG1kgzWAcsa8beWcfi5O03HDzwfg/Yf+mz/+GHn/ugJ//YB274wOmXvvSly5Wf+Zm3xuApM3N96Utfur8XefD6d//ev3nJL/7rF/3mf/v9OOfscw5vOXPT/uc+6RnxbU978a8+4d6f8cwH/O6l553/gPPfccV5V5zZv+2OO/pezLUFa/eeUWNBCaHg0SqVTp6CS6IA8mX8ZhWR1I8zrk2e3f9q3sqFYEsM5vUeHEt/93ZDjmh24jHNi0yqvyMGAAGKZM+KFSqsRw4kX1c48xA3ErFZhonEpIBrxaFzXQPdy6r5WibFie1kfevs0i5Gm8vG4i7kSnz7qhi6YujAwJFZVKND0jxzC1siSHJ9Sls0EUQSWwmSeiewRxCUI0BncmURljat6+GcqNgmgFxL1T+Uv+QOHSEY1AS0FQjwfZ6DZ5+BQghFtYqdGUYg52l7IfDf7YLAKX6pJ8rX4SijkIhQpjXcD/f7RIyH0pB4UC8AzxTtsguA2lzgCyL1vX88psOIq3OAmuRio9pQGaXbDXOeo46gd3wtXKmc5eadUhcdYQ46AF5khBLO1g10lXPiCtprRaOMGhhfcZWmjMf+blGBOsOB7BUP7fE4ElW9Yg79jXR1wFLb2JLEysiKlduTkgGVNjmJGNc4aslHbacQrZMM0HUMoyq0xar1w1XWqXpN84eQDJtWdKJbKtK/u18MvXkytOkhCFdpA4258G3P1ngS9ISHBeBaKE4BqWowwdqomZ2SLDReXa+0gWx5tR4tKcxIbTU3edr0UX1/E9deGHZW2gptzuRDEVkbe6U8IsaTNvAAh5VxYasr6tixJCYGw5G8mHcI4wRkHf+ZgSXtA8myu40/gIcFhhzXcFc7Wbb4E7UYVmPOIqbAViTXLoOQaALfFLTot9V8zggunaKRheKUD6kz/WA+0m4rV948oHU1L/oOl2BOx5Ggb4j/QeO4FaymuYdMhmwX8g05+vXz/MAI1x/8hHE7VIw5LzRYYFDzAn8pzSjHYv5h5tGyJCXN2IwXkm1s/NWvFT9NH08aA5fxhRRWriOihG2Qk0psPugR+I7mGHLCiFBcWaTIaDtqvJ7ALtZYV+WjJh55KJ95EWpEtV64yBHiCQ+InFCq2i8Aq/jdm5T8yMcJ7yS51GCCfNCcpq1AT8IQmkIYXfCB9h/cFsSpHWJ7Pn/OI1lDY6iArbJAYaTiiUwL+gvabUEPS0QunWeMuLeeuvGDB894zDOPf8Vjv/Cln/fJj3njDSduuODyyy7/7arKl73sZRiz3n/D+x/wsZde/vZX/+G1P/DNr/2+F73x7b9+5qyLLs7b7zi5/7zHXnXyO5/3Tc/9xP1Lzv2VP/y9Cz7zvve9FXzs45f1cHb8iOo9/ETeBngTtMNZK2LqcBIxoaS+kkYp7XhC7IMCHngOjM9Pm4rToLNEBJdodX5xXHWSRL+2F4LqDAT40fzr/op1/YoDOA0ypm1Cz6Bh4RLHCWzsWsF5UQzCf5Y+RwCFYMJVkoD+kBhoaZ3QDwAw5wsbcYwhwFkIPM6BCrLBSoNERVSskXY9OmRaJUPQK9JiOb3uF3Mg7qcrcltk6XrSMFBJK5u+HQbgU2YHbZMwnfmJZpbI9tbWCrc5ABFA3+ytarrnLAKgYQGBWePQ59g/LhlSj4kA6b4HW28oKYA3JpX/up1LwEHZjdPwtFZbTSdyqrupJ4WN/6mDK7qmhMeD2uziku/0ZVGulYDJaN2qiwv9+EoZt+ZtMAoa4q4B0I8mSidkSJmrb4RPPmdQ987OxbECbE4P2xip6WJyqMi+H3klntJn3Q/adxDFGDOhECsAZEzwVfN5nUB9MUEA7y7rlm+0HbExRLzDUC5DQKkinWuoWq3uF9V+Ue6/ocHUoS9znjQ/aA63lV7yzDmaMANFwJFUPOlRQdnyopxBR1LWM2iC/jkmlsRFjJnvctOnIkZzoO0B+gGu+/5sTs+GiOQczjntISIXwx6jFzKE3wDzx+Xmj+Zj5Ljjn2OGN+bmgkK0ewK/9VCSBvnZ1HwC66L5oM4Fep7ugcJkVlRGRizzDgk1/cpknpvvGuv6VhQmgDIyyYEuBDnChsDUjJnTagMYZm8etth/mUFZnUtuiOdb+EOuEopvMY1tFl2iF0WZlZeclwUcnlZJiY4zGTogh8nPbTKcbXpT7uK4oWtIjfEImtWsNGPyaU1mLNPgnxOJ/ZRyxkjIFc2B9jmEAJDn93+azigZxlY1RV12tLcEPs0Y57iQC0xqbtgOn5bQ2OjuZhh6hUGcweyNWgw4SbkOGzdjcT30AMyMBBd9xsr5fKlMqijDBUfr7AUIrVpOvgc9bGoDxjoXCeVvvzummiqmhrflgGnnuCGXLvQSxLCy5YRFNcfHBrqJ3z5+LI7F4ekzh7Gue1/3d77++Fd/5vNefp+LLv925ycz69prr92/4oorDk7cfMPV5114yQe/65d+8Lu/8xd/4Kvf+s4/PHPB8Qv2Dk8eLt/wuV9z6jue9qIrM/P1fd0kFxaEB4d6vAAkNojt4DcF+wi9YqDdhli78Ywp+/PEui/gDbyIIJtokFLIpC2OA4mLToLZTrgNOv74ZrHjpuhpix4CgQXlQBI8aITDqygASFZ/H7NnxPDiqY/QFgQ6RuG1igbikIE0wL/lnTkeDgu1MdHxbRANJiudU7FD40EOpoqKTpzXGZyZfIq2xLwmM49PLHY8KBNjUCj2cQoI5zmwp8wStommhasfxbPZr/UkGQiSwcTiUslUMTGS4xW2wY7D4GvnfkrIILYfde2irMViDGkLgnXMosTnttpMsATZqyyj1TDDkjzlPrB3gCBAcTKJHT52Px5gxMNqtkE72BkGdqsgx7C5QPMR24c9sPlTsVmB3JLaPuHQtMinlg6cWJUb83XCXFvrYShrOXbyBD1A/5ClF/zyUIQdYdMUdZSYTtLNsQ6GpkO074y81ihLjVOWZEToNSaBAAsfAKZuRKcGVeicnAtLl9A0ZpQEUxv/9VngY91QhCj00IlkqMD9F7IRb3R5wQgZ4MUJMQVsZ1eylnyQjI/EJI2OYrzhdscp9BjOwO1KR73wpaiAOdCfK2BydrcfNRetzchwzJWmnHEENsPGU+AiUadNMGU4mEYfQUcfKS38k8heHYztF9AwFznNV4KnzZeVetBL2rmGb+M0Bws9O8vWoiSLdHn00w2AL+3g2i4a8jvKTyt8bSYxI1kPPNlLiq1JABujCdkI4QwjC9rD/x2NHbS6JIRCrIDwTQcREbWuhg2uL48xIFkJvaLORs+tn2njGPwGtguYCMtzgqI0nk12FdPqH/F0e86GvwjbkIkvM7QDymxVvtBypr00MWn+4VK23NVfuTDgbWmdFceFvAdNKjoxH1+xNWGxrmWxXpApeGs6VrQ1FGcjYFPCV6prVt6GN7PpyX7KhKwCTrZpq3ruBMRb+RcLWhq85yWIJS3/kJ9xbuqtj1AgGDptzNC8EYF27iQBh/SpEd54CtsJvwjfDQLYrIU/lGiNqsjDIYvl2H6cOnPy8LKLL9t77qc/9Q/+2VO+7gfOyvzhuCb26qqRWWRmVdWSmQfX33rT5593/kUPedGPvuyCX3nn67/mPTd94Mxy1v7eOWedvfzzL/knf/Yln3HlCzPz9de87ZrjVz3gqjOZs8VqhXA9NGGLYQq0IEBxysTHYYbeasVK0F8YbAqPXYaSLJxFFB8eoi0fSI3bAHCcsiaEdWIoI0sbl/ZFpVrAsN9g6DDYAkgYaLgDz3WwATgsaFEHc7VOK7pvPHWiJAk841crAhMF55wm+numfFDcC4jvllgGJAB4exWGBUz1fOxkmnwKW0eB3CYn6+QgiaLeoPuIkRSvSLqTCCnXUiBBiYlvkPC7Xcqlk2r1+ZXAjH/XVTQzEGHbNwDFZcArAYC4Tjam4Y2DCoKhimPxNvU5qu0WICHKZCNY1Vy9SGsQhXrbz5T4S4dYTRemoTCbPF/+BLVtAt1sr8aAyZ9jouiNmsZiJ9tkME3VNuGr5uQaBPQF2Foc6TKYfWcGepxofmE7IoA3KGK0uDCuW8HPZBWABdhEN4pKQuRKOX27C0QmmBbKBC9QKXGF92qGkl/JIjRfjCIAdl1NX4u2u8tp9oOgNbfUsG072vdoefRprQr5zghcK8hb1QSBx3qX0pKrCXVMn0O/ig+e1Hi3F8kuNQ7ZMuaY+gt+YihsYxE3Wj5edE0LT7VwQQHYzssLCXiSPu4EQaMrw2ZDxJL/s4hmMmVjh1pxElp/740hKj91HfCBvjUnNtauml2dMm57gE8RB63hYWqeUzYbzugM2COK+xj0rtM10gPZaoUkx2jesHLYw2vrVynOGGZhB4qaKyv1B0yKyFnHoH6Dd9RL3/JCf6n5/WmKX8vAeMdEX2a3AlSYMU5eiS0puwFt7gAR5nsKRh5X4GP4MYZJ4pb8kBT0cDX5Ib4QTnZ8o4E19tEfQZPScS/w/b76iOgndbbNTjKJBjYPMlucJfjxeryEUM1eKiEybPcNchbGDWDothkpPKa/l/l565UPsEFx7U4DvGwbnXy9bCAbdG7WeAPe/JWNDS/kfTiLWwmsT9lm9tPzm8LqGLHNNbL1rW3FwB/HySWqVtqV6wi5CtXlWGOrh1xx9twYkAIMJt6mbCOj8/7U+el6hQylA7UhSSgxxl1LzzTobLbm3ADZXtVoluxVxFl5PE6euOX05R/7ccdf/KQv//1vfuzzX3TDDTe8/aprrtm75qqrVhRzVUPap07d/syzjp37qJe8+ge+6NW/+wuXn7j1tsM6ONz7lE+6z/L1T/+qV33JZ1z5x++76UMnX1q1XBVxsC0GI6wglBda8tDMQe5D0dXKMhACMw74FChGb8EZ6Mxlu1nNZJYtsFYuk76KCLwMvB3J9M6khXCy4omjw2BqDYFayI9mcJ8u6Xng/HZCyvGworEkluoQWxh9Bm8MXNFOgWnHeNyaZvKFHKdkKkavZyFI2Zgo7gJQAJgHUUsooeR6UxTuwminr1VgpoQWxXHBH6cA2pbEjmutCJ+hXITqLSWp6IwZkBQMykB4aU6gG4BUdIHJzm0EgWwYTrKTmA12g481shYVa5H9rijTY1NjmMOVJdDN7pzZzTQ9/+7A0I0RBFpuN4L+FS+7AdOEsMCF/gCwoEErJx6IBnBaoCjYxBx85E9tizPs0bagEnYRALTteQoU4ENFPxhTQl+S3WZcBkc2LCrUrKkNp0V7oc6gP8qOpbL+LekAjxih35IeGJXwouwr4Ce65aCB2NWygX8mcQgiQAAa/owcVvauRhUTuLV9CE9lbLzxlR0VpCEfgKeVkjPaIfFMuK/mcXKe4DGIqPQ3u8eai5hVIR5sTEMoWGIgaYiwFTijJdIwuZtURfKadyZ1RT1gC/vww4X2B7/QfTIhmwteosQkIiqWyBpPlcVDfSqMLrsQMXSnGI4wn7KEO3UtExj7KfWaMtxuG3lRgCIZHLJL+qAwxHypgH1IoksP7yYUaeVDHteyJiaoobPzICT4REAuJgyzxzLdDdIXFQAef1LjeWNxkAKLnJtDQ1/me83cWmvvSsjAy6PXwL2TUi12oUyrGtiZEsKJUYWWrgs+M2IOHFHj6YIx4rsKqWF02qrqPjT0y5e9gyazAoFvyqcpfy++BHR8UBWvYfoqC0NyDxPs+KSVbpkniGXsSOhAdgSk9CW3tIadGikRapqsxBXL8QMNLxa4wG/qTk95HHYr4/Zmjzc5hyyIMAxo5X+YjpFT48N7fBFH4J+EMBgMMF/YiWEG/bohobDbYxUustAexie8hB8ClxPabyuzArr8bwaz8fvKxoTjTct5WWKxXKPC5kPeYXbPnClx72MqbkPmEdYoMeVIINNYsA3OPuGtX1fkTc+LCFuVTuIwPCUpm1ULFFI2eQQeKAQ15tJmhFNZFcu6xH7uxcnbb14/7QGffvxlz/y693ze/R/9RSdOnPjQ3l32Ln311VffGnqKaL323e8+fuLjT3zr4dlnH/97//6lX/ojr33VZfvHj5+5s26Lz/70xxz7jmd//Wsef+9Pf9P1t9389ntccrffiIh4WRz9YUEoQy4JcTXlQpjALLoswEHMAZQjkKT3KEhSItjhsRrelFQxbfWpIqAyMU27EqfZ7zgOPwRYckHLaHTg8eX9ySehvFY8V6m2gZeXVwt1megYg3ThMSxU8u0lqtU7VtmbcwvdPhQg6E4Uj8W6BPa1Zy5ju0eEZN6FnlYEzCEh+XXQkWnXZUXWGHutkeQzgTB9V3UzIfVstmlVxrs8FhEqEIQtEABIlqCMpyYElNP3CY6ELiYjIFwzAVQgwli4Z27Y5joKV65eIwFteys3KBVknCvVD4NpIYgG/5a50XLMhAg6KY79vh9do4wEOjB3iSSXPWhV3xNnfuvJJcaxttb4yrqQTatsJp0i8h4FP5pSEc4rd4MgQH/aqUYXQmGTiwQqPciFVFP8xVFq2DGp3SSl43rY7/hJzEk/X7QMmWHmTUfTOB4/io2V6eWEwcg1/CLNr2vGzTK9T8UKbBDHLJiGSWf4rLATyT2NMkKFYplewB18oXXDRgtltQFeyBsJCfAS1zSGMvKiUwTe4ZeQY1GUwSYc/SV5jPWSy7/Wxp+2CPNV8MuVGoq242Gb8hQzGovJE/yJBNr7eSmV1pPphckcisiE+GCLESjgfVVk3CaclNMgG0VtTddCntwjCdsNxIox6pKLFdxjHjw8baiiNi7TDb+ALBsTMqYmBEWpKtnq2ZxPgb20PJkKbxp5sIep4De6/Ri29ZHW1CllchDeYj/jKAB9Z5CKTbxr2wvSsVIyds8swRUKs2HzEMbCAQltvzReW3soxZSin0ho7j7uXEPkvWsogTSFlCSwKwEDTcUG8QBjWwLbevfAQF9LjTfvJnOs988c37RbBczpu4B6rbnj4+tP4DMtys4tDjvH4NK48NMYfqn7TdXM0GKJshKanyeOGwlNqFN9/iL9RjjE5oZ86XTkd0GfYOHX2MR7H3Ngfva7mqr5xwopdM4c0gKYGoARWDEtMol5sxsXoNPAF3afQmKgha6HPrEgYDKtxsWwpiJjAPxF07HW6BgKO1CTRrphztqeOOElbUf/lism7BxgEXU//vYCeqcpCA7bpya3zYz9vaVO3X5bfeYDHr587dO+/B993v0fXX9xwwcv+PjL7v6OiLg+hg1URMS1VftXZN75lydufuNLXvWyV/3ob/zopccuPX+97cbr45lXPPvYtz376370oXe7z2+/+T1/+JOPus+DP9hbS3deLIKPVghXnOOKMkYCzoyuFexwBqftp+jwZmkUwBKLVeOY05pTm+ukpNyZax4/p2/a6ItmNbHlq0IMHhFmAL1iYNFzch4AJII6HN3sB9d4MPOA6fcULTB0qiPbwZeedwwK549AUVCcx5N7SG0tvawYXVLSkYF9cINX2D26s505LpE0cDZWGCQrtFrafLY8RqDEexktwE32laMjmzl1X+XHKn4HJmXoXtbJaOYLQ6bMsGBOSjlC32sIXEkoikMvcE2/1IPOx2mUmeGgfKuBbR6m/9ZN2MkvWvcAWRyixCGhtO+MD+gqIYOmyeQtexfdXM1GQ8TYd4fiyiISCMdCBDlLCLlHH0VwFfkf/I1mBGx7BOPRrZ/xCaSv87GeBw97WeAf2+s0wNA/kgDFNsoXEtVKnXBj8cKvjP0GLRTu3PLXWzazik/+ZYET66ahIjl7UBYnjkmifYZn33CHBhKCZOkcsAY6nRm3qe7W1irat/LHD+0csFMwB7rbfZBNFLMJ3UMSMe6jwTnmP8Cmvgw15hJ4CNfAi3XNWJaif8mHeiS8FH11GCk2SFggRIVvAQcmKgExUaRUqJVFchwoAsd8EJydNeFHMClaevDiJNuJjTUMmcJeNZoqfKcNizaoAIlborhKqQMeQb16lqBJgfxbXBI8qmCeBGfQDt8rY67MfpeMqTiqaD9rpoTRkr6kYbGplO5b3RoZKFBn2/Bmhkc28D1tY2SAhx2sga2Ic+5QweZLBKpQ6goPbbNgM9lyRcay6HpM6/xAxKC5tmprImUTQNDFZsF53WD1NyWY7sDvLBuVVKWtUQZe0nHARxiAHACTlxo302z+MTTSlJOis1+JhQtsvMl+09U51Z60rLTzm1bG4onKCjX/+1pUPVaEr95wtfR+5FnTLIx3bK60Dvni+GiFrbPo+QufTI3cXE2QZaufKac1M2eyaJhZnqMMOvSaM5exNQinrllSFUlBWO7OJoGUiJg9FbYRUl5YKRTNK/822yTadPyc3wyycTA1tSOFDxFlD1aL2F8zlljq1Klb48pHX7m8+Irnf8VT7vuZr3j/b15zztd/1tV3VHdO+p7B/Lf/9t/uX5F55kOnb33MP77m5T/z4//lmnPOP/uiw5tOfODw+Z///OPf+bRv/HefePHdvvJ7f/77znrxlS++s6r2MhNvmT7yo3sIXT54ul4T7l2xGVBk4KNrbsBV7pDVspy0F+oK95855uK7mzpLRYHDj1BYc6CLRq+c7lom0QS43qolgtgjMVBGsbHwiUyKI0jaMlAE8V6ExAYvg73Uao0So6I3jOAzklxuG2xUGDiQ0zvexsxL9JIehcrtIoH1QDgyktbClWEb0UKrdwI8Poilda0iHDwHdc7V19aKVlKRPFgHGsVvud/UBJBrVCzQs9sNE77s1cNlskPdW2i24PTyO3RwBQrDPrvQ6ERZ9wJUb83j6bQdQI16upYsIRFabOWiBA4oHEfyWtPYM8Am6fagAQpQOKy1BlfTkGQzkq/25NXsBxe1hXQRjC2+S8tHby1glIy0oiLN74Yk9bCpoo+0blEMtn0N/awiD8GjRgIfbVMe5GHPAdOk72ls+DB1HaHXQdBlYfcGQbSt1vUi+dJPc42KfgdZBDVdpUaFLBLU4CEA7X80TnVLaRtr9b1O/STDMuwMCWgEEYJd8968LljpGPKlvygsTfaKcdmNZTPDus7gxbDXY4NkVSwiOfSu+7bciwUccRFxxfyMxZECA4YO3IMxPaCoEKrDkpy19T6UvUSM3QD0R7C2UI+Ye9AN+x+NNWKp+VCSqOhzjIeI0H01YTpXHBsrUa0DFOqrVrcjrGkCalbgaxE/eL9NZMSiOKQmpnYDEKkYRiqwMka8i5E8rnOlYnGldTnuXgvEj/mjApGrXMCdnlcxUasCtFfGEwy/+yAZaHEtFBm9vlmyFVJuuyUEGBZbAlFUjTE8YRvgAgxXA3klnZR5msxgkBPgdYFd1pxpfuh7qpY7jmCsGjgNDG25F9+dJ9vVzwRcBIrNIbuFGEJpFsjucYC1+Ldkp7ZEQHFSlm0Lft8roGsc8tUhy5oM4rgi1PqaQqWf33ImjZbAuxqgoyzpapo4hO5aL+jcbMlYyorYmost+AVlUGQ0CEVpciWOdNQgXlqsyI4ja/t5jNhLPdCQVWRpxXDGsGF+OfnEiPkx7WgI8LJmRNo2aeiVCxdjNVKFpuWVOWxrag7XmAf+qwc5eZMHRWEJS6l7NHmKfqjcaHIXqjTX4tYizxeBdZN/ZjKvITkJA2u7sNd3QZ5wrGpZe32w1FipDVgV48SQUUbEuhd1+vab4jmPf+7BNz31q174yMvv/8pr3nbN8asfOIpBv+ev48aZ95+46fFf9x++83X/8bd/+tjZF5233nTDh5evfMZX7H3PVS/5FxfG8V/6x3/wquMvfuDVd/b1f2UxGGEF4WLCg3wIQqUgrfsvZLh0+Cj9EQoBDGS4rkLJL+bI4cJ8WIb58fihJ4JS+CR0Q3sEOwwMIgZ1UBqccnxrwcINqmMX16bK5gfGtBDm5HUkzujATHvj04sHgHMCEcf5eAS67Zdm4GTii+i4bhxDBontL+TeAkuAnz6e1DsEJzBfesuOHi+N68t4SwJN9Pxrd57CVlwo/1DRA+DV2CKFiqwc4GKBQStRKkJpp7isdE8YnvA420sGig8zqYDWMzC2hyuAb+l6KZgRiwmTPcpMAITrDbiEmDPYlAdKs0XoDjGj+eaWTbet5ptbnQi0xS6gABoFpo1dBtQMZyJeyS4cQTTQ5x0TmoGRaM1FCOjO2rwynAk4Vs4sHTE5obiQHSiAAw8yKmqRbFyPetJtW6QVcFzNW1pfBPVsW/YUfEgciS+bPLK8qOhk0+ZBoJdfYwVOyf/gLTUuzjO7k3kjgCFhBtrBXGV3wJkA7rfWdp7gSyw0efb1smMvJ83eUQAyNlhxRnoTKqFOIS/SDv1b/88fdkE64Cj9Kcqy/xZw8hwly0U+ZRsq+ITLqZjC8XGs/SNN9skBg1qHQkgCEtu+X462XPy+WDgMR3W7HzCwGjZKbsJXx5qWB3DAcD5TfjHf6xWMW1vZ8Tj8MUq25vo1bEmuSDhKV2TuBTAls+ZFZdoW2jEqfnCSx2KUNmlxgasx1dLJ9mck0gW7xb1qY7yFeZrufYJhKbGEHA1zGx5jQRwDMBR+8DpMCFtUf8JsiTPJlvU2SlMujjH+iF56hDUVcBl8EOfXAiFgXE/oY/KvDMeKkHymmKBz6IqN9diIxtVfFGEt++JL7q2cp19tCrumDcW3LXLNcZZyCmLovOtKvo4HoYivCO6e6zjGe3QN72jns9kE2hnb+84xVnJeYFsjYRmdekfSjENRk01H4wXyzJEztu8bXviuqblBhmkk76A9695s2PTS19eCQtULvgw9vCmY23jePXI4z9dBgGyN8zvOuOZIMySS/G4DwQ6KlPXkcMD75sWxB/HOrVyLJ2PWYwdLZMR66s4TyzMf9fRT/+a5L3nV3c675K3x0pcu8Y44HCSMVcHMrBMnTnzMWXt7n/ynJ284fMlPft8vvOp1P7V/4QXnH9580w35xIc8/vZ/9sxv/AcXxvEfz8zTVZUv6+vjf+Czv3vIAGySsypfD5CeaCkRssDmQGNBYzLoI2iYAnSa8riE2IJnQDPQjjD10puBaE2GDIVO3PzlstDYDJW0YwAAFaboGuodsll9ZsN1S0Aiw5/iBnU54HiHE/QqIYCoVhVS7PBr5qkLTKIUTL2gIaC3mLNED4zc7xukenPR+wmroQQgldjm2uLGvvcIFRY1ywm84I+lDPioYyGvv/y3GlAQcEHnttoDACRuqAhPuiFbEZVNL23kSDtoL6ColQAL3RZe57Zf4BPdUgRjBu7ufqUoj14ZMMWOK1K+yO4kiMhurTT9o3HGdoNBYlHOKNrhguCXfGaE7vMMggYSfn3RUpkSmgxsvcKl4H3YYVLW0fxoU4H0QTp67kVuaz6bZgdBWaztI0vkuB8CiXxjnWXurUYlDW4ugz74Wop3GgmK1aQuEVxYoMC/4T/tr7wuR6OpjV1y2+lYm7KgelDmsYH2DbzVMaFb9ZMLZUe0degK+kngoMnFcS9hU1b4U79zEysyutCbi2zrfmheyBOW0bGDSU6g0IRtYzwk8axCZG9FRBSmtUwWOlGKfBwK0eH6cLullaedA0yA2YQPs4a91S48RjJZypZV3wsNfZC3CO2HyuHzxHfybA62TV7X8d1wIyR8hm8ThgyG9RA5sxKKBxjd17KITKqERRpllbhM2B6hPKDlbBUb7ZbnN9lsrLbPg5aRqOp+zEica02ipBrHc8ecS2L0lrYMgi/4hp2KwmADCMOyUsCERfmpkcZhx3e+723Bm1T7Cb8FFgw/YKAciyeZwpKuN2ApiSskFeLG5Y3nOOZN24AJ2OIA4xDHsNE9TuBvB9+eEM2RqYGLa4nBQzF8Wiah2IvYDL3WSX5ppEeE8pdIYcHwyfal5hvIOKwE75VOnDx4tQYEZW4o1KxRwOnCMcLSZIdVKOI27FzuPcZde62ZTTsTLfNmHrBYjPxBsmPYbMwdY+mWoYzoxY6Uf1C/nTeViB233azEOeYeVqSTzszAu68HTsJeXWvKaxR3jF/YDvQDuqsxycQtY4DXC8sdLzxPaQAaK/x7S9158pbl7zz2OSd/4Iv+fz9y0d7Zv/VbN7z7j+vbvi18Va+LuvyjP/qjmz7pAQ855/te9//8zCt+7UfOucvFF9fN17+vnvuUq/f+5fO+/TWXHr/g2J9+6E8vqarrM+L/dVXQP0dvGQWnwueo7ZWlVADdDGiKycxkUGBql4hJoZvka1zqTlK9qgvn8HQkeO3Um4L1E0g3nmDXpxtAdnAo3OcEZ0xuGYvqZ4DluHZ3RFCRXM3Cde5UeGw+HlBAYJzo7OCUEdgWtJhlahvG+IUdkpSMJ0C1YFcteyZSVTFtYWxnKpPvYsGIJzLRSxZ+gubkShQsh6tk7ZwOKL7qYtV4gBLcazhEtlgjRwbr+X8kcRETBBTgiRguH4fGvR3rBniQIJK+sDEJNhgjycLOairs2lY9Sbcl0trKEAJ3gFhPtjIagSSBJx+6YS7QGzNV4JoeNk4VQc0baPfRpaQekNDrQQyMtC+zZXR6x0kCXUdmfwgJPnhYB7vvWVN3FfbrDyhgImI2DFoSBTf1336pG26DHeaEfFMBJU0wxAjJbQZUm6OpYX3m9lWGAdDflJRCB7BhKL23kft006oEOr3jhMHSisYsbcsRGOzh4VbyH52jBn3Jbr3oKDQUTRT2RwGn4NfRuE8CcnJZp8NzV8cPN1/YIv2jfVI2y31cO5YOWlkrVT9pEtwX8F28UUQsriLQ/LCbUuiMEzpj2gzuLBjUrMR+ndrRxlYsIU9uWXIZW7yQsaqJOO++mQzZVl7ZqrIdPWkqgYwx0oZGARD1PmFTf+3XjuvL5Jzm8yP/WPBd+6EXq1Pfs+nNHnOshoEetE3WjqPj+ELsbv9JxW5PeGbJYUJoL8ZdKEv786pCcPiH3tIq4RXVpCe+BuPV8MvGkEX2qKYc/9Ex+qhjoukdp8IXasRB2h54TAEkduTxs0jD1KqSH/p3n0pavccwLmliVuAxBUB+IC/FfaOReGl2FIiHsulYcjMvhkFTXUXMkKHkhFjrPQjZvKx42BtkoYPcpumA1ZivBVwYLkYCHrYMUnYx338X4x7SKO1QYI4LfSdf82YSJSGIdWzUATs7Bq/M/tsmUYhBXoxDwZgwpXNIINBgM9jlPxTRvII7Dq4mj6Bt4Om8SzcJKoTtOY3ieIoY5PiVYRroE/GXsK0lgwA1yRHhhexUxt7BEllRd566NZ//pC+67Xuf+y3/8aI49jtf+NNf+GOvvvrVhz5AVe1FRNx84uZnXHT+RQ/8pp/63he/4rU/du7FZ196eONN769nPfk5+9/53G/5vz723Iu+9tVvv+6cqx94xW2lLQD/w5/5tRPOCCNdM1pwoNlhsSnBXyeRFK5ORI9SyUyLGs6wqRSnvwDEfRpBmO+N827aYobhEQD09Zlr/5Mbw0BgMiNWB0vbOlYLMgQhJrYZvsUQQZJdXHavxvbH5MqefNxXCKpZQQE0iCqCIEE7lVzWAvkXT1dssq0PBFC5iz/GH5Ty/pRcVMiQl1nx6CCPecd5C7byeOJSXMcaTlgC6Pl+OmhfdlORDIRcyeGDJtpWkZhkUC/u5mMgJKPqtjHeNDO65yWC29Y8ebdXmsicffUOcia6B1OYlqW6rbREZCGWXOix2iyE2wayhuknZWcJUyoZ1EuoLTCZVGHHADYVI0G5Yv2HttpybGcxgAAwd4HRr0VQEMWQSToBmEq+zCdK5yT80kzPe6nJMXoa2H4SSSJNrxgI2KJEyLw451WdiSYWQY0xBTlhYOgBFmh4Zk2UGXcQuqq7o7bSY4+Hol4afzwcsWwHnctmVYE6apudGjQIdGnYVxNmOMZBZkO2sC8Vh8BiT3qH7bTOkJjnSqVm22OFUgHzPGK1ElU4fNtPjwOay65nrrKJPTyjMTwMlyLSsFDqWA0zi4V1CI/oexl8wkkLwZud5JDNoiSNVdXb74MTa2VXq1nCoZqSTTah0qUZs91N+Oh4VZTftHq1NLIDNEEOWbTxtv7ms5R0RhHQZ7rBs5jnlBoBQdrgs2FPPoTMh1dQB65ta7wl+EPB2Bi8RkTyNRB0To6f3qCCLBZhhI9JeWbEAp/wjtYUB4a++GqKTPI46It5XvhlTutjQVCIoL0PWiwuGO/AwIbD8JVF2TIKWDTkUhgewN++xaPVy+IJZFhciRjyWHmouUTxWqI9pvEwjujFL0IcyZarzgWrkQ/iUiUDiiHjcM75fkmsOl1PvuZ1ZbGJO9zGBdkBcfhBmUiK7pI9N9+P3TLbFpxtwHAe2gGJtB0CY/qOHZa/1DqaE2NcZWjJ88BnUk8DVxAHFUMkRhWciFD00E6m0fTAczDY9A9fKLBmr2GF4qs17lt4fCBk6X3cg23sBDT/b0Gua8+KobCLwM+LiH6kF+suPiOAsgFt0hPuX669pU7fcdv6FU/7sju+/znf8mPH9vLNr/j9V/74NVdd02yo0sJKYVVd/D2/+spv/JfX/vvzj110wXrjTTfmUx/z9L2XPfsb/9V9L/rYn8+xPfG27T2H/6MfNXVKTLopk0F4Qal6JthG0KiTg8lY+wQGWK/Apw+CWgFTe76+PDLmzkLZF8YHjA2FFTpi4G38V1QYDJ2+FJqDIK71cSYxZSSMbYtKkj2EVvBg0JGNvliCN3ECMAEA4xcY2zqyGCTWAV4hhpZxZiy9EXAJvAg0InMlAPl+9lySr5Jo1oIdy/QkA8Wcuv3OVtQYS6gcMW7a1U3uSvJwGQKLpRwNMou1HD3ZZI6KDiWCKZIEsxtiBmjNsCRXcucqixTf8hnn8ontIn2OsaCS2NtFGhmwZIWOBtCk4i1mJ3ko+yYTIA87AhUGRPgukZgX9eNd70EvgFpPGR6jrUcUg0Uf9aIS/jRMUFKBL2WMQG+wTpLmFS/xwuS6Nn7ZlsJi0NiPKK6e6KZ+0SnFdVCw5YSCHa7UHpPniPGwngGDNc2ZTQR40DmyZ21zGW0MJIqzTqPPgRrR3NFqHSWTI+DipcmcL9HJXmI8NCnat4BjW57tydJhxWA0lIToishBN/HE5Y8CI0Mo0lLtrSdT973tLhALHKOgpMWg3fGHIDnwODsoYNFs0N1yYZI7dI54Ih+VPVmEV8whb80/4lep4LW6t+Ux+zEvjZrPX0zhAR55cvg9e6Ir6Y9FHfZ8CgLU3cAgCKYaE1r2iCPldmD2svErCCTTH1wWgh1cjwaAlGFfuoe3zTDuKJ7NCWwR8wa98gMJE4X7JPUeDfLsVQ74NeSTvbLZ/HlcrRxySgi4x0hiEmwejRFt5RZcyleGyaZhGQJ/izhh7mq5+dN2Yds4j3J2awY41XwrCVs3Ob6T+hBHch4jNw0D2H8XNn2bWfChUMRWYUIuyf489AReAOqTmUGXKSThvPAFC3GglXjpI2ExgM0LZp6kQX0BXx0jsgW8bIrdPTTtLSfqwUQgF+PAWTMP/gFIlR6wBhwg/iDepDx/HS+eDTQXyBobYP00UsOkink3oLsocdnHIoaUYlOBRsi35UP1yAeY19Hemv5Vq3YRRV+KjLESDMwn48gvUvnSpukOGZtQHabmWELMQZzu/xhr8EfbTHXstJjgEOfxBD89D4jAqmjGWesSxw9yPXP7zfW1T/uKvR/4wpf8xHK4vvmVv/+HP/7Cz3jhQUQUirlrrrlmLyLiwzd9+PFV9YLv/+UfffnLfuL7zt/fP+fw5OFt6+Mf+ejlO57z9T/24Ms+8R9m5n9hY+N/ohiM2KzyT5YwWa05fEgYEbkdIGYN+GEDHJzXwW3Y1kpAx6VTl6Xg/JuBpz9TWnU7mfjqyzIjukOgxKngg0wwFCCG2gXmOHG1c0CQJbS4knSv/X0/Uh4OPcm9KA5ctWQoscwMvBcGiWvf1DJGb0eUzAZIjCJrkTQazKsKb5yIqn6Z+JShzoBCE88BOCNwBR/VzyBYYaGtZQyBJ5yscGoAGCCH1RKviHGvF1MXABL+3BSFRQTos5aFwUrgpC48ktqq1cJGkUZSNXVjg/ZGgJCl0LYINpHTZYHzGlSnAtI+sD/f1ph4NYBnwj1eLgvfbTTdPD4FDhWD8sjhEwTNxModZBGBgh6JFGwUUqumpWwefJh4hemgIkYPT9Y1/BhBAPbbiUHYdQU6OYMFXrE7dQ0RdCZ/RnDox2jD9CmTOYRERT9PMTVktq9FWSEeUciIKplIozFiz8K3ugABVpZkPeFQsRPT/IutGkWu0jsp77lh7y6zpk8FI2eyz6xHCAh6o3yIv23P7IyuZm/wV8kQSR13J1SPOsW1MpLNkFL2DWpUolKwnUzovaPyWitYM0YxPXEMSUaMrekyEDZUSE5xLvJXwGyRDANeN7OoSRTEMTYXkAAhsBjeAV/ULPLoaRhesHP4QbBYWquG+y/SIxIwrMArtJp3tP2gu0kdC4h38NFDDPAGUvYGGXwrW3BMPrN9Bd8taFa2yMtki/iXTXGBNjR5ou1fDcbisRHblsVjgXQsbDF59wpQ8d+x6uHscqXHmsiQkcc4xAfgbJViC93YVnjHzyV6i1CgMcawVRTeWPXgvDZm6wOhBd+iQIWvtiENrXnO1as923yNegfGOYbSnlUIStZJf9jGyTnLQnupac6Y7kPNCKvfgFc52SEbbkZzcf6+uErXtY/zO3WGZgBhEUNjlr2QNytE4P9oAMmUqc8lxlPbl8TrGhStEFMGv6vpoXlx0JpoAR8b+SbiwxorZAGZlSswAv2maYcDVGSr88Ts1hPl1D+pu7Dr+KPIi/AgRrNmi8kx/J1PVOUX7ceR3UzdYr7mgs2VqRicTGoGftGRumHUDd5cIg73ok7deSK/6Zn/IP/l1f/oK8+K5ZXP//nn/9hXPexhZwbrCnpXXXXVGhF52UWXvf4Vb/ipl7/kF77/4ji2HJ6+/WQ86OM/df/bnvm1r/yMu9/vzb/37t+77Nprr13+ZwtBfGzLaNoqV1sMK25UxzAMCWLo1JIFubMkFjEbpAE1glLEsnkJuf6paWRPBtxLNh/7rgy8kYDtXj8UqKKwjaX9GgnwRvsxMQk5NpX0AVLsvC2B98yRqwaVytT7hCosmUWSw4E1C5yPgA1icTs55L42nzLWiurXEbQxT1UvJwrbMxJMTKkZnI7z50Cw8s8uPkvdVQKFtVuKZ4sEFZdeGECmKUCHvgDKQCQUoVB3JSUQkBKLruq3jpQBJ4fQZ7N9fQJTsOZQQz4z/KElVBmki6CVZWM3f1XaoRnz/NJf89TJwsLAou/0omZ3VLC8Samzk/N+PDq3bSQsoCmAbrlCl2TbGaGJ9T9qLMlax3UZYfcu4KceVW3P0QMJG/vRipR5I69PbR9JXUVz32BOtn/SbrEo4FjgLjleahjetR33E+D1JuP+VCQ7nvQqAsE4+vuKKOyX7zH15NDgWNy2XsOWRyLg5SXEOfuVXFVdWzBkr0GbRym7fnKQ8BEZQ2DwTC7bV9N8IU1XkD5042NilUNuJp91/CAOBOZBQiGfxbalaewIykw/+8mdpfPGJpJZrsO/VPhHy4f+upjNBGymbDasom0+2D2M+LyRvTBuVXMCZ3WMd58JcunyGQSxYUULw2Ur9QMnGGf464yKeBf+d+ASszrBh+GJiqFMbFFc6UuxZvew0uydu+1DW0NMo8RCNTEcC5XIVvgrMqLPgw6FDcqTkARKCn3W7PztP+a/ATMdeAfbGq7nNjLH5zWlFb8nHQ3eLG85WE5S0t/GOmb9oIlD9bkVhDACl3FVXudwpxP8WQ7upkP5FHSjID+ZTZCC2vCWGoxTGg4g5yAOJCHU69koyJXmhWkl+tKzr/062APfSpAR8/Z+2Y2oGCcWbHd6fQnGOCLGpRYwMBr0PmOeCmr6aYZ06l7t+IzvEON53DG8tlP19L0rLIq2baqyGVtiqDd4jj8hF++7DE9BQ8AQkx2TL7sjzKWujM+aNi4CsyrGPyueR17e86xFeVQIz0ELMSQyjq0ZsS515uD2+IZnv+jgO5/5jT96550HHzj77GO/UTUeZeUFXVVlXn31spd7h9/9Cz/8w9/zyz94/p0Hdx5U1XL55fdYvulJL/xPj/v4h33Xz/y3n3nfs+7/rBO13Qv/P/FRQZgAruZmU1DpbwUN745xGDfCkHBhtMxrSmUSTzCvd6VsHUjAiyMIXrNRcr4QW1PA5lAOicHkbgojZACBxs5BMAHJ6WMtLPRCIlTAw/HFvqTjOi9IUktAakBBA2envxjUu/HbvyOwdQcucyTvfLGaCiY8T1gdUQ8bxe8zrLhpWjNST1QL0wvQY9Iew29wa1frjvfE2chTUd/E6r65ovgm82oaobWp0wrp4ZUapsfA496jixzXRglSpm8KQKKnue7aXXfGeGWKXqreigibRx0u+JOBFbyq9+U7hlP25St/aY+n9lCbkxwyKvRUhLSX2hbHlBDSSCrZdOakFrMM8gfbycAqHBJiJBpGN6yxxBrfNUZcQjNrchrJ3fyL4alEE0UGG4AfVBotZvtGm5KB0rnAqJrt1JOflX8LO/17NROkf8EzcMeLlQg+TFcZjTNvepiP8MFQzfOEDy0rnOf2qjjRDRrwYrrcFofSqMWLKNo75S/qOD6x1eQz6Mb41bHM9G44I1pAm82SbUPAwYKlGH55k8b0nKFCcedeQWBvT8SELQwPeUWRXteRGoHSVTT2Z8t1pQGpwHTdrNPT/1IMNF2OMXia7WheLFNhBL0rEDrQu39Mv/TUwnO/jwpOMuTBElmSh8y70QW96C0/BNMJb8LmXFI696JQGChNAPEFd2gOtXzXYgMO8zEeQOakx5sf4NJkkYhbRrblYcTlSDX6UvqPMhwm8ITlMl4omPd5MScl9BBFggElKuZ0xRZXCw3njQ78WQHjiZ9D5tkPGuGzK5biu3I3HkDa/QmhRBzDV+WbUIDsbPI0wyjuVGi+Z6+XLFk4tD8smzHH/+Wr63CfoSNMFFhc9oYKxUqMSVxDjqA7eUiUbFXy7mWB9v/seTHPMGHh8QRmbWO+Egwf4M/QT9DG5gwuMP/lbVoyTKu7xutcCk92K2nPGyw+bzCfDatZZixJs33lVpLQnJP1mIbLuBY0oNijHqa43LjfY657UQenb4mvfMKXnP6nz/z6f3zqjjve90c3vePXqupYZp7RlOP+v8ysvWXv8Kf+8HU//NL//L1fcduJU+vxzPWsi+4ST37Ao//pF3/GUx9+4+033udZ93/WH1XVfmYexP/ihwVhHdZOZ1fdYUtoJpB2aU7rRO1MBtoh8PKYTMA1HQjl+6/UsenmbBp8tEEL0Pya8b0nivYVtuGAHgP6pmwOUu58XpiEx9EVU7KgKRvfLXBLZnt+0yGjI/hGgxSeipW456MNjw9kQJAIghsFv9p7Cw14IoLeiyCke1YgY9CbsvoeOzfyVgSSXNHNH2BhEJ1Ys1QCyCCG5LILPtihzNHtzAvi3t5lILCk7GNlWzaB/JJRiT3Id7ZJJAY55T8KJrYCirEajEnxnOlrrogd+wV5U0Jt/sQHJyCpGcrUhR0AqvnlU3qtfzf5B5oYDpC8FoEwee0uNvQBC2hRGq9sHvHiRq4n+3p3k5QWflhTw+ygQ1iQ+l4pQMGwDW6wdeJHBxfQs0Cq1dxhxa+nXHoVqGw86Rg2kJpbRHL5nJ30KkSmEVDW7pEmusgYczG8cltq2XhjJSyRTZ3OxHc2N9lDk8IH0bQulPjSCgNJhhLbHpYZcLW+rUtPH0D33ltlpnxLxrKDOXzb7ctXuyeM2RYuxujUXaakQHuwCBq6oonJB7SUM2whFAvUrJM8JjoKjY7iNk7HGNHpuOi4p0+2jwCrJ1wsnqDx28bxdM6i3bW8K0xMZT5TIJ3yNtef7cBDALB2Y2R+RGKUH0szFlN6PL+uQsm1aE+jVcwzfue4YYlNv9YFbct1rW6EYTeaUs3rUrKXiBjvp2saskzz5nOGU4g1TFOqr4PYW5Czq5eryWzZ6dzYAYuKmHhmDmgNlaPwgSs7nLN8aJ6vXu7GjwXhkRPvdn7YgdnUZ2L6b+RqFDHjTXBe68loVl/1nPImCodWo4eqOCYFoYxDgio0Bkqrk4gfG3Nue5993mVX5HsUS2v7bcLncDbmp+32jhuCv2QTIbziQ8Pwfcjn6LpR5GH8NXa6KQ7BpEUt5VDAEOgDxXfTjyLNA6vphZiGsa0Twa3w4CXKoEaYNTkO6VUbXLjpqvHCu+eb9BPT9TgN7xLfP8jYy72649Qt8ZzHPfvUd139Tf/xjltv//kLL7zwj7YPf8Hfv/Hhd57/2Zfdb/n9P3/n9/0fP/ddL3jre995+qzzz907PMj9b73yRe//hid+6ffceOLGB1x6waVv7Gv+l4vBCCsI7e4scrjLdgSS6VG5u/maUCHiyQNn8SqplMFNk9MUIWQBVE6nyTEN7zefXRoGIuxEnCkATse3DrNLbjtNxZRStCcNcKlghOkLJ/xaU4VRI+30SOIEIBWDFbnK2WjhwADD6cOuxcyEOpn+TlPJgaA4hxxhfZhzQbRksH9ZISzZiWRgNlIKgiTDVgr9yXDEtgYagG8gmHI877oboDuSOgBZyNKe+dYhkgmzF8xDY8RQLi+PwqmpamJGclAPrbu9xjeAdCRCeEfP7C8qpCxghtGAwsMSHHTjNpAexmwE5/IzkTwIGOViC+U7+Q9NQUIbDZDNNlFjDYwhdsC8eE9PJVUU5S8z1rlatJTw8cCKObCynzmR00SIxnIZoLkmeiK7DwMbZmFYqqo4X2pVqm167UQzW9djlJWMoSkw1CgbQrK144cQgukX5rDtcmYN+5jf86f3tFUrh206ytqEBVBoJcD7J3m4SO10XE9bKnkUza/nUwKfRwwWxvfm44mqYePcI4Wx2jXIAs1wyniamykShU6nJCYc2/QaRbtJVZgQsa5ja/KA4/YjJx7x03mi42i8ibJsCzYgn5vGFfMK8SYpp7/6H2pODjg1BVP2GTtim/QCQcrOfUwm69BH1PRKFciaHjrp2LiDsDKJLdV2DNgo1znzmdAXTl9k6Aw1uyiaHXqdGrP5LYaj4cSgYu+4Q3EcFSti78RkhYmbEs95iWtqXtZ0atIv5yyuTP+hAshHYDNV3xFFaRae2G/oDvHuUIz4Bb6IaV3Qi8rd8oscKnmKSG+GYBprEpkqtrY031oR0kfOY+gyFzpNlgYy5+SwYI99IT1ZUY/x/OnmlHvKh1W0izHKq5L3+mVhB4++m20yI3t71CCjn3nguWjjyzAgxYYJL9wnyHhf03phDuOaJZRp8QjjJOwrI7B9f3IpZ2ve7tGrsxu5OoZQ9mOupSqW/aXuuOPG9emPfFr96+e+5BUXL+f8zgdOfvgvCkUU56qMiOXGkyfvcZe9vSf9xS037v3L1//4C657w3+585KLLj9+++lb8quf+oLrv+GJX/oTH771w4/+mAs/5uerai/tXYX/q5/pmTAbdyezGeXNscYQOd3uVZb0+Uk85N/DWWYjLgPXKYVs5+ENx0FdBVaf/EpchCf5QVEF/DYy2PXgdxVCJgEE/jd1DNuAWVMg+JnxcMWIc6hrxWYzAxa4GruxtR2iAZxOmz0vI9P4scacuxjl4GI4Xa+44nUSOG/SG4JLUB/oFqmTOP5e/R1bDQCD1oXA5Y+3RwIwZNB772EDTTU6pNgG6Lpjl9q2S0WkPaK87QcdX9wXiO0LPVh6dEcQ4Ah9tMLAxxVXEn13VPWaFiT3JpT2KdmIwIUNj5pijbARq8c99pyEe9EgP4HOxINU56stss6Mce/pIvaqaKOgBatyKID4gI1IbtmoAsn2ncuukno1a6Ntb3s2+AVPgGXSl7pWKmsbg28GupNtI/TxlhP0EdFbLEsmbvZOX6ekxlyVFZXjpkLc6K/+p3X5UfyQp6TvKSgN2rPWWBYlEb56g6cdmhsalIrXaluh1xvwCXk3Qm5bp3UbHgwzVwOKI1vzyJTJoDq3v/pU4BWwN7ohAP8oWcbAy4XFfIRwz7GQekdoCWBEBl7xQ5wsi2tgriBnYICwhffSUyQzP2qS+HErDCE/4I77bwKWYMOGSdX2ykaD2wswtuaZMu1v+bfmUkyMAsZi23zFtC0ZBVFjKcIBLATb2ID3XB2c8HyXfxxP8sAgYz8M34UCE46MeNc8LAtpZRFHO4wo8tpj19AxRZ9YqZhnhPzxpGE8qC0nshy34BnAuNkSgG1jzsYUzLkxq2qb9B0iwncbv3Wl2L/QyRnDURhBBm1mjHigHXrkwEGzxjsRoX9/Sjn/LRg0CQhKGg0Bh2splb5IG8fJ/TceHCK8klznPldbacYkX1zo0ZGuPxiczpvunytNSxyxf2emFBuL/txNXOcJIF7aKUHpTngNP2nsW00O9tDoDPii6ZmexqjD8X3ljaDo/zmphlmDG6IAL2ec01YJDgCM4RODmfNPkX/OQas69BVtR348RQ/XInUH3ToeycFL2LHxO/gDVaRoYB+rCSyA7h9kHKv9OnXq9nzsw56w9+WP/6Ivvvwul/yjf/W6f/MTl19++e2ZufrqYG8TPXzP+99/y/Hjx9/6DT/xHd/wyje86uC8y++2f+OZ69cnPeRzbv3WK1/09bfefuvruhg89tdZDEZMD5WZitWJ1QiTYSBWFYOXioM+H4Eu/RoF0bIBpUgdkzqJPg0Q6ta73jxE+Du2yEFnUwBV5wOHsIw/7LYYPHRyTeLBfm4t/6dAnFmGZDp1FdZizAfw4WI4QSZhI9jVoIMUhYQx+Eag7VaEOloP2xWhyelL20col+r7IuhDToABiekkMX8EwZBPEVzUbeXcrldL2KJEl5/HVURaxJhjJDniU0/UU9IEfVaj5yi7VxG+cYVlAWChmJ3PQQNByRPkqeQBcKxgpR+jYJDMBcR2fQUDvz9AQfLGSEH+Rq28sYFptaACyZ5dRuYYg1lAR6jbm/1/WKldp18DfimaFHrJQ25ET/46ANTRqvFAp1VlMIs2u8kl4LM2kAUrHrBjCJbZvsDmTL8wq6bRwUtNDm6LRuGugz0/cMc5VvW9mrwR1WQWuG5Ow3AtinI3NSGJ5vPPgAFhIGWH6U0Js50oyfBOrheAms+0CPmWJAgZaGsWNUYZ+Eo455uGhM3Ihv0ecHmK2QHtHNMoYS2oo8QndQDKvTOxEwcw/0LfobVwB0OGr7Kqwre4YR5O320sVSOwpoQYuBK14o3BsfZuAhZ8LYtBF+4nrMCDIdb2ca6mQ1FmD8LboNwge4yn6GP8UXGtF8SY2URaEavhnH8Qo4BRwtLZlym5Hhu7FhBP8JWSQK17Gv8TCO3iujgD7gVpmlgnJ4opR2Ec9EKM2J15aAu4BL8oW7XdxppwWjAo+N7YxuTvog82aKWYZGx4F9P5wrt5tPn8SDTR2i5xnYll2s9hetz5mC+p0EdTw+yG1Biilo1qK4WCY9iSmJwakKHYOhpsZbFNvGculi5uC1TEdOVis39VoCA2ibTcmsaMwAMGw6kyvxA+G3TRD4Ex/hL70aCYdF2ArLK6oG07IctVJ0+VuvLLSbdueMSpoK0O0bodpjuZcu9QRu10SeKl6QzHhPobrA/Y8WJ6kJ0sy17dcfLEwf3ufb+DK+93xZc861Me+77f/st3Hn/xlS8+sd0qGhFRf1Jn33DpzVdeev5FP/d9v/ojP/e637v27hftXVA33/Sh9QmPePLeC5/yd5942VkX/g7O9/sO/7o+WiFcMvRStp6QbE9kBxILnMP/DLwLQQL/ORhO1SXXGuPoEt3O7fcQ6dymYDONajkECBgFkgmNDDsnGGewczpR0eOv/TqI1SRUUxLQsujkAcnvSPRXgvOyKUyXfi41TBLXTu+Si3aUKnbRud/dukZLNHhmRfSKBWloZ17I4MJ56dDGO0E8IN8+ueaOoNwppmOxqFSAc42mgYLhdBHP7tdzpI1c/Wj0qFjRvcdXVkhBr1Da4FuAQNjMYGeTELxI0uPfNHyxoqdXtvCSWfA2gqnbxtL+gBVYyCJDq7JjLUkBXzQrb1oiln4cfjqgQ4uLADxhfwEUpu6LryQoBcYNeKp7b7ozHeKb1baZj66f6RV+BqIScup7dqYi3eQF8U7vZEJ0sp8F1NCrY/AgBVzDbmN6gmd6lFuB+6ZrEb5l+yJOr9QjtclfB/9y24YhBt4ZEyhsMyJyXYP3k3Y89MKYltbvDFNA6vs1lqLd4RvomLyE/l4bexY2ZETfkLlWPkQ4QDUIlLCpeYVqvCKG7+1MX3UefrH0e/cobsi+64+ysbk9DxoTS8IIgHbiCXRm5yYBWgKeHszGW9JeWrEBCtUcHATC5CIcYwzwwzwl5bfCEfxmr90ZRNAHwSe79WxGaJbxSiHJN8izbCYRC+hIwkaPfVElLC1Kmn6cuWe2IZqdW9AqXYGXpGGBTPCtnRFNfvp1wnffoozEHdGDYwsgAg0SQASKnhwgT3ln636c1ViI1eRF/s7mS9vMdmcFmDLknPiirLJC29/LBTpd47lh9d/TLijmAWB/8Kd3QpZctc8d+YOnukbehDd+hlZ7MofskBBn6mnQXKlJyKH4tGSrumSXbF7E9Ek7r9FtXNPvz6oYz0djrkN5yLaQs7mC5u3SmoHhKH2sGnwuJgvqucEZxaDZtaVlxMkhsrabzH6far/ui/gI7RVxB4PytTWYOjOi3ys7phsCXNe2DeQhGRG56O4DFEEde3LKD5AbVgs6aX/M0YgVnaPUQgxK5PeI3ShU2/mKK9kQNvAyJbiKpr2kROBXWBxirrLdQQPr6czNd3cRK/Th1tLJE9w+/LwePzUadT6fjqvoq1kRy0HE8dqPO0/efOYBn3z/Y9/1rG/8z99yxZf+5Ove+rq3PuIe979piDB3CHn8K7/t4LILLv7p737DK7/lX/z6/3P3O04fHJy8/eT6afd62N7LnvIPfu3z7v1ZF15zzTV7VbW/Q8Jf02czMJzEg1H/28rzatmFNP7cFRU+I5+w4OhgxDgFJLVkwBWbG7rMBrjVYgPKW+6QoIgwcKSl963ZEBcsMHmw9PMFSxhPjsZP3/lK8nvikZdwIjqrQzVvA+C8IoQv67Yih4VQ2vlITAhOZVuv9K8ejlCckCAMnteKsqAxSW4pBhJ3xhWObhjRzHOM4eT8LbjFgmB/lIKt07UEtzFFdMeTwcvpTM4nQhRwK4pbMaYuWmK81hDtD2hSlB90EAgSLVI8BInNiCVMXkEZeEAjn9nADAthZZwCfbgIVzSV0NJpjN6wuWcfEK/Tag7l6NfLL9wvIeqJHRRECLJIZA1n9JhzcqomS0Tg3hZfgRVtc9ECIhBwtmnsILAm3j3x9msZMXqcFFMcaypCp644RFa0g8iMpfwWWxNecmYZVMx6MtNtPeAxOEWeAraIP/opwNn0kaytb7W9UWI41/gx9iNqNLhY2FTFzo6L1caBD7iNIaGgQc0fjLZEPyLeCinpD168wVX8HTp3Ose8H/odSoDFz/Ejyuw1ZsTGTzbbAi6apjNZ7mx9QVxGceSy0ZOVJRXafvaOB7dJfNkJHRf4cvDOVbV+YNkaTmdG8ZVFRZ4g3zRdR2odFf4McRDvNvYwP6TDcBb+BpzGNC2m4kN+gMEAPeg/DEtBB2Ij/LlXfdoPmTty1akkO9rK2sWSx6/kZJM/pttZmT+nMNLxyHwIuEg9mq7URAL2CwPxwZqQSZrwgcmmHSNGowC79QocKD87VHBzlCFrf6mF/ApUTCPod/opkGiLRdKfBxqzSsaPwIygt3+SP+ONDYdk5sbpZuCebYpcp8vZFgJCNhbQmYnfavyYVoGn7c1zDjigSFjgTcDR3yiyDCb0BGKjtzZ0+jLwRq661P8e53O7Mmy4awXfVRRZqgFo5m13iyEn8mXwspG7wuIkuEk/bskb49/Y0+QIm+P6TT7lNmc0kJdxzrHci9On7ji8x90+7vjXPfEFv/3MB11x9vW3Xv/syy647DVVtRf2qlF83va2tx1/8AMffPqN7/mvL/mWX3r5t//lLR862L/LEudfeNHelz3+6h9/zCd/2hf91l+849Krr776r3WL6PZjBSFrbWN2Fpg6Jh5YbTQmpSGnxiFcwuxXIDQuAfCmdRc4mObjPyCFEBYYXrTL4Gkcu7rs71R6bE/AkAKZ6cqxXM3AjeNHyMKNivMtvQSfk3NR1BjfhoKjVDM8CsXiCegO+02v/qQ8PTyjOMbMGJxX8gVBdIzMwOpFAAhwvCHVH6mOQOZNmuS/FqQA2rx0JLbYWhXY2hkA4VLBxnMSCmNisRke0uzr3Ar1m7qzss/yeVvmtJtEBzsI/GGrUzHxvgXaYKGRRoWK9obn1BXz/bYktAMArrPwlkfAob0HDUm50yb+QlsGw3SHzhjsFq6KbnEbcUZOfxfozpbFFm4YDCzQ06Wgl+J9GNo5IFmUhNqyK/ndbqygjWMrPBx/Dg99cUi2HKttHJ5OG7RLoT+e01jKHTkuo25ipBRg0FaiCPLFmCiOSvqk1mBLbIyoS+vwSIuHzudQwOGmTlfjwNA1QMp9r/gvZDJtnQfUV+7OV9Xd9mDCTjv1OaxJUi57+qAKa39MvRolsrVtDTv0Vy4kmcRUxIZkACv2sCKo5u+y6qIwoPIoxBej1+aC9oFNg/a29eyNnyzM4egiJ3hdMX4MG3FspPhUSJkA1DhMMWu+PGQgHpIXSShsMCRwFTbE9mZM6MSiwezc8IrG4vJF8ipQDEA5nNV5SbzMbB6Kup6fkmh0azdqEEPYzIxZduXxQx81VNYJl2FbU6HoOFcmK5zTDRh6PQsvRQjhpSiwLwKNu4y2kfQtvFZYTu4rLFMzgdAw9AfT6/imOBfCEarHdEHcm8fcmKxNlqG8M9VbM37TfnpPTmMh5mFooo1GMQwfPiiZe7Hpdit5JXnAo8M8ZqhgxLn9YDHE0swJt0hLheWDIb2ZHcEFnD/oJaYxFfcEaLIEA0HyqaE7h+QqKYm0orkUBzic5Os7raQIYFqRJHApebiWdj/EzyO/m7GH8banhf6WzDhYD9a9c/f2XvDYL/ivL3jEc55y0203fcLe+Xt/3kNNxWBV7V933XVxj3ve47NvuO3m+3zjL7z823/9zW8+c+F5Fy/rsXX5+0/4wrf8g8d/4Z8+58bPefQ9LrnbeF/hePny38iHBaEegLBBcXwo5NmotmfyNKk7JnjYasSKBjdeb52wM46VA4Js7ZCJmbgtxCoNX3nByXoinB1zfngcK1TikGZS4WLZ5Q1fop0ZKHpRPPXm8d5+yAdc4BUQ3e2H85IMl7QF/On5jIn46omaAUAIBtFy5CsssOfdspkV3cn+e/IfC/xISLDnneHKilHFdXRsQa/bmIE9JzFQRgCH9aIwQSAxO6iISL6uw56SaGApfJlpIL8bXo2JSdXqFpfpZyZpfD0DHWkn7xmyFMmC1/fcFo7C+tbqJGoWkpuYv4NIBYLW5nwk2QhCCerKVvph2W1buCWTnQWL1LDHid/xO7avMSkPde71qO7xEvnRDRWZ3cQO3GOmx78X73uQnK1ZVCY/6lE+gUA2BRr8vnhAVPBkIVcGcfD5TXJCMRP3sF22701gsW2Iyzdv47PKOlvnRPRMnjrwqrS67f6LLi4tzvgZimIEHPrDheoGT+e3vtRA8T5qj17RuNeaKtDcI7e8BwZKD5PoFrz43UOzZA81u0+D2vAxoXdL4qrlh2GFvT6SRwTIt2VFP63eLiz/mR4keUT8gMynRqxjAC9F8Wu+3r6alOFqvAxMch/MyLFdnluz4HPSF/GCV5gSAINhkYUVOb4oXsfIZfPLNsSZ7tUX1sjOMWTbpBVIRXCg8nvGtm5m1Rl61VnbKzgrO04qReEK+iLocy6PaSUZ9ulxokBRGH1YXbE4mM6DGWF5kloTzeNVIvJ7yE0QPHCGNJThcQgjgzuZ6CChado+6FfCW53akQuJvttNRkS/rgfF5EL+JDo3jKIo0vx29msNkBonqZRJV2McTei+hobI9pYKfDdfI0Kxiqe8Iq2A7WyChXhjZ45t/dm6hQ6QfwkngFxzk5jnGg6wsZHQe1tLeRMlaG/WxYZ2x1ywmdTRsLnVZBL+G/AFmyfINUqjeHNJvcdkroGtuo5JbBSt8JdoG4PPzAsoiqtSFu85nBo0mw8GaVqUphh2wBMqY+8wY8lYT62n1i9//PM++H9e+bVfllfniXh1/IHUN7cYsl8XUVVvff6Pfuu/+g+/81PreZddstx+8817X/fEvxff8fQXf/upU6duO3//nCNJ/Ov+TC+mnxwJjhfBYO5+uu3EQH/bm+PR+UJRAMccSkxujSqfkOe1ghM0APZyBwjw4QvYwxSNlSOLqQRAgszu9oQMAarbQg/ZjiYQZApWCNDovmDAfudTAGwwDiOPDNWAQQ4sGhRft8+nFiBJ3HACUSmmQG8qycI8/kItnm7vhzOe6TuWGKPIiMADaUqrqRag8cyMWUcofnMHEKKq38NYXWMDFCZNBRoc3B5mPHohhCeWedtlJCBDlv4wAQ+60GlAHsKJSBNm+qgcqmmcijkXwKb4hD0BYyM9OgYSDm964D5R7/6PUdZYqyXeeoR9OX/Zc65FqzJc1dzZJ3PLSESDtWx5Sh9tlcW700l5dBBMJFxd4JBlAb66rzI2NlRQkcV4KNDwJ7ND27YIaqNyvEtsAnvgB4rSefVnaHnhOKQhQG8qaSoE2N7+DbQq6GsUP2Gjs/FFWJbMQd+UfNqnqEsLiLCvrKheAdluF0KBQYNGgmH6U5KTdk+immTTtkDw2t/jvY0YyNfmkbAh0ZE/G4kWqtS9tS9QWJoe8TCVoRfpaYps5l+r9oprxaJlwUImJWPqwmMEybWkiOcklZxrWjyAuKYBKEZKCk0KL3Snm7TK/AZy9GaAggTjK81DDbMeSfEPboXkjiutaiSKWvsQf1XoUexS87ytjsC+UKCkpaTDanBAcrgA9zkHBDuEvBZ+j8lzmQSTTU+0ISdFvtUQLKO3L2O8qRmmHCQiYuw47T+WxeQx4vl4EJoZV6Z2IXFO2A/yFMey/osm1j6M4WgH1v5D8dC/6+FNaGAXVxa9aehxISEfNIMYTOQ7KlSC/uY2gcJV0JOWJ8EGXBaGryHsBY55Ucv4Yf60LYQkwW2+EMaT4Q3V4LnKLCNvQjomjYv1F/w1wbe0RWHpnc00ytigo/RJfgYvfPWyn2o7q6oxWs4JfWJ4NQ9A04IcJtGIlARJohgc84yAp2J7Qzoumuk0XCnhAQt82I8ZJIvHvky9izTb8yntCEAIsTBUvPNmTWNwObYfp265fv3SK794/58/+xu/93jE+X/yb286/xOvuejWiCgvBrHS96HbPvTpd73LXff/79e/6ode99ZrH3juwbmHt915Yz3qQZ958rmPfvpzM/O1k1j+BlcHI6bXTuw+ZdRicQS/Vdjd/uSp1nHfuq+fzS7LFOXNU/FVBy/eWG2TKmFQNMlNUHLw9CSGWDUFR8wzk7SZZVol8Y9zGIgFdlQ3RvfTadABYVIkgBnA0OA1rWSmaGCQ0IddkYJDCDDTh0h1oqg70zcdKBEISzBIcY/jK4OJBnBdKRCp65ytPy9ckCwzIlRJ9kYnABhzQkSYZ+G5dn2DtUyj1IlqYMsleW9ImHZ97/u4VPrwACa7gpyS+kNBmjbykXZN4c9jBwIfAznArihTNBVgdd4YGeJcGSChA4B5mG7Z2YSs8WCEsnNgDdlnWkxS0mYKK9iLxoajO+sIdOz6Ya4K+k81z6xiURCHZKkY735VlqjxhEAymVglazo7DdJ5oJsrwMCUdjj6WWMc6AkL6lIvectFKzbwycmUvMFgvoHGiRcFjGR2uNxeWl4lAUFyHB+6rch+mAnoVcICnHKGPD2WqRblkzZjZKhhZv5Eqy3+RlnQxi1wT5jg+ETc2kY2nT0enCF7d17w4hAO22y4qP1BFxh2SG/hZdMv5JcESsmw7ZpllTKUuUAm9iVlNf63akJTVnJes7uI4KpgWNzbxPk2Ss5XgcTQcUyreJPLzH/IL+3wFr/9ZNjdJGk0fUw/2YoGvmbObYKMmN6jNhLhIq4Id7Rdj/osZwfYU2aUcFPpcQyxEvPKdARf4Xa92YijMvAIOplHin++zsjwc4qOKYwnPlJX1IKrZbbNbnpt380KepQuNf3EI0oiIlPYtIkDOEa5mo/W1r+TZkubZxwCnNZ8ndu0Y948oMbZ4iU+U5xubGQcqvk8NQktVlhx6vNExxphDXwoTaMQ9OwUwmbMuUbUtk7w6+dDIx9cJJbN6ypmOFM8mEy0dIYjcWbi6VfdpJWDz3gWk+9k24rvPouQfcw50uZijGv63KAF7ZJacJGSqHme5Fy6Nv14M7IcZhyL/Th18tbD+9/vQfvP+fSnfsOlxy/83sx8470uvvjm3LxeokandC+uuWrvrne56x/85H+77rH/+td/7KE3fODGg8Nb7jh86L0euv/ix7/gBx9+10/57y/8oR86VlX7VeWdvr+xz0eeRPlGIFD4zaMOEPq0otjJGUqrTbcE5251EgaydG44Hn0ZCVZZYmD9ZQAv7RA0W7SpkFHivLLpt4Gp2nkJdjPGoJjr9QeBOkGnA0rZJBaM4QRqgBloRHdnHOA7ECDwRfRWC4RqOvjay17ewV0MzKzA69/5IBYkvKuE4VuGhtMo6fFVtAQQWjGHJ63JhYeSkMxwpawWS/xNBTADdpgkKuqkgW5pGbNcnwJgC3mRmCPnwGuuK71TZwALPLUwbO4Y3btUEVGdcAiLEayTfDmslfNWoetT9pQBi5+DkoSN5M9XvRHggwkJgtLCEZVAwemYI9DazEEgPzQ0SiuUSFylf0gDQoY6apKFLDV4DruW1FfSBlBo4+SyLjK61RH9VLYKdVc3gX/eMgzbbXxJSKAUPaeVQuEU8BK2N+YtyT7HU0pXGmYy5rvdrLVSZgFJ1ngBObfoJOwEDaWmi40VyRDZNvjD+cTlkq9MrtdJM4tF+GzI3pGYIOdEo4/+2gYAN0wc5+9updY+y+AWoLXWCZipvoLspCMk+eCTds7Y0bNYMVj9O62/MJZPFF305IzVMk+PRK0i4Q6bJLFNfCThIm9zhJ0bcSr4uJ2VsjCca74VR7tYpK3iHrDmCQoqm9f8pNYN3hh1kGqm5jLwlV66mCK+lcapUEIsaDUc749aK/KzpB1GoIvEvykWTJj9RFHzEy4tQHepHTWLYQDtJxt7jDJL/qvGalo2PdnXIo8S5cIr1/7wpQo8CTV50OVtsqY3TwLdfDYFB31QfCk+uK7L8GR8p9dkbFZrTUfSfh9Lk8FGk95pqXnqYMzxCWLEesTLLbOYg4sOmBFyMT1m4d2b4AM4V9z14nnP1OQN2d0mZZHOw8lXPjBt705DejhIlp0jv9zmRhHJhp20UGMrPeI87CiFVQMfovVo+YSbNOZDjuuFmcX/iFKOrXAcfHI14cDzWSvgQTn5Xc1n7XrQhdhbRjBzARIvDJqCvi/RRKTFHx2EcPS7MKFPy4olKo7FEod33nF42YWX7P2Tz/va9z39vo+7+U+vf9+nVtXeUYVcjvcNnskv+MnDmw5vf95P/NZr/uk7//htB8sFZ+X+RWcdv/rTnvabX/DQz/n+v7z1+uXfftVXnYmIw7/plUF8uGV0EkgnHMMmK3alNUMYDSLCFGLdQgf0EtxzHziPQ2c5nY/7MRToN5/EUn3K0I1GJvEVtlUo4AkMBHrqmA3SQa6aKi4ZZwS3qJQlGPjKAGBq0qBzxTGTtJDrsnIP/pU1uoJlgNLjRajDqP3woG3+XdtxSvOuNW1tlV46wK+4J0GJFtVj2oItpG0HQ+hDsKFUKiJzHS8U7vlY6E9XxbR7gVuHWPSMkwimkIGpdsimV8B9+x46rLkIuNLk291AFsoW5Ar2XZSm5htRtgMZZA9rkD4CJliwEwRsgRxWWgibwL6UTEHP+L/my8CWJgQwszfz8RHYYEeznxXfmYmktQWeFbgXbbBmNsbhSRl/el6BFBk+jw6/jFvBCn5ES+sELsPnaAtAAtU+PNEiN+UVEeMVGlnZO0F0LvwDDQ/CBvwg0T2tftpl+4CBpqjbnX9+V15G9b2AKLtqwUt8x4X2ZlNeR+tG0uDLWGbTEl3SvjF2tT659ZXKymko8ZCBFwlHroGnUFPWRSPUGMAq9w8GayVlwHBAKp+4Ny3TjJO84Az8yC0tfS7jOzCmbcuSEuI5ZMatFo7HbrdDR7QNyklIhj+wuiBcxsnF72Cvk//zp8c/03FKBLtb5+QfSAZ9b6oiVjR200OHpixZqhDdPg/FP201C8Nl45X+GD2/xfoOTmyQ4MqJP8dEayZF8BjVZsa04OFk4pZ6jAjmBeOvhRhSLfvI0dwh/jW+VqaemGsBCbmGYlo444Yj1fxV4H1miNPUf7sTmkIVo6E07jHuOADZQUecyrbWldt0NGZbThNzA5DFfUSMp6ouum4YQSw15luWzVblyaba9gMYimgSzGmCK1bCeW7vpL6bjhzF4GCydHJqflyg2RqraVfSrzZSwiaDmElbNAzkemyfwztrQpiWHEvFs6yjb8Ow/DfbHphlED4tN2pZ04479kzv4CujoIr2xFepFWhUThuS0Pi7Xz3j+IwCefhCj222pGdDJHOAoFpcBlZkW/yJMN5bvksG89LhE2qWAz+oMepe5+OYYzKhfEa1IWzbCr6DPXaFYlZE7EUc5sEaZ+feC6/84vf9nQc99crrT95y/J6XXv7O1pGm7m2it5w69Smxnvm6C84570Xf9Sv/7v/6uet++diFxy49OHl4ez7tUZ/7x1/31K/4ssx8L2c74hUVf1Ofo1cIrbCBybAYDxNuD9BvFtsOwmBQigxBd6waL/XbfGozPukAmNEZxszeIQVwRsXUzdSWTMyBJLbY0cbDxCLxvhi4TL/Qt9RF3nIosArN086oVyBZ8APIND8L7BmOyOIQK1TN+6oATW6azrVWHbPvsR2T80bv+cbWIQMk20vZ4AFAQAIh+U/79M1Blg6mmJArIbm1j6PsqYMjVuxKW3e0bQGuqeO0Gep5Ts5YEPk8VTG95rh5rP6dWJfOnxXZmCtnW4oGubmjH70VtflIfQGbnmJZReBJzAxTjmhREbEQ9CCrQcPKQZAk+OoNi0FeFG3vAugR7AxNzV8EuKJ6ifEs2IneHA+IEdkqSsXtHIjS7K4A0iEbhU3hvmMkSKB3Bmy3ewVRu6TpZHjfnLeY2Vvgtq2dGV0+ZRfNLeThqvbO0bZcvRsSJCrAIgxh2zKe/oqH/MgfWxtDkfLDzMhl6es2RR12ISSCuwJ1VJs+HNgLK0+KiTuQIRqA7UNMYIKJFOVafr9kdFISBtYwKBi9ooDHAuqbuxgETcCvpQVM1vsXPSSm5pEtRow/kZR3DGACSwiAuHdxi3QGkwrw5d/RTwCtiLd9ME0sknT4qFGWHEF8WuWuKNviXRPdCydXsV0UFO7dpH+AxSVjIX7lNDFxCAKB8suF5THAcIQFN+zYbBoEFGyr/BD5g1wwKnCk7Dwl0fIbrjJE32IwYez4SavHA7Xhd/Cd8lkkMTSxsQorm7eGSsTAmYIeFA9g3FNjCbiYc+HGeSlG4Lfe0WoheeiilkBDzqbgWMQpXJOu4KLeKkMP1grDFLvYvdljJxj23RkYSfYKeZotRbR9l05mHCzON22l39Avmwr5Y2iskObZhIAOEKtkxdDTiAiLHfFVb0xCWy7zJ+rP9SjcQgBP4PwUn/GxPMKuS/vTTmVsG6R0E4NESjYMGvZJXjpoXw1OPU6AKrl+GU3yZ8h+4NMYgX7TgyGemkeEvFGrz16QTiuGON9yZXd5ZiITDjQBtlMO8WnvIGJ/3avTh3esj3voYz/8nIc//RmZ+da73uWi3+lVwB2pv+Utbzl24/vf/2cXnHPeG1779jdc+y9+6YfOzrPPOjxxxy3xmE/9rOUln/fVL1/OnLn8LX/5lnNr511Nf/MfrhBuKScQ9x/DAGbwl+J18rTTgAHHJoEl2TTBMQwQzZFlZKJSe8UxdO0u/VpI1VzojjOWkGAkMt7kZLDJNskJPCQjdTpzFKPtQ1q5kwEyvQANi6iriGk1yidxuapkhNwxZkrE1U9t9BW18K4UEn3JCgkc52ditC2qQIuAzNig+JPIYoCa1oGH4EEbZdT/5EJ6ht6SQEqNWgbKPATFSG66PinHp1WR/z7Li19PhAnidr8tdazHGbml0sQ8yQnAm1YMpLIew7oMU9cfOsIVtZkL8hmCMcBr20DCR5WoA7lDp9uNlvtjCjzhfqRz1GHWWK5vdYaDjqfFbdi82WpFFFaRnJbUjNA1+RK5DF4S5byKeMTihl0sp/eGDFZzYT/jwUw96tLWBB/nVLYuwRWz9l9GWRUhYbhBrEHgm+gM82uzifLCGfjWeJLoYEcHY3rZrNzUsbSAWSQo9F0HAZgCTc2wcDoIHAyxT90BPyhHJMJgxlo6vdqBIaqCmB1I9rGagrMY4Gc8kcTlnPMOCugsiC2EX8eilqtw2ry3wcg72Rh73r5IQZBmFI4cs2kvdjV1nSxCQ45vIFlPbAtiDdxn640D2oibR0zk8+AgqcdwNjKMxrbZgg5D8oFeCOrD/23pjPi+wG7NPyS9OSBhZWaIzmVvv1vsoHzSR1OzmwINqBcSga5ykiNU6/qo6B0qJlEUHoyvxoXLJBt3IFxBHtve05XUccIGDAejjC7fkZGT3Dk97T90AM1F5InQXcs3J/uM2T40m/30gpEBwuzQCrcQxogzeuic8wXo2lyPJ9wZLVjZdDzj2Jmhp8eHsAznVwRfG2aOUJH9MBZoveerCjx4j0/SBjYBA9E8CGH+dkWTRRFtw3zYLaOEobqfm6MHd8ZoYJ3i9jQHAhtn/g4NCEqhGlvRsWATe0aw7Yvut/qQPos+gZihjzfbvJoQ2Q69Y5qc4HeaZ9mLUydvOXzYgx+2/81P+Ip//+kX3ufCP77xjy+898X3PnHUFs8uEM9ExJk/uv6P3/1//9ZPPOZDJ2+q5djxg/s86AHHvvxxX/jDD77rJ/3g9rr/nR9b71qjN9a3ocmoJmAhSmzhJkMJWZmtDMMKt7VwYPDjRSzdDNvHG1y3mgwk8kGHxBMqMzzYDMb8huBsWrSCJ1PXCMZtywVdN4bWHC8iTxY8KTBvFKrugAz6cLyBreka+5QVkBhF2UkqAVlv2Uqsai6zVoA/U58R85jkSMsEIsZ1ZWibhHt7xWId5vE/dF8ADhkzEsPjzJstUPAsAIB1kXivZQS35o0plpbPmG+p8RTDXGylxANmnzt+x32QCEwyDNzkPGopC4jkHgGouJ1tsj0HLNgc1WPgWfbTE/hGoSoEIIQ/2GBN8pq6oa033FcZC/TTo5A2hEvGC/mgN1ggs8T16WYSyIhHgVTkd1q5k/PPfEbSRyJy3rroc5Ln5MpZINBbEjg9CAG+E1ac9X/YEqxV/Z6sV1cpMdqid33RfYfdKNFPCypImsZD6i2IdZKIYBywI8AlCnfIFs7sf/a1WdH32I3rCOChlQR+CM/qCCcCbMDjrWvNYioAPWQOJMG99FoMnF/UK/27RAOPp74f/KXMJHSdAnzrPdSsk7ZSBS7sGrbF4G5lkMkHtptRverhwmv5GB6NaVJFTcV4IJUl8bSNzOguAe0uMjiPRx1BZ9J/VB82FhtmUh6TXUi+YxdMz5MV5dctkGFSRsX5SvxWctdNw2xgdR1yEYIbLxAM9WZ6xlkAoyMwjLC4pIWSIv+M2FwR1cqp7tkz/YXH9G7gsKAOw1THfiMbYwMs6SdYtUmyjm3A8H/MCblWKxY4xXvsjP9YV0mtJA/8w4fSmOtRX7UVq8W20O4o4cXMK1a3CGzEA500W2C2z4dkDDtKQJl0Dd1nAJjNgoyfIo4U5cJnL9gKs3zIx1DTC2mp3nNaLMRZJNE8ExAWm9BPOSViFexs4cWMtNpKCtvr3+gSOUy3jbYy/CzKEfFI0VTy53bcPjIeqLcYM5v4YVQCm2Z/SRoN7aFW+SpoI8BpHI4li+A4XBzIGK96gX9BvoYT8HXSMRl4OYyYX5Tx2Xi1/dD2KNngPfkYrs1x06sLP2FZlzhzeOrgY+7xMftXPuiKn3/SfR75zZl57X0uuc8t22IQK3033njjhbfcfuurqupR/+GNv3DdL177usML6+L17Dh+7Ms++zl//rxPe/L1f3rT++9VVcf+NlYHI6wgdA5gA3pSo2NGsduVIcGmX43Aa0YSDNI9HjsbOSkD5sqVEhZNCGhyK6QBBIRVNEZGrGnJxaInxg0j9QDmAQulgSWEsQmi6SM1LWsfsSoADrB0hoj5FATnFboZ7CPwwA05ohxs6UBL6dsefE9sqKFWwQqySwnQAuAPraqwoGm5LBXjfjIC4NJBEUChYEoHxTF27gfN3llEobW2nJcN+or37MCwaoKsqBx/MxGOccxKnyFn8NtyZQFcsx1P24sromKd8pldiEnagwekwUPPWOsUaMZXq2xh4eyyd0Qj2CeHlGDSgB9BGH6qFYsZuJ1S0mvnFefBzMXvxxBtS2zMdOjCvuf2c3zWWsNSGgFxRtQy/Gq7LabAJ+bF6lmGdI3AWclnbLDgTTOgsp8rmRo/Vi+RYVLj79FU6NcjtOQqe5txma2neCro/Aj7wcmwR+gSBY0o6PSxja4CxWlHTlS1owoWDfhqUaEZEdw1wSloUSyfWEABRwThjamwF1zPHQzZPJF0NRoqInszcRMyfmCeBQl3J/qwiWicsGaH93K1kpdTJxfypL2CPzbNDEerKC9iuDfEIsYrSXidRbjGbDSJKoJjqzdWknVV1IoHBOlcaQLikE1M295gD4GCBYZlSTK4KKU5K8Ma/FbxAHM7JbiHWmlSj0rlqLlArSf83nTScYPY13TJwTAGdpTgOyveE/Rm+DrXwG7YQMxy7Jgo+yv/VniZ48FMTdh4xYzJcUzSjfFa1bho3eG9dJIl7KclSn4qGBv7XBTnlL77cAxdRQWL88J8IMv8eo3iygpzIyGg8LFtWw9lgmEZz/1kbfBfUVFLkk7t1CjNwrys8Z87SVr/fOZaBRvWwC7oZ5JVMPyhiIQNcmsvTQX+JQwaGDjnPLADbseFbWdNhQ/pxGj0bfNr4kAXWh1LfFVNRWuoMILfhzVdMWbYNQ1+jMEda5iPlWhBfNBuJ8XEYRuGp4ZXELvvVutKNlSUF2UBLfgtG1hM0JiQibCLOX0XfFGaa4hy2YlLC3MgyzOKqp3kk4zLC21IeIlRAfDuk0Y3aMOHTUPzn0zGlDXWsdtuXWP/4DCO1VLr6Tvrs+790D972RNe9Dvvu/5996+q5ahCLjOrqvLEcmK54NzzX/HyX/3xL/rh6/7TOcvxs+u2g9vjik997C3Pud8Trrr59puvuedFd/+ziDj433nfoH/sxfQkv396GB5/jx9pBl52XsUk4XSzcvAOE7oHJDsz52AFQEYHQCHQxs0gRWM8BVUCDFkTrVwfScjBurWJ4sNvHETAE9F6V6LGZ8noWXYULxMP1bsNe8vhujKwVHtAZr8QPnLsoAwAdeEOx1nSiZiKAg6kWzHtbf+QPpFEVdRYNLYolEDLUvgZLx8HkFIwg27ImL4mudA2TDYo3CL83kGcYqk7+AkLVImAasGiBMBSGn6Hqgx1ara6mmw6qW8G50pLKo0PkypPpnqMBgY+edP24/hKXjAUksgIJnSYI0Pja37ITnJKDdDnDztM0AodpuycDQY4mL2Na+PpE05QpqZ7zu8isbN8hQi0W6ogfrYycbfD4JDp7qHZTphEhwNTQJ81+bRsh8EUW1sjIokoaDhoxuHPnbAFnvYaDEZMZjwomn9NTVN+ky7hyRp3bFFMjrnQiU3QJ/PXSow1w0x59HGb23/R1DnHBk/cUSxtBoO9kfbaRpay33dZw/zzfDmNN9uRvfOubGraKQw1NQR9auulmGLEn1yTeXA5rxkTDdMIfbKTK1dGk8EiirEzWUOznKUmhCegjgnV32EO+aMVHSzal2klBPgD+5nQkU0QM97y68RwkQeMjLgIcou0am6wusWN6BgqjBgnNJZNNqZtdNATii9dmlHRD1MSkVFixrhGwqxraaCLnYn3xLdd1SwAXkqfIF3kXv4zAwBtRNvKjRQv0gIy4GAmYR+045aADoc3LukFr11uRT3Rfou19uuIZzT6HS9hQ0yKICuIoRoOc7V+l83UTijnmxkbO0R0keQABVXbteI7C55Nrj/ymJ5vdlcJlFs+i/zCXqcdEGO7SO9CYLYHIdI23IcBbpTIFnw2b6Rjs3qrLms4TKVA+s/c2IGJHLS0fWQEn/cz7dDqLe1WFQRW43VSEH9qR6YmFxSUCnu7EJ7V4u+59vfjjhM3Hzzu0Y8/9qIrXvADcRinzj7r/P2Y19Ukr36YTETc9OYPvPu8N/7Fb331Bz/8F6fj7LP37v1x99676hFX/stPuewTfvuoa/93f1gQblcI2QeA47Se2MBLgML4DKXIoGHgjHEwXOvKEBcjwgPa/EuoqJkcG46Jc3aZm0CPQC0O4SQE4ZDxlAUndVRSVkOSBd7cE97bGVZa4hhrWsGuCBacE2kWhtICAx15tnAm/pOe5pWPMZ+BpwURrr6hsPTuv+mH/bLuwoGG3Ly8XpO2s5rsHOB0r8wQDEdIB7EIPdysz/AEueDagLJB5Xgi6obfrJgfb99Y00r3kmwcqgkcc8rConXcYyYlFkyeLEg78LnORqc1uH1o+FVyPoubcycxRSPlFPMcagRoOwj1iOVDzNu+SctjDFJhNIYq+UfghbRT9JDNVHFOv6fHQjbNJM1+4C1+f8Usw+K5otgGm6KUfEKRJ+ycnGTlAaVicx6TyT6EZychKc0I60tPusHgKwyj3LfRhHH+FBQp+8WCluHssKWVNjfjXIQ/fbDVMgc76HxbjOE7iBTNDw4UbcMZkWufl1RBGi+z9oWJfKqz41yCL1MVBA9ZuTqR4Gb7XI2Ea04CsfpVgaaTJ4podmA1SpanGMBjFI0wdM6jpdfZ7nCeFfK0e2Hi1GDmpY2X/cCbrYkzUWmf4TZWi03SnWE9dmtQho0DxGDD1lIMWDGH6ZRUJ7Bt+xFf5maDL9heAKdxvg1E/Gp7Nx3uVu3COoxNDISuMfQW1zeIhhU2FoM1Gj5h07IBl5DZ2nYYMcczN+xVxtffLwt2Q6yUQToPEvgRny3uwPc0L32A/DrOLVPRxNjgdFM6Jbxg48pZdDzXSgz9A9/WUTra8JhteynvlPANb3T67B6Ur+JANb/jggIAhOdIw49gHhvQzPa5UrwSdptcGZoUN8WodFVkICEx85E5Eu3aqyttNChg13znpjU54RkqvAZ/vneIubbbjedrVcQJokSlKCeGdwlsSfqUm2YYohhJXWyPvGB69F+oUZeRi9FdpZwLRd4kIjcst9eUOAxUFHtUq2TfX3p6vXM995Lz9p94z4f//JPu+cj/+Ifvec/64Pvc54NVlb6yV+OVE3X69OkH3HzytmddeM5d3ve1r/5n3/Dzv/KLBxcev2Tv9ttvXr/sUc+9+fmf/tQ/e/qpW+9/6VnnvzvGKyaO9PD/HR8WhHGIqCaM2u22G521EyrN4JQkI94BHCOChhRMcsOCAsb3H94Nz+mn31Myfb/pQCkJj9DqFSZBILIkH0BWMPmIJQ3ojWY12GY9jgC7ysE8qZkQLJterPZJomvTskwGPuZdSzxCWqMg6sdSh1YgPBHz7s7w8VXbegT5gYenyE/GFhi8ygCKzUCyK8dnSgEn9yTBHLRoZzCU6ATR4IvFMMCq1MDI8WRTxzfDrdZVkSYFoV4Npu5AbLGTTKRwECPSIMjguI1DTYh2FpcAG5gpCmoUCdFyTkuWC4liB651bBlhQWYJHWbfWe3shGbIxzqWU4DqVx4wEPoAYcUvCoUOhwi0SAzSkqrC3EmZxHZsK9YdZ9jV7nOgcK1aMfR2APNEZdBXJb/2D4LcnIALA3Fv0ZBFW0MHxVF8FGUJfe9gUECu0g9kEQyiXdZm211F1M6K6/CLnV0UyCO4olX8jpS4U0RIf0egdrT8hMnwW/i1uTgwTVkFCwwlETGNtclVmzNhKHGnJGvz6ubZPdHtvpjXBfHSdLJJiLb6hyzksyn76zGnmGZ2t0DHUxyB3mULC21pdwu520OBhuYSnsPvLOgojKCgX6Ki8aPnoyx4DV7Bo2sDsmeMknam5lZE4P7ZGdPMtyO40kwq2ymn7WfkwGyOmDr8zwucwvUuX0824Z8RbOhi5IXFV0+eaMLAF/2J3IbDIN/kMhfbFuuAfWiqlqvZfX4MSutADGy+Vu48aWVbTNxunx+fsQuBjYkIs6X+2a/G8BjKkBfbJbLWQ9h8wLvW84LfNjnPECSoaN4Ms4N0GiYSd+DtmzFNbWbwgVUhFRbCPf4GLAcvgWJGQzpuOjbNduaytesQE/HqEdOuW+DSCRxyD967KjfsCRBfO9c0P9zCIWxgesBORujVXCEfSmi0cQ0Gy8lVXAHfcISxHjAMp4Cvrvag2Q2uua51GJYkW3XclCETZQYPC/Bj5LXggTbdkvLGkFuVUyKKTGdtT4pNLYeMiLVi/yBjf2+/Tt5x88GXXfk1x//PJ3/1yzPz/YPPuRjs8daq2vuZ4z/zjqviqr2feecbvvVX/+RN99s7fvzgxIlblqdd8bl7z3rYU59xEAcXnJVnLZl58Ld17yA++x/5q2K9pi6OCduAAJ0ArvPUruCdSy+cfNubbMeCffRqD7NU0eejzl3a0svZFYtUHEyjYxjr+pnzRwwwXgwsRHdF1LJJLMfI67pSVig2VhaH4zp6H/13OMaKbSyNQ3z/VgekhbwW3xMHlSzdXVwMhBNggMASGdHvO5MGi4FHD52ZO8mD9jWwJU57+5OyzJYXgq19HY5oePeh7o1cAu/+4INDoASam0KcKxgd76G/7uzBkds6cS+TVkysQAFV1lwQv7D92X42FtrBkdZI0ESw8kCzGtApgWmaaX8KYAR6FDcdcLm6RP3VfL44s6LbC80Y20vIBz6gW9BNcCRAi191UaFrOF2PVkE7qQ5g0ViCRIY/u1m0mn6nFaY+TvmCNso3DQv6YBfcViYpidjAiuNRRPB1CRm9pXOZi0j1MhoHYhQtqxlvh5sOXCoK+VTIkma03a6ictFqV09G6gqJVHHRcQnghhdLhssBF7PEqUAZEhHT8QqXhQ0hKW+ZgHYLzEgytIIEf5WuCIERDOwL+Rz+zG34ZUVEDHqWRhrMN8x+yI44We3rBGwEJSU5SiZHQoNbTJnw5BomfOIXdFAbvxry7OJ+DfGb8kce68Yi8QfJamSHIhRYkL02FScwbhMrhx3JUwMd9hK/5K8PgP8ATdSrAuG4pp/2nIqewkllAKCBD9hgEgH+hCmQCE+LEJ8WZ1FsMwc0TGPxzng59LUguaOvV2T0e29pE1b0RDdkNt0w2hCE1+dk2wuHol23HTq+7+D50gm0SbJq2HKHsupn/AVwqoBXHmuSvPhOlYhg4owmBGduWUQmizq5OIUIoCCGevEb2dkD8oRM22EgPVAKDrAVzCcKWJ0e2YV3+I8SZsNOeBZ+nayQmBvAJsaY5GHQQh+qZH4wxKE4qTzHsLA2s8plJn/OjKiVGQ0Y7rEap/27UkOwqvSqo9rYUftelGKH0zbueTX+MmznUWtoGfylNXvbbGldFZDLHC+xEk5t0D9Vmo/fbGeDVlPmGEXZeVEoPUM+xKFh5BxLeZCNxcaWFicg9YSyMBbyIGNwzvEilv0lTp68tR76KQ87/pj7PPL5EfGU33//+9/ykLvf/eRHWtXLzMPW4/U/+ub/fNU73/tHh8cvPme5+KK75DMe8riffOAl93iTX/u3uToY4bcObt9IiCIsY5Mk+b/ESHYCuC1j87+dD40KiRqQRGhgOWfTZMELQTY3J/RP1ZBjdNxkHxXhN+BOwNJddtDD+z6QEEQGV2psPhpnChH08AAzSNyQnMtEtz/cQk4wrxEQpPBQlVgZ0F0e7JAkRqpZhraym5vD20VTaLpc2bkM4KT++veqqFoD22vwM0zutA86nPQ+AS7trXXQgDc/QTGEqyBvzuwjc+m3AoEEPMhFnWeQlpwrg++3DCo/IpeRjgFHVHE1azAugK3Lvn8zoEmdPuvaEwVPaCtkn1WKjTjPwA4zDpsGC2UnJGU/brC3oqWDn+uRFo8EKiqSvprUExnY6By6yJ6Zq5ergj/ixM49LrP1WvIp/+KDdahX75oO+fgDrjw5lw7Av3iOKozazxJAwB36ZxHfcwx2RdtUyEZZYiE+h++vPAt4saa4k1uWzadLoCs8rA7TjvmEUW4bfP9iA6USyyCgZ+vZEYy6Au870G6JTIEGDDwhNHFtwhjz/wj7FSt8JRudIHNjPxHyEQ7L+SQXzqGwE4m7OeGHAokQPkMvM5bJ7uT75o3U3c59REtjijWsIpIrtigCigMY5qdmIPxbgj5hZjROr3g/Xvty388wrQYysFfoURWW6O9EkU4EPbZSZlKVfjMj5tUZo4hdLS5I6p7AQSe2GIJ/1C8klsVkY3yIFoOeF+Ax5p/og36HgFFgZCBQwhdw93tzCT1zhd4KtyS5lAnRjV9k8F2k8BP6KORh3xF12m6A04wx/W3LCrHBeY8iS4xVpUBiak3GQb+exWtItpOvhnAYXA4ywd/sG0NOBmp8UFfHFhY5lkvateQXhjR9JdzbZErBtd9NnoGrlRc6zsMsTc4tC/cc4XmE4x0bDpBlF6QoxDdZof0u2xgYuI64gjjeYwsFgoIXOjVNqSYedy9Vy5f+AZyyselnK22kTL6UasaIl8TsmRvG8JLN8j2y0DX47rFMmrSnweOwf4nYityAjgOg6RYbPlNkxOGyrsfO2cvnftpT3v0F93/CNe++4d3f9Zq7/+AdRxVxvV00/uKmDz60qh74T3/hh376l9/+hrjw3Evj9Ok761kPe9J7X/joq/7529/73ouvrWv3cf7f9ufIFcLc/KWtOFa2zOU2P1SKcHIzmgQcEaFEcp4d13rljy+8g8DeUM5U+8c7WzAk4nTYWAgoDDDYWuNupKQo1ylSzZkFglV0kootBQAeFwMcs+WMQLNGJ5HgzwMfQMBko+amr/Jlj42/LKHcgPS4VsEznUbqqgE4i90aBjaAR4Y9tr2TWI5XTZ8I0Ks4EFCsi9VFL4ZnEEDSZnZEHaelr4m4qRVRji0LMQAxU7TYMvW8mhd0iDNyvEkehQ7G8ApbBiGfgS1MesCvWEFAt287RNmoSqUykt2/iugbzG3aPIKWiaj5Q1mmrTMV70Iac/oN9iy0y7Zk7Q49ZNj6gLysAK6an7y4AyR2ZKqbC3RueVEfeXtcGDAIRcCS3Sv5p+/nOO78ktGUTrCSp3OUNGctklNfy6Shoh92gGC8xdOWCeCmbQWGkhH9SoEwLJCPeYIa0feQI6BPnXgXdtt4ygf0QApXhtukdBw2rDCbA0n+obmcgB0rbWfjI/wlkkCiiO9gb7pnukeCD04zzfpy4525OspjHJ+dUIsxcn4aLxNi6LE/SyJ0AGc7kenqHzypPq7gq3SATRMf5kuIC8BbE8N0i4LFx8mlW0X4OUHdViaYL2RzPLX/ISz2agU/wLAK0QscIw1pYrWk1rw+c7GGk80XM25rq28FH4xG/OuYzPgXUf2U+Wws9V0LrgPZ7cK4LpmE7eATBkK2A8/x2CnlO9DblLwW/GujBAZhxGNED63m6x7SRnd7qAdyC+VOsOEYjWrSlLJXqHeiZYMZ5GHT5Ae+uNFhBMq1aSJPjvFu18A7xTBwP9OV9DPyEqXGqkyjTwU+ozEqjBAYQUZp8mocmXJGs8klTV+UErEe5Oq9iTZ2qmGPucWLY6j5TIr3IZ5i/jX0UzGtrqJ4KpbNPaIjdNJuttgB3LYpN3gvm4TiKjKYkhum0S83svLfakPXpJsQroJYNqIqYu8wYn85Fnfc+sHD5135xce+5qlf9W2ZeSqq7ox82RFoNz5vectbjt3joo9532vf+aa//zPvecPDDw/OHB6cPBWf8+DP2vump73wJ+Pw8MEfe95573rHqz9cefXuewv/Nj5WEJox4J+EyD1kWnIKw9+W+GGyNgPj32bo2y1afhmfejdpLjRnBAOqg4wHnd261QJgzg7iBqHvSmOGOUT5wNZJDmzDcQNs+dArNBaAjC8jteuTAOlAkjuyYgLjINUg4YlrzRcJ4cw3EIx3AmPo/BXBggWchvSdW76k7/cJDt1i0uxgu7A76PcxAZQgH91zpzEyk1vP/BHnZd1aFkptT1MDOCDbnh9Ag+5rJnZf6e/QagC3XxJMMLS/sHZxBclnpmSrYtpWi6Bhys2Wz8bdlAT0/UFurxwx21rMXXfuGWIRpnP5s4MiHgISFXwNg0zJgpjrsSAN6dUDduE7BLcIvUdoweoaMKroHwpmLYS29w30T0URaWNTyex700WFHatoRXAEv+YfE4ZCLq3T1LFBpjVt+po1ECA7MQO2ZGnzARM6rFZoTG1BRBOvoky3Q3+2ou9MQlcLQqx+FhTI8T25hRygW9hPESvR5cbWLRoj/AV6J9Q7RiQpIT6H/Iw4WbCK4nwDjxQHRtyQjvRAE9sxgAQoM5Rouqy2bQX3xZp8nPce9aHFGnOw23R+oTvwOYRg2KknZVJfSQkY8LrNxSzfQINtFEe1oqgMFlxTqZTJIqyZkvrMhxlDRKp8wcBD/g8cyunkyfcsFkOJfIZZwHObQ+C3rbBixF4/o9YytG0/Mrk66vkoCnfaVDfwtUpiyTINCvNBdeM6jdu2WPDfGA8XX5P6pkSRaNNeRgBC0eTpFFTP6zZNAuJqGuY0DcAlNnAW00dJZvRNNhHEb1RGLD0fcTJNL4pbZfYz+G0Zs1ILjo0YDZqABMBzFP2Im9tCXAPah5PTPMOYCZmQYgN7DXQvwy1YQMVU3M3Nc+gvrGC1ggp2k2ZLwP6ez5unQLqgnPszPwwfAqb/85aCdQ0ZZQrXPf5xnmF3Pg9yFW5LNVGXycB9nZKm3UIuId6A3fAtYDb/HYqljrwTbLY4YTPIBn2oPRgjml++iqb1tGicpZY4uOOOg0+89/2PPeweD/7uC2Pvj99/0033ujzzT466d3AMk2tErFV13599169982+/801nzr34Y5a9sw73nvGgJ77hvpfc82WZecv2ur/tz2aZEl5KZNp81Wopg9e+xLcIcsvZ5qMKXh0MjlT6qSmtw4z/VQW2WMEoxx/JK6Zx+y/QtROsnO2mESP1S7hg35JJVWStozOI+0ycXXkUu2oDHBAUJV+xi5erL4FtmQzGYUbe4FJh75oCVGLslu8aAAMFCd8KyW0xCclV+At0s/d+D3pRaGy6eFHhLxRdcgl0YqufHrrEuJdhAKCBcQbn2wiDCCwA6QFWnm02lrx8NXxIyLwRa61DBkR/oW24hMtYyzCZFTvBsKcIuQoDrtuA7Xmmz7Sf1Pb66MAJec8DaZse7Wde4cRW7cqVEoWaqvkQPQrMTHYxRvmYmB8BEqOGzkOBvQXoyd8s6FSH2f5+uyUHxQptzAoq6iysWQLdBwK22bjTLSEHGxUTfwoWTFt73PYEV4d0tUj2HWdm9fvyLBINKL35c7wEBgWaEG0X1MlGD1NrgOY8CKcdwI4nu7KLou3f9F+UnRWtbsPYntUqX0B3ha7Bz1r7OvFs8EGVCHtbnmhOZXC1U9eJUMUjyTC2MRoFn21VmpMcw0c3RrffHLzM30WMhGmlLWN6rrQQI0xX5seREGDLzBglX9mxrfTllOxkuLaMfwpdtrlGrHUYEf2u4cb/6u149F1cDv1ND8ORBYJOnwuXjjPsIqNq5zBkvOhv+XrS/hCduEWtDX+FjTXuF6JaiaqlOVGkbNmZ2t0HhpwXJr7TLSPshNK51fAAAJC3bmaGeKg+Jy124D9eNuGC4UvHkRW3aQDj0/XRft22uFEKz2UDKLHKVbynKu1/IiBnH8qMqk2uMgUf0yXojDReB+IuiwispnlZ/JYPk82UhDTPCV30MWx5HEAdsAC7ZHLx+foINc16LqpT8+7AKQey6/t3cEw99Q8O3z9pOrRbx3jYHPJF/BeMVyQxjR3gJGzBjZ0CaPomQbcVYB4QiPsTKLPZaVrd2j2QMw+Ua4ouOND0jJGOtZpCDbGpYRljnLVUn0TMsdUoC0w/joDo1gmRo8VyfKkzy0F8/sOvvOX/eOwXv+KtH3jr205cdNH7xiVzoHnpS1+6RET82c0fvE9VPfxf/cZ/+pbXvOmXzjlv7+Ll5M03L0/81Mfe+ZWf+Zx/84EbP/Dx19Q1ex8tW0Xx0QrhFg1xrGJj9Dmdg26VL9eqwzz+ReWvE6yjbpa/GzZ0kEmayX9cWZMPD5rUKYK6dcNsh4MCHe41koO6QT0GnMWAaPgCgoHkwi5Jd60GewnWTYRmrADn7M5LBAs2x/AhEwWJaam/pI8lkwFy44viT8oLJKZjpU0yG/PjwQRpcUTFuBK4sWrGoNF6ReKoJMBkDuJQtBZ0msZqqrDOdtamU93zjMk3TSzj31XyiQhud5Uwhgz64jmAVj8Y0O0RlzdNJT6BmWZOBp4K1gMQl8DKiWiDfCWeJfEaE33nrqjtPxF42A+3uWyEMuZxf3WVyOF92wgLzi4GoJOdbRqMlRtvLlqECVD0t9Qt1CblQqE6DxizdebF4QQkZQpL/Y2k0BS5O0eanPF9oSnSPsgtoZtuLu19Jmg0Kcx/Qw9+YKAkGS0DJxM6aBlDB0C2cBn7WBiyZTaz7s65a7xu1/hwp5Jfrn9IP10kfFj57CzbYFIK3fAhHcDLjW/S/UtjF8c2H0LSRBsBpiOZqom+suNgcFyWnLdg07wwEcooPl6ziVPzLRdy5o03jXlxzkaxwMSkX/bxHtg2aBB/xqqT4yUKnSCOOaYOdzGshMpqtjMmZ1NC7T9IVV/fMoFtcLVHooxyu57lNPxs0Xt4O/PckWICd/hIHhNuTDZGeSdgoseEOaUwUdgEYlt+Id+fnkCNUzLNj0M23HM5rHvBv30iMl7xtUFxm8vta9tQrojUk7nNyNR8ymnYCecVv+TDGxcIj19lMrIw2H9rhdqYC2+u4NdNP4XsSYa5wVs/yXiXq7jUDHNmvNvGS8mzhBHpJxuu8Jpiwcm4mvKbMfEqX6fvgY4ZV2eausm9zCtraT4PrY2FDCsxLVeFtdL9yXsjr0E2MRzxJDYXyQrCc+NIZQHT7pnSLgnCdOV0TjAy+DxS6yxzFz50RHFNc3HVneMMFexVxLK3xJ133Hz4iAc9Yv+LHvX0H87Md8/Mzp+Xvexl60tf+tLlY8664Kvfc/KGN77mv/7S517/5x9Y73L2eXXve3xCPfchT/qpc/aOf+Wps879/qvz6rdV1d5R4/xtfVQQWpXvsWcS0tYw+afE60lfYTB8Y4nX1Oma7KWBw422B6P6M7RNjPNjZACbXUuAFI3EigIQoBCD48AhYYx4imAwGMpwYwawDmYcM2XKlDHmTj8K+uTsSmjGL3zsLgrclGx1v1d0ABwrdajR3CcA4l4UIpgh8AkT8XLtcYBPY1N4l3NVha884htsYeOWxgy7IwL0Bo2P70IFeUVYIp1hfKOYGzrJjnFFPslXT7HykeI5wLAq5tddAP0Q2BbNj6CR0hW25umBAQwZk5xkNKBrtodo04mEHpJyVZccegvyjSeeTcGNv4Gmvr4MOCGfptYWo1gMEow98IKGDR5sYJj6gyxIdqB8AX0pNw3sIEioIMK483UytHnCznE6yM7WCCJMtyHDYLgz350iYfKJmOWy5lPKbPhO/rh6othrCzjjiaS8Hdfpa+6WHkPb4O11MCF5Js+bgx0VGmAf/AULMOgmJSzSOvAmJcNAY0j2qERmUn0Ps7QetzG07KwgT0yIXEdh8uVllqRAdj5zpR73jqAGv0Rzq5M/2X2ZfIqJN8acXk2E5AaFIDEfwi/aFh4Yg4K85EzUN7GiYIEah81F8Ecsb9zyR/1TpJZA0Q81L+8bzaSvj2Ym7remd02xa9ukoRwqYlpqM2xDEp0tbH93q4YDnxEqWGS3EcLgsf1wVb5gmAbKyWT2U0e78EjGhjKfg3+Dj+ba8MpUtblu6HOxsyz0OdzwexVLUztpaAu5D7cZ1uxfHat5X2Nt5WQqaH1CPvDj7GM8cb5pVHgMaVp+CCE6jnvTY8zhPpQcb7xOQbJTwTEM9KhVH0xZxp/bi0RteJLA9dI48JmpUmsdwO7wYTAy/KHBIr8BmMseMoAtjjcZut+07BzZPjxtNOtGrsmbykrY7/bD/dPGj94LHR2rgNGIZWO8+TKLFOCFsvFYaDbaOILvZBqmqH6uAvG1i74FhWtAPv3ICVPt+GflK1iIfXjnbrq2DRenv+1Pl5HQwXA0ZTM90v5hRh2uh+dfdHFecb9Hvf7TL/2Un/zTm95/r3tedPc/HSRst6FEVNX+ddddF2efffZP/cxvvuZnf+MP3nB49qUX56233LT39x/+/HzeQ5/68ttvv/0Dl5x34ftbXofbMf42P7ZCKGGWoViGnHEWtHXQ6fhHODIddLNK2OPRZy2IMXH1UzUM8xXQTfCNBkAmz/NcdN6wgtFXHM2xZWJ4DUQ/YjfXUcwA3KsTxKYRzsQCuMED76pCMrhW9aOnB7+V/aj1wGO3lTwgFRjjLWSHr5Mi0NeOowAUsRIBMFjXlnMrePtghukeL4yY1atUoFOgiEvJex/wVZ9yASERNjX4NglfhYoo8oh7KEnv0gVq63aNca/O8G8kDYNHJdC27aCJXi3hIQxW2QpszebSxrLyK3XtpvcCBYqHVcBE30qOjQQRK0WUZ9sNbZIJEIQG3orzRcsFhSov69Px6PHG3BhPAGW0Y+DCDeMYgF3pjPCHAo2vu7DAfGio+Cp5+8mYbepbdjMAvFX7qQV8mY3JV7bJIJudMHpCs7O6gqkyFrzcFoV1YHxfdWgZFHwA/mGYCdFxnuzEnqPa2At/n5pRGVOSmyl9IggDm/ldBJtEGh/8lb37btjCiiAespuCYRM4+hzOa7jIANrygow8wc+cdOSJG07C2EpSVtKEwpZ6d5pCvNGW4QPtxeB1xIB+Sda02pqRAymoP+IJ58lJlm5vShCLdg971SPhUTAKS+GaahIGdYgkUu9KQxGjOMikP6JXA2AHiKTDfnDOeHiJknRgCdQQhhkliQ+b7OJQIQGxuq9hU6KNnqtbpnfy3hjmtmF+mZqE3+H+7WgcqY69iDB86mDHMSX1HIhxj0GSaJPilBA6XhWC0xGDuHKPBgLgG/G2zTtd/417S4bNP9vUsiTfO+pxdoq4C+KarpPe3OflZ+XyNJsCRiDkrMSbxjncH99D6T2DeOuw/INOzGYN6LJjCpRmc3CiZM6XoLPlSpky/kqPmIfNYg0QabpmZDFI04q8rLwjZJPUtJlAYevC0MkDd2VA7Lb41D/xIgk1kuHrwTSM+DdeNBzLAnLUcIEkFsv9JttarbbPfn1TArMXPaSKtITptqQLiyGKheNCFcZ6SoPfBwgjSv6qOBmBW50Gn2wcwLZYQEdULZ1bl/xtWcJteuDIJs8xPxtmaQBODSa/8xgttIuos/bi1Imb4okPesbe3/+cL/3206dP3+vCY2efzszqrZ6GdAE5HEREvP5Pf/9pP/Ib11xysLccHNbt8cmfdN+84v6f/a8y8/fatpa+z/Cj6jPvX83N7/xv/iK358YAuAgTZ5oT2od7etsooHwCfbQxYt8Glkt6bu1o0P/oGKRg/KSRY8w2Lj6oJv2KbJp7/GzhLOoqKvD2uR5YkMSBnmCkGXQDIHjvat/zEKOgiQlwViVeqbkYuiGSwnHR5VtYGawBmAgoK7nQ+SG6EMAsnHWwi+D7/MAzA9oKjAjeCJ8xtigUOqZAFEpKAGAGhUIC7EuHTRNMI4IBWPQ1DUgoxMCg0xoVAHHQN98nJpBw+6Qu+foPAxqbX3rBt+PaBUBrssNJxQAlfTCxhU4Y4RBRJaelxx02RUGQJdjR0N14jYbuj4woS9D6WwuAAFgFZ/fuQlGum6HoHZicNkqZCIS1yso7X5uW4nayaHoTbGfLFT9LaoEZ6xxewKAGm4kqqRsJNGholrzgZews6UTxdGPHERGxKLnupMkTJgXAopx89Q3yhRTln8ExhhvAl0BWij/KdBvDZowuYMzOd/CdxiyMRVnpXPJJr7bYYGYfm+8iIFMdcDyGQyltNkiBnfcEpGYqYp2dlq/JWFU97N11hqT1iGYNuZgixEQ/+WzbJEz3dwNV8boL84oSLiG2jHG6GOUhrDAYkq4dYdL5TMpZGGjHYYsdd2b+QJvrLCURS9zhchUbuzafH7+WkuSEzcjO8Kod+MuIfwNrxKl4AYvZ8lkywp9ACsxP+MsSamb026AW4i148aYQEM79DDabbPIgmaeUrFDINgQ2PvoeRWJ5lfyg5aeGREto8q8wY0qacNEqIlAlKjcbAy5MwFNxaZG90+5TzRPHf1LAmBST/XBXABsJFMmwlzZ4z1WEvknZ0Z+EFDs/Jx+vMBr9I5vREWaSNFrafc56nCZArDBnh09kzvYpPEuLFb0oAL1UdH4ofyIWUv/GJx62s0CfwihMQrVMsW0cZOMHgNwxDY3ggk3jcpfFanbjOG9+Bgr8qdWSotGb5vEFM0rjyZoKRi9iPyQ2RSurG5h5pHQ9aRJ0keiMqCVOH5xe73r55XvP+JQrXn+/c+/+a2edddZ/uvi8i3+v9TgVc7gX8P03X/+IqvqMn/yd1/69t7/rHYcX7V+c+wd7+bRPveJtT/nkh//E2z74J3f/SMXkR8NnmX9pUEL03fWd8afjeQLsxgfbXXaLwZx+LVT+GHAqTJSMZc6K5iof9S3rkzMqMQg7ZVoZbCfcBrvY/I5CkMkxAnmNwALnqMmI+/uMSHvnIIw+o+hIRQbhDMlxqoOZILCBGJ2z8OuKcqlSWYHzEJg9meJYrUhs41ghX5OhtNNFCwpOOp0pal3VHUJg4QMJZmNKBt2QDXS3ks2DVN+CiTmDZ0TWErjpmQerRkKEOGO0QpFKkqTU2vCr+736e1FCe5vsFoG+JyYW4gyIdFOIF2UI+5FlAgSR3LHby+aKc1GtI08EQCUCT/Nuxo8imltQmTikUZeaN62rpwEoFTxoCKcU68QO+M2Cb9FV7EvbApjhT46NRJgLo4lKnQJxRowVBC+K+5dNw9g0BFPcKk68TcBY/Jq/LPYfVgAgfQupfbmAhglJ003LY7QyX2NQbjkS5Az0OFc3PLZYGkNPune3cdhsxkRmEiwCMCkyORR1Z5ZImEudBPsFd/2PKE/ix/xggJ7I7BfUEO1YgEMseOO328tGH+Rr/ERTMns+T/64DS5FBHGddg3flQ3qdLMlhj/o0xTVJI4HKzjDhn+Ttjy5dxZnvGFmnsWG17CDYdPZY4/nfKx22cAoFLYUG743PY1zNnozOv131j+ZoQeAKHkOJMotJ3pHGzXSFonWVw0kjGrbqD7OZJkv8USo0MNMJiaBW5Q1gUzbdhFHNkUdbQq853Zs84XmtdZqDHOsAmZGbJ/IveO5xQGFJxGI4oYQsP2ZHN46IgeNDMMmsFLtf1bUMq9ovY6QgJYk/NXxqj8UjbWZmEcwwmxdGBoh3kkUbqBzvKqJVwpJeAQMR2OiKchJmsK76aPk0RqATWUKF0V5a6KGOXpT14ua6iYXnylQPl47Qo3jUy6fYh9Ky0i+Yhe7Hqa4FG5t0gtjTklTPIfzB203zBdnvkP5jH8KjUc9Im+jav7F8VpHyr2aPlO/XE+2nKC5Zbl3kHG89mI9efvh0z7tc279ykd+/k9d9/bXX/CuetdZ9ZEfAlPX1DV7d7/w0vf8+O/80vN/8R2vv/TY8XPrttturSc89LHL8x737G89jMPPvueFl31BF5MfVQ+TwUdbRrkGDdELsFG5N84KEtxw6EutpHKN67ztkjo6RJteF6MNXNsNMUKJ9qBU4Oo7n2gu2KJSw5lUUBm0lXjgtaUvqgNnRdrj+yCdVEFmowJIuLIVmpNuVCRxOED1I4EXhTAwtxIYlMCRXm7LSjKgbWVp9M6ORzngiarZW/qgTwapEfzWkryzFHSRLGGblAfj0XFazEaGXFTsag7IGpSS+kwGp8HbmJAF0Hhpm6wl52vD5gHB6QhZfm8kxJWUGbc8wQS5shnTthYMpm1v7S2bpsn8yd5Gqa4X7Z3kTqGbqsR9SxJMmKzla9jOgg7i1OCIYGd7Iq1vbEskybFoiworurDibdig6wC4kZwVYwuomWRHe0nLc8gKWGNNIgJ8tT8jWTC6WmbovLv8FMKO/kz3WOIJ3dpbZtjQjRvbHoiCGgldD+iWEShc9NTajFxly6ST2/CS4/goDE3kuYhvwes2gT2bB+i92t8WYJgchzKzY44fGHm+TrKPiOC2S8BTlJLLCnvtAYoCWxGn3q2RR5vqtKxqpig3nMMvTT+yyXEu31EKk0WhkGZ30w6O4AArsAjGGaW8uoCHQz5ImiGDaSs4/rUCaqwApoFO0xvF7VLZpOVavWJQkimx1Bpo5KH1UCm9sHpuTt18UrSz0AMg8oSmCT5hggbu0IbkRMHVivYdf1uPVgHagFK6rd7OOL4qs5HmlXa3kk8MBfkzKuO1RZRv9LvgwCMsJgNbI4n9EJKCmxkYVlsae01mwLoqyX4BVkEWQAs2bRoRKBNhbxkO9BK+/LLP9WYNC5aCLdL0hDu4B7d6lVbQ3LqRJ42DhhmB+aQH3bfoSZTFNF4v3NPuiohM6RwdAIyguKCPdIS/gUuGU1XsA+G7oTPYSeCOIfo59C6chz2YDugL0KP4HPAiHZNn0DAIISZCmB6lIa/MZBM9bHwMiuPIMRzbSQtEipyMCllbdykshCRTcxBjCttUu9Dse+O1JR6NtdJ8PTbyR5gBhy+XEg9SFvAm2CwhBhje/HiYkt2aL/S4e7kXB6dPHt7zYz/h2Bc/+HN/LyI+7j53u8/ll8Vl74qP8On7CQ+r6tFv+LPf/po/fu/bzxy/9K7L2eecF896yOPf9ci73vdNmfkLdv5H1b2D+LBKTf+FYFMGXjoJBo4ggUsyc+zx7SQs+T0utE5g+DzBuZio+JXo5Kw1mpWrLkPHOdfxH4HMsu4MPBa9r0t06jgIgyIY9fsIGccKiQkAJDFb6NULA/zVLFyDZxlarf3eE3RTEBwWvOqBOINOh4II3xWVDdLtGiPRqtBm1P7XgB8MjYLPOqT92gsFjzX0eo+gAy0Nzos5cGbvae8ZM6IfE5/isQvq7LGSgNLMWifLmwNDBMUFRhWFCNbUALcaVIxEDQUzpaF/KBdtXzaADfkDGxuQXQf1tYPk9OqPCna7sDo8tnFqG6VWdZLy8kJAvgD7GpMuy9KyR1+1OIw3RNhZM/dlwh0IWwbm8DIUH8ORp8IYtuIGnIGupPABDw8ZoiixQD0Hz8aKltQuXhU10/Co6UTgy+otXq1PdCIRXP0/S7JnrpcpAJXJXGoA2LROsVO4R1/5u/hIUgV/SPlKZOAx/lHLKGZtSxs60gtwlLiIwt7nUkuIuoZ99TF2jyuZMOHeWBa6KR6QU44gbvqzW5cxPw8wwQSeVPuTbJSqzO7J9sCLP+3QxhR6aIs6eCxqEFPDXluWru9MzjvYSNouPkv28yfZXBkYynBAXaYPqwhVPNCFdb82yPXf1618hYPsDONF07ksHUd5gvx+8NGbFgnXZj8UuGbxbV08Vj1ONxByo3/YjFYZIIi2RdOZCvjQyhCxeJy4tuKKOYD+J3AWASz7NvhhByJyiSUqFu6aMFlZXEDCaojWf3cjDkUZA5SN1PyNB/ck78/iCJwHMWC2S0kWMtjivApL+nCA9ZxpaptbdAL9YhUSBvAdeQLFmzEefhAxGoADRt1k+MfCB0FFaOXF6IpUI8RyRGy/I07Srqsbd4inGW5EiANqXHizfrU5IF/DbpoI6FKco3a0lB50FB4SRozVMhUZkA1kAXkGaKL8sudf1PAyaKB98CN/iWj7XeHPsLBVCqL+wWxRFyNTUxZRnYcXZQ9ft6jYTOk2gJYl8rRk9hZY8Mj2gUTsKQ2JuBJVzBHH4slUAUSEbiphk7AoVb42gsLDLSBhMaGFOuUo+N6OM0Ws0PH+j9tEhULjryXi4HisB8uZeNL9Hv2BJ33yZ339h2/+8H+664V3/aMhyt12fkTEn9x000VVdfGr3/IrL331G38hzz370r3T19+cT37IY/ee+/CnfWNm3viWt7zlWPmjgj8KP/vTX6bciAkbZdSFE3Pz5RQuY+eskpJojzg3pRBFpIB3GKgEu3reStHKg3Q1yb3su0kd2zR34bgqVjZZQQML7sHQY9GTvPFBB22IFfYUJQf9COvMbfkGkKXpA1zWhhUkAHYu5ZwMxvCxSHfQ4r1nsR0fJFUavd1N3xFnT9g3+fMlqFWcV938lFqbdyTfS+tg6vZVr3xY4tGHQ7C1xLj3Ut831lDOjBEWbtjBj6aZPlAte8iurLsZUyFhiIVwTNlu9SFBQg9ub34y6BjjsQ7o5EWFS+kaIKzZu2wLolYwYLrgumfg3fiG041vaw5xpDkxumTtpl19UtqYHRYpCxS5UzGHZHHCItG3+VNiSL9WXMEXJjzqYEeMsW162U8QGrRNApGdm28zyZKhB1bZx2X2NEcUEBYkXexjLKO/tJCSMa9s1/RvbQrODGeN77WkvUA3eKJjzILdkbJEbGzSK8dw7rMV7sbc2ZCun5jGhc14XQKZye/mOC25Nz12wOU7+TV2Z/RJLjZzyWmFmtwCX+cTxs/N5qBpxRM8GsZaZi5bdNyjXADQtgMJdLQdIz4KA5IYvbr/rkG8G0keHs+JS4eOKLsaBYHCtRL44U+tz6XkExJTsyenHRx0Mm/5gPQPuQizxjgQ7sohES+i/IXaaog4JrquiN0mFDxQw/q9ogyuWKEEmsX4GHFOhYVnabzzk8JMN6Ahv5I9ukHidPtj10M1NsrGtRyhIZc2YNhwAKuFZYrgKBAFnv6g0imH2KHHbKXPxrcqMl0eZIH4NSltd4Jwbsd5M14fjWkqjGwo/eVFpelg0jFkUH7dPJXio2NaRsTh+HIxjPDYEWUrkAa09K9+hVVERHH/QMermmTBkA/o1ZnE27GIAuWLKUNSi5OhQthHyRkA5xVAKYF45lgDxsyu0Iggzk7HTdAyy9lXDJrneBKxt2Ys+/tx58lb6jPv/xl7L3jCF313Zv6G0b7zEJiqyt+N2L/rqdv//clY33bN7/7CQ255/4fXi8+/LI6ffXE+54FPesdl+xfc/eY7bv6kC8++8I+313+0fSxUbRwtAABHwcvGyHG+nzsli3K4YTOyxjSI0Y8KdA06rCjIJToU1qkIO5dBh2EkKthomLhwp4WBj+vXpl+rHDBA9nuXLgBTTxHFKGs7CkAfwWSNCN0knwwmXKXCfDGeAlohmY7Ti8GXkFARVStXKoZ8FxN5UX4uXoOkMQ86vzEYHvQv7GAZSgef/hUIcPYfOjDo+mQXzUY1AyfPG9+NTn0rGsdIqwUnTBWSSaW9XyfT5AXGUzjKxEYBkCHY7Iz3T8AIdqIPABPUCmi5XaoBjJw3Hdasop4U6AWG7MD1WPi5JPRkVJWxmlZwYcTsmNH0TQmO0Ti5dlFkUzNox/2d7grKhDbd9jXmthc92xDo9OPGdk82okT/GC9krxO9M9YgaKjjCV2j2+io0DqviMAW6qZ9rWq7SQaoOZyF5Gkd9WHP7Vt9z/GSM16MMddYseoJky3ZAXRETGu7pQzabmvSu7TpWzhpexi6utsLn3B4N+MiWsAHo/jCeG69QqMMgTxVEBCfKSccawSArRGrsmmbdSda+hH29LVOQMBcGB/gYtsR9/uVTY+MUd2IEnSY4LbZLjG8pvlhysB9bJ1yfjxhQ9RCp3x6Yh5kyaJs6AzbDFEQId1fK4Mr0uChDYBz9yqgSWD8lqJdD3PouAA9mkzH/70TD7tKKjYpOxnEGFa7OSiSEE3sgzQmQAa6P5OPBGtY7/cTAtWs2BqXwC8lk8TFoG8r+2AJ3ibgcd4aK2j0Aag2QWvITnlLRMR076U7QU/or+ECniJHGcMjjlX/BxqEAeBvDCknxHNpXQ78NoGLk7UGMy5zzAmNexBs3Fhbx4y9mbKLsNiJsXylCquBxCi3R5NJzvEkgFcYH7bAuFR9DXDV/4MlAhug+4VyWZp27DQasU9Y2pJT3MtovGxdtd2AlgUr0M3EarhG6dYSsoQWFwevjQAq0PBmmkYDDC5quO8PLLYWUguVK66lh835wsxi+hy7T5rnzY3ryguR98FY5KeTTbkf0OoQA8Vu8kCFOSx9EBjfGjP/RLzL2DvM2Dtd61mxn1/6qKtvfNTHPvB9N548ec+q2vurVvZOv/e9+3c5+y6/cs0fvPbx1/7336iz7nphXX/7Bw+/4HHPyud9+pXfc+KOO96+f7h/+0daXfxo+nCFsNZDGgw5zwbOCCqEhiLUNGiJTcdQwZoBpKyb3bEIo40CQcQ5HZ7oEW2a3vGjeJo6CMnTCfY+hE1SNk2G6NCYCHYqUquLQT3yOPSvgZOCiAZdXShY7al2pFgsGcSKUChITA4BefZYWePRw0s2oHjhhyCSZIov/oT3IFmoBmWAZ6mbNWk9QQMeSzSdRCAcvC3KoVCApCDbCxQWFuFJVEba/T4reMcrNPBw537Bq+7fATAH7QIFo+4/GwJdY2zXU9AEZiD4IxApxcrWG8QCnIec0Ezwj7ZKyBD1FNxZ5miAMEBgRdoCi8Iewpu8lDqHQuB4btxr66R9UCunGwxjsqNgE5VR6xrepSv+a9YC31kC0jSBDP0Oe1pj2tJdOltbJq3RUbCXmSbGlslPWuY1novrCRDxxBLroXMyTxpoxgiufV518OQrEIAR4VjadPY2Kj7afQK81pXZcuA+MSbFVmyV7DxIixX9zTsL1JDPqebuAF+gO+xLSxSZXAPTkHDbOdAJZJTDd922MvBER2cbRbneE4oYgqCOZAw2BtkN8uVPaFxlCCJQKi29MohXsED9vMecIps8KfjKBBbYFppanwsxIpTIMzAWYxR9A6s1xKRoPrE8B/76La41YzDePZaFNDb1XROJd1nyfp1mCTqfYxTwMWb/gJ2ZukqCalPBawoGTZW7762Ff8I5teqNAjfMPzAn/CN75QQnNu+tT/ClAFwknlstaZugZpFeotpYTD59GV4dxdWLks8TWaCDXCL7PofxkLdVtMMnyix4UYzD6yqKMdgbisHrIoN47e9M1T2FSXtFdOTcZrugnTLV4Pr1I9gkLsN9q4FYZHmS2/aYz24SRcyA/hKyRpMjJGtQZ/PCtVwsYg7n1ZTigKehStCt7+DvGf3KMQ6pOBsBbF3Fg10Nh9rqBdjir4ZwvOYKIXFDtgyfcJyl/UyIAIxJvu7COh/6Dg0FU7LnYBgd746Gz/pOlWrLwgo/XDI6J53QE3ha4Nn9Wt4YsPNY+im44BKyz9DrIkx24PNIXpKQwE0BjdfZ99vWsSVO3nZzXfnIJ+997mde+YQ7D+78pIPlzPHMcw/rI71mIjLiE+KOU1Xvvfbdb3r0DTd96GC54KL4uPve59gD7vZJ/3rJ5ZXeKPloLwq5Qoh7kBEAzUz41/haBk91VzDZhhngwxUoeDAdvMyQG3y6U9mRSf/hvBRdagYYWAZsrrtANIiG1MRPBRkMmDDSiAjrdmCNuFLvBhwMZWA3tJ7qKV4StBhLU3LlK04Z/XqLFJ+2UkCZRQTe18WOB3EIji8shD61tazH6hYWA3NAF+oQC02BIxnoNlbMgZKA5dbSSwTs4mRE9G53+ijspaCPNSoOp1BNS0KhkRK/AsQkKCW5qeAnq571j6fdwj6XZQmtdohQ8OvJzrgvq7Qqw+p3Iwtntuklb7ZiE1VWMCspazW2/poH3KTaSsf2jhrPWZ98AnKA7nz7TCZ+zp5eq7qrNOsI4gMCi3ww6as7H4kluFJYkCvGBIiTgvAeOoplN2R2xRMJrlYBGARJghfNkO+Yn9iXxSBVHXSojhLt4/KWJyIM/XHY8fB5D4fJ4rGi3wPKYCh96OcafKccErg9+QBklws0jSQhJ75h10KktuHGFL5/kQW4F3dJ28TWId6rR38ELvdP2DLQsO1k9qfQfSaMN9bIaFIrUVBIRNN9Q0ig+joUobxnGixt6NAxjYv4MHotKMAApslFQV8hhonJf4ctFM6D5hFb0uTbeKGEXGm/ttYXmYBpyT9a6wDXpKdQ1gl7rorV8hAVDIaJWNJdlqZL+llT2slpDE8MK3DXueuybL6gD4XCPBJ/dOpzGQ0jZm2zzF1nERF6MJmaAm7708MzrEEC+0eJGsUr5vGBwGjWAd8Zw4EFOptQaHRl7il2WrhKi1HA/BWYYnZM+aJI2uKp+QeL+o1csNom+cRoJiw5ClJfTcyIiHU0+ugvuEfcCyBZBQo+QhDjYlCXipOQfkR1o2iOsy1P4i2PKJQy9sg/QCv0IPuGvHESDHCxC4Q/SdyUnfIMiwO6x1l2wwiGMREfS/zhCaLV9yKupR1kwjbICvPbO0ZDY/sHjRFhqXBZYnCbAU4LJ1F8A0eUhwkzXE5CqUnU0zd6UOCwQcU9yyfoZyvnwcN/NxFt0A0/NkysvneyIvQcC7N5JVIms6brzHrm8NKPudveUx/8OT9/7/2L3nr2sbN/6mPOvvDdg7wjt4vu/+zv/uw5e7nEf37rr3zXz73pV+vcC+6WcefpuOI+j7zpqx77d17xT679J/tVtf/Rfu8gPkc/+hRBs51U0dUCHQBoe236UaXhWkFDYpp2Bs4pab/Mio0KkMfp2Cmo+by0cwuBg7NYIBsna8WmzT0jkBQBGFynCFi1gjskV8WCQqtgzT+6i1hSb+dggcDhK1AwR5S2dsHBPblag86z3SblvQj0bUehK6fhvMnHZ1AO0ovLJBoInB5eqOs23Z9qnTK5RfKDwbjChmgSpBfglOXF5C4AT0YiTdHmUARQeFAOEXNjW3ZALLrFBm0DIDp33CyBxlYPLxjNh7gaiZkKgItvlb5kc4XhgqBoSYDJHlvKRs1tCSv9C7TYeb6CIWnwN4oJQWvB9QiAomZ80489MPlL9+7DoyOpe3I8bACXinpgzMd8nbxzxwDkqgyiXWXLFdSZTO6ZpNBHJFvNWSTSfYL2Vik8aDpG0rvwVT+eRI+TsEqcwrey/8BtGn+WOGkb1KABQb1PkF243UeJh7bPKYY54PdJmZIfthoRt6YvzSb62qpV/ELzjYtBW067Zran3YuBTSkb2QQBkDQebILGVl/jDRHzG9o23MT0ouk8QfRIJP7hl/p7ic2hUFTUbxPnEAZWsENwiYI2luT7RVTvKTECetCg02VcLNBxGrBNvg2RApFgf7NepgLfJIK4wNPN/grjIpwZgyw02i7Z0Kt5fPonRZf9TK+kX1Q3cylD+ldOthAt14Rct2iR0lsthuJortDRUiaUjh9FX1OCjLkoIOnWzBljgGfIbqIrgwXsWKxUgYbp9Yt03ktUUeum8OvriKvwHc6ZLjr+A/skzTQwGKnjl8TMV+KYvMtlZc2dAWWlayxGTI1z+gKKURp0sFNhhHA7pscYCVchpTTPlO8ZPhd39aRwUmDjTO7guiWB7nXy1W5KonmWeEch2UaTD8UZWlBJ9pWXF6/hLNW+y9VxwwowDTayuJAiPMDKecw2aDRSZGwAWTyZgNlVZgizsXvP3XHS5Gc93nIYcSz2az15ez35AY899eWP+vzvPHN4kO9617vOOqqQq6qsquVknLz7Ex7wxFfdeubUV7/mra+77y0333x47HTUve927/3H3ecRP3I84tLn3Ps552fmwUf7yiA+eqiM2yYPRCAYVVpAruI7UKZLHAz8/Ckw93Yh93x0RXIzSCuYidm6pScIEsN8YPDBfdyYT0CWjmFNVl+ZClXDQSSDKRcDgfDVJTnOMLq0gqiT7N4+smD5vWkbCaPd4ZgR2cuDePnzMHA9NIB8GUHaxqWX2k/d0orR6S0tLiFgozBFUli4ANsdWva5QI7aigDwGzIUb3ycfUV35ZQAzWKs2G7/A9Bpa3EFCpQs8cqGRXoqFf13dLfQLTRpUxHS59wxj0CBwu7TdmsZjanBPQWjoEJ5uwVbo4EmIG6nVU8Oz+2T0jmLhDRaLNHIDo4JkO9HdU+dYzQnkFEafQoJLd9pjgisXEVZgAwQ3gWZFQbepZ/1IwusiPHqhazeftSiqohaIvSOqL4mEcDmYAFM4AJDb1uLkI8TbKwTSvlKS/JRUpmNVUuwgGUDowKvcEkfhyZsEYlPSpUhZOEhLlBgCx1TtEGoSLL2gBVRWOmrtj0UpBQRd2vZa2CAMQVsNuJpCClbNlnRvOErAdvFA3OC/qGiqzi2F6fuIkoUzTQhH4J/65X+X4GnXJZ9B8ujGeNKJoOzCQdWnZY+QrZLYmB1SY8POiR0DvwLwoR8v5uA/h0SZTQltBLRMWv7ZGou3YDm4pg0CzYU2nP6QSssm6qlmmUr7mhQImJKVvA3vJrIdRARMd0EBTk0zRlgtnmLjMi1IVG7SZi6Ii9YYloNXm0+lz5k0EKiOgbLsE3EJeipfQT+RbySL8y5BsQ9YlrFygKEhZrNDzvbZCCj5nJ6IRfEQrMFGKByFMOjdsIyf5GRzrvcfDVeuATfEIZw9FQTHXJRJGp6YzRZy3DWoa0m4xYeaJfCGAf4M/FJ+RgG12qP4kphC+wAIhG0mrSS9m5XSF+BuNG0Jg+Y/sh9q63EqxTQPCiW+gqZfkKGK88bpAyBMNwZtfi32iCzZUzZRxnWKI7AV6ecZwqdK5szjNk5fifs9zxqHhlZbYceushfmRzoCzqH30X061+gf8Q0zMFMKSotXhqWuftJfhXKXfB38NiyZhyePrXe4+4ft/+U+z32NefGsfPf9b53XXbfj73vh48qCDOzqirvknf5i6r6qh//3V/8zdf+4bX751xy4eGtt52I59z7aTd++Wc9+99k5n+P/4+sDOJjTxltp61qBMZhD7ARoVAyDMCUPxTeX5liorsjkXLwMXQrCitHCHJ9YeJvBlFSKjPqMVg08jqS2GOVOQjGgaEIgOg8ZYG6QWFJhtvoqBhZSzClTfZ9x3mT3MKKJHMBrBSOCNHgMWS2LBEOd0iyxpVIygGVkEk/KRWBA0kk3icUa6xVsZjzo9vj22FY4lTE6KYWPFqBskwWCXuY7R8d2bFykVy9CQTPjJifaFiTzHRvHqA9dS9EVd/vZ+ANOVc/ZMaSJiSTU28uBVDqlq0EXMkedujnFgO4ALdi1prJ0UANYwi4cE6O16dYgGKCGCv1GkwaIMdOCqbihhFRoN6dEiR2GzZJ43RfrFWqJWEKnFfH/4yynseKBMcCiHcmOXlFm25Ocq6I0d02XECsGwHR+IkIZASytVAyEKXtTxYMExqDjFkoim82rQZXsa5Jf+eCQNt6mV8zSURAWotYo1Wsbhj1iwUHb8scOAtBfOMn/G4Jbp+ikXhhrZXCYXfSbwWwSexyaCviUhF2ajaFJQHgC40kfEqGzuKg2ib4oJuOEWs/EIT0rIJu1mEyAhcRE1DhZPH8lHAnHqdCFXKOoi/TtIzlcDxQxoQRaf+jsAoVWcTdHhpNN7MhDE8Mhui2ygF+huJq+jgTXSGMj5AD9PWDgJVxgj4QkKeaMIyppCNky5MNMu2lzQ6zXDg/fapcnUn9ut7B42LGN2wX95VDBiSqh5OcenTZbATjLZo1LAIRD1fzNYik37NU1X5Hmzf9NoEL8pPk7NZIUf4x1AL/QSwtxRZZxMSvpJZ0FOQaLAzAp12DVERiR9KcxDycA9shdqJIF0HmP8Jxb5Kj8STwQHxWTKZNTiGzSOe0vdYdspvdsqOk38we35K08xQL1dQDfiqcmt9wPAO+/hdypz8gv6txzx7tiI7R8Qsy6mvxNf0bwmkbQ+HqsVBNCIAkJqtI4kxaoylC9zI38him8l7aUHy0SMvcZVsDhJHh4LmkMGQSoUVWuuyK3MphT/5gFjPpFjwoVPWVpbmxeosHntXx/Th98sZ61sO+8MzzH/55L7/uuuv+6+Mf//ge6uiVvVfHqzMi4mQcfNbPvOO6e9165sTB/jnn18d94icee/z9H/lLmfnff/Fdv3jWlZl3HnX9R+vniKeMbj+mvCNFg+9qbEebdGR/7464M8Q0T+FHKx4xi57SQS5SN/qFGWKllM+hS4llW67UnZwt1qJzs8hIEDUnYgKt5BxymKSPqtgIu7CZqYxa11jtbTK5EdLc1Rq0oaAYgAMgkQJ4b0ZU6N1neE6WKSK9ewbRoMjFSmASLJw23RMCBYV4qPFwG+aCpt/FHqc4gDwpE45PXDbAWgxQUu/74p57PtN/OP2qFwXSTsd84x4t3AsCXfPpWG7wUNO2WCVtBuDzt/2dfwtoa3srG7cqYsVjIaoxHjLqoEW/opVFgG3oqDRvrqZrBGPIm4HGYkdoWMw5Vu0E3LDyid+khXfcGn8tJT45RSGOJnU8uTYkZSpgQ2lq6ITkZmpXFZSSpety+pTGWi1h72CuyxYIhUk8fQ3CK06rYwmzLPk3tpk7luUwZz1khVE2svjmuQh7d2JGr+oEsI1ThuwOPMCe4P2G6339Nr4WFIVEPiVq9qNgwwRSf+H0+Knkd+M9nsBERPl9kziH9lM2ZCfMEUxSSTciWuLXxRUifLYu53S9041j2R5eXWbCMNfiOeUy82ECPjwG4v2ueL/WdJ6lOJOoMHiK38mOG1My2JBTb0hGmbZLY+NpgVXEKYBnMGkKjG2nsdvvRBMjgWVADTpn4IVryfBafcywOkHX+KyrzTHhn6bviGhYjzi5+VTy7GmAth/Kt6TPJfu1GMSjGrZahxHdfOQYHWO8IScFwa6gMwohvNmKuf1BMEnBb+hu7gEA2qEEeWI1cfwkluSuDMv1j58VoXfzha5L8NF4VsEGbPVYdPF+P6pqdBX7HBLXc17jwalyiG68h6379WyQAr+2Y5GNxYachGriRaNBCt3KrCICb2Mfqi7SVaH7/BFBKZPe+abVM7tuAoIj8ohWY4L2mv9TsVXTEIqJyA8goVlG4x2Q+K9MhGm6bHp6Ws97NWmwh4YGFFftPQ7M009wgGyeDSTkbhbr4X8ZsD20yxQccXypiKglTp85efCJ97rn/pMf8Jifzczfvi6ui/wfeHF8VV3wy3/whpdc+4dvqnOOXZgHJ+7Y++yPe8iZL/yMz/3LG0/eeM/bfv+2g/+v3DuIz3wPIdtFAHnTjNniZDQbdlE4IVHA2UigvMuccDLv9LaDJ4N+mwCCUalL5iQyGARAtYGgjY7dZnRh2gDLvlsTV0cHQz3WnFg84yzBH4/LJ1GFoOHCA1g3o2U0tLnjJvnRlVM3x0FDABe8kqthkPFhA3miIzIo0LNAPYCZLkg/AgCcuV/FYdUd9LPkogAYCDbjUtwE34MM+hISXcnf2on2XHAjGSmBf1O+5MJxinJPUbAgCRr8o4tbUbEsAgvf5mbTSva0yxzJOm0WMrPrW47SSiiZolhh0UgmW08Fm1NBPPQKYwuu3Gr7pD35DnbR9LEYSAQ8gGfx+Jhk8IgnhNX4Y9oagvOG/YpfJDzsazTfDEStT06XESv0Ee4f7Xer5M1JMigDX8XGLmuiDQRtRo1QCAUMExm2wQeHMOAMJSTnxReSFWxj4Ej1mKJ4evhF6xaNhjHEEr5TYqhsBZOWEEQgK2z06jswy/Tgenaux3W58SVtZ+1zkTBsirSV+pCeZL9afVloEliVSmFhtJ23vfHJnRu8y8aCFqj8NIAtzdWcXYzzIOsqSyYRBZLJFp4XrNWTloG92DoKBWfjBV1uviYp31DQ+P+T9+dxll3VeTD8rHNvVfXcrXlC84SQEAJJgMGAxGiw8dzyHMdxgp34lzjxEL+v4y8t2U7yOnH82vEQg2fHEy0TjG2wjcESMxgBAgQICYQGEBKaWz1V1b1nfX/s9Txr7VstsB34vqAcaFXVvefsvfYanjXs4YD9Qn4g99cF/rrneDUclxwcUDGVswFNBTmbm/bOrRrdSgSjjxoTpyXtQX6rvv7GNe2KzDGk/ORz0Y2cwkr74A8pSeAjsp0az1o8QCoqf6jTrR1PGbjQQr6p2yrBNkBbbjwgX/kKKNKiJHksNCk54+8GG12/wyzlTnxzhM3STjLOyaQvyJZR0f85fDCNfQy958xHO1wkfAwWZAQDD5wShqL4DImP/tFCb9qASYtsNMmSDQCuPZPinaXfEsbXAoW+pb7FLD/BkMWOijedelH+Q9qZ6A8c8eozPDQ+5WILbUoHwfHV9jgGz1uNMvN8XwZHV+Ku5J2L4blkN7TfIu02qpHBB2JM+GTdEwIY+uJx4lCxmKBv9Ep08INK4okvsX02V3pEMTJfGwa2HMNNnxzGldwkv2qsAb7CNPS1zo4Gvc0mBsAGcO82lxnL58S4WjNRFB/pf2LczBWIr8U3U6ZdMlp8Ga8wW5gBkxmwCRP4oYOTlz35Rf6151/xu5+6994TcT3Gz5fI3XLLLStfs/Y1fwLgh/70g39zyf333osth204btsxw9dc8NwPTIFT545Lrrrqqjke65yW/02vevwOSigD8DcpRfm8Jg/xCB1KGq3rXsAy4Meik0jAz5duhmEF4Da1acpulUw6Jsu/dfR0WBOTNjp4C2Bo7bT9dj7G0djhkNvR3l7YEQkpQQcFhOmMS3WXlWSyjsDd9ktEzUIDGQFrSxSHAGNza9kp2kvjuaTKYwwECYLyCNNMQR6yw0ogK1NDBhcBpuZ5RtZIw6T3kRyISvk3WZpLPVwVsV4pgqcKqCyWLORYeHIZ4T2Thai6ytm3sbaZVMfoY3Ny8Sw47tgLWUYghaPTaToyBID1TgNO50pppjOv74JKHCr6HTKqG+EVIBp5nuBGp6d7yQuCa8wMofnJOHk2iyhMhITZ7q0qX4HQirNiMOZQYCrnGCA50OkUmmRPJfhIbI7Px+KwpQXe2Q4DCbKN7XJZ82LgT7st2Wl/r9MiM7hChz+FlrhXM9oSA1OIkiAA0PuelHhmsgOUI7aZmNHOR6XiYTI5XnibMW/jHIQ3Zq3AoaVwjgjYI3j0okeOkLHFrGO1uZDFkLpd+bO4+kXfKhirE2yue+DxPruSjI4suATPiTkW72dVYTAMK/EyZ9UQeMyZBdKS6hY2g0yMBjp+YUgsnpcuRjARS2gBaGmb7IKYZiZc7OwwWlUAlFOcyP+VwmTYcwu8Bo2POKI9ZiiBV4xT+hd0ED/YgBZOoOnC0ICh19Vok8vC8kwSyid0coy2w4a4NL5W6onCdOrEBuWD1BmuwKFtGt1xFjH4Gf2HbIg+m7ZffABHS2xq8iKPIB1LO0HRMe/8NPVFSMSCaXwm3a/v0qRsh4YHA9t2znZ2nkVyMCWHlG1gngWGxmcetmQOBfWyHW9An3pY/V+sLjAW/dJSM6ZxuPaZJv9ghmEySN8bdiQmNfGZZkCFy0icZ6GE/XBmcwye1S0VTQfJYxa4ozMvEpGepmVoCWPYdssRvfElDkwyJL6bCtXNP9f4grNEABTbFE/U5DJkDOMaMMKI6H8gnziOY4y5ruQJnbQsyrhWJjEe5WqkklQZpBcI3U09J+ZAekT8AfgORC++ydM2ibeB0cJF93jXb9pHIqiLL6KLZlZ4YsSCABRi6gjIjtKW0uYAT11SDOTC8oZJriJYnU3lkfuaHAle5Gqn1FdhjXypaxLK6hjRthsdXjswu+C8J9s3Xf41r8Y47t6xdeUp11xzTXuLxmNcN99882TzuPlf7v3gm5/9xk+83Tft3DZ/8OCDs6++5Ir5Nz31pb964PCB31rechRfaL/hdNL/na/cQxjOIE4PQVW2DZej/5RYgOLQ+RWFoXgiDBr5TBCQjfE3eVwIvVQBp1hpt1TARBkoSisOkk6qbxvEoIXWUQLuMAYfm7rKXiMRYCODoW18zjMJ5Ig0k8bxpdKKqZZgOLjFEsbcmZjBcTgHthZxiwIKJqi1WlNk4GPuR7OgXyBr1vHBkYMxMZCyrWNoPxk7OrwtDUU6FNFbTnnL3vLgHIovhRfyr35E/C2ejS8kFh1WZO1qixqo017RL3bTTIF0I/UtAaaBkg538Ko5vX6zjzrzlrMHFGnx0snO5lTrxxEUNGlFMCG7i0+t2IIt8JDBK1km+0kn1d6ixYC4tWGO2AMXgSYDllKM6N+3FXpI1RY93hX9ClORe/BS9kpKpBwOHjjgMXZHBCGyd+/snMGucIO/qd+oeIOBQQkQ4m6PqmbrxkMv2t4/U3uBUsFY7p3LY/9TK3xIfnBkknXVosjetbIsPut1LezdrM1uaP9xth2tSx9yZr3oRGfP8aySpXieGJLSQT28hDrBOIJ7iHll4W/Bt1jKWnpdqO/28VIuWvrBfqNpi8CgtGPBH2IXsbvzD0VLhGNFpzzZBwX+CvAEfHG7kB5yMKVtzl9KfvIVBh2HjyIfeJtlOELb/F/cnWPx+pPvBJQkocCf4+agqb/0f0yqqQnCj8TZYnzRdsjIKn45tM89hV7+pP6RRyUBkdjzHvl42rh72nqdxY22BxIefBIbJX5XMtCaT//QvrLqRjpMkT0KDxOvG5NGKdWYnASEKY0qfV5YUg/mSP9o8jnVdqtOpe0kTrLlVKEFuXE07Jd4OkCHUnkISJwy+pDkg14VBHT+QHcU5nexBp+hzIlunjyVX7eNz1vQwnS0jyMqn03YJKjXz87QxafKc+IN+2twkPohfxL9e5EbsZm+JidYGi9zryTEAyD9ug7rGaHxVfwgfxUxK+4m9texypihGXnhGc0iY4Eh7m/FL1l04+swyA9oRrskZz2f046t8FLejLxB0iVMENkBtoHFNd/IAVatIh2GcWnAfPWwvfySF43PP/2ynzOz90KPHXnJ6A1+w9JlV192+MDLfe01H/3L8z57/6d9snWnbVnZNX3RE5/9yaOmy791eL6O0o4fqZ3/Xa/PO51J8OEyHqCYlff39aNO54RuT0goImebKHQUH64WPOXMThSYIPdgLLK7GH/x4+iWy6HrqAykALrArfPLqMpo3XMFcFgKib7UUij8UO5uFb0CrEzKkGDqo4uPufSCtGRdSBGYXHxPl/jrsR8iB9XzOoeatHmVVXMuAs74lOlpdcQei3YUIKqTsiadFGgYJoCkxIyV0UXnW/ofxzHGYeVeOic6Eyt0BHgGmGR1DgJhi5nqNtQ8DVa+VEso83lSyOS8sqmNK9NiMb9jfKNzVHCYt1Qecqz957yfempHuIfukPeX2ZkjzuLnmDq91+eLURUfSuOWHYZcerNtAauWRVZajRbklZDye7ETVQs6invFXmhDKmilD43JkUvcStMF8JrOj/FqXmKLcbAFhKz4JittNII4/zDmlFmMKcgZveh16H+FM0/bII0W1VGLGYmyAGODBJRsOrltC7yrQF1+Xfjai11V0+6vtGKVtGJ2hCxpf/U6TfrIl0SCuKfgzuipFz0RvgEb1GC93xaJ7v/uX8kBiTThqAGOM/jzBZ5LxBKg9KQrzogHVe2+AG2oVpEF6mr/oxesRD8WU8eL5eB6n28kIzWzYKkVG6v6Yvl3BGjC1CP1qIC1uowaI6Q2yFBtgV+dgLKHuszMg2UeSwY9utbqEjYU9pSHs4W5Wy0rNrnytTK6hAEFlwu8+aIuls8zkOdsTsXIlG/GUhZkVH9bMTZxVvLobLqbt9VS0iZfV8JcHJ/oEa36PvsB0IVNLLJ2JtgpGLW6kDb2X3uJ2yrG1Apb6g71L2XZXV7/5ZeMfRaDJc4Q9+DF8VnhcfJh7Icbt6YcF1cBbCSsCKxrqMyDeXFBwIY/yDINs9oSk0Dxi9qfVmXWXl0aCpo6yde00M6HwjMZrVXW5v3yi4UW5DNYeCQxp6DIWMRGHxh8GgBMbMDa4YPz8869cPLiJ37lH5vZe/f4ni+4vPMyu2wd12B88y1v+7cfvutjp02GTePs4Yf8pU+5Ei+56Dn/9vB8HY/1uoovh2uov3DJQrPLXP6QQEhHswhYYaze/0M8D1Dp0lUVMWuGQtXcCpjiK409gg3zQgtkfImlVR6WerYIighFosMWCIaxGDdUZSKWVZcInKw923jIn4BjyFlAQ6M5WGxxbyOJB74MomnQvq8YfQR1jcRYkuAJkCa6gssVxIo/bJ+P0Pt6TNasvh1k+xFAOHjYvTTbPd8xo/ffhN5UMA7ec+EX++GMCjfqi/fuLWF2zwDPKH+KubU/1uPh3NurC+ozSq4KX4Z6KmzqtDBRS0AILoMOSaEDciGph27kzJ3FEovWVs7Icqap0RZ8Ckdh1oKMElfDxdvESw9n4JR9ri1DTerc40ATq6Nrf4whEzlsymwsfRqNCt2yaMXepUIN90xCqLvOgIuFhaBBuMKx009URx7jAucdyROOm8m2KaBIvTc5OdPnJp5orwNn7z3paz9LcYC6C0PuhYMCCTPuL01+uA9Eid5XD2HvoV8qPAmT0ju3JYAjMgkq43OH3tsn+6ZQytyAAh/qs8m+amGH2EceG/+wYh0K3E3KlXqSqN66zYq5kuoSD5RWkcXD2ib5GargXslJrKYfsL6tAQzCBmEL29GMRmG5KOeMQfCHvFPrNDOjTnjyPp4XztKdoNhONdMuGooKfugTaFNaXdI6zYiFp1y2U1npX0dFd4BO7zaDxcyiZs8sEzZQpoE1Tv0KWtqx9tZjnSNswaBXmzg0+0sNVNLA7z25VU/azajCJaN++bkF/7myRFxUPynj9HkqtUabXNofYAPOmeXSveSPB67Wg3VaFmixjLHwi8/B4IPDh7RxrpaBJ8+JuUY/wtZiCYkXPgPWtmBRZkE7x5ErlNJOnDKqPkL2Y8JoAm8jq8z6s13pe1vdVOORxBjqReqQfsoWKF3KOgszXM5uZdVQgnH4B96nwpdD7xSmXjp9RiYGikerFnV8rDwscV/RSYrdCnFOCAT3fBZ8lu2Qd4nhIKtCV1qixHiItiMTlh506FbiA5mkcMo2vAMQss8h/bSV71Gwm7FD6BdtrVkfD+gKPBDmc6a16A/oxdNfhUIirzLeoEnxICDsrjov3yEGWWFWqg4A8NyR1Mv23TAHlnxwWzvkX3vRlftecNblf/rOO9+5+WpcXYkr8vIJABxaX7/iwf379rj7Se/55Af/2S0fu2W+bb4J2zfvtK887ZIPHjPdctd1n7pu07nnnrv25TYzyEv+xfRurVHKRWWoI+s24erbNOzijfRMrUSlI+LzRYAENbWbUrYKolZVLu4otwukcnCAnH4ZXP1VgVU6zvocDZxjUHJDxxPKzDa0Z4dJV502F4F0cEMYW4za2uwQF5YwsfDg8eBcTz/I4YcFYeQZYiUZaXtsGqeHIWcOiw0lz4ZamRrkLAbLJK4tO2L7BDSOLR0lHUt8lQ6+BEcWga8CPtdQJOsheJ7te3FyHnJM7WHbCWiNRiFt0Q9BbYwjpJc8YNBQHFoDwKqx6SASqaiLxcMRZJF0dct4DOmG3MuJk2kX4oHH6xEoZPKi6GQLzkbxlXQqQQ5Ckqc1gUZzJAbtSascA6xtc1Uyx/AiA3DitRxXcbNyHiUwpcOnA0vCU4+GhYRRAX8J/mUOTcEyuCe5fNQMudM2kchDDhgNNlaciZAvqsoKAEb+DpiWSDfd1olzqP2WozADXNrMQrvBQ595yICF85UqqLEMKJUYkcPBv1FBC79jQALdF0NIPFBbxPsE09zLlM6fmNUfWmIC5iwYlKChJIzZ25g6KYygTlN3bYEH6ErttEuZeQRoxCcrY0mGUp9SthVbPFq0+IIwkkkEIAKoy/E5V3gKjIIn1eYgngPym2bdDILrq4py1PXyTknJjHiQCS4sAi9wTw7tlMF5aV84krqVTpQJJNvuxy6crPgl3x/9GPvlHYkgBtKJxLNIrJJ3xZ+Q+7ZgC+4YfR4wEW0bgTqkGPbp4VAU91hihcGAgTbSnqN95vL7YicRCGTS5YqNKp0ehVkHA3aCpSVGREEg6UsbSnmD6hu2k3EWdVhYEU8pjqZuREMq3KHgusZHzECjXRkpiRlL2FfHkP2R2FwCbEWGidU8XA+jw8ZIqsfACKDgD1J/LfVJSVfwJJPfMivlRRUYp3Uxas8LFSpQDZPY5gWaMmFr7LGc2whdJn3wLOJzqs2lO3Eae+wrNQrOEIWDaKOKIMnq8NLDFxJTHIAPJdlewCF9WhxmZgLW/azLblNH4rifiJ+YKJt7nN5If+nivZNcSyTKcfEzC75InHrFNVlKvapQX8SMiU2wtnp4PPMJ506/8vSn/TmAU0846qwdj7VMFMDo7sO+1dWbty9vOu1D93/yp//qo2/dPNjgB/bvs2c/8SsmX/WU5/3HNaytrkxW7Ms1GQS69xD2CgUvoFyc4IYrPVW7eK9DAmalEchgRGJO7woGD4vOlnpffW9XTSnty3KqQ2PzWAjAUZQI5fli7woVeU8xwo4NxceIqBjNuDDj0wJAvtsv22I/GbDFu1tEDBOScI4x09Rs3RGvC5YBWSFX1e3SdhmufiPsh7TAALjOTFRZesx8DZ6VyGyZzdK5DAJDA+DzHLsJtCrvWgOjI97JiPb+pxIsDIPFSaYN8ATGgZL53seGHlkpD/2WY4k2Rku5UBvpWD1pTV3I8Q7ld6mvF/l1nE+F6fevl4quUR8y8EnW5nhdRpAyI6EWwQaDgxoQdzxYKPRIL3rigyPkBQksLKZdKtCv9BYzjnatyE5VVQbu7smEQpPs2vMnZZIv6048qf3yEQUOkkbcz26l9x3HQLKUDlnODKTtoaeBVdeiAzwcZKSDl+4jZVWXo8mpQmPic83EFmw2TxZJe9MseVo4itw95KG5OAmEL5oE4MUXCMuK2Ur+FVsrVlPfkL7CiPosPBROFUEtBt4dkqdidX+qP7OyZLZHvY6PnnLMMSVFQ/mObmBBO4XLaZZV/kyWaDTxqGXATntu47VsXX7Ywbff1n71nZJu6msWVIRlurvCWLW19AVFHN3dQCYq+U0NDPmLCy6rPfIrAMKfPimUCYXP4WqNdq/GuUhecW4Oy/cHC2NMbbbg1RJTjAfgZSNFAsLS3hfQPnloXBmXIWdCic9Sk2KjoP8Y4DZmPAFHfW+jZEYfDKS+FabVmKF11uw5uJiM8sKXAkBp46ZxapUEMUbFi6EUHGMLDDFMbE2cTJ1k4cqkZhkvBq/dEreATISUoPaypiVzhZPnqBIvrMBe8EoJjfxNxYGMsyQ7q7yzLv5kIaYzHCt+RMUgPVAQzaUjnJXt26Hfqf3mKJPe1Kx0LSXxY6u+OO5Co1RkaPV0tw30dD6ngr5+1/BRV4tlnAbJM+MQxqpjwXXrig1eGubISxlQoUPxdJLfuGSY7X/UXvikbxq/7qIX/JyZvW/v3r0TPMZl7UX0wwnbtt3j7q944wffeviGm2+wTTt3DVhds0tPeuJ7zt95yhvMbP9jtfHlcimG3QCsCNAx1VY6Nwyv0J8uSYCemUH7PgLjug6+fWFC/WZIUVmIKRf3qG4b74j/leVSVglcsMMyGgBl2XlfVksedLQhK4DcaL6QrEj/OXLjsBK4Smgs5cyJfdaeLfHZGu8N3FtURlEMtXrV7nUaOoWN9AYNqnABzDz7pD93FgooyBPinRU+sJpOIZCdZZwJvNlWYwtBrDja8hxBkw/VwAN0TgTzAha1UNA/z9PI4hMeBU6wMfIxjyzPQMCaUy6AagsDNKA4obxBZA/lGRRmROVM3LZIEANQ+TJbD4cb1iWfmDNT8SlnORlAxEB4XH3rNWXMH9W+DQX41YeTPDADYCLb2qhHvqTsdG6KsYpLXWcQ0DuO0VGSmXQa3esuvBRENKjEi95dJUCkrSaWQPKUV85CCizY6TEzueBMxTvinbXXB1Ca0vEQA3kYtopIPpp6ROWTPCaVTPScVWJT20lIa0uJbPCIfjlxvEjYiAs5GqpdxbEazCc/qi7HUDhLyvZG9LrNnwveucGIvHf6h5EJ8AJuLV4daJD+hVfElItLtSW/BSytiVDvDxoTYr4drPqXr6JvIkc8P1i25hmKN9nUIIZYYZKbfoKSqui2wK/4PQeSASjnYJz3CLrLWpGxvLIisJVFFgZvnR9CH4IJJsPeqo4af/f8mYWuxGHp7YKshXPB85zF4qOWOqoEphGkg93Y/0K7pC/JY3GHeOpdYEnZ0USl79H3kH+lVeU6S+EPoZ9E8Dnpo9GvDairl6qspadetz55b7OBi6PnXv48w6DR1rCU+mUaoEleLjq5kqYPHOlAXHon6hSvOPJMc8DilV5spJ7gDfOM04wgVoQnXIN+ES9TFAAMPPVWh6B1Rl3iH5oOX1miE3hRls5a6l5NoEoASpl3GAPqe9WJIU7lJK6EjNxL4sR4pdBbaeUnpFdj6nkBT9q5Uiq5GYoSx5lzJA5k7Ene0V/oP9V7FJqkyI0+7qPWWMohGvKPlrqS729Mq+OzGpITyzI2AUxLXTckg4CC/7W1g7NTTztzeNa5T38NgPe/4pWvXIpXRDzmxdnDDz9w5/Nfc+MbDcvT8fDao7OnnvtU2/2Ml73LzPZf96nrNn2+Nr4cLtn1qFeglqtwk0uKFCxZCpMXldPgqNP39Y5hsHhZOS3ai8JVRe0BQAkloKqbpVblreWeBtolWDPTEqJUQO8SMBosnWDWtdJ7yAlHZ00BA5gCONpylQS26hNYLSGt6Xwq7gW4eknSAnhbLBmGggJo4QAtXpgsHE8fAe534v6SPgH0wgerKwdz7PxlkbZCYgOgRECPHb4F5rXnyuXkDHx/FHlBsKL4Et/6AEX7GakTTIKtpbgDxxz3NAfU7uF+A83QdA6AQ43jmkufufSpJGlmWcXX6x+4l6yv2semEPR1rcq73KPZcNxST1OdQ64FFBUM5DipwWo7eCi/QseKdAZKxIYcF3XdLBax0IaDLhpel7Z66hPc295OQMWcGnBkXEKdLklbCgMMONMuqx2XfRJF+XuX7enLpbo9mqVz9dDNCBTdc9jV45NmozXLo4GBWFvxxEQnltzSlkjB0L9I3ZBV4wVRxQDa53mGQfKiBXsqN6mNDMqpkxVjghsSrSGP8o/nIlxQe5S/9nehzEbWRFTiIMJAS4bQaK3Bak18AD4T/6gPNapvHWuMVt5rmfJ2taxCQfDKMcZSfSZeCkdCn0xJ/QK7hPsoo+3subu9+Ma4qYN9IAN+dlfs2wxRoCz9hd1XranyCbXgCsQ2vmKrtTBDW4WX194Q3/S8pS6SB+W/KmrFTyu/I8Y3IPZLL8gni5gpczoW4iz3vtf9YQwCyVMr7yPM0gzV38WrxB2JScUrzogbPxtKZU9bJUz8TO2Ke0YvvGf8EfLkTJQXH6tTslMhvLZTVL4NNbb6CL/Z+6il7/L5irkK7jlQD4La8BoZpLykZ8Fr8cUDD2JI+WS+ykI2bnn6ugiBi96GuUWMMXavg457vNwjdKRv4KFAnPGXr4HGx9HR35NXoQBZwCv4zucGOWFoXBXzpT96nYxLz4ktoTSSK/mZizscbYIkbZ34GeYpPmccRmNPFYQ1GbX3/PK1PEHzUGZxSRMfK/hA/5y+03sc8EZrHl7EmKyS4xqnhy45RtStBvIP5jAbdHJ4jWU5zJwlZxE+TZP40fDdMLhhmA9Ynk/dV9cmF590/qHvvvTlv3rrA7duP+kVr5j7FzgE5o6H777M3Y/7i79900/c8ulPTrYO20Yc9ulXnnXp4aecdM5rHnzwwZ1XnHHF6udr48vhytKSl3/ls77i3n9X9L+JJGIAftUpavdcXz2Roi0qdgGwREHrfrABzWDQEKjMZlIWdy/AG22XxAyGnl4qvCeNXQBSyGtrox0WlXEmDP3oE6TyI89EyEl7OFUkiHQGA0AnXsrBJnm1qqQkRQnYAt8HEyh7GDRBiYFsKRCitNwvEyT/G+HBYgZwMZPnkGPr+KkxJ8jmz41y5rI2fW1W5F/4UQAoKIb0rAC/U35AJsos1SqpLe3nx4UfJbE1tMCB0NeJm0aTT3emR4ddE79yP7GYzDcrbRZ9qLTmkfDp3ASsHJ/TNL173qtcrReIdxsSmjHkLfRwkXyXhC9nJmiCRIsyTiW2/Cbl0XIIy9nKzi5SXg46cHbGMWTiLv57BiKaZesUkMEnQoebs0fQP8rVFjmRPM/u2aSDMzFI2lHKAwu41qnjhlMDymyVPsq0lCUPEMtqoKC7CJu9HBZxTtLz0pfzngKkcseF7eqzgAmlEDiVMB+AwdMwKyEERYKdijPtc5cO1AGQT0UgxDZQ/lYmJFzjol111XvZTa2iRwEmnvPstuOlvhQgR6EBpIkYlc86WRJ2JzolbvKBsxOG9pJwa//C7jIi63GIyX/21n7WMjHtlwWHYrVhj0WPwCJFJsbyM91zVRNyDPxduFKWzlKhuOpAmB46mWpYNCeI7+hRx67+5T/ivapDzOJw72Gnyzq4Ux5AuEP7INUs4GpBFAslhrIhqtcT7tcVTrC4V2UVcQDfxyc5I+ysQphkY9Ld7gTiiicaT1zDAn3ETcki7dK6vsoj0UWNJdSIN5vzmNHMVRILulkdr8ZaBU9cqPeEXdD2S58qfhTc1tijaKvxwTUDxfarF1lcMUD7rrpIDO7GX1a/0J9X9PTAtIxBaG/Rs+CERZrQrWLiLHppdNFesjMLMVxmL+grRQytFqK+sODinbZowsU73KXy5z1kAZmW/QZfSzwgVCqxnhXdq4UE2bFJmhjmDswcm5dX7BsvfcndAF541MpxT7vG7PO+d/BO983HbNr1jkPz+SveecsNz33k7vsw3Tez8085b3jBky7/k/k4/tR8ZTiPS0sfq50vh6t7MT2BqnzUA37xUGSzno3fFpNAOedqyMWM0qHTwsII6DgWAn0qqXf/Q/d8A/B4rmKioTmW4hQrAOQ4IknsAmBIuWUo0U63JIc88OIMOwIsf03uJjjF0evuhavGvjLwo0PWykfRkobE4BtWaI/n+BJRUWasIorBoj0dIvkrjqAmcpm/GxYGrk39fI7jbu90tO5eRlIuwk2JIBmQRyJ7PlucGnkoiK96SClZCVmYtBBHrSYKjrrfg+kCsMjfZAvl1ttL47OXW9g1PzDSJUJcYM87pLML469+piaMhZgcQ3VacDCwyCVb5VsvPA4ZNzNSJAEVDzomRHBcE8fCrA5TvH+yOtzFZX+8yxa+b6rb5JiaxjtduFHACl53flINq/ykmp4NWnM0zmVP+peySR0ZhXGwHrdaF5021OEljwqOtNOBg+9eEaT+T8PtBkQ1Gkp3NuSMZzf2EEJuzncVKXpVj/+NY2IGdRZxwm0tMnR01bEVHSZ28idxiWrkIg/5IzGgBtzGToPWblY3xrxh5ZfGlTisYt0GMRUb7DCi4mfSkIMsfODfkeDaAi/az5A57a9iRlX2SKwX9S0zkTJDSnsgLlpts/gT8gmh96QVjSYrtNdGnMOm3xiLnCp+oszMSN7lPq++AN1rmKxT5kZv57cLTVzWnJyPn26lyJLjVyISs8eUg3TPuJqFPCo0lxlyhM3mKykKJGjYo6hK9qRuyF5KoCy9LbOYXdJfmnJfTNQ8ZVsgUT5Dfj4Kz0wKCi5TV6lDFrTwYlliA7oZJKPUdRO7qg2i9APEc5RLRzWK7SN9TPCRtnTEy1ocwm03tWXZT6ifxOJpG1aLBnGNhjLyoo/06Sr6ZG+KZQPn2yvJPJvo4qQSk7Fh+VliK9Wg6Hz8SntKFG6y8AW9k/yqn8uBtN+c8jRhQbMnKWjyRLBBu0a32KSJ27r261U/zXij6tJGH6Unlyc4dOiB+Qsufd74NZd+1atns9kbj922623uPthjHyiDz9122/LWlc0vuu7md1/5vrtv8ulRW2aP2EG7/MyLDr7k3Gf/2oFD+//zcVt3vTfa+bJ6Ef3ipUNlBPI+Aj6R80G9oeJs/DfdLqE9vV0NvvjC25R772T1q+fz3ESe1U8HFwLrXXdKVFLBOCtFwwXpKiWJDQEQaSayxJd8AWq60vIcZxVorN2XbCWBjF2ONDoBb/SxGOCrahzV8wrinXBaAqxKMAMDJwWO3NMI1DXa3RIoAYxriSCfJ9O869oEIgxS0kStVS0lYM+xIscpjZCnYQDT6OBbGhX0xzjpzHNjtTXdKJVks3YgjWYpDZDAOGOF0EsvNBSYoRsd4Yrt9aQBPAGsVrLMoINu9KLYMntipSuP/nmNPvYJToCzxYvGc1YpnJRTBmyDp1XSudRRhBhB+Xsu/enqWib7ZaGA3NDeic7XmUiKVrOvBfv2+lmMoapzBzOOOGc3NL/QxHCjgkgGpSXA5BLhUjVufPHKlTYCtk8Jc8lh8cNGnldHXXcOMWAzz8QrMIVBhHBRNueiuek+ZZwYwO948mxV19bEWJ4nHhT5lLE3nodVy16KfdHeWG1H1aBMdbuAZCHTGrzcw36pIGW2IW19RPcuxaDTybGE5A6nWiBdCh+SPzp/o6JGXStcnksTDByJ7+pkA/kqyzRAy27L2JHQCc0qxdde/4CBe33p55z2GfouqirOioKwXzMkezxOJvTSVqHQixw4XhOXc7BePiPt5EG9r7OzxBYL2en1Rp6yTrXJ5WrejYq+MjCUMw2WMnDkS+Kl90DibMcnuutRbYgXGNEObaESUCHaj5HbHSJZoM8wBOZaLunLGZHEfLE6Zl2ykJPezcNv6eA0FBIs9SuP0S8Y6JnAaVDUey/4z2CfvFaRpf3ORKB7xUZhiZd4oqiN9Jt8kc5LZsTVlEnVJ+qKtId+TcMZ8+GCGXU2qLGpb9zoq1DpK3aghD1kKljIu4VJVr4ztjRKT4nRldRF+ecBYcWePMfNdrvCk7Ft+hSOobU9FkzkgX3tD459cUx5yWMFyNHaN2RTFd9la/VLYqIIjtVlgBUcCmmjo6pgMcfZlrWS57VQVK/yWS1UxLIJsiWxpf2bDfNxsnXT8LKLnv/A8dNt/8nM9ufAj3y5u5nZPnf/yBs/8pYz7nn4bp9vWfFdO3bZpec85bVm9jei6ss8GQTqDOHiULoIgsbr6UyC43VmoFY71Iz+ZUWkVnvqfoH6hMKUEhy3oG3olUQzGmkw7m04NBiPLy2JyQprxX8lbRmW5F4zLIAYk6NArxIQcUR00AYel58ApcVccpQ0ZKBWguPh7hmOFeS5tWVBmh0hAyoFkpvpOSYSraLT/o06+ICC96iMtU/KAchJZ9kkrKoT/8PlDu5oG7XpsFL2zQEQHWMslERJQs0kKTjidR0MBriGimMMoNMyB+oKAS8AhO8ZTPrRYSdlYGbd8qFUHw/9KY6XJAgwOYDsYPRIGgnG4dDoZGEMLoxiAJM8yl8JWI1amSCHDxjno/SCMktNNfmQ0XnMvYl9dHatx1G6yRFr6SCyshmdoCgB6n5JM7aZtlQRoEsJJMZSiBEelFdhhIzz6Zjhp6OVyqaQxU/ihzG4rrCQVld1I/Ww2kFwJZIdJgqNPXmgEV/k3LDMdJAAqA/suehgXfIp11uwbAz5j1XGHbbR/rLfumIjrCDw3MQXKx2Z+k0DqTPCepWB7LPopNhPBpuWqiWzBx0Ek36FOlhxN0XK57okMsCiqbxJ9Y26B9oOAb0Tavw9aJ/7QOy1FuiYDK/gCnG54mnHX+pigR5qqptoW7QlHpzGBIiyM8R38W460p064kUO9Z4Cbwoeg0+0avqFoMTF0/ius3uTbLpZCLKxCE6lPdrZwFggl+VBPBjB/eZZ5CnfMQCnjLlfO/4WllKXg65hGPT6pFRK8iI/sDL2NsyhrPix6CdsvmCwGQ+xUbkF3COL8FONJd7bunAx20IdcmmLe75cT6YOZrGs+M5QeLWt2GKBFipgCXRos34EfmpvppW+REvS5974rtmbDlkJLyXOCx1LkfS6QYThx0VgC/0Hjhgtquiy/jmn8kpyRrE4PN6L6JVgLm81yqzxhBisZYzOwkjxLwMKRjYgG+HQvruQj2RrA2wYtCRU2kI6OB4rzxn1jw/QXgdwj2vVq4zdqU+pBrJtxmvkJfE5DUi+DUPGaw6+fzFGRD2UPA187dOREs0mIvZEPQj+olymDkV06mZbEbNkE8z37xu/8pJnDc88/7L/YGb799500zJqtwuXu9utuHUZgH9036dfessjd5w9m6/Pfd+j9uInP8/+yXO+4RcB4Cb35cdq48vtKvMCDBwDDhPrqosvJldA1TJkyA2iC86cnPf+nxSQ9yqATyhE/Y6VfRltB91QcI1QqTCYekohr24kXgIG0KFn63qmgnYQrSAvQEIzmazC6cFGjNZ4R18CxkgsWzu5TFFUFCAjPyozbbAWtJhhWEDLrCh6GhqdWjyjnwSQwq96P6s3nbyCMRa6kHsPSysMNAJEa/u1ipU+LQLTYuvca2PG96EVGPGomhU0459QgFFYRi0pzjj1NnWrdzLtH2fNFKwv8DAdMZOPAvrsWTaQy3+q9TgNpmB/yq6nV/pvSXvjZdGDSAqak4cwFJX3Yl/KNOXokpRoksN0yYxVcHS6wcDWlRQakOBe7s1KdCSR5bV9/Jez5xCd7c8akFcUkUfVM3n0eYQq1GEwoQrbNorBZB+5lHIhuWKwSp0ohPPEWD5HG6ezMyCWXm4sItgR9EAji4JQC0QUtraegzaG8sKvzplnQFqKzIHXifoKgFL8aavwsmTJ4cUuiTvRW/CzjMJ7OcpmpVthd1UP0HSszGF1Ms7ipSm5qo/WGZNCJoG40yGitHxDpVFtRBJQ9CKvTKQ6/0aT6Wa5C/2iNwJM5Dgg/KHOFbk7otKONG0r9BS8a39n/8TNzPuZAKDsGfbu3jaU+j8mRFWGqSuG2r8LA6gbnAmjbiN+KjjX81RW6/YrZsLYH5QnnBAdaXtNNuEj6G9Cx9iHK6ANmUmP0pqUWwnDJXnI1qo4aC/JSOFbJgettZHyjqJKYz/1Nf2AEnfNEkXAbcnPnPkaYqa12BELcOSzo9g56S+xjVUMTpsDvCUIRV8yTiCWesGa9DvS84rjRtpYTPLiuqjDieHJuVQV6l9OUKCXB4hxljFjNgvGP0TBTPjL8yEj4nJr0zWWAuWNjpBnRy8Sa2rzLA5JltV2AOQ7SZlEET5dHEonWsfMHqti8lcDC8H8L2NU2XNZWZxyi76KPklv4+tR4zxCok9SiS9HiskKBje9MBXtHA43YDICw8zG5eWl4ZJTnvjhpx519nU37/vMsR+59tqZf57DZMzMz7PzVt1985+88y++9l03vsdXlrZhy/K24eKTL7h1B7bgzofvPPpCYP3ztfPldOUpowv2owSxOG0pr5QPAlQFhPIR3vewyK6Cf7y4N6ZWK3KGh4fgcjkAZGx1xpDANXQBSQFOoDh5Aq+1l8wW0tIuCLNF82rgWo2gjCbNKh29k0ArTogVOBuCVzw9jUbQmm3BZHpV+hw6TzomvpheS3WYfI402sJ0nWAFMBEl7d2LoaNHvQ6gsALkYXG2SqjJHBfLUblZf9KpVQOvbB3y19pxAdrKdzqRklBusFeXeMukB4BiC9LwSm83kIqACbiuhaTlnoRtLsfT8iIv9hJAXX2dfB+rp6gBlym4AXJHnPaV1ESt411rNCtznUcUAekHc847x1ST+t6hpX8r94+eCYoVXVrovv+j6GHRJW20L4EKiaGjJ09Hp45mm8kxE6O5tK0lH33pkIhBx5UJN2UNqUW2DtGkbrSMKe2qY4SVMcMjCK/GEPePve4PDAkUNVO/LfmDGF+5t9Sr27vtQlWpsQwU+nmn4rU9MTqhLfW8zliIl94K83zfW1fA8IWQxFKXSgtwvl5FtiDLT9pjdq+baY/f6xNiI3XG62yOSkngG9w6WXVqb7ITmjbtzIs8HFb4TD1IffIy8JzlLgF4yLGZdgd85XIw6I1RllUl8cCQbasR0Zt9oVTxqcf61up91CaFo0Unh04OUovMvvRc08shxp/qrDY5q1iGnhMmLmztfWi15solb4lgJI8jNxM69WKUfpAvuRohdG2BITWo9bLHMYs8Oeb6jr1ayEk/n8WExEK0aQ/aW8iGEvd49U09wdcXxm8aR/HVEg/H7gW3xASosDHW56yMoiaX7TNH0guzFDuhjW0VmtLbmtwI7apqKJA4p9UDYpPLF/ZSJz8Lpmk0VofVxqSfljSpH0Pd2wn3judNR6qPYBya7OPRq+YsDnv6EznTWmwpfrV8V7nWRbTq1/ScEt1CU1d49GyJYzeboJtH4my+lTcNkQ+V31RzDSXxXlhXnqlWQX3psadIzYLukjCylcHbEvq1tcPjGSefia+96IUfn8/nTz1+2PaMa6655oiHybi7ubs9fOjQOY8eOnANgB+++Z5bXnro4QO+dMCHM446Heccc/p/WpuvPWkLdlxqZn7ttdd+WR8mw2v6mN8UL+yAli0mcOtr6tsGIMiVlMWV16oLkMVJR4pxg3PLNmSExYl10FCMsAtaahWWlanyvCOUk7MGAQJ6PxDvkVMdZDCCajHFcr+TN961dsoslfEzVvNySRkDghEM1vrAnWBj1sxxIO0abPKCNLc4NIOP0aEKE3yEjx06LEoY2mfidDKlwlecc9sIDSWoepZLnRJ2oGVUXpOw7FcVXCmYaymehmlNp9gvQadLbsmDoi1tLCk7i4XvutfTGRTO5tUBuWXbVUnQ9lKRhSMdHnlPgM8oEJoV9eQNKL8F/tBxGqzsuSiAbsm/TAyQDifknLRAbVKGzb49l6wI8JEOJZmbOibwl8F0lGuJUXVM5LuG6qXTdIp1X5ohvlLimUyrCFHpR3IlPzMuvfTST95bgUDveEx4SdlZGYSIa7/zICfu9VXopBK5qf2BL6OONriXstHNAy4yScgX0/N3y2ZT6D221rEEwdZFXo1m13CLw6YC9LcXG7J4qSQ6fUfH841AXyC04HL1DVkobJtVHG2DrRNYGxv5jq8hdUdaoWo3KadgSYODAk+8YgXbxacNeGAkfAE7g1+GLBTVZ5vbiUDPmm8RJTE+mVYwj1RjrL4hAkqu4XeH8WXpZIOl7IQdQT/tRERZ+iYUE++KUHoui8T8r5f3C/TL7DMh5waFtLX0WdU0nNhv5EvSOQ4mv2ChI3DuyUv/USdCWyu56SvtiDaZVHYrY4KP7Kf54sQm8Ze44ZazRchiNkfKgotmIsGxlJU4FL4RPxKbiqPSdw7AxsKron8FZhquCycjGhETk3cj5YnSZ7Gb9NPpaySNEgfkCJNnTZVKsQLULXWIIuqcsBUtCzeTPm9FcfGMbC7YvKAOQY917eiF9NK7klxSjob04cV+6GfpBvQcsb/qiZq0rvCeXrn4TCDbpl6ZqTBX40rqFsefgJ12LXlYFL/S0GXvPNk9n3fAR8UY4v5QVFJ6G7wDC7XBgzH8csFnxsYmzokrIqwiKONuL90VZsIBjNMB80f3DS958vOG5595+SvN7E1F3o95mMyh2cP7di4ddegNn3jHrg/dd8u22ZZhffXQwaXnX/hsfMslL/oLM7uH936h9xh+uVyPndVKoCUoDIN6jGJbqSZDwaSqdF3DCS4FB1FLa2k87bPM7RJ4EpBKxBDfE2hYACUoupfqPNtGVs5zRiyUiaBtVGZWeHMGLp1A0MMKK8fuWYmyODlKFXcfdZpUzjq2iiWNqlXjYnP7OKrvdK1e/hcVm6DHLCuAxrbkHVGAm+NPx1pyCLCkp9ktOPi6jKoPbW/IgH6paJv91ByvqSuJrAPF8igri24F2Kz88wYodW8qlyVwmKpVF0BMJ+Nkcqd3meR6+YcA0vpdODBWaJVceQZh0aM0X2qWRZauglgYnzqLrkpbB9FAccG9GaQbclZt4yKUAIOOiToZn1jShUJnZ8tmXVCWsqRNoeNreLTQr1g+WeOK8rh0XiMKfoQx5/sq0zGIBboc3P+rwBYcRMjaXf1wDLmMN51RJxe+aNw9FlFkECCHJhHEvUeQFkFf0QABAABJREFUpQLYklRVPRgxllUBUIGFe4+GwaDtVymGUI8+CKtXhuXkQd7RHiXesuEi2xxR+809E8iwsVwq5aKJuNPTsRAI0beQh56tEq8cKR+vbY6pk3xIoZPALPCPn3lCyCINUqaSZPNmvfhYbKTvqfzkzakPxKBiUr3ed/Yb4y1VF6WwYTeaqzSRWhqWqYknRD0tLy10844O7oIh3Pddl3Mni0gVfULDabdGl42Wyz/ZbwIbRr6+pQCBBw91WBYAzdxLUEi8H5jsFp0GbRv9jLOlj9S4rQXgep1Ap6b8oIJLj8XN/MmFGAuXxVkWdD0ShITD3j6tqk1J3jx0eQMPyK9UNbVYk82csUreSX6KaWJc1G8Qs6pOFpu1KBwZZdXztXtOuJrEi2cVf1Ext/CIeEl9DuKlvtX3OS2F3Fso/Mkeiu8rxZT+yud72jhWSM/1aXW/zADJX5dq5D3y0d0H2X35JeVkBdPa9wN1Y9Hm3bWUM/G0T98bzww6TMjL54KImpY6uI+XM7ddEYmvPylArtia+jg25gnPK1eLL130XYkR3n9UR1RyiNafYW2+Ojv6hBOHp5x8wRsAvPUNt7xhxd0nG5qXGBpVJ20/6XObV1Z+7p0fe+833nTbR33cvoSjTj4WZ598+msBHHjDG96wsvfztPPleJUz1yHnE54vfh3ToHijIb/fYEehjJYCSohKYLDu/lTQbuN6CUr0jKdqLl4duKIpg0cf/YvY01H1T6fxcV9geKR8Li2rH4e1RKhWZ5uCF+M0A4Z8eTMBqfWXiXf7YCh7KTLtg37rjSeHkq+oDlcSDjJ6jISmLckBeLKx0TrVbDXHdgNnOK28kBdOmfaOpwYk5sWIIwBQmOIJrskV6xwk9151GFkcSfI5EdhLuxw/3XbGWRloZWW46yRoDflbBhi5v8N7wvqMIEEw11DmvVoOyOAPGgdV37AgCbOF9gv4luTLwlu5kgNDt56mNFH3OmiFqXSe3Sz02xFWsEAkmP5Lbmr/pwLAvrpYvHZhXx2XtRmR8pyWA3WONmRV9AGLQ5eza3zJwlRNHlvD7cfCSoSKS4EtfXAbCbOZAtzWZw2AkF7X9VTigbCj6VBdgimTIxlKRFJnoaZz5DxYhu+m9KIzQhrq45F+t8ITykcAIpYomK/6nH9KsvlI0XeJJQZPrMiCzgJ+WCkIkWdG6lJ36ooFUU69MCbYfbCU/aWfgigw2TVd52KwsnGLRRkgbyK2xN+6VxiavDMS5gP6wlSPPUZMVPNevkmeVaHR7oPtJZmlpaL8Vu4jBcS5MjQlPgW3uNRbs8ZWZj4scSMLn7WtLFaRRtlxYYWKUp3RR9vFr2YyV7XRlUhVn9LqUQv0SN9ZKi5FywZQamNxlqinqo2hYoyKH10FVZovJclaQjbKIqDV/0XyW0nj7GeCBTHNOx+0Uc+KRpgiNvWFSBic+CscsJ4HRQVLzt0lrSLL+0f4Bb8v5CfGxBcVp4rX7xJVACp6VFDubHYMvFeniS893S7aamxCXsrPxiFkG3DUKKDCLEfGH2NN+Flqzyt9S6TIi8Ut4n0UKjLqzjiPOiUZlrHQR8HQJ/uhp6kziclNHm1cxLeuHOCWr4YJmVXsWVCXxIsN/9ozk9Gw5BP4wQP+zPMvxQuf9Lx3m9na8eceP36+mUEAeN/73jd1d/vsow+cfcNdN507nwzmhw7h8jOfgpc+9flvN7NHj3/p8eNVX6CdL7ernyH0otHiflFmOt4eZfOy4vhlVNF03rTxMf7XUd69EobbBSypW4PwMRW0fu9eHlIni84KOV4FzVHdK0u9xI+eWkjBnba7of4eHRmAAe7QzEgFPyDGPeZnmmXUTbW2E9wZ9WZcmY6AHd4tIyMYbUw0CmO9mf8izxubXP1W4s2SMkc7rZLUVEcop1A9DB3dWEC4OifygkUF2Tt1sThlnZJr9NygeB1xmJiVccQaVZ46Z7EAfhzrst6iT/yPA+6j+KqAkp9Vh+cVhD34a93wcvmjS+4ZhCNfWlweYlJLwM3XQtSrrx5HY7rP4xRaBlntw6gUojopcVX3hCIXHAh7pd55CMShpWQ8oqh/31dxze7l3UWxFEbL81AHIacTpWfU4CSdshWvsZE9GagiZjKCGjpzxCxqZ0Ol4OECIHh14u3LHFk4axVTiv2OY5FzkZWS3DJV3u/FW7DRCP5KNKSvkm81YFiwsaA5DFiBhuTheW/iKiv/izQtVHCrEFh4cC8HZARXDP3Lr0t/Ll70JCMC3BR9Qd+xOARPu6/8KV9nobLKgTZJOjyRmN0Sj5SidjawoHbxvHvVP/ouUyCDsG9pNR8KS2oEhl55HUtNa6znXUlkOrpC5vzwiHzy5Ev7SVsvvtBrm+23sQtUiWs8fSJ6GCrf4nf6icK45K8vvOOtH0/1wRpfdw8Lf03I3PfEW3m7/ALHHq+GrbGPgYmsA95WPfRvEzTZUu2s6U1gLOU3pg+oCmeLA6D8wnhUKh4hWnrdyucXZ+lzFAU/q2LUrgsIVzwU11WQqcyOFUqL99tG+dSZ5b6PBWiry4cKPbkaJnhd/bayr4TLUjsCbQ9dywMqoV5sIFsuhdv6vCEHwiHX/gyIgAOUWlebEXOSaB+944mRKDCmLDNzoA1ZISjpVvF5sZ8ggsmuFT/O7rTCrDJ4wZazSfqF8nHXbxmzvqceudoW9nJ8hacJG4n99OM2GqYjfLBhesFx59x/+vZj3vq5/Z876TJc9nkPkwGAyy67bN3M/PUfuu7//tDdt4wrm7esT4al6QXHnH33+btO+dt77rnnhMvsssfNYTK8hv6X1HjpkjxYADofkK6mtba14JbKyEABWekj6C2+I6YHi7IMtACA/OJCUrVop94RqSfBqW4BSXHa3LbhXdsuLNGdlgFqgk2MV04bBWMIUKmwbcYyDKusI2lPD1qGUY+ot3iO6tdOMM5q5BDCYkArSiSzEflOH1egmjIipyzBX5hi7d1WrIzF4Kkfbnnscg0eE6AzuBkM8Z6sQbrDeMXMMmUpxQmr+ucAjzM2R87OlL1f4mYABmcY5Yilp6kdrbF8pclQZEw6G85H62M80gGWJSiHfJmUE87H+n4X4XDwl06UdxcHQvb2y6PRtSVd8b6qJz20Nk5D5ReKfTLALCDOQdYlxk6aKmKjk/Wi3ZKTPHZeuuqtbx5Nrpm08MD8TMstoxrNZVWikbI1zrAVzxE4ksvC0doWY70E4G1wtMEaLJAu42eyJVaC6RQHVegVNKi/+HwMjJPjtBwveGBnLB3nEB3gIRfVx3ssL2diYXG8eQYwtBt0AZpRVvybe25IL5Uw+OoAjMt1JXPqQgmOQN0IfaGMCi7zPu0tDp3N96pVZ1+HW74kf4uWyXD4M3SUr/3RATjFNwWHwnZT5rRE2jPlVoOSxRFJBpJ/S30d0H5j+Y8I5LSNQfIdRQsLKFqq757qQr5SD3hf5ZTn8kHyI2c3JHjZFPEuMTVQxz1pBjKRLsWTnLAcA25KAXN00dRpXdjQwEJaPJd+qEjfrfBZlqpDnYhrdU803RUMGC3tVMtGPdM66aobtMEhAJ480/+oboMBNpQJ+sUkiHpAngW+jSPMPQ6/M9TT2YWv1touapyyln21/2WBInneXDaLfJ5ypLx5Zzhg4gyL2xoPMT5bzhOFU9Mav3kmT4mTTEVN4nj6hipjnuFA9eQyWSt6RiDUKDt9T58n/lhPd+od9d0BG8VzA+tSiQu0z64oTvyQHdNmqD+lv6o34QLG4JHH6jVwBZtRMvG88DgUo6x2a0tFDWb5Wg+NS+MnvgZPyuowWLHZRfxUQbX4ROkD5Uj+5x5nikN5kltTCtl/0I3is6kdwffOL4RSLv6PfIUQq46jyWFihsNrh+dnnnKmnX/c2f8vgOdvmmz+NxWNF6+9e/dObrjhhqWH9+/7CXf/7g99+uPfcN+9D2D54ARnHXe6nXvM6T8H4KtXtm/9l5EMPi4Ok+GlQ2Us3rlCyTDgbl/aER6tCpStKLEXMMv7CXT0vMtV8mlwOqmG0XW+qe+/AEDD8AB87+5JW2rAm0cuZ1iAosC1qlYing0csOAbNIpwuB2ZMX4Z1ZAOJbyTAp/qcNGcKI2wQdIoIJTyW4DW6AEMAZcGBT51zJVO8oj7mFzgMUrkOmGPtLrimq6Z9lwiwshkzlInyn/E21pUBEJNBLlZ7TW1XQKgkkgPCVtqR7plGTLwh1EGho6fRSOSsOJkeG+aRABSI3JhePUICQZS1t0Tg5OOc0momqJTJVccGmk6paCeCX/0kcu/gncEc5SlTV7cZAfU6UCqA2TwojHUkm5ZE7UIGdRFL3wTe0mI9/6UyxrlpKTTSIdgGbDTpr0yLu7TR5bfUR6lhJAOkLwbi945tNeiBuUV1eSU0U43a7bea4EB2nzPIElUSbRhu5GYjpqFjMBp7A1HBQPL/pLTGVDUEhw/6Wjvn5J+alzCCAZJ+SQPXEj2F6ztaAodt9Tpqjdpt6EDhuS5l4Cg2kRhh3f9pQ1IRanTnQ1XPSYwUJYFf8h/trXIadozTS6oFH+ExaXoou/Q+VwGP6LN84fCNOqp2snZ9bo/lDc1nYyiAkZYKGLhVKOYKxpKsaQLhAurtDyRAyg6UfU7UxCXrtBH9LNXXiiRkXWiov/0EvAzWVZCm8ztcS68KAtT6XxZEhoh4wZ9KW0+AngrY/DEd9ggmbe+WQiKZxf5GYabOOTJV508Ca3cMB4iZDk0lPvdoRMrnXSSz4W9Ljm4hq/2rPAYLhlnsWSMZDVlTbwTrwQMbexe/s7ZeNOzmXDyhes9Lkg7Kj4WX5q+kb6PX3GcuosqEHhZOFMzGkC417k76rn8QWiTYpPSn6HoYeKNWL7QHf0Bz31Ivas0LfAiH4QcC0kveKviHrlgUe6SX4DGVJhcns8EcJEHwuegxZgjhRwNk44nXuhquDyqv9SFfmxaMddBGnneOxCSNq5MMD98EE87/aK1b33m1963b9++t+7cufPj7j58viWjO3bsGLasbDr1o/fevu2tn3rftmHzZDy4ut+edtrzVr/rOV//wOrq6p8etXX7rV+onS/HK08ZVZ5rKWTOJgCpuVSYqvACDlbwiyq6b1RgtmcJ0hT2Yoq4IcHqYpZiCF6/o2etzjIdkRyalQUZCnYIyhmIlA4F7OkQPX1HuJKky/MZR5x4R4oamtBJasmaggwDN8an+0/+yBF1VdQIlSKBZGUlHeYRWChuoAVKnAGjA/N84bUcPHssguUQRZMBrN2yMjt4Pq8ggZVJjqyr6JXPiyyjflz6JMjRSRnaewoBBvgxnFIMkNhLMGmJibxfIO7po0piqgSckBpf5UyWRBNypsx40mvwIJzLwAA4BKYgim0seJEiXfESoi4ahSWFNQsW/XR83o03+ZNOrvNNVoO9oZ3qp6S5Vf0rPztTsqH7pCZmSsYk9SJ9JRFFrjSx0kGtDCcvi+4rqEuH63quQEr9xbiHFkX/GJiE7XouGuNySDlD6ijlwtmHvKsEeyannqsXkEvYSuLXxuDSd+GAdJRtleLTQtJC50znT1F4/pJ6VqSSPSXul5oyNLPIlhyawczW088oQWyIgYrZVS6ehIs+LWUsvDZFKrUQEt+FzYA6VOQq++B/F4tRxio1bSkTMRSM6WZkPUZa9K6zCU/sJxa1v9IuUfic/pLFPmJ/5SfpQPtODzraPsTEfgbZGZgWHKGeFdzjPUl/DCDaMC2fsJCmwLGMyTpMcwNMS1iLToyFJjEtitbEnQFthsqKX5UdUn+IlQjboz2iLHlL4G82yT7STkGb08/qHdPfVl1CnPiKwNyufliKDG3o/QoFK37BOO5aDND9jAFq0dsLPmYRVrOAkrVHgSDON5fuWsragTxy2VIGhpJcpl2pUICelpzhlYZGG5Cf5imw3fND0W4x19WEqCJsqbBRBJHuD0xA6IPTSVixR/7NLy3lQDuTUkZ/i8jY9V9p4jPBX/KAGBB87cM8S0wsyZlWzVh25bW/RPPOuXkng2ZrFa85ocjn0gsU26nCQ9LLE7XJV62GAGQLWORh55s2lFt1VbpzRjdvnNtsXNq5bXLJEy66fdd006+1AyLdzKzbuFKvOC10DuD7/vvb9n74E4/chXH7dL68Y9PSxac+6eM7V7b9dtD6edv5cr3KktFUwOb/rBNFW77i6VSsGmXapqqaYVyyr+KgOie4cFFPrfy94Yb0hgsOol0yfg96uJQvnDEDurgbbQO1Y/AxDSnGqZQq+MGKCquFGAJMFfgAiSyp/O0l1PGZklzqE5eGtfemNP/jSYcBOt5XzzKRLDO5DhhfgB6fDzDBd61kylmBAYCXgCisnmPnW84omKhgjdEP+J34g3So0aaFYDJAKeiHeP+TEygt+9cy1+pATIoxGOkqqFNBKn2A5FA/oSMknDjXqJCfoRIDjOtdF0DMRB+rwUwGO1UwOtg2Jn7kDu2htBr4GuUxhK3FOLk0K+imPHKzfuNFNzvPsVAeBFzhb8qqiZS6x+CBmhKzFu7lp7pMfhoADBjd8tw5Bi/SuyAv6FSgCqR9lCTOg0AFY+FRh6b0WnJGEXHQI/uQipAAj+U2ISCrjoqPx2CM3w963x8tyREnpoZ9a9aAS5tqQcuge1JtSBiPDE298fK/XMol8w4eIJfbiVOmPdZDp68uiE+rNDVqKPtRZU8pMCKaVVnR7ju9azS1pnPVAmBKbuVHGGSJ9UPXv5eeoU8s971Vc3XIDjoYCl7mEvuSsso+4z7PHnPo6WDcdeRC6HV0rPdCSqWhJdDVk7p3dNZtkzleyLYoqwFNlkN5lUMIQANVkiC+AjpNdCyPyWgLbgyQf5EPZP8M3kNXhXFWBBA6xkMhWAwj/8j7WpyRXgXNAWU5pqp4xesN1FyzWHZH2aX+ZfGCDdMuRw69JT+W0tHSv8Je2jn5V/cx0QZdDUI85zH+KgoWaNE4YWhZbL6gWwUf8htZYCNm8TtyKTmTVl3O9G6fhrwySffUkRi7hd6wMN62cJjoANAprFGPCfqOeAdi8S1oTmWQ96jtpR8BWHCIbgAMGGJ7SZGGZmX5yZi+TKCKbEj8bHRY/JNyNgehLTjpiyjH9EWJnYV3xPm4R+6mYEwqUkYaFpiXeiASm/Sqzpbh832NKocPxLty7+haok2HTBb02BR41WFU3BS6S5dUFqgAFss+C/DWmJHjYFzJ5yxWnnFbGW1YceEQs5b0X1gYv6WMuz30gScspgwOTDFgdvggnnTaOfaSpz3vhhGO6/y6qXXL/zZe7j6Jf+f/zSfefdShtcPjuD63U3eeOF7xpK94p7sPr7zhlUtfqJ0v1yuXjFqZ5hWQE6D5R3my2Wb/PZ8vfy/uaZDnXbycFZVogrfVnyiKHG3RwStUcD6f95i1nRyI5MqEWAYwCQzDVNrB/rolwtb9QCSSVF0lhepkiMKmawycMdWJiwGImiUiBxgYVqdgzkmFBT5l+9Xp6gO1CXTVdjr3FAJyNCmr0fN5zggzmfHShtHZijqkLnk4PB4iIGmHM2IgY97Jlwnb6DkPZ9Fv6SXHP2Y1vTrX+r616mAX5VJFLccQg+K+z272RXIpy6xgOYNRdEXeonRS01wGrXl7Kn/OqHJs3rXVATJbN8JrtY/ifMpYyRuE6np4WQ8H2ZtjCQrUIzUnRiX1i8A3aO/YUZODypMYh2RH3aVW1oAiFNFDKTOMjvDDe75ugB/SGfxkAKOZcoRsnTRFA+GwkimkjfZn3fOStkGvSZDlMcj3nMWVTtEGyBNk4JSrCRZBulhX0ZOcQQp85Hgtq/E1BWu6UGqvVjWyJueFllhVMvL9d52lQ+OjopGdid3EKVGMOocqvKOsi9+os8wW/fR7cor+FQPfuGQxabHAZmkfedA5SCTulbZEibO/sbPvcpNo4oymtEd8be+lTLQN2xyZ1JUVAKLBNWDSkuPqzSD/NvEttSHGXVSKX1Bu4nOKKjHCSktjw8nq1yh/NpYHFSGLTim1Ms6i9ZWvmoEZ1Ebyl3RKg5HDCd0t7XbOpPKBOK/upABRVPTEhMIOjVPEhu0YkHuxpNGFr1XPen2lr8l2XNhUMbewTVcjs2Cd9K3yoFPSsFuOz7J4oYIBSU0FYMGv4ofiMX1W4iAqRhCT2uiCD3jKnbrdK161d1kAH+xcgXy9cDcxWqMXsZ51F0CxEIy3FLwTTrTPk0ZI7wnRngKRHpB/UpwaV3j5vYwvV/lAsW6SXvSIiVjhbi3CoiZrC1eqhGm1ROOD6TMyqM4Kp8xihVRFZ4cSxZoLkMJqPEzyEwukVRjmwHQy+Gw282ed/fSHLz3+/H8NAPfhviMNpbu4BPSvbv7bF3760OdO8dls3Q+tDS95wRXDs0550s+a2eh73b4P3/eFmvqyvDLbWTwhCOiAQJUgBReJ4lnBts5A48amBJ0o0mCrp7byd+fPrPwr9t7azkqDAnd9nb9x5q3ZUalOR9DcnWxWKmeswmcyABUD+4pSVDZ88bNiXIV8Z7/RU3XQFo6rDqZbg29taWGtwnZLLzwD2xHeTnvT4yMEWe7guWis1IkFPP4XlsbnUH9ewNgxtgAQ7Je+wlJveLwyHTwZYZZLdQpCSy2s8CHu5+xYo7lWQoEqRoJek5+lHkY1tOrLIpBn1NP+JRmB/u56DnzeLRMuTyeUbcbnMp0INulITXU/5FEJfLBvo0ssicZ1BGZqW8vNSqKjplRV9a49yS3+pn3wJ1M/OlZpN4OgmMncaN/BT97LoCWbg046pXyKUGtIUfWlSqv7UANIm67QFGwBs9MadHC2uC7Xy/b4YATparPO9HoqpLeqbXuheqFBFR5HzhMkw7LgU9DBFmhHBGXFsBqry+xJ4Q6C6hwD+6vfeo1pNWbnr1bRFaXmVRYmGfXNu/8VUAw+RwME1hIQs6Cg+4nV6oN63z6zEoBwiLkMN2gpWNKebwd8AIlp7LJ7zQvCD3jKIQE9+OxlnKI7+u6KRLIY1BuzEClj0Lf5uoTin6hb+qA01+lO+1kTiYpl9bCkdrAZUv8sC3PqB4BxZl7iMPkulRSjqAGSglL889BbQ/ovrwNAwRcXDaknyUAPuZrwIle6SMw25goQz8IK5d7re7sGLm8uwbEKslZLg8gYRwWkRpmV+3JVRa70iLuKHDQi6IAQxQPW5v7iWfLOZGdABV5b4KfpuYKv1KOC6bT1elpl47HHd4lr9F1phxUZKr5RgzzlJZ6njVasIqZR4/W6lLAj+dIgX6+PKnLt4hBNBMRzveMAX1XWMN2USFWMr+Vy6X3RG9mJJ28zOU4+ex1P+axWXrL44jkBOnBMGorG6tkhQUM0ZzRqGmcFjCrBwkKJUsWoEksjxsbVRaSbGNDxxQueFhPOoLLz7gt4doS2il+kbcGBYTTMVtfnx5146uScXaddD+BlN33qphOvsqvm/hingu7Zs2cAgPsfvv/p7v6yv/rg31x50y0fwZZhK3ZuO3o4afOuvwZwxiP7H3kZdmP0x9n7B3llQjjGn1WXKuuUDaQaOWJJlqMDN34PQNUyBvGLl0566gwmHIQ14OlrhC5lIqGcxajOtwJJn5yFw6Kj01gzmenbcUQpI+lCGjgr+PXdRtkXBNSJsEF4N1OXzoVLOqTg4lECM+L+BTRI0CGYBvfq2LiJ18WjSl4KUEFNqShV/vPDmsTkjQYLXSp+sSsoZCWMfPPyfHLYwefyMYK1mMchMMAo7zZo8istcmZEulMdbh1CcYowcJlnInwCW0e6Jtq9fJ/Ous5+ojSRINzzOx1OcULhiDPwTPpJbwy+/RuTH+JqJMVJa2kfjnjruuhZlG8mTt4nDXXpFOh/291j1WOQjKKEpeJgpT8vzkKfRSVXM/QlUVVQXegga+WoU83Uv9gVnwtXSlvdFQWAXmxFqGhB5ujQilB9xxllOmcWktiXbMJ7PpWAvsMbQ/ei+h5XU6cY9Ff1TF3oAL+YeTKyw3ArQcUif1Qh7u3KFvrA4l8FMIx9d4GA949xiB3by6l7Vr4vNmRY1Cf0fPHqCrqaf6OtrOBQ4CM2lZP0HGAyI3pckoYSPw2VFsiqOin2np2ZSQTJfK1J/WfZZpU3sk3yhf6Z9KR7sp7vC/zvZkPFg1J4KjrPZK3OkghiugJXwxEuY+yXJVpAk0n/cv8e27G+vcIRFVDEvsQfB+rbAOJf4OBIHnrfj0imPXvqPjzpJsB7YqvSp1rhUddDxz8vC5Vq8tYVDuQX2FC1/Sr56FfJLhPRxGAl+aWIkHgOxTuVxc0mcssKk9neT6H8LE0sNFcxT8mncUw5/pKFgzhYMaMm/RUnKu7r7x6OythqUXWE1+W4ZSaswymOeWFloXevGiJ6py3YCPDk4ei6p9eijTELCxXbRIxMoPCHspM6WrrrjkzroFOoJLERO0qbvJuyR9JvG2hBUSZkR0PtjbZS+ZpFbvGz0/f4exiwPlsdTt913Pw5Fzz9z9bX148/5cTTn7jAye668MILDQBWVjb9yAh83Z37PvvSQ48cGLF/HeeddDaeffZlN89ms+/xiY+P1+WiQD1UBgCl6+X3hfghQaY6mmJci5zq3a4VwMqKRP9kvb98swA+7UmZEjSbVT4DTEvVapAcuKnhUDeziyFbqMASSQyrIeFi5AwLfIEJBUYomFdFMcv2qAcMtHEkC7qkx+t3JUGwXLKhpTJ0fPEdwZqJj8NhA5fTJHO1DMRSLkwlanWsOlE4MIHptV+qNKuS7goE3Hl6m0Gns0ZTuXcpGaDZK/PYS1Ccd61M8hFnCGyBTS70YxDinFkFK8ThEAOAIoxr7eqUN++WMvA0N+d37J585Gwk0n/lHAYBOJdN5eV5F+VSbMv6BuNH1SMPXlJfO3fQydxKu+pGM3PRjwLoukSIukuecJYnK+zyT27ZJnktmfTgz6COFDRnSmn0dlaXyuhuz7YSrgt/CzMsdCttr9xenls8pZG8Fn5JrzP5qrYuHnnoslU6C/8LyFJ3Tfpbxlyuev4FhB+JQYmm6cKrvDusl83VQgptKO5lASf4yHFr5iZklXrXl6cSW9hvhLxMKp1SZ2GsAK+GWWdPUApFXUmxtzH9TYMZ+na9FBAcWHhRpvi1cZY4r1obMj4ifQ8peOMhD5LquCMHIqDK3i0Rt85eqiBIY1sohHFAza5yVYh1BJbCGqyMvUMN+bOesmJ7Oh2LdpvjS2zM/zjITxc91LfSOHi3WZ7kTR2TFXI80qNcLin/V/hFbEynb8G+oSsgVRsiL2WfSFKVWPoCnUUnskBVBhh+rWIsHRWxSZ/yWG9jPxW/4+nu8PuiG+Q+XwcBto0On2VfNQ6Bqz8Wb708l1gIPZPqmPia1ltOQR8KvhV+Uh5yg/KTaUNicFfRLhhq9bnExH7JSse+7ldHjovqJX2gH6mAIzuLP2Wzxf+AtOVng+VpLd2BMPJtKJPhZAg60RZRRBecoEg2wSkPdPWcOuki+Wnp5cLUR0mK0wKqDy3FXsrcEOfiE26oB4XfoVvkAXnqPiCrM9kkUOw3BigZRcPjFPDx8HDFhc/G5Sc+8U/M7MEimyMeBLN79+4RALYtbf3Im25/zym3PHz7Ft80XT80W5uevuMUe+4pF/8agDt2Le3aF+08rk4X5VWWjDaOdlUZ9HVUxDcKFCRZ23DL4p6MUvxvT2wAglBmr3OCCg+yoS5xKA1bgmqrKJb9A6xyFUOjBnHTvXdjKctLUQ2ren62i245ImnQWA1anlG5JOAEg6x4zmgyUUV0pJMDYGO7dyz8rcmGzHVotLQJ2urMDLBBQG2wpLsc1NBYbfmPsyGl3+Rt76B0aEqRbZfphn406RIECtA6XxBPnURU1hCOn8vGsh3qJSum5jwgg23w9EdW3yx0LoN0j/aM9JXPE3Q95EEmFQyUcnmCNWlSxc/KzxrihtAcyOkkk/xDmtFmyo3A7IW/OtQBydIGmpUGeTNwqckou81wjndRn/NfdRqQDSYNCL4btQwbr2itQAVnnKm3zvFHMiLKPU6/pVmTdsmu6A6QJxeyV+sDt1rKNPZfMUrAhU7m0tPi1PKAoCZ30u1hZ6oeB3Zwjr0P8jySrpK0leCISNN5V9Ja7BaW8igQ2MtDib7Jvvi1aPLUZQuMYkJMPaWs6RtG4qrX2dxCJ1GrDETL/aSL8V3BQn6Wsw+pi012LvoyxiC2BVFauTEidpgvDLjgEZf1uqMeEkS8aP/K/cKcHiNAqZV7en5UYTLQyeX+tGiFVOFEmmtK2Yl3boH9g+St/3ZL+IleAzLzpQH09pmsKatgSjLSeFKWVnq+BxYL9NMmKm5JrhybAdwWYMVmmRh2M+fCA6+NL/AYRTbBg+rpLYoc9KmehWvO9tmitKhjpU3SpGVtMr6wXfUb94kG0zjbUuax5enUv+Rc+axEScSe6helK6mHKYngcWQeKR0mg9H6ghyJA8JKrnCgeZFXAk8DMOp58SwlEqSOqLM+usczIq1/CwvlYoNu2q9kUXojhqroaSlfpAgpEX7INs04LuqtoRZy6vL9TgWNdhmQ0h1ERb2hflH/+i0xlSuEEcaCXsdG3S4qqThN9JdGAPB0ad3ryQPetjg3xjMpmhsM+Q5sK+Nrxc80M/mMQkb5pe3lLL63jos0pXIoXjAHZrPDs2OOPwlnHHX6qwGsvuGWW1bc+5LJka7de3dPMMFr/+rGt2z/1AN3uW9fxrDJ7TnnX/ZZAJ8ys32P16WivPolowUwIKfiRPkOYIs9YOHX0o4jA2tWflEC6ApaJmWT/OXmUykFFYtOqoBII3UUZi6CT1fr1A3tpxZAckmQni1AZNmGWT6bAxi7wKHRxmWano5bziM1n0siiXBt31F8J8uOH3w5LPnphcfRzhC/D/EMX2DfmDPmeFQBbA26t72HPJHLMWLsAL1P3PP0q14fku8luQThLl2vAhMv1X4mMJK5ax/WIHAJraiJjDcHR/qtfmcMAjwBeoHGzo/Ude2hx6mxcY/0lJ/SWUrRoUSjVDuD013Ax4KAPitV/Or0idB631NSKftK6GwnYY7ZC6oBFRIz2LKN3yU6l++K89TnXscQQbtshGLzhJW0Bighj+8ks+hQB7QM5EvROfnB0OTibbz+nVIqzs7bO77GHGHTNdNAqeEWowIDD1iZskveOj2h7NLQ3olZdMHiRDl38IXk9OJ58FRhtvNees7QvjGxNoOlot9WfixUzl0BaPI8/UBiiu4XDYGYJfDVHFPR0Y28Q9ENoJuVc0c9EpNyqqslEqlFtfS9rSrMYKMm0Bx0JmUQVdL3kkQnrkJBYF0pJz4RTnNgPf6l6sdYXPdJLtX5sdOQOQuHKI9V4kYvspcvsQgmWcVvVjZSP4pO8z9NX0lX7GHmVoixBF0jEc8L/UlzsoTBOT8jwEyykMAKv1FnY7kv25GIG/OJEa3PVvjNJY3NnrgsNZfzps0mZg1kE7RCJOivy4eJIzx0aYh7PXhR8Za4BiZwHG75p/6t6IGF/HXgWvEtstXErqJ99GqNlrHHHfFPtljpCsyS7ad9VD7JbyJOCk2BiAaAuM1+qUuAV2aSOicPE+hTr+O8e2JYrZJV/+OZ+FFP6SUzjkHyhHIrK2k0jA5HXB+7bN6h00QNva3RHzk5lTPVgOm05dRpFnDUC2qxz4ZEN8T4qW+1QNYmT0zPJYuSv2JV9JfbK/Kzzk+rkEPrReVGl0dTrbJNIXCTDREgMsv2V0v26fdywVHwQB2QfeEvjVhrmdBS+4rt2WiYYgI/cMAvOf1J/uxzL3+bmR04/tx942PNDJbLrr3q2jmA+x+dH/rWRx96wH22iieefgFO2XniKwEc2HvTTcuP15lBXloymsIPBTcKlC7TBBB/lytB7cj387sa2NCYWNnlxxYApzYrYtLVxIrCVqwpvS92X4IWAJkSdyhc6BxKSmqAXuQbGtn2yi0abLazcfmAZVuR4Mi3C5Tj7qEkS64GFQhzA7VmAQ1oM4sJwmGuoPh4UinLRZWfor4ms/QqvD/GzCVxdZlg/gKNmLJsXxGkDBtKTcSSYZD8HC348EFSLks0XX3lr+nIcqlQ/Ccm33iUNIE2DyBAyLXwBJBekt8lPcz+kstyxtTjktl1+tv0lHJxBa+uLj15wufiGTq2El4HC4OCfLS48yoVlHGmg81xbhBLtOSimw5H7Cm609hWQF9ttfENpc1FXorasmxKquKQzNIc6uyoV4LVNHWnOvBsoMiDH4fOJHbI5SjUyDZTfuJ9GTcDca1eQJF9OM5mn3yrtCMPuGltj3SiXtx00X3ueexkxmAVlvZs9L1jCTR7ORNrc2uAlaA+9GeD7XrwMMbpETjJPmK85B2/E1u5HCyY0w8v5RD2JPkX8Wj2qOp3F2iWQKT6HaS9jwAwjhl4INmw4aqzqkEbsTBtsGCML+hgCUwNXFqVfqLJq6UtNXlWodRKW+ovGee6D1KpHDJXsHi2g9JHOAO2AWENIgHjIzUpRybN9C9AK9xQ+5mgFryTL43ZmoqqpBU9p1OPJdd+i4dOjA7cT52OJMKQ2BR02GBl6Wv6d/EQBR9kp0y6epQUjfWzGMBghTaNz/kAdGIoyixlDM6Dxw3TKmYWPRdWeNJa5VK6k5+lT40ktb3MJ2UuaRjxtrRVlhjC8l3D1OK26CV8BQxloUajyxc9ArEkdUr0eeFpB2jIhGQB1/kCScklvsvliS5/VotgxJo0c5M+JPKnzbNbTg645fn0pNs6WXsBtsQN2hvjCPKt0pR8o/qYxuLlHYKadXRoyXRabOpp21Y1SGe01NaZmJbiQkH1QIRkdeWVS8TQ8mGg04ccL11K8Rdss/LJO8qL32gxwsSByWiO5eWl07afdO/Fx55+45133rn5NDvtEL7A9ZGPfGTq7rPrb3//17794+8FNm92X1sfztxx0v4rzv2Kd5iZ73V/XCeDQLdktDBaV6CipdL7wv8IfFWQmjRDGCqfpfLyCnDWoSfRAnWfTpFJUHXS9Dl8nkbRvT5g44BABVbVjjQXW+WhBL1zMiVSDouiNg2n6HcsrYQt6LGAMpfTeDj2NpsdvVn7fAyvpSqY5fgIEnrH1MJgW/ux9KJWa8o6bzlqh+4TKHeeN/riQQ2siGm4LvtnoFdwCOOYRszEUI6sOHWAldzUKaoLgxd0w43qL52RG3zkKY3piDtHEPQKC1V9a++BbB2OHT/KHBJqVZJVTVaitdQ3+ClHSx2I/41c/gR9kXqQrCgkL/SPnp9pXPy+/T7G542GPHBCylqCo9yrVr11XpxVdre2ZBkGG4bicPrgQ/8IHGE7dK4ZmCTYNx5wOKkVpFN+1GLpUoxdPNC0IgcaOp4kdHigxIoBhZuqqBbKLMyCiaax8A5WDhiIKIkBjTmQG2tbQ+6RdASb6zhACbHYExSOtAPqY4CVlgsHU7VEtLtijFbDgCwKAIG9lFHlOTKgkJxZELLEgDbeLHYYx1Aw3MBCUlpj+gQjidGFl/4ABkc9zDUGK1C35CHv1mxFh8OJhSSTmEVbz+Qz70nwStmpJS+nkGgZqonnxJdWwBnVrgfhIt0RMxJZZoBwj7gc8hZmC7HbZA8PCSmsop9hIt+ZZWk7GVlXrnAW0NTX6MmvIhBwaetic22liaQi+wBx10pTXmRXZe4eyT1xrBRFsUAPmyeesf/yYnsVt72ie2KsAnDOOhEqkIlXXelBnqbeuvgo/ypdyLbq0kPJc8xXN2n5OZD+F+ljSHeNg4YhQzqTTBNzhWl6CEmHq0VxpMYu+aEE031cv2ZRIItJ1vNZ8u4kXQgHFPCDmsgkeUDsiSmHuPWkaf+3ZrCIPkP+7QDf89vsNQGlj0sN7qWIUsYo2jXeRi3dEU0s9YBdZBwqnQllc82WBaaYxzLMxNYNqwIYFwqnVcLp/o0xltJx238qvOt9gwy0ObRyj2kVlgv9Q2ZFlM2PpAyKyoBJR+qO98+JyTWOTd3ocDzUYZzP/ejtu/zck8/9awDfsfPYo14LADfccMMSPs910UUXrZnZ+MHbPvLdn3vkPqxgeVyZbp2cvfP0247ZtOm0W+666wlXmT3mKaWPl2vhlNF6LYy7s/T8LJcGxUf0mxI0DS/rTTKQxSjtSJecef7dBRU1mSkVBIHDAtb04/ECeCgG5AKiHJR3hq3PqsVT6cNxk10KiBxwa8sdeVy3G9oygZrwaYwezrs5j4Hn1SuY52l2pLkZOwFYTsQohwUZVCDikpwcimbTPEAqY6OUOY0ciFXHpT8AepF65zEIVgPBNnm84NtTLgI+aPzuDh9jT2CAaGoAnX37zjmzRjAcShBbE5g+yhRJ8lHSkvyk85wMOBiQRltyLnVsxWG6M8jPANjDkGqlVu7R5RvUPpPk9n/X2OuexI6xSD2S04/7MshuNw9IfXUUm2P/5Er1j2xSSdeicIvtdw4unXEbZ52R5DMluE+RQ847Ww79acFA4oKBaTmLyxkIkvmQytXDgzqa4bF0O/Q8s9pMggya5Wa1uKnh0AI4k7AXaPbsP2RDVXfiAGdvUv3UAItLoIzF9oJvnnQB2TYDROspgvZD2wC9FJz0oWCD9C2dvmCy6JqFji7al+RZVVbFhiqHPqikr1HQW2xTwTcWfEQ3ygX80hdVvp26LbiY1ClbaKX2ZXQIhsJDEJSl3fyikyv1oviiHGYCrVrQYKNwJX6YdK9fTp2zUwPHK/tAyk+jqiUcz/EhC7lcEbmBv1TDoo/Cs/wg+DoguUpuMrCuBSWgMs+47OwIOqV+SpzXklKDdKv4e/ZVE++GTcSokI3VQm6xDVJl+bdRFuRjsfncwuDJNz7nnvoOS1qV4CDMLHSqs3XLZeZFZhlKOVqRlA+lhHPrhxW+ueKGeuV4rH6S8OqdqJCJmVXRoxZNhSUoRRHZW2+NTf4biwscb+pOKVYxOOqgLMF1MSWQTqjNpL+DOxUoi7XUmFVyj6QV6QNR+cT+9JCEVux/ga8d/xNjVaQljbTRhUfa940uxbTS79KbFMzVnn7GDR3mFjuvNi8LZxLp1eoX/Uh7wpcmOLy+f37RWRfaSy+54u3z9fmNGOwX9u7dO/mzP/uzDbN7kdzZQw89tOuh/Q//grt/zcfuue2Mh+97eNyyNhmOXd7qVzzp6Z8GcNrxx+z8jnjsC+5F/HK+po/1hRexdfrf4XgiAP+bplfQwQBN9SzompfPlPW3L4pCm3SfgZYcmb4voFuMuzr/gBUpGc3VQ+MTvHpn09Rz5Eqfwo/CBWKI3scH9eHVyNh+GK67t9MfHYAPcG7mBANQAi8rR2Uqt9LaBfxlBsoMzoMJzCte5ExILFvN5X+JPkoMPB+ywhkA0AEd4nf5Tl6oY1kRSi9vJSfVubhvaJdOtzXlqMtOmLxb0MolPRmMJHjli7eTAdmLFX0ryTRMqpoVwsITOtD8Kr4bEwAZ2Qsgi2A0W5Us47InJo2ledD58zANwMrq3RoAVx7Ed57gy4KFrJhfOGVsiyaqQIbsU2FWQkIG5+STaPccW+h4ir+4DTqDSGyyOQ/9drWrZyqh6HkpcYO2DbR9vwbYABuCj2PpYyj2UZYLakWCxBqJB5eE8qHRs1PeF+OoJtF+mvoFuytooETY8l535Ps8C+8reLPGHpLP4NGd64ZQD2tKfQvdMrTDeTpmBhdpD8UEmohceNRVeJ2rQ9oto2RvBacWl4dG2Cv47mWcgvbkYfd0+d2rPEqy6Avt8X7pVhSV1F2Z2SdT5J9qMSyWplnhBUkIHlRFUFJLuyCry0/Tf/txSQ88ThyWLtHa+jHWv5R+0I8VuBiRQZs8FDFg6HUx+ZM40fl6FKw3QAvsjEW70BsSUIpCTMDa4yMMQ6cvJVdrGu9IPKx+TKzLRCNNrczUkt/UT3e4t36x8A5dj/t6rMjnCXDatuBt7BY0FeTsnh8xtkMXayJqRTdQ+q/ChcWS8gQaLWG2gleQdQW7Te11ctzgQwXY3buse+vL32TNhVED0k50f3zfFaj4vKX91rqBfiWutT+K3UgoVMpMyKToKR8r/Oc94q/44YHzKAkNSerjInAsxQLTVlr/GcXU2cQh9RgsNMSzA/1f329/FZ/rRXxGFTNY90w1YKTxBC9r8kt+9xhSMEk46IWyftNICpF2v0C9baSOkqBfcnOMU/dhZZyce8zJd1xy7NnvNbMPYENrXbt+ww03LO3atWvf+vr65z52351X3Hj3x060KeaHDh/0Sy+4xC485Zy/XF9ff/dnD3zmZncfHu97CI+Q7W4UiMDJgHwVQP/PAQG+AZqNUnHNRlmS1Zarg3CgVmaawDMQ7wpzhagOfARQWbEi9si7HUFF0pYJNGVWIoxwACuXYbnFtDNoi3+lSkIH0ozaC+2Nes/j+OTQWBHTcMzQG5LV3qCZwRjbiAI6QK4htwFt4z6rPcnUXAvPpUIQDXVJWqOJ4/bUg+iMy1KDUKiShAReztjBs+3ariDCDFBlzSXDLslGJgVkSNsvb1zlgDxnLx1SBl3UD/4rla+y0b/NSBYtUfDRgEz6p3Hl323ppoGs4XPJ33RyCPCv/mWkoAuddAwcNPVAjF+AeVYbWV2VU4zvmOwDvaPKIz7EOI0j5V4caneflbEYi4zJRL4j0tAnNKX64+bpk1DuL7/XpYWuxutMQ+VDaUjDCTlhDF5zcKE5XcSSMzKLvGu4YZqdY7C3yNdBoEk25fKy0cd2cpzk3Ojhd2lehSMRQEtOop/DJD+Koy4i25iYNvpyz49Fwpx0EucUnEinkEGKJU4kDjhyj7pJT2DGTUgLmsu2Q2VihTeFr6q8Ff1mwFiVNZetdImDWRm7AmEv+G8pQ/kjUiXQzHEQmy0TWNl1GUujN1Z1pLoVVEMqjHBkQaoL0zJMvDS7UL8NxefKkTrmnEEeEv+KPTlitpDybEIVfhCDveOPa8tA2mYqvZMH+p7ves0xC4fikDjhXmDFYAPyYDdIXguBAgzpE+tcf9qLL34im+f4dQi38WfxVVaWbVvRRf6P5l4FGGS074UkaCt/8pUEBofxkMRO/gAPhvUoPlW4y4SXvqLIa8h7qoxlT/S7WjabONPdX+3JXbjAzRvwsWpnIc6p7j3P661Wz3souEU78vhAs+rxjV7cTl3MmCofo41G615tOT9LH9MXVpvqetdGe4azrq1fHiGWlGR7TU2blZoKsRpFN3IDhI0ik7IjdtSkVkEGeVN531r1aKSsVpVc2RRjjP4VTJ484zJuy6YbTckpHVpmwDAk1hmXwZbLkDyWf6rfOzTDq5vjcMXZfH3csvPo4SknXXiPmb1/997dg3+BU0Evu+yymZmNS0tLP3fTp2/+6g/fcZNPtm/D2vLMzjrqlHvOOerUG+87fPhTFxx3waPotOPxeR1hhpBAACyOPyELYDCZIJ0AIWBBtiGDMIBLutJMCsDwXn1RFLczvP53g3cVqnRDJmVPeI9+qresfhcuZ1c7ccubswhVKz5eb+8bDsakC7FKlAwmAaM6zOBWMigr2eEgu4pZCfTzcwYU6Yxb8DBqpjAZEw4pZNUAyjXJ21XVQB4Et3lPALrFpm7N7pB2VeirVBJVykr9PpSqM7DGMZCeyp/8vQtAqBFsvgRaTF7E3+pQKEkmtvIOLcgmn8hXWYsCRI+gIyv/1ukRx83nHKqCO+KcEeplykVBhRcfAJTZwtA+S54lD4ImEcCCAxOHAsq8p/SfyWhjSN08DlgRsaWqy8kaahXe4NqfJ0I1XAZXSL1x75L1RmI+I2t30tJpmHCoH0Pqegv8vYw5Z61asLFY/Q39LkEkSG8sWUtZe2crYagZwDmD+awxUway45ogyPH3sxq9M3U9ZzEmwXfCkGQkUyxw332mRI7jShtqYyuSDV1ufRX5wtOei11xRquYRRvZAiRzXJkAkQOhB2W81ae4yHfV7SC7DJ2PgpVWhZSpbz3iiYsdc5yzgUU3hf3FYSKNX7rhVAePBKzguANuY8qCOK9ku+Ej/QF1ZaR8VHyJznwEMHQy7mOtpC1pzAQO0iNTEJz2ELyQ00Lqu+UJn0y66+oMlHa86BV9R4YdnHVMXW50pJByyWYJidUAcZbjSiVPX5HEEG1qrSW0vfxWFZSY3/oSHzXC1hH/Tjzwro3UeYGxemnnD/Q8MGe7BQfoo2Jc+d7XJEXjqcn0kP3l9pw0/zoUYmZjLbW9n+HnrGYahgZS/k5DZWLCKCALDi59oC8Ri9KsZK8FkFP+8SexWDqrNtEBTiJ75V0poqLKDQsMWogRjxi/pd7xhNPuWUcpmmYcRJWhXTdZhT5YHeiizyiS8QX+Mk7UIYXeszDGLicAoB7s5ZZtNbYSk6tgOK6k0XW/utJ/sohV4ylg8AETDFhdP2RnnXD6eMFpF/wXcf4Lz+h53Hfoe3/7x7ceGlfNzMYtR+1cOn7H8R80s7eVtvyxm3l8XMMRfusASTW1kFRWs9plaEEQlaxWQ1Jd0gA32L2qGsX+pOWIICCTOiYktQDSFH9h9qMEBmXqqzdSK991Y0ZWfSxusaLABSistlWMI3nH39tyLLcyfe7ccE/eZGWNFRIaUyPV5Vicr4yi5URBcQTgPNo+wIb8Z+KcFSHORFmh3MosTqlZNSbH0DOAg6Psl2EL7CNe1FvlzODN8nhxJfTV3uhQVBCIdjvtKqI06/io/4UTGzXVUQI/dk45Bw0RrksFKTebDFnB5/Atk7q6j4VyGkcGrAGKxt/5UNGppBByBOStbnI5XpTnZGN02rKblGzWOOLIQS9yjE7otDJI6SutkjkjaflHJkmh2+RgDSI0Nv4LfQj7km5Rdy3vr8lup/cce89AKaWGZ90dIbNibRyKArcYiSetFv0qkS+fi4/xfpcMm+mgyQEv9hhyCeDie3jlbOMz2WXgjE4ipPy8QGaHp6mPbih6X+1XyqskeZGVbYxBu7IGl21a2A7lNZT2ZXUDcbrKjvqFhcv633UPE8gSlJf+3VPnUpdSJ9MzhF4GomTi4pVRiZ16Ov0hOp1G8QnFAuSQCgayPSocZW/Jz06exZ5y7SPtuRoE392KHL+Idgkil+Tnstq6Dz8D8MRP6qx4aXE0h0gRWiC5UvsQg0L3s89qxUjWd5hoVlZmKkHhKpZBNqu24pCw5CllERJNRwG+B7TKquu4/Eq5mde5/4oDGag2XjY/50XuOawYL1r8ZCMxyMt9nNkho2tSaSpqdG0ReUqyC3h5l2FAI5MHi/7FF0s9LAKh2hlSRhxGazYtbTHnCwqCFNpmYYnuLf2hXunHFnK59BHFlhpNtJzSCbJIkrpdsHuBvkxnglT6YqDEPPm+ayPuHQnTFlyUuML3K8smic/5GOULq3wJfeBvqfwxpsQzo6/SsorAHKl8Amkm8pAOyO+RHcXmU7JCeo4gsKb6Pya+vW80xVxNOflcldsRmAcqzjAHJjYBDh7ElU957vDCsy7/8HXXXTfdjd1HeKY87W43+A1L7m4Prh9++acPfPYo99l8XFuzU7ceP37T01+25u6TPddd95hb6x5v18JAbcOfi9WPFPtQqr3QPV0LtFiE0LlMENluQQOBWqf2ncdd/JYtlE89P239GhJFSyC9oRU6akFqtTJVbAZHqbLz21FgoXF4DUgMEzmLVG9WhrplXEhHT1BKcyDwk4PReoD+iJhlCVOrVc4MTGmEj21mtWLDSndlE8Xhjvg++MEZwQBkPiCIp1dxiPYSqZRPPJaneR80W1tygHCcAnQHdOiNWTtCvAQjde+ZqnG8R4wozp/0DPmdBarJSUQy3zOjCrFWhsvMYD3eWRIoSW+xmU4+JYhu9zMBg2Yz6vdqAIa6nEo9xus9CgVFVibb5rA0QxsOuPucv5uVNhf4wX6KnSR/kBRYQQYlrTVMKiwvo80Kv6c8PVmgYKLiA2c7yaYFTKgz/y2QZWGGDjb7qRoNFBsOXRW9zmS5zKqIgPbP4Qt7Dok37f5hMMAmicw+tmXnImcBJ6PpRnLYFeoNeSNf30MbY6OeaIMS+lWGaixc/tZppG/orD5VAj0RihgyusJs4C8TusYXynaBljLEzlVZsZ1UILA4kVQHzy3bFEvUT5n5XNDSdFsOYbKI6mfxOJvTEe5efEH0M5R7ov0W2HmOk/tBg+9pUUcYmxjmcehF4sBYtjx3zxIT0etytT0lI8VMCvvyC7d8tZN8YfFtZaCGsaqbeEd6+9+g3K58Ep/FJ2ErcIk//YGsK+06Ywm+46r4CnYY7atgpOC2/d5hrlucq9bwfEDiLFk9cFQFN9hfapy0vBSewmbJT6MueCjMoO9YBG2uKYsviT9FZiwckT8UyJirAtw5ppCHQcnzhghO9kTP042mx0nJqLSj56tRpAyA2EdrpgRI95XhVd/AuTdhC+/lPVYINb5KpeDlBp33fpyBCSWaSLIr5lPmHIsBphm7pKkWXrxgcsOb1B/dQ8wpcV72h4B1C3fkKKDVsIW+aWGcrSkvvGE/VlkeakTk1Ms5REn7MxnNel23PL50PMwdPs7GrUcdNZy648R3ANjz5Msv+Ztjtx31G+4+NbMZjnDFjN86APzR+//6GZ898NA2myyt+6G16UWnX2xPOuHsH7d2suhwzZEaeBxemRCO5fhsGadCjnRIeqBPETudiL/r0gqChNbg1Mtqn8U/Z/PoO1kElYRGq5q3sMxnkU79XZpjMEVq9BzbK1W37uLQ9FWr7g/TAfNx9NVDh+aYxz4Iz0quvIoZVEYfymb1qIj2yFX6HdmmA4NhaWXTxOLoaZ+PYoACUz4msDZUwTLYR8jchhjYCC394mDp8PIZ9sHAqjgIfUswSZmRf3Ln0pUANR03PqiqnMti2j2TweBmvra6OmIcXfxbTNp0LTi7YUj9pNdhGXMQ8rbv5nNgAixPN0/HMfdIZALOpDsgL0vpCcLtC/HO6JjVjUuFswIagE+ghrUXqWtmDhnQiM2lWGGScKpx9McEXAGMxMyAgsl52ml5HHy/JeWxwdAkbQMwppNDsp12k8uD6DstbwwDyySK/FHPFbXItMSF4rQlraLv2ihEvvAP2jwDC8khv3PZQgmOqA+CjiHpNeugMGdSOXPP6rG32Wkb3AxYXV+bYz6Twk2nK9PpMMAdNs7blKLzYFkWC4oD7ZLibnieY5bfTSRMHx+Omjc7wEzFCYRMgupUgHhYGAyJSGPXvUXPRQ2LNEUD1WcfmRRLjDGWrFCc1hIptpXib79ksFc1P7G+yfFILiGHaMoV+LGWMmaEi4Tj1OUcYeEXi0zGYJkP00+7RpIzwaGbVb/ZC/2PuJL874JdB3OJPsEXszLBzeVpI0xZLIRpnYGFXNonJbl3aIzMdA1j4Qb9BfXWE7NTUh0W5axaLy/XvywsAoAOU1Jb1t3N5eDyRaWYS9sFsb4mgwGWNWkVDzo7wQb7EP6EDbIQJ/CrsysdjqdVtCSQ+hd6QByU+F2rEdpNC/sYDRjCJzdIqHwlFqdOdelPNYaicCV3LmPIhHswqBja5FlkXVWbSzmPwENITlmQS3tKf8L3DktmYmcKTaugqCE8oM8Mi/FgG0IRuH71OIU6tLoULDrfVDFctzgQ742MDjJplUjGMnZP86T/KVifdWfab2tT8X/YYb+lBugZ3eukViqIS3UAPTD2qUFojeWTXULOuwbD6sH984vPuXh48mlP/sBsPr9sabr0B6WR7nJ3MzM/5IfOXH1kddi5c+eWX73uD7/7ozd/1Ldu2TpZXzqEM3ee+PFlYP2zDz10JoDb+cxiW4+3q8wQ9pm6lAEJys3QrHMGNXDVkgyk85UxAakEVWGxAYKKA15QAv0ojgu0Ec3rdeDm/YMb1UNgXKq0QasNI8aJY5hNwJPPPAjSuNl0ARiEA7NhwOEDB8fNyyvDE89+4tR9xDhvxQotOTCDTYaokpYN/abWQjoWy2JjRoDuK06GHoYBB1YP4p6778aBsS2btuWl2cry8nQ+m7f7x0zxYWWs9XexqvAedIqWQCCfn04HVuRX9hMgxpkytaIvAJf2FBJU2aazb9rZgM0dUfFyTG3A4UOH5lg9PNhkyZ5wyhMm23fsECAn+JHnIbFwku4j1ufzcLRExuQ7l/1gwpnPOabDFCOAWz71SSxt3gJoX2OCGwM7OpQa9NRyeWp7jJ/L1cKbtICEtgEFyJR/PVyV9Kf95N411DbiP7JLgjf5giJSzaJZjRmjNmLZTnHqvSCT2ozViCFZqGCQEtpW+vGFAMHyHspMXxZckAPKmZLOEVenpXuwcBV+kYii7xyO03krI7aOXiWH1hpjxZQBC2sj7mM5iLbJYjIMGM3H1UMHHY7JJpvgrFOeMN25fSfG2RyHVg/h/s/ejQcffgSA+2TL5nG6vDyZzeZR5EBxoBVRiD8bsTkD9oq3gX9l3Bq9SdCwbu/BIjv7lQstoODxrRRhgr1TaWrQIl0H/AjPdXjDQLVJIf1C6K4CNqle9Rud0tGryU90xQ8+S1IU7GdQqvtVbHHRWceXtLkq+a19JlYhxbIKoutewZsjE/xSFCidZZ0qU9Bkv6W91jaKCclny7ZMdiEdWkyWKzbUmQ/aDRavLHYNDvhgcdpmbRQJLoZix1mYEXaVBL90EbYQpzlazp6YofSXgyfuWBiMZhLFT1MQnTRZLxtku5l45XDq/shGp/XPEUtKUcEKX1yy8Q5n5W28zIgXbIuR93KrCW9zwLkyxSA+JLwyLpQDyueR9Mrrl8It/WhrpyV/iZVFQwqO9NBdUk/BfsEV8siBjErit1rAAv1cwlJjNfEpMUZsZ/GjxhAhX8H6BjvM75qMKVvQMFK3JOP0xyHhDlN8Qb9K3bIwZQHjGN92jj7/ZnyRuDumXhNBYgzUIRUqAg+zfRGXPqbg4EYk8KQJNZF1YDq4T8bp8StHHf6KMy/5o7WDqz+zc+u2TwcvjriH0N2HQ4cOjZOVpT8H8Advuumdy9O52fTgfHbcKactbV3Z+kcA/t3yir3ezD7l7lMAR5xpfDxdSghNrzvoBZH7C3pHVpWkzAiDE+61mfQx3usZOgwEoxGvmoG8sXM0iw1ZNsFfaisMuqrjleLWWT8PhR+BcafDTxow3hIV+zjzqpvlYT8EcHfY2IB29cCjfsZJTxh+5HtecdtFZ531qqXpdMumpaWtGEe0SbwBwzDFdADig4084b6Qwl3uFRkxYhyBYTBbXl7x+x58cNuj+/Z/181334nr3/Pu5Zs+c+f0jrvuwPLmLaO5D3SCFRCZxLHv3IvXYHIM59cSI7UQs1uZ7JDmIapH2WLjLxMuyrCkNCRoIWYY5MwAtNMVo69hBCY2YO3w4fn6/kcnZ5z7xMmzn3IZrrjs6QdPO+HEPzn+uGM+O19fH6xtEjtiLMJrPjrW5muYj+MRvwdasj2g7R9cn81t0/LS6mfufeD+P/ybN/zX1777LRgmU8c4Gh2l9lZxaIsOAAsyLuAu5z4YjJU9L1kfyiwM0qGhOHxdqtwWBrjBh7TDZtIZGLj6gHxGftaFE3l/GrjaS5tl4FSH67q3Obghx2Q5ToMBo8GNy2TSI6oIpEJCBhbdsjxRGXilW9mGx3R5L5U8nKKNpc1MMRnIGXDxKZpiYBeF4nTEHBMLI8LNKvu6QdVhkwkOH9o/m06n06eddxGefu7FB6986jNgE//Fi844dzqfj8OnH7h3n8/H7775jk8df9173rblXbd8cHL/5+6ZT3cdPWB08yEODll0vrAykefCr24/DXVjyEEoqJE2LGAx9dOYgPVJaFaWLbE2h5z4k2oA4TLVhzPp5etKm77pfJB3bklxJUWsMUFfJA5CAV0exuHBh+IWq1EYSjGlaEDxgXnQQtHhHGT5EVjLRFPjyCA2fZIVe2521a82MMmhwyB2zXsGDSLHW2Qi7K9XMIGL6DL5ORJHDXqVU+ii1TGIkQBfDTQOaTfkihJgS46gBrZscrQYW8dADj3HYnkvAB3II1kS0xbifg+99ZH4VBMNoC0tFJz0eMn+rc7HF90phTcWi6uys3CQy+YlEHAGSR1FwmOOPLXSocKrJFW6oY8nBuoVNaUf/uxm7Gjj7FazV1WXFmWRdgWY6p1ZNIzHAisqntXpLve0u3ZXKaYAZYIDpQUTLylsG6GDXIhrmaglg5w6InGlr1IyyHHIpipFpbHK0pAC7RgAzPNsBh4W1edY1FevtYLGA634yf5YnOfnabOa3kncY/swJet1e5DkQF+gtpGYVsZt3TM5/lwUVK2zKErwyGEYJwZM5nb5eU/btB1L77ety4fcffJYyaCZubtjy5YtdxxaW7399n33nviJh27fasMwHlpfxcU7T/BvffrLTji8dvi2Y7bserW310087pNBoCSEWbVoAYSCEkWKnqupjmD0DWfSIFkpqH6kKny/hLEqaO9X80kvuuZJh24OWF2wpwocNYjYUFxGKioMsBGY7wDGY4HJLcDgpbLdzSClYZMWGx3DOB+3TCf2T77lW275gW/8xj9eXVv75w58ZNNkcv0cGCbASG3tU76N1xd6E+YEcEwmhtNPvw3AKV8D+I9823c84TVvfesP//6fv+4f/eW73z45vLo2X9q0MhnL8d1t7B44YUGLx1Ai8Nd7D+vK+rZ/ji8tLhGtDm+x+LyePMXnwJZKQKSloCCWzMtTKSgbGz8O73t4fsKJJ0++6Vu/4/B3ft03X/cV55z3mwDeBOAbABw7n899soAg5Hd/DvFk8YON1xzAZI75OgYMmE8mk/PwRDy4dceWl33wjltf88m7P7u8NAwTOXaiMLyYRDqkTq8NJcgcVUH1GjloFIWXFoGVKq4pw85Ry5zDwTlnqNhP6yPlUoRgwBixT/ER0Z3lu/kiQNB+g04t6KzLrzE0r33WJNJIL3Fh0PO1Al6viiXqO7mc33v/efI3sC4cLICobqpT+rgijwSUkWRqVqbeTybVwIagU5Jvi6Xi7rBh6qv79/nF5z9p+vXPfNHtX/OM5/7W5Wdf8ItoXW0D8O0A7KLTz34HgJ956eVfuen7v+G7XvyXf3vdv/jNv/yfz/3z6/8S0y1bfbDButmuUipuMjAKQ2NUbGGWBetOF8vMFNIfpG5H5bwEZCZdq51QJtbrDQAuT9cEg9SozC6TjZ3fSe9RyxCLyV5vKR3K6O/ufoF08NI4u1zxqdGdswxedKBgWYy9LmHteV8Rc6MuGxhU5qqYvHkxeDJ9VyhaQMb4I5IZH4oueOKYZr9CDpzJ1LjLCoWmUr1n8+6X5k/KKxN7W5Cvta4gwVUpRl1QMYkFRkdXMIInntTuhS3sp1My9ad7hoQo0UVrJl8WxsqkS6Kh6xUW8gTYIU2wrDJoI7Agaehb73xMMZwNujx0svZxbPwseKzvAusMuVMlY/1qnBph08AyQ5dFSc56CRHyHu8LhNYxGhp/rhwKevMVzXq+6ujizFYXH1p+JiywRAmn0lEPqMRskXLRILKvDttoG0NrU7cZ8ZAJZa+jjC3T90XbVhNvcRzubfMBzHQCeZcwa7wsmABMyG0oxPJmy7+FE57ShGRZihxhB4WZssP0b1WJojvpnRV+lu8kv0WrWrhCTPPZbNy+Y+fk9KNPeSsAHgLzeU8XNTP/reuu27RpaflnX//et/+Th+zA1vnmYW22Ols+acexD5+36wk/8RHgUbSlol8oRH/cXEoI+3eNgV45P7UjGLF+KeEYgUz2U2YTalwilercVHwWPhcBHl7bR1HRVOwMPYBiF73DLB8QyEVHAUdDO7loWAF8C2BxaIzeK7VwNVaZgnmYYfXQ+njOmWdMTz3p5D9fW1t7wfo4Xvvg6up/PH3Xroc2NPCluR5Znk7/yer6+mu+72f+ww/9xTvf9vy77rl7fWXzlqXRR/jA7er1ikBPy6LkYtu3nPYIPo/h5Qw8QtAz+Y5nR73cO+Wm4IKzn0YsdzRX1Kqp4bcSsB2wyYDVRx/FZZdePvm33/vP37T72c/9EID/ZmZ3BJm/9aVgZr0+c999T9y2adPrX/zUy//z+aecNr31k5/0ydbtmGNsYU4s5/L0BkDR0HSl7Z13AxpvNUsRwSar0419jJJoL3SYC86WAVEFaxlAzsua/l4IIVRBzGDHRwcPVaLjzPuR4D1Gi5J1DRZcvkHOpCZaNdAozjyrsewf6fgDKEb9ngWsmjyy2UX80oxYmQVh/uelP+GNpyscwt6HCEjHufu4PhttGCY+jmJ9OukWECgXj0hY75oehijSGgYMWDt0yJ51waX4f37gx/70Oede9K8wm51lZsSORwDoaO24DgF4tbu/5sVfceWLfuJX/8vv/Nqf/f5x62ajTafDyKW9owYIBtZkWC4HYwLXz2AsxmzUF+pQ8j7nkqu+Almxzn7IY9er5lDbGjuNL0WEil6mzxg0Fs3K9kq0UWOUutS3noKXdpFV8PxvFgjlOwzdsnMtd+bfHa0LszmstuvvaNQTga3wEDqIJf5T7KUN1QsfUwdROK7iRXw0mMGaX/D5OBsnk+mEKzNSosX2Kn8rHZRTDkbKU3EhuAeWGQErRUYs6EraomZEO/ssfYuowFZiQ6XYypiIbdW1m/4Dq8G8kRsO75bkkwlpO4AXA6eKZUHDgSwAyXYywUzdEClivV5KT34VXQwYKbIixgXPSkGFW2Ea+wbxtcNe4kABaqunG9UEphDqMNkdcTtHnm0WLepsjsBTZ/MXprx6GlJwkh+xo1/VVVhC+cdhLYbsL93tqIkFpDjT/lFxjLRbyU8rfhTcM+vypjaMoJiic878cozpf/p60iAsViJXHR4hQqxjMaf4Niu46GWcIJ3F9o3iKPF5xTsKwfPz7kFyY0FuHcmlGJDCK607MNgEa4ceGS+44PLJOSed+Udmtn/P3r3LX2hGz93tiquvmP3jK65/+413fujH733wc47Nk8HHOZ7zpMu3ATh4kdmau3dsfLxf3Smjmr4FUoCO/l00ca9AcGPZt/1VlNf7//QW5Yj9cxudDJBLBjoMKBcDYvaf0/MJzgC0mb5fYJYOUkPhEEYASwZsG+ETb2cRTYGM9AL0HXnoyNA8kI2OpS2b7aF9j+Luz95zyvLy8m2HDxz4lsl8/t/uvPPOw6eeeuoMRx7OF+OaA8Cr3ve+6eU7dux69NFHT33lj/277/7Fa1/9Gz/7u7/+4k8/+MB8afPmyUyA25zb6BuXTHq8mDaBGOBadnKc/GuBm2nfOZ0NQYZABSCda/STRe10YDyVDNbogDkmGHD40X3jC698/vAj3/k9P/qSp17+uvsefvjlbrYUa7yPvO75i3PZ7bffPllZWTlheTq9aMumTX985333nnX//v1LPh/XxvkMXA7ntZir4KU4G1azmRRQwQOFU5tzSXMDx6FzmLlP0xJzzYCxJB7kdX2BbLf8o3f0NeEzfmnFiZtj1FpD03djJLRw62Zt6hI5OlWvTr04FliWjxQoGlCO7QEYv3Bs4YBUkPFS/Y3+tAxJLzNP8dSx8ztHYhIDUJtMMJhhnLvPxtl8fb4OzOcD1scB8xFbpiu2edPK5OED+zHZtAmmNaNkVZk9MwfmaHoy5Njo4A4/8sD605/y9MO/8m9+8hefcsqZv2Fmd2DPnru820CjeW3V8q6//vqJmc0N+IvR/YeOPWbXq675w1/ZNFmauo/zxpYBbZbAiwJUujoH33Rz4FkSXQRCDcmAr9TeAfEu7D+cu/FAEuMJi4bpMLTnRi8Y0QhoCxQ8dcaQC1j4t+jnqYxHugZw1cOim6kUy+eVGyp2dbpCW+GfWplHW4J0scSGwoJso7jEccR8PgLjiHxZuUuH1Oco1mcRLpprXaSHa6csRr8GGCYqaGCEr62vzse1NQA+xdoalm3Jjt6xY/K5/Y9isnlzx6NaaOJ40suOsk3N6nAEstfQEUfMSBVZV9wJ6pvv4OhMn3FszpUrQ0zhIQtPbNxFYyleFBkF5RkTFH6GiyyF7tKOFdyKeIAzt7EbMYpVnj0ywPfAMfoM5/NpZ8ZOJFMoUWjEpIwTV5sA9F456fRC8miO9noq8tjDtJLXJYQrNsB2Ei/zdwenUnMsvS5grGUQFkEpkeAr/Wd1UOwieCc5Wr5HU60WJWJfXgfC7KvqFGVOfdOQ6P+iQaoZIPtsfRqlvZAEU4ksdQg9L5IHiOcaj8dyc/usyaqeq5X6nMkgZceEc5TOUbdjuWdqvLYPcMbXAi8cA+AxruLzW8Erfav6Fx5GwUm6Xtr1BT0WDyD+pJzqlUK1sLHBBtg4s9O2nzi75LSL5gBw9e7d4zX4/Ne1wPCWa94yO3T1+nPXbfWFq488NB92HGUnHXeK79p69H8HsL7nuj2PeULp4/UqCaEsLj8yyPiVsIWHk9Dc0gGkuxUAqWKKdPQERhkWT2YCpGTtPkddqVPpqn+oemx0OIDVzAQ58a39FcRpfddXEN0MWBphWwCsGPxQmJ3FMkCeLhV76eryBAewtLQ8ue/++/39H73pW+68/97fOO3YE/5wx9at59sxx9y1d+/e5auuumpWqrh1dF+sax3AfXv27HnV9ddfP1x//fXfduc997z+V//k2mcedswHwySQpM1O0am7a7kIZcsyfbtH3jYMvK/VOzyXxgDdd3XvQAWXAqsCJY/22epkmODwgUfn55xzDv7rD/7IX1182lnv+R9vfOPd/+glL/m5LwHvNlx79u5dvuaqqw67+3EATvvQbbfd+mP//f/9nvd/4MZxurJpOptHwjWg7XvjkJGOOJcsU1eK4wX9bQkeqlpEoEDQNaTTkeuXI8rAScGH1eCoOM3Kb2RiqXDJkj4mES1wG2RHVvWIIrOcweBPBSQx9jz4w9QXZJ99wNZFJpaBRE1UM7lr4R3HSR5wSVBqFTOdUTydDDxAaICP8/l8PmJ9nAGrhw2rq8B0eTj6mOOmx+7YiWM3bcNJxx4/O+P4E/ddfPYTVw/P1j/022947Yvf9dH3+/LmrcM4zrMCWmcoYtbcHPC5Y2wkY2kcsHrgwfmTL7hw6T9+zw+98SmnnLl5bbb2is98xn/y5JNxqLFVSrHBUbn7fO/evcOLXv7y0w4cOvD1/273P/u6T91zx+t+469ft7xp245hnM3Mh5DnODZdGRdnTlxVFYD5qonvOeucqTuj10x8vdNfioVN0fvHk35o/6PA+qyJcu4t+xtHxonNqJQEIg/LYaN1mWT1XxHAtq8KGvXTEqmgJXzsvtfzlVELNwwT4Wka6zh2UbV0odoBx4CYnhuBYWk+nS4PPo7NisJmmzBCZjHmIQ1OdNN8bBgwiWIGhvZykrmPGOfrwPo6cHANwGRy3EmnTE/ZeTQ2jwPOP/3c+aWnX/DQ0dt3Xffn77v+5X/4tj9dWVrZYhg9ChiZRACeNQXPz2T7QOpFsH5Ew34t/exk2P7FmpMSQDe/owCc+xvhbW+3AxjHtncxBp9YWOdvUv0QNGgmvCz1deTeQcUFxLmgzqqeI3Wf+iUoisA2f226bwNlxWTZ5BOVIFjybzBEQcuivVJopQ828ikJNgXzkRDoHcPognS69NFGiaMeapSQvLAElRwzh3medjkgtxilriNOW6WkI3aLGCP9lmmfghWsEPflC13yS3AJ3qIkjk6PmvqJ4Jv8nWRmvV5y25PFPV66khqW2Vbw/pARV2QEzcU9lgU8nAVk7FqKW95kq/dwStaMyXmyhWWssQFehtSRTu+LbOReTV613aD9E/ASy1sSlPAJxsaFv534U5AdD0FILr6o6BjiO/EbaAckjgZzH7Fl63Szbf340Vj6tT179vyd9vtde+1VAIDX3fS22QfvvNmxdSvGQ4/On/bUKyZPP+3JHzXYfO99e5e+UDuPt6skhFSkBFscQWGKCusv6JNElq4GGkDV2vQEK1SjUEPEUAFmTSQWNSmX2bBaQdXrHXbVrwRp7/qtmAFz+NSBFYNtM/jDCcR5E/LvESXoBNZma1jetNVe++Y34xO3fOJ7L3vyk2982fOvOP6g+9oWs7eSL1/Kq8wozB965JGv+i//8gffcf+j+57y26/9o+mWo46ezGYzBay5pCoS/JiVYkXTOt4M6STIN/7B2Sk3uI3o9gs4skKaa3nCSafBu7OLcC4jMF89ODv5hJOn//zrv/31F5921mtXZ7NXfNeLX/xPvst9AsC/VOu847hhXHPVVWv73S/5/ev/+tve85EbX/zuGz9w0Uc/9SmM7j5gY22blyrPi3objgNAN1FjYYO5XI8OWWUP0OnQoSGKFB67yxsr+4o3f4oCd2QJkj8YRDSbayLlyDLxz+UolZbWSCYTxWbVgYMvac4lZu2nFechrQin35VErdCPCFo8HvKKAQQWeqDoc8hlS4NFQD0O7nDM4Ti8emiOtTXH3CdLW7ZNtkyXcfT2XTju+BPwxNPPxtHLWz939M5df/mCZzxn6cRdx1x/9gknvA7ASwH8KIBPbNm8aemT99555QOrh8dhaWlor/1wCTnZ5kVGAEbHbJyNK8tLk5c9/cpbX3Dh037v7gc/d9cpx5zwjr/rkdexWX40s0/dcMMN/+iyyy47eOMdt77+httv/eYP3n7LfGnT5gmXaddcyQEFamCAxotw3eEdg86CedlSYnYIK18dkVjZhjwCs5ldfvZFOGHHMVhdW5utLK9Mp8PEVjZvwmQYYMOAYTJp9A1NxxnodYEIMlhqn/AO4htAonPVCG/28gzpj/FhBM90prSs/A4H5vM59j3yyIzvJXV3LK+sTLdu2zqxoR1KBb6gvASSLelpRYm19TXs3/eoz320T9x71+ST99yJyWQJNsZrRKjnbGJMmlmQHPSzxW7rs/VxNlsH5muO5eXpps3bJ0ctb8P2bSs46aQn4JIzn4QTNx+NlenS773wsucMO7Zt//mzdh57J4BnAfj2c844Z/eNd370dTff/ilsWdlsa0fiRY0LaG+KmosSGRAvKUifXwJlmTkTBvkV09JWMU09MqGIlUGR9NRld+YD3ZXocjmvjDWcvPREuk6rJW4Dix5DsYMueFASk5grRKbNEZaiT1A9F6+YusmVp1SC9rkiEvJR+stiW5oinauSW7ZXMoO6BsXGsUB7rNbKN09I5Fpxws8cZaUW+8jfNbPEBIr9GTniHTO6BJeUDuU1NwXIZF7iFbq2RUNtW6O3Qip1wFHZXguuKpBb7SnsI5foSBfqgWIcjxJipXVBiyeVfG2VIwwbLNq1oqyKH8K3QLmEv2ZKVdmL721qaqXzTiwx7GKr4g/KA7176t4+AMs4E0ieUtZ6mspaGyLrqWP0+1E2mo/YumUTnnLGRY8A+K8/9H/98MnXXHPNt7r7kpmt4wiXu9u1H/nIZK/v9b0feMN/uvvez9jSdLPPV9cm5+06/ZFzjz7lJhh8t+/+vPsQH4/XxhnCHslD2YtWHSksqcJX0Fm0qTYXbcg+q6F6Kkp2n1UToFYh2V5RcHmLBDlR4+33HhLKX7IHgyKWweBTh2+PLd0WU+0KgnI6XA6FJ0OODnPH0tIUH7z9Nr/prjsvefMNf3vJH/zpn3z3//ir1//Fd774Zd8EwG6//faVM8888+G/a9D397l4mpKZ+S333//nRwFv/Y6XfNXh99360X930yc+vj5d2bTUlo8VUCW6BbozkJJDJa8YWAcQVcIHRYvkbpFnyJxBV+4FyWQ7A6/Wxmjm66urw8XnXnD3D+3+1t81s70AfuOLyavHuCx4uPTad7z1N777//PD33jj7bdtvf3uuzBfn/vy8ia3laVBgYaqlqUBBFAz4DGqfeiMd2lBVuE0fW59sgxTgbyJSJ4KPHig0sAlTWPMvBksJ3pq0OJAvuLBBeRJK9t3VbIpMw869Z2FpVmOQbOdtejgPVbUar6Ho+OsJFch1PcdIgIH7aVU0JNtGvsk1kSCsT5bm/ls1bG+BtjSEuYjtm7ahNOfcPr0rCecjpO3Hw0b7YYnn3OBX3nZM2371s2vPufYkz4L4K0AXjyfr58ynS6/CgA+fe+9N+7YvvlfHFid33n01m2vXlpeNp+vuU2GFkGNY5tyGL1U6a3tGwQwjK3iunr4wPjUiy8dv+4FL/0ZM/ujRvpjv1j3MRTWoxB0aPfu3ZOnnHbOf/7mZ734BR/68I07hukmn8/nxuAgWJswXDWHWKwCW7lZvAZUJPOwczdhPEKGcujx+TA6htF8ff2gv/AZL3jwv//La37ppOOOvX+c+fHz2exeG4Z9k+Xl2x1YryXaJcRbhMt1RI9/hOtIz/JzrK9HW0vxgX60Z/Sfpe6LGdZtiiWfzw6tALjSzGw+n/vmlRU7PJvdgcnko8BsmC5tHo/UfzRlAHxtdXbMdOoXH1xdPfTa91zn/+0Nv/P/3PTxjy1PpkvDOLhpGTpn4hztgC0zzGazmc/WgdkMcB+GlU3DMAJH7dg2OfrEU/GU856Eybo/sn3bro886/xL1i447azJ0tL0xy897fwZgAMATgaw3czeCwCf/Mwn33fysU94xtFbt1+8NExWsTRsxnQKs1liUSlyoGAHg7rEH5TA2IsdlxusYJIC7LBf91boIvoElnILmzCB+hUEaWYmfL8bIaoqL4NxL/ULL2OElqJzVlFxBYvcXu2lILvgj9qfKFrrAgol4GXswStpSinuFcQ040xojBlpe53tCtfpfKu39j5yChuvyxtFgYqEQLciw5p0Ou8XbJb4i3rkLyDTQY/C2V15AsaWRX/q1dWaTCEK+EqEuhedPJHf1H7jlqRSv7qcydMXtTZydQJXpCl+KfrFEKiFT61YwXf48YssXpbZScqh4OxogEnviLPJTI/tPkqo3cEDgsS9sndcNFVR0PakdRmN5Wcey+KtTwyL6Xn5b8pFDlsFYYU3MSjqd6ealnEK/zbxvbWzPl/FqTtOxtNOfdInMGI6n/vvxd2PmcxFnL0GAD/46v+47fDhdWz2Jfetx05XfOXDAJ5436MPTc3s+jhh9P+8Q2UKmurvxXprva/D/wwLBV2ccKqgWJ2GpoD5hAEe1VJVBC3fE51FrBaYdrlTmQancmn5B8skwp+aNEIG3Y/eBIg+AtjpGDGHjeX4/zF5Q5qrURigpU2btm01DIPf9fBD4+1/c53dcPMtL/vz6998/a/83//+PWecccb79uzZ83tfKqVjknnescfuA7DP3X/9qiue/y8+dsvHd8LNbWxnbDMBaE4ygaS9EoCOEg2wgRRILQA4gbNPcuqMg5byRmDj5J2VNoGGgsHTtdUDs5NOOnnpW1/00usBnORtVnBiZmtfdIaB5Lmh2cfOf/wzP/Wb7/rYjS+/5Y7bsLSyeb5p87bBV0abz2c8bwjkW3q+aIffgculCOKBdJbg2jlhfm79Hhn3WGLIO6sDQ7MByYCyicAJxYaSNkhePNKdsu+2QsLgcaD8wMDJWYU03VOdcxcEtI4E6MQFOW0AHseWstKfK4HGEhRo5NojkTOWKIltoFIEcQ6HTSdYX1917Fu1Y084bnr0jqNw/imnwxwPnXvaWfOLTzvnwLYtm37pKU+++NGzd55w92D2Z4VHm+6///7TjzvuuLt+4Q1v+L1nH3/8uHfv3snu3btHM7uRfPrzv71uZTbO26FNpMkGuM8TK7kn2yz2HzummPjadGl6wclnPPQVp577yCOPPHLejh0/9wl8gdPSjnTR5nfv3g0ze+9r3v3mm0849sSv+NxDD82Xh8nEJ4Yx+h1KQAYkboMyRk3AUQ55STmEJMP+HT5G0BuBiZx4yGlwx2x9bX7sCSdNn/vUp//Jmced8OTV+frXbpkuveLQ+vonB/f7N5l97O877v9/Xo8ePHjaZBhs4j4uT6cDxvHDK8vLN/5dn7///vt3bN+140e2LC096Qe/6ltO/KnX/fqL/v0Dv/Q1B1dX5zCbtADW2yrUGTCYY3318Dh/5NFh23HHTLcffTROPeZEnLDrGGCY3Py8S79yy1Gbtn34jBNPvuHZT7rs0RXgDWjiepmZ/Wzt+5U3vPLmS3Ep9uzZM+zevXt69iln37m+vv62wXC5j6PbMMCnjM4Qez1N+qxAruCSdF+ze9zdyVmdjJjbIcXtvjwgCmWWhQkVMikYx7bC1mPGpTmlxCIz+MgXYCzEKN6oaDMvrqJkXQ5ZV2KY9TaQEOfdTGY+m0F+Ylu7R5hqQy6xr8zz3qbyG46Lxe24WfGRd76X9uiFn15OXMr9hCyoeYyqGrtGAb6Ky+BRDDbFZxxTkRJcCSNpMIJz+KQEcrKPa20UY2CkCOQvpWIRM3DmScl+tJVxSl3NUnUL0MoayiXUZwxHwxlA+e7oo8M++T76siF1Cq7XD+nqPqDPJd+SZ/KPio9N8miF1CbjkbHWooOUX+X3OXBNaki21ItRSz5zeWsJZkhL6ZOxgsxAt1rSo5U7pTkrNsjbZKO5DNXaet/2KN8+RT1bGjA7fGg88wnnDCcd+4RfXl1ffei2R/bf0brfGE9z0uWgHzx1/ZDv2bJ5yx//o9/8kdMP7T88bl3eOhy1fTuefu7FDwB4zvJkabWK+f+UKxNCq6KnKnA2rFaB2/c+eNeQ3g+kiKE2OMgINcW/oB8ZRVawzZpF6ldrq76eLwFU7inbZoTjjnxJKtvr7ix0CD6A2Qy+awoseSyhyCUemjFrDEhaAmSahcSsjbstraxMVrZtwWcf3Tf/n39z3TM2LW16xk/9q3/976+++urhJd/7kpVnnfasQ0cS0hfrik2yt7/nIx/81b1vetP/9ZFP3jKuTCeTOQzOJRgBlGRLLluI0SWzBbx17EoQalIoP11nElNSlHpCQYPgYRwxdWBtbbZ09slPePi7XvhVT/jcQw/95xOOPnruWaL6ol8EDnff8n+96pfv+r2/fN0mh823bNk+jON8Mput0UsVyjmkKGqo5Ez9SNYxQG5P8bCXHDnlQJ2nSNSHCC33yxnHDUwgFZjJVTcQ38C+LAQYzykJPa6loUGybsngEG2NqA67Bi3xHH9Z5Av4p0XxtOpTKGEpIljRLVZ/24mstd0yqwqHjY6JGVYPHsRJxx5v3/dtVx0ebP5bF5x53tpzL37GePzOnT8J4CBa8nUBgE+a2aHn7Xne9C14y7j7o7vNzA4D+HhUDOksgiwfrr7+6uGaK6+Zje6O2QjMRmAS9DMIKLGWZBY8nM/Wx2N3HjU5ccexrwZw2tq4dr/ZNbe4X12qUH+/68d+/udXfv/3f//yj372jj8+fdexX3HPp++1YdMmzN2BSQQilrIH0GIwywBsAXzTTxRH3mRQCn7Gx0wVdmmqoe3RXB6wtLSCbcubx9lsXFuZLi2Z2e9wrO5u11577Rd6484X5TruuONs+xXbDQAevf5Rv+KKK/z666+3++67z88666wBlwJ4X9wcv992223yQFddddW4fcuW31tsNwoGfu21137+oGL3bhxrtg/A89/5zjs3v/Trvmbysbs/8dM7t2/7mkfnhzCZLocPG4FxgE0d6wcP4ZQTThr+xff8CMZxfO3Rxx1993MvfubSE3Ycd8Ou5U0DgE+tTJfeuDpb/6cP33PPmzaddNLt777l3TtO2HnC7+3evXuye/duYPdu4NprcdVlV2ny8uqrrx7d3ebz+XZ3b3n82P61wF4RANpXYYvDgoKH7yD21XBBeJIqB/6p2cP2AtwMsgFk8dZyDxMAFdaiYxa/8qCZxMam2y7/z37T65ciVwTVnHExmN4/mMF3HwovvkqEITPJVwLDAKZbJRFB9tj8h/xFBPFDjFmzXmyUWMjVFx4bFZQEjDkW8SdO1YzHdFiOEqiUlmDY6PPJtIwLM37kZ0wCis93wxBL5bPyVJIgxXzjgnsK36LZy5RaJpupQ2X6WRMCCyLR/W1pJWdJh9JGdBszYhnb8EuRIDqs3iQfFd9xf6Vle2khuTRV2AsOi3ZFXwKF1mpHvEfG4SWGaF8MhTdlLtfSlzpy1jMLeIzTELJ0ya6u6urZWsov4klcgxf5pDItOrj2WBlDmljEG45xAsDX8MTjzsATdxx/tJm9c+/evZ/3JWLuPhw4cGC2PJ0++SP33nrn5/bff4wPWD80O2xPO+FiP3nXCT8DYPrgve99bxvykd9l+Hi9pp/3WwKB1CcNYTEAoODrVLTApqoKARFIpZR6LySBG8gx2MDZlfgscTQxGii05exXwkSppLECUQBeRc1xgM9H+LYRwxYHHp4ASwH6vIdxk1f+kDgu4YOMaVyfY7K8NBlWVua/85pr/dSTTv7Jn/r+H7jz3O3n3rVnz57rL7zwQrvqqqu+qErIBOf7n/j9Kz9y4N/esm3Llv/4wsufbh/+8I3DZNdRmM/XIaMsCJPrymu1DwIu0ImM6HgJOT7KMzSI3oQzO9SZqEblqsKYmYBjNp+PW3bsHL7++S/+wAC8c3k6/XEA34KN6vHF4tVw7bXXmrtv+unffNXv/Pz/+I1NPthsZTKZzg8dBqZtVz5BF+RZLYCUim/VOn6q3QKqwpkcqIIaA2oi5BHAaL9JV9llvxHku7eKibESmMbSllyxmpwOPiE6Bd2lrFrKI0aByNDsT1FCeNEC5mW2z51OhgmgCyNcyUjFCX2QQY+V92VGUlNnQJWMRwV4GAGfrY1Hb9s2/MR3/sDb/8XXfvMBAF8P4E+xtvarZvZwEo+bAOC6666bXnnllTMAuBbXImaMbbHyGLY13vrpT59ytV/9ba956189PBkNtjqHTVIt5PBhwCw+sex17fDh8agTTprsW1v9CwDPW17e/A0AngO+h+UfcF168smr+w8d+sPzTjnzR1dWth7COG6ejIb5fIwTbqszz+AYRS+oL/LKTNYrIOhH4jJnuKsfJ46Mg2EyLNmD+x72P7vhuvP+1Vd/228DWD98eP1lmzYtvf7OO+/cbGaH8A+YHf1iXiHbI9JQT3wNG+RiUjJ1/PsEE8ToZz3rtMMA/H/82Petf+iOW/Dp+z+LYWkTRozgUf8OjFu2bR1+4jt+4Obvf+HurwPwXAAnrq+v29LS0m898Oij59730EOPrM1nZma/Hu0P1pLOfQBw7bXXPiYtZuaz2WwEgLnP4bMZMJs3vNEesj4eEPQpkubASuCeowXD2cXVEcJFBqIW/A07V72ICZp6ZRLCQNoVR2ca1PoahlpjcTiGWJo+ylYZtNbQlaR7wSZbaMmIVyWQJ6ZD480ksI2Nr68YOSlWOMT4wQt2eltBQwxBYi39KpO8GknptEm2bm3sNPp8lQQScwHFZCh8acMY0+7LjJIKcp3lc1z5X8Zmi4mU835D+pwyFi+BngUxLC2r8FxlEH2REM3syo8H3wbX7VRqntzKZaMkjNuEdGhPiW1SM7Aoxfa7pafPhHlo8qe+klxf6BeNJp6Z3AEsTc/Qxci96Ch78kJDBV/3ZYpbHVHFgGYoKauwQd3HsemifqEf70LYRlk2t06aK1oUfYtCDuU2H2fzTUcdPVnxyZsBvPmVN7xyafelux9ze0UU+Ydt27Z91t1//FP3f/qffuSeW315x5bh4MP3+7MvuNSefsoFW8zszbEK7f+4ayEhtO7Hhs8BKQFg/V6eha9VVObPEGYCf7sU0HpRVBojEJWyrFoJnCqp9AJsryot6YoApdmsS0kt0EdT5NR9c/hsBNYdvjzHuGvA5H4ASwxuSVAsgQsldjmSfpzmiKPoHeNoGOGT5eOOm//yq//An3Tmmd/77V/11c/1Lqv84l1cQnbiiScevm/fvh/YBtz8zIue/P7jTjr5aQ8d2D+3yWRSX9ehZE+GnzynE2+HAHqqhiGB0tBV8xKaPStQBLoAAa6Dz0TDME4nWFs9ND7jiU899FXPueJXAHxgbRzDl3xpKjcM+N/7sZte+sb3vfvrVlcPz1a2bZvOPZYoxYBtLA6HyS/owDLQkZ7GyQYKblTtzqVUubzFsoLtcnW8K9oLJ1heByVxKEIpiVh4Drofyo7LLdvseSwJpeBKMBHNIaFdDfdO0mJE8u8cJ5NVk10riGFAEfereBy9j5Z0e/m9vp806Y3RkXQzYGUJa4cenT/zKc8dXv7sF/7W7Z/5zPtPOPro7bfdf9tHLjrtogfrPgH3dtzR4r4945GDj3GN4zgCWBttNIxj2881RrBlGTq2VbFhFD6DJn4Ordn6wcN41hOffOH6+uwHBsOfPVZff9fLzOaP7N8/rExwxsrKZm+bzqoDB/iXHDK/KEWIRQ0CkEtB2UbPfuQJhiZnjtCu6H+ytrrq7/3ojVf8wC9d/ewXPfP5r73kzPMudvf3m9ln8b+QCP9dr0j6529497u3f+XFF188nU79of3777rpzvc+cPYJF281s8/d//D9T9+yZcvSocNt8cbmTdtx4OAjh83sfQvNtVm2PXuGG17+8sltt922wYt+vosYvWfPnsk111wz+85LXzD86bv+Eu++6QZgxbQnfTDD2sGD8wsvuWx44WVf+WtmdguAW9jOHvfhmh07tNzW43U8/5AtCSOabvrowKxht0+b1I3TRVoC72lv4UPiTg4wfrhwqsubkNhixCVAQMBER8VFL7Nd/NuLvhJnVDCj7yHDEysZgA/t1KJMmri0jnqsz1wNdLEA+kTIGRtEXN1mm6jWjORdg6v8YOIQpOvSwWEWsRYxnpjpgE5AR85ASQaOeI+MI18RETwY67iGLNrSx5UZxiH8XMKupxzDD5B4K9jcQgsGBSH1SDoyxgheUq9gulcRZ8hJRevAGyZwVsZswawNJQQPLKYPlH8ueowsbLl4yBinTIB4z+c2ThdvLGIiLc2ty5CN/riNeaS+g/gZOsJ7fYEPPArIYqUMYyvOxhJ7nTZHWsfEcAfaDG6RN22OGK4GKJNaiPFMANFWDBlnoBWYmOJCee4MFVC3lDE05E1M4BtXmr3PZ+t+wtHH2bPO/4qpmR2KFXCP6aObaGx0d9uysvnN//lNv/m6+w8+YtPlTb7t2GMnO5e2vgXA+27wG5ZwhFO8/0+4lBDmmuGUQ0ZABUU9f8hOa2hBDGPQ6/m8e1vOkJ2YqhHUQzoGbl5F6CBPcJOZSrFAVO5pX6jw1QoWnVj12Nb9pxnwMGvO0CeOyXGAf4pAPrKWUuLmAJtyHK8ud7jPsxoVNjoMk8lDDz4wf+O73/WV7v5NZvYafAmvSKL+AgDuuv/e/3DBaWf98Vs//H5b3rIZmDf6BjpWKwEgAQ6QKgiMAQhYVKlLAGvOO5MlJpqaOSoVYi5HIGyPhvlk69bJ5Rc++c6LTj71j7+UvAEAd1/6+B13POH800+/e88rf2nPO278wHzz5m02n4/AdGizKgGMbr7gBBpvnEurEOvjWSFmQWQgQAOcYeXz9cRcLmOx8Nu66IgQLrMu22FrjCUS10GHQKOlLE03xcENUuhw8KEHXo4LT1upv7j0RDOKEXRwqXi+4Bno3oNUnHhdEtp8lOe75egILd4qR4xBCZTQmMaABQwYVpbtwf378Ojqo8c+6cSTn/y5Rx46+ZilY97v7pNaXPj7Bs50QOefdtrdAH7+T9/95u+Ze3vdhCvoAHzIJWIYy8FTo2OYObA+A9yxf+3wPpgfPHh47aeji39wUuTutv/ggcPjfDywPl83LC21GW5D7F1MVbQAYC69JR7z1EGdMode32qBz2IjTmuiHDLB5Ufe5GQReA022P4Dh8Zfed3vLf3Je99y1QWnnnnVZWdf+K//9hM3/tpXnn/ZT6y1d3vaF3Ly/5Br7969kyuvvHI2wPDSZzzjdADPB2CbjzrqvScf9eJPADjO3Q+izb5t3by0WU5w885jH3b3j6NGqPzSbP9l11yjVZB79+4dYp/p32kMF154Ie+bn37syetYnQ22NoeN8zDJ5r8evO9+3HTnbccCwC/t3bvt61/ykpVTdux4CIBfHc7PzDYUNv7el3kkoxEnt4aRysPAHCBuAZbvWIMLQ+Sv0cYxAMIGrgnR7I3xJ3KSguhYpzfoc7ySnLGCCozyV4EXYwbziABzjDYVL1sLzptahx9kYhHtaqamYq3n8j/tb2QhtFGYGEq/wa02yIC5rthmYoocgeyxhNeBs/G7kh1iZLRRXoWQmWTGcHWWsyr4RgX2XB0Ucskn0q/VTJe8ak+lDsl/WHmTKDGG3o4VROqAIfWtLEOsvEL4aYtluNkl28nOjKtg5Hitx7d4eKGuEGOPs+VK4sbXhESdIdhdXutjqTOZ+IYcqJtlVgxBdp1ty9nDRshg0kgaDXQIi/QX0Nt9ZR85qcG+TPe7Vko39TS5YukiLHZGZBxQ5VNXP5HX5Bs1g1gg0YuS9E9NvoaJDZjPDw2nbD0Gpx578u+6u1117bV/J4yNmcKd3/k/fuzwHLYV43w8edeJ0/OOO2u/mT183XXXTe3KL77P+XK4lBCO46jqRZ8qxXWEahU23GdFoby/ZcNzizDT+9Za4Wm3pVNJReyvCmGDWSydWBiN9hX03fIlre2zqACtBtDMAZwA+NYRdngCn1ih0HKDRFqM+tDozHiqCMZ4AbOvz2CDzd/z4Q9NXvfWtz5vPveX79v38DW7du26A4B/KQIhzxe4v/WFz3iGvfW97zLbuhXmMwCDlgRwhPVQGQ6Xw5PfRKmiCenihjgohDLzBXlbgFF3GTBMJ1g9fBjnnXm2vewrnvPGXwLwile+cumVr3jF7IvNFwadBz73uWOecPzx3wHg3pvu/vQFvnrYJ8vLU4c1+CSqF+xmACBmAAnShVndsmUFT9G/uOFI72H5E1Dlku+IzOpt+QBWaOoZqiApAiiXs610FkBe9Of820ofQb0qxerXNMYMVxjgVQItOwEWxlyCQ553XiqInD2tAUJdPisyYsybtm+ffOBjH8Zrrv/Lnzjr2//Zq44/+tjjVvetPuH666//ZCSFesH7P/Ayd8fr33t9O110auSeKuA5TsDGdH3ujqWlFXv00X2Yz2dPW5oufWRlZfmXAXwl/hdmym5/+OGdJ27a9LpP3HvX/xxs/DksTd2XJiZFYjFGAQRSdCiOv4B4h6VW7qwOW+rf9FK6ugi77phMJsPSjp1+774Hxrs/dA+u/+C7jn/PbR/6d//+D3/xnJ/69n/1rbGZt1HxRTp4K2aE5+7+3N/96z/957/wut994QOPPPgQ3CbT6eT7J4OtjHOfTYbJ5gOHDty/Pi871s0xnS5Ntm7a/NPLw8SHYWLDxLBj8/b5acedPPmDN/7Zf3/BFc+//filLR9aGqZv5/L/xcLDY11XXXXV/NJXvGIJwIfvvueeV+84+tjvfHT/odl09Cnxc2q29MlbP47/9upX/ps3feyGe1/wxEvfAWB29fXXP3L1FVf8g2YDF6855q0oy8QhEpC02/K2Svo6I/Z50Q0gN94FIqhYSP8B/Z1+lf1ZzKyhu7MFkHEIFRj01p7qVXA7MK4jT6NhUdcBHnBC3EedXwKPRci+jAkwCyF5mS/cK7IqHzirxO+q2Udgj0i+iwtV0qgAO9uu23OS8vADsQSVX3ppzN3jSOwFe1+IwTr+9pUleXcllpa3VFksDqRyjhhOH+uQm4s+i+bUIgGsG3NyAfDR0A+qjMLKvRJ99e3pFAeOr28heVBceP22/aml37q4NHbxfml+F/IkA5WAZzBQV9eCK5Jq3CJFqTOYdVKlFOezt7RW/S496K2zsiKLGENpJeOVsehYJ3npZR9FcKXdZDIAs3U7/5Rz/Wknnvt6M/M9vucL+u8b3KeXArPPHX743z44e/Rox3x9PmJ6yraj/cIznniduw/X4u+WWD4er1wy6k3UXIaQylACyFhqWSskqLd3QSDSSKVsqTLWfUYIDaP1XgUBK+v+TbMz/E7T0mq8jzkTq8of9YbOtMtDh5pjgI8YdwB2LOB3OGxaAiFf6KSgXq5VL6qu0orD5nNsXlpZuvVTn8LNt9/+oq977nOvX5vPn2Zmn4o1zF/0ZZFmNtuzZ89wzTXX3P/Hf/PmXz/1tDP+6afvu2e2PJlM3ca2PI8zW0daJSdb9QA9ocgR+KsFPQGOtVLM3+nkPJaytDanGHw2jnbmiSff8dLLnvEr999//ym/+Iu/+NkvNj+iPweArccff6+Z/fRbPnjDP77zvnsmvry0XmuvVocmpxOObCFHrUsicrSeR10X9MwiX69HtD16Cj1iif+ylOLnaiU1YyHLpTz6enFpywbGpP4a3YHlrUqQs2rewTtpzHWrYkkjg0Flzt4z6FGyMrTqfvMhLt55lUSJpERucVbjgDbVtWkZP/27v7r9bR963w9/3XNf+N5//JKvfeaVV1758SOM/O9/7Wl69Ia/fUvT42EIrPROpqoED+FYhwkAx/Km5eHBRx/BJ++87YUAfmN9fe0Tych/2PXez/z1wZec+pKf/PQ9d//sZx5+0IZNy/PZFJN2Sh1nLAN5I4CscwIMnFPekK5beaaNK6rrBmlItReJyJDv/4v1zqPPbZhMJ9PNy7DJxK+/8d3rt9xz17f8+1e/cvzxb/yef/S/PMtVrt3t0IHR3b/26j/6b//zla///ck9B/ZjaWnlWIwjxtkcY7xP3kdgsjTZBh52BCgwnK3P41cHRscUhimA444+7kcveMfrcPzKtsOvesuffPJlz7ryF06YbN33yCOPvHH33t379u7e+wVnC1/xikthZrNff8trJ2+99QPY9+A+DD7BnG8BdMfSsIzr3v22TQ889PDPv/QZz7vj26746p+75sorb7zmiNXcv/81aflg87v6Vw2LgWpjiqdyoAvIa/DuDqVemgnhM8Wfl5ihngVAu25/RnvdFo2IT0IuXvoppIVepp8G2wtE0ogc0LE5TGJLvzU+8dKW+OKWw+bX8gcomE5Qy8Cc8zJW8bUUVhV3lJ4drqWMOYNWZ2cKH5zs4qqSWM2AQcF6dUddjFSeU4JK2y4zWkF6tB3eg+JYDJksv6Ms4lHxjqtmUnQVYDwbBiSvnFhYkKv0BJ3s6jJY+WyDCo78qRfPl89qUZK8Ytjq2XqLX7MT2MBIImIMFoUhM8gCrqVcWIin+vD9wZQn4zPOwG8Mz9Kbp11RwMT/0EtOFlguo+VlklnxFUWWigqctJTxdG0Uni/AmNc23eLVZmZPOeWCdQDffO+D937wBDvh7V+o8PYz1141XnvVtf5H7/vLpTsf+qwNS8sYV1eHs487E2ftOOHXzGzcs2fP/08OM/vf8colo6MnoJRolQKqxtNXjeOLdPvxUTUBfuwJNkM+WxdSEPhybfaCasTzenlE7xfUnxeagaLwJL2r/vUdKZ4+ANi6wZcAnwLDyQa/s3WWpzkFCHptt2/Hy2Zt83htgA3AMGJiE5utr+Gjn7zlZAB3TJeWvqQnjbr78LnPfW7LD//oj37LzOyDl553/uyuT93mSzt2YM29nT7YCBVEwq0z+MB+tJmzKjv+lNcSQHRBIeK0MUfMQLpOOQWaaqzP1mfHH3fC0hnHnfTXAL5pumn5+VdfffWLo7miaF+86/te9aqpu/u/+41fxf0PPgBMp5ijHwPoDDzDIC1v6viWzlFO2VM/ubyiPxQG4gmnVbQXazCMscevfcUErH3fLc3wDFGUAAKiW8uCIgAa4uRe7W8o1cYcS/tj5Hs25MAHvYaiW7ot06IdmwqV/SQojQ1JZwmMyBQveMJ7GTC1/axoLy8v9CpocYPPgz9LE/z1269ff9cN7778Qzd/+Ldv+MRNuPTsC1/7yCOPTHft2vXg/+oSRRvarLqFzNwhnjf4SwZZOPL5Uit4+TD1d9184+Z1rP/VHZ+47cN79uwZ/lf2yr7pHW/y3a/Y/chfvP9dF9350Gd9umkJ83k0NwYTaXMKCNIZe+ine/UJpqAGnjpuqLpJ9c0/kg+hEUMJICKRHGcjMB9ty7ady3d/+q61P37XG7/thU99xkPu/suPHNz//F1bt/9SPeznH3Jde+21sKuu8lf9xR/+5M/+6e9MDozztc1bty21PXIjJsMk9XGwhofcvhDjBxxL89DJuQPjHBgd4wjcdf+98ztvv90Nw6Zr3/ZXFz738me+6qWXPPvmf/0N33vTtVdd+5DtuXqIJUuPSePdf3b3/ID7Ke+79YN/gNX5N07cloexmZAOAxodWzdtw4dv+ej6h+742OmfvP+OX/jQ3R9fejLO+/nrr7vervgizRR2e6E5WwLIwDMg5awCEvu1Bw9g8CC8FDdNsyPRI3K2qnkar5jGhGksgXjQ07olJjd6XV2bFFD90S7BthO3suhRMLWGN6JvBGxAt4UFWUCnz+BYiWkqtJPH0T4TQCYs6UPylT9MEBu7o6jCBCiA2oE8qZXJQNi7yYaB0a0lJM5l+JQnNAZEXBbiaZhLj09aqSb0RYVZWZD35IsvxneBDMHXah3CjAw8Cs9M+gf1yLEa8jRVz5FTxlUL5Xv5s87EWuevuKy04aVeQwwlUKjj8xyDTuI1sPTQ789r0hkUvcbpsENuISE9mQwWpRR/GUcnPwbyPD5j/FUiNslKiTkAbiUpLlq8B2JLQSyH5jP9Vo4SR6ZmCk8zbqeULR0Ix7hwDW5YW12dn3D8yZPjjzr+1QC+ebpp8zYAb7/++uttwwM5HP/BJ//glr2+d/Jj//O/br/34fuxCcuYT4HTjjr5DgAvuP+RR+4+dufOv/X/w94/yKu8FmeUvXX/5ActgxghXwQUCtyyYdP97R5nYxanNEoTCE/tb/Y7lG5r4OKeypadIW2CylwqeAq8va0Ka+8M7AGEf/B+DIAddNhhBwZvp40ePwCbAZvVKlIJn7xWwtKIekJNAZFPJhiXJsDSFPc8/MDaofX1lelk8iWrTnBp3Pajtj91eWnpVUdt2XLTBWefe++wvDwdB3MMBpuEjH3BcL3tL3If9XvjZSRHTCYCyrRs0htYNHijE3UtFfANOgPADGtrq5PNy5vW//HXfvPf3nrrrb/8gfseeHnsiUll+CJfH7/7bjez2a23345Dhw61Q2QiWM3RFX7yvyUY8NHSoTR0bN9JUQie4RCGohMwORQ6LiVe3pyPhbcuWxUA8H1yPCWs0BlyUQW/JKwiX449WjRvyZUxEEin0cx6kF40hxv0DpYUMcDRcx6BzBiHF5AnbQ9BJoBDc7JW+VteexIfCSP+v+z9d5xdxZE2jj/V55x7J89olCMSKKFAkshJAoPBGOPAyAZn7xrZ+67Xce21vbZGzjmvbcnrgL04zGByMFEiJ0mAkIQSEiigLE2eG87p+v3RXd19RxKI4Pfz/a3ftocZ3XtCd3V11VOhq9muV9sP+ZGtvMxsSrzL4fBZitr6ugQq1ov/+Lts8Y1tv06BBT1ZT+3Llaw+kubUoqYBX1jZpxQoUqAIoAhApMA5hTRRFNfU8HN7tg3949I7fjBr1iw96tJRETtB+Qr6wJxs27dv7OL5i8sPbVxzyfLN62f39xUyYoqckmdxUJj+sq10GNLY/MsYq+67QL4ivJyFJ6yzTDhHjHuHGQx/uTVFFDyDQSmge4qoiWqjletWZV/7439PA/AxzbobAObMmfO6rP1H1jzeiYy4mpMoK5QoK5cpSzPKMk1ZmlKWZZRlGelSSrqQUlooU1oqU1YqUVYsU1ZOSZdT0mlKOtOktSZmTUmci/ODm5KqQY0cqUTfuWRp9ulffnvqh3/6hVVPPb/+61i4UJ/04Q8nh5tXZo4WLlyoUSjcfcKYyTMao/wuWXEcOoBihWKOkQyuS6oGNepr7741++2d138PwOS5c+emrxnMyEoQK0WRdXb4jyCyQJxOLGDO31oJCuCPAa4cs5UhIiS94eA41IkWKw9EZgZqxvCYvdAaUu4LMQZh5YHTX/JGkfPygQXVzlBR8N5nw9MGyShnhBpIFMhS6VgFkBJQPECbBA4WX+uU7VDE6QJI1N6baFKz2kdfDL1E71g3O8ueTVmn8n4dQLggzdQRFO755p0C3QMnnYzfGXIGJwTTbjMlDB406sUrsDDAwBxEm2U8FGBDm9hPILtfziI2J1/Y9VAYx52b6PrGkGM9/BYIr3uFz8Q4FrEl8ot1pSNX5sVrO6EneRyspMCYnWtyx1SbPgBQZI1BOw6AXB0CGQfBOoJZOwXosjQcjpD7LZ+QH7NbHsIjsA5uydQK0IGf1yBo47BN+KbgHnNjRQ/kGkYgOA7R2OIDw5N2jFRxgVm7ilBK+7KJo4/BlJETtxfL5aE5FR0DAHPmzDmk3FuyZEnEzDR93HEXAvhEWRevOLBnH3JZhJEjRqNA+mcALtEqPcoR/x+wefHsE/UhsL5ij5ID/HATDgCVas0HfEOPUvhUeVwltStmHSE7eR3B/vsK4RoITH9JhSDhAcuErQAxiuXgXghgRZFBPcqg0YzB9QweBug0swKPMXCYFPSbxVMjyIt1pcCIFBBF5sfEEV8XsHO4JtGG6qT64XwuNwLA6ovPPnvF0UeNp/4s1VkcQbseGMpoJ/QraU4Bb4jQA/wsc3BxKC6cZ8/teeDgpuDvQkGde9xJ6WmTJ78wfPjw4XMnTCgw89/NWA5bHrBeOiuQ6GAuYZu+FQpDTwH5Tf7fwZ8G61DFVdIqPGKBF9WBIwsGQKHqC72FBH++XGWvA7VqV4RVqLJerKINhb1sKvfHybjYfDBSp40DeU8BKYII6kHRx4ACdpyyQirFj3iktVNQHhyRA6XCp1JtzY3c8hcToaQYxYRUPGIYrr3vTnXtA3eeNbp5dNfq1atfuxJwgNDTxOtBL9nYzZWkZTKiXF7t7e7Uf7nv1jPW794yb/7s+eXW9taEmUl4/yUMCWLmiJmps1A4qjaX+zAzT1p83e9/+PCyx3RVVW3EaRoYgdKCol7BjLi0MgFbIAcsQl0QOia8T4jdnLP9wnU6QFcWd/ln2oPXYd4f6Z4enXL59J6s/6HmusarlyxZEr+WiGnYIpVEmdak5cw2RUGE2fKMxSZyLCcy+xOqQgJYkfmJCBwTMjDKpKmUsKoe3hTFjfX6v2/5c/qJ33ztC3944IZvrVi8uDyndc5LOh8yndXUV1fXzJoyM5cVCh44KjIFrnIRkIuhI4LWrPINTfzn+2/Xf77/5v9g5vode/eeAgCvWmY6Kge63pkEds0P5ETy14kp5RH/wB95qAfdFTDSWZzB89l/FsJxf5/IPdFZIkWC9e/6FHRY7hevXYAn2AELK3GCSIgYAA7AHyKaIYvJH9Ni14XbsWwNtWCsFKwPI0rJ/bjzZO04Gb5vnrryoEo94Idn+yBGM0SG+98e0HgnAAC3RhihA1DAvvSlMuLmnuMoR0GGwgD6H5KGgdwMOYUH3D+w745MAS3Dy4M/K83pILLM/uKwKFEl6wd6SHRRWGArfKE17pyh58Y3gBcr7vHyEc4pFOAwS2gC+60rwu/so9uCFcw6sUdLuCMm5N/SJ6e0/M0Dp4bIv48GUiSEAcIxwEHT5P7wMoPJi1y/TuD6kkUAVBaNHTSsOHv01NX5JDmrvqr2KjtHBzHQMuZk7ty5aXeh7yMNVbW/7yx073hqy1qVJHmkWYbB1YNwzsQTa8ppuSVO4r9rht7/11ugLILJBzBwcQXOMccrhu9Dr0IlrKiYR3eVtf5lbZFncrYv8phDvMwEiSyCyRZksOKBbTVHeTEzpGKSS6mTBTTAA2Je56N5Pq/degtTAN0KBOMd1MSgcQqItNsHI8BeKWX2W4hhFAB4r8D8u4lkX0ZkjzMwi+D/xuEnRJQR0R4i2nP2tJnfOOukWR1cLLBSMXsDwURyyAoiClIFnefLilHNNnoY+Gacl07m0lYjM9NIji6ORhJp0oxSf1/a3DwEMydP+SuAqLGxccOhQvjLli07rKf91bQ59ndTQxPiKIGL6LgfG/G2MkfB1hNyHwldZK1oGyhi9x1ZbztbQ4u099rZJwCAj8aigmuccgwVv/PmgkGszZEY7G8x02DBjLf4ncCWP0S3mKlgaK1tQTpywMR4ho1RJoDJTK8onwEOugHC3q0tGYdd59o5SwLYKYsiUGi2GxIzsanuAonMRLDlUREvFBKRzJpDTIir89H+jj3ZExtXnQLg2NbWVr106dJXtQRb1rQQMysOZU6wUcalWAb3GKo4OAhdLqOmvon+9tC95W/++Ve/3d69/8qF8xaWbGTc1Kw7TDqrvSYjIjRVV29sqqv7xdf/vPih6x+9d0JckycmTSAy1faEphzwEQd8ZDW14Qc/Tz5iEkQHSIYqhNYwkQYfOQI8m0n6nbyPwKY/WujDyCJAJwDnE2zbuzN/9V23ETOrpa9mYg7TUvHyZw71BXqIrXEqBrCG0gzl5KG2Mk8GRTaCZpyHFClQrIBEIY0YHLOqGTE8Xvr0Y+Vv/fXXn/vW9Yu/ef/C+9IFCxYc6hxgZmYqp9lHAFx8/KTpRUUaZc5M6qqN1IGMEQplIupxEke79+7g9bu3vgXAadVxvK+N28wG1VfTosiuPXJrzywribzZzgovOINBtIJtTnWz0/UVThxL98qMGnkB+2wCWDnpZwhaov7ynsB5FQg2T1jIVFfOt2NIgpNfrEXGGX41p8qwjdLAyTqWPeHBmgmfLePy1dTZjyXA3qEzlODTYYWOxolt5au7lh3+kP+SBenikxJdpd2Qzfo0fVMuei9HIjjbJCwopEWue5zncgCc3hK5YXUkS3qrvNdGPjmcIzidyFDO+K5Q8+ylu++cmF6WBuCDAk/+n1Yas/ApDWQLOwdeZzgHMMm4jAxwqZIEm0EjUyEBBm10PpuMFPM6CUeQN4IDWeuicGBvBAmOhZe/0jRJRNfK7LBovxtxMHeWzlrLPNo5sGs2PCpC9gj6Pfuezj692c+pwz2hIe+iokG/bPSRg4lxzi2ZKBbd78chL2EEtAdDK83I5aIJg8YV6nNVfyCiDiwIPNUD2ix7hEQ/yndBqVte2L/t1P1ZZy1iZP1ZL8YPHonZ42aO0KxbVb7hQetE+4dLFwUCg9D5id0Em9/iASAeaEoJH3im9lqfXBqh9zTbML1dkyoEaRYYKSLB4AFahVMEZvFbwME27ZQGMg+7YIp4CM3iIQc4OGB+57FzXfGLgDSBDjBUageWMng4gYcqqwgOVjiyAd+F1QNl6kZUYQCY/lTnqxEnylR3+7/QmJnOXbAgJqJHT5oyZVPdoEGxLpU0pRmQaY+RrNCX+T0kHBWaiSCTMwWhnXBwfCSgkmXxi4cKQKYRZxrc28cnzjghvfLiNz9FRLe3rVqVO1QK1OzZs8uvZb/XQW3OHADAuKFDUVVVZQSeM/DDCbQqkX1moGdnK15FObrfIvbhiQnY4xwCQQ0OnkV+Twz7SWD20krsa3OtSFv/PAccLFjwfhXtBa19hoUOVmC7oAn8BQIYlP2hAA9T4CUVmrBzjIRqz9wTAMLw326dWp5R7JUWkSvWYld6sJ4txYIUZvG0OzBgH0EWWDMyUG0NPbL6Kf3kpvV1RKTnzp37qhZge3t7RkRaMxNrbY0J60TRMIzCAFnD1xkbmm06q5mLcjmlfG1D/Lsb/oJP/eQr/7NkzSPvYuZ8d/eBOQBo444dw9ra2iLrDImXLFkSP7n5yabN27dP3bNnz8nMXMfMx3/+tz966nvX/vfQHp1lSCLSnlJw4pAC+jnkZsGAMIFd/Bq2rwLIyOwd9VkZsjDC/UbseNNWYLeykOES1ywdpPgOWUNHEwH5BHv7OvDE5lUgIr106dJXMzWHadaY0B7MCNbx+5I855pAIQeR5/Aez91u0UQKiEx6MCKFsi6jpmlQsnrLc+nvltz4H7+48y/fWLhwYXrVoqsqnFpWzkWDGxtvB3B1mbM/DR42AkUuZazMTk2hpZc45sCEDBk/37m7CUDc1NT03NClQ1/TfljYZQ7HBsGjQvAt+hnwx00EBo5spXCyY8D9DpD6Wxw/ubgSA2Sjx3IOmxg/YoxokavCyuzLVlXKm0rQKvrLGL9BrEhkir0/wMEQajijwM5HpdxFQANdIfcFn8hnxtCUN5jn+IIedp0R+cwCu44tWvdOFnEGsrZOOouDZA5FV5gDSQMjgJ08dwzvMCCczJXJYNsn1pYjrbEmcpcs/Z28kAQ0Ep1qqWiNenJpguYYV8MPvuPegeBXHBMAyeQVpRFYhqb7fi37240S4DDzx8kCcsqVAt4Q55lFRG6vpuxgCZGgu49g6Oz2NtjxyLYNso5mi2VlpQo2FmNdO6+oPVYiTN22uixQulAiTwXHwjuR5Dl+Sw95HW//bcYqOIadsSu86CLMgONHt1YC/mdHV/davyQc5oHjQ28ryHoVOqpAJptaCjX5Khw/ZkpXX6lQw8zErQMs53A+rAwc/q0fblLAlx/Z+NSIveUuxdWJzqqiqLGqYf/wfMPiqlzVD5uIDhDRER8T9L+tqYF/OUEoSO9lAzCBmBRGCISICDKRRi5KZ9MNRBc6o9IxYPjsUP0CYPIeNg6v8nC04nogEP7ywHC+2X1hgJA5gJwVgQ8wUCCANJACnGTAhCgQgiHdQnlEqHgp+3C4LDfKNJBmQDnF0KZBSBD5og8DqWzTxl6viBgR8TB75tW5s0+9fvKosVr39VOciTDxfZXxVAp0zzBhloJ9eDDuii8C50EghaywUBog1jquqYknjh7z5PC6hpEdPV1fmDdjRolN1VURSMTMyda9Oz6/u6dnpP33a6bLHPNsdfy06aivrweyNOCm0GvpxxHgMqOknOERaiE4dvCd9PtChG+do9rpeivxg+tDXq1gMfkKRgmSAw9wikBUFzskAPeciogPDhbcJioor+SALjwgVZsrx+bmfuBahksPlC76M7vseHGIJkpEe8Dg4mxh2rvTU3Tw/ZpNZKikoRBh7549qq9Y/BIzn7PsuecaDvXal2ubN29uYuZziuViP6hyn44HUsChBuUidhmDSil0OaOqmgb6y99u4c/++Nt/+vof/usBVVdzETOff8yIEdPmzZuXWWdIOnfu3PSE8Sc0jx816kNDhgx525/uu/W3ly386FPf+eMvhnUXyzpRUcTl1KY72r2UHM4/VfySvUweEviPyQu3gNeF3x2B4TzQMvYgVVb+0FR5fyi7yT1QgYlRLpdfyVQcYQstHXIySJwIXrEMXL/k0qeD3tpheZo6I1HWNAjlcgnVtbXRs89vKP3q7ms/f9eqR769eP7iMs2bV5HWSUTp+vXr8wB+PnfmKR1HjRlnmCNRoCiC3QkKQfsMhuYMiGOs37yBVzy/jpmZlmLp60Mqt5grd78dEjH5S+H2LCEwYByx2OnPCjq6yIlkpNjvQhwBuDkDLN0DueUeJ848/1KRtA6MCkY2ETNrhInDK3i2xHk8PqLgmQMUoJM98OMWx6hbDuR0BMm4nQEeyL5wDCzPNJ87We4VBnxHyGWKOIc4REaSm5/KFihz23e/50zmz49H5JqPJLFPinD0l7XkXZ0u6hU4YqSfASoI9KNv4cqDsFAFlBP+Cf5dIcjk4wE3OgPO9ze8x22GEkjjPaiB7ETgeCD/HiGpCzYM6H+4V5FFu3qd7fne//g1SO4+9y873YRQf1vqhUQNaeAy89jLduck8Pw+kGNkeWLAnLqPKyxxOBZzdoAfqhO5fm68rjH3ERQrcKGQHnPUJE6qa75CRH2tS5dGR2LAnTsHiojWrdiynjuLBXAMRLlIzRh2jMpR/NT/rS1J/19uLmWlIv7iPDNAODFu4pm8kqdAUHqVCr/8rbIVrxJ5hqYBjGKepwJG9Tn6HuA6CQ7JBQswjH2UeG4qBQwILsUC9nafcy3vC0atAHQTuIeAwUZBcQmIRirwIAV0AEjg+uCfIzSCA9FOIUAWA4AsMwCtnCKXVMF+NFAGmr6+zsVUJCze2d393ca6uhfOOWEWrXjySYqrq6G1dMJHfZwyAFXa0vKp15YBP7BVbqId2S9++Xc4pCRCf6GkJ004Jj5m3PifAbidoT4QvuuJZcsSIio/uvqZfy/G6uvTR9beQEQ77HheE33m2Mp823bt5cb6RmMQattH119Y5ebXAIRGTPYMq0CxBorE8T1EobD3uUg0RbSjfb7fj+Gf40Ufu/VRoaCdV9WpFHsfW4+6fbasKzcdwreBNzuYepnTUDyIvpOUKfEKm3EFa02GZhWpjxiHQw6UNw+ULezO8fSYpDLyFCpsU/1N3uEVsOyJNam1BMo0slKKrr7uIoC3jGhq2gyg8yXYpKKxrUpaVVU1CMCbS+Vyn5IjJQLpw7DpZwIkHL19IqakZzNrpDqlfG0dPfHsGn560/qT71//1MknT5r5kTNnzt752Nqnvzd57IT9URTRph3b+JF1Kz/92LpVTU9teGbabY8uxZ4dO5GrH8TQrLhUtsWRhI+FPhz0A3CpgQLShDdt/0Mfj0yYPzxZvgp4SS62AMMtn4ECGQEPgl31SNddpr9TGr3P3jAgpJKHgiUY8Fd4jecpv7bd6g4uZlPhlgBoRrmYUlW+Nrd8+aPlnzT+/rNb9++mCUNHfvauJUviOXPmZAJsJk2eVCIQM/PPO7u7/gUNtWMRxxrQKlyeHkgxkDHSQon2HjhANIF4wZIFr5FGqsKh4nRBuM79aAPphkoBgeDPADcYUjupAon0SWTAI4hAltp0RHONrB32TrBAVHtjD/BhHwHIBGd4+ROtAGgQK38v2dRgxyk2/U7udXre1t0M+ueqOpJAJ/by1H2GSkhjxwKwOfRdSTE2WygrcKDb4Vg4FnCf8J10W2S9o0OQlWMxkU9TdAN38+30iDgWWfrp59avEYO9ZFxetwRsFchAZxQSefno5tpxziEVu9WOh7i+YhUivDnYhuplnxAyuNeQXKK0CHSxOG4NPcwch5xaKQNcYQjhQ+skMThUOz03UOCEEWASmoVjrxgcwWT7CL8pfxEFgEEMQ1l7FOzzDdeVcEFAG19VPxzfwKh52E8r2+GzJyrkwxE0rviLoDQjVjHKpX7MGDWZzp0wK5NAwMKXedYSK1/BrefPv651bm/HvjSub1BD8g2YOPSoJ0qcxvg7HPP2/2/N72GIIoQK2jNncNBqxWryvObESIAOyApNWbK2eG2FEBHeRLjQACdM5aEevNieyGeBQgqSbjzgHiBGgqXmnh2oGivvvILimEAlBu0HaEgE8VTo6gzRBAWs8ApJB+ABTHDnn5KktdieiSSS4glag1ijsa7OJEowp2G0y/5NHehoaELTWADbYUxRHCqN8kib3Lt7//6lAFafdOz0Nw0ZPeriA12dmYqiKDSl3aHsgFeECPL2neYRIgZEFYoHitp9BSBMxeQ4YvRrOvW44/r/veXKLUS0B8B3bX9l8afMPPpXN1/3sevuuqPn9p8smtPd3T2SiO7lIzz8+SVaVVehcFR9Pq8aa2sZWQalGRlrsEuqlnQNk9oiytiBAZArEy10Yk8kryxDh4Glo1RYkz2xoti1paIDA4HhJAVknPJy92m4lGUGYI/3kAnzhqbnYekfArDsl7QUOBeFL4BIlE5wTahU3FzLOmYPHuwadVkEAmSCF/s9OmHKksgGkVV2LbH3OoZORmZraDjisLkl06A0gy6nKKeaAHRr3vta9g5wxa/wU9cnQy85U9HIilBhS0qtQsYZkvpaYqX0nY/cn925/JHGwX/7a+Mxo0b9qrl+EAhAV18vtm3fiu379iDt6iyr6gZVVTsoStOUpDIkg31GhqWfM/icAW/nQuiK4D5GwIN+7Vb4PBwgscpbwHkIzQiQswflQQ7uu2cFaXcGlR02a+K1NLeXWcZDbgqMfpEuub0NfjWH00sH/RF8x5DzZSDpwZQx0F9CTdWg+Oa/3Zwd1Tzy38tp+lMi2lpxr6WuItV90df+qbyhYxshVmxVst9zqbVP70s10lIZ+3u6SwDw2gKEmZF4RHAblQI8d8h1Bi/+RT44aRPqBTFmHN/LVSFI9SmTIMPHkHVMTnwG/CsAmi3JTWpZBX4AvIwkNkxgwa5HwIY/xWB0INk6y2TdQJANiZPHSkcLnMUJAnGauFHZcYrxQ3BQ2bNW+N5AV4quYGtUCO4IHYBODwSyXgwFiKzXjmaCs0RLkVXUzri2L1VyPJR0lHz/AMvm5CQMnOPOGvbSJ+9wCmho3+sqDrOPmjLEWHXMY6+34w7WrXNYVDxb7ve6RrLXIL+48hnyhRjnciwHyIwzrGAtNHT4VeY7pJcrmS+Pocr7ZPbIG3Wig919zGaPMlc6ZP0+7UCv29oDzvnI4bNEmPugjNBHBXQJZbfgiYo+BXyD8NoAO4geN7jfz98A7ejnQcbj+APOgU0wx00obTh20tCxvYNztTGZI3wO9ciKtnTpUsydO5fvWvtUcUPHi9Ws4rTcX9ATj5qpalTup0SULlmyJIbdb/iP2ir3EFqGMJPJbn+Ho7bRcBXK2oe7/UT66RGBCb8gnUYRhWIFPWzKhhNbZFIRRPrbXih2fmj3mdUDfqHJ691C8QKzYpVZZiUrNCRA4heo3fO4SwOZ9Juhyyn0WICaCUgJLsfZbjgnsglJoizl4cGrvTUFsM4wormpHoCKIjRINNAaQBER6a6dvRc+u2v7yntXrJhjjbmXXQRH0oY1N99KRM9ffM5Za0+eeixnxRKrXAJEMLnqTH5fABGkyhkDNq1cxmGKG8AOV4wmEW6ALZQiUyNFRAKypJnWtc3Nauq4o5cQ0dKrFi1KJFU0oBwAjFj60IMjtu3YST2l0mgiGj3g+1fUJFWgu9g9nnT2AIBRw5uaCSV7hoTbZ2QibAw5+87n6su4bCnIAChWlvM35crDKmNmjengGWbdBeDB9xQD96I4lnL7CLzBapaoKC27/0bAhp1EWQ6mdFLAk+z34oKCZWOtAwc+EK4wcdhwIAc8QGAmHxmwfeDAOy2AT17j9jJYOWMi6wLYRP2wp4eVT5JMRYDb0yTPBMNEfYN9ewx3ILU5V+YVNInovPDCC/sAtOfiuFZLKmxIHPnFNlLIZEWpBlj7vRewbKEAROKE0qqqsSGpqq3jzlKffnz9qvRvjy5Nb39kSfrQU4+nW/fv01GU46qmoUkcRVGGDIhNgRNWorjlx7yHrMz2CjjYlUrwEUU7H7InjAI6MjhwAirnfBD94Rx4zmMNA1ZEVlvGsj1wACV0KmmtUf47GIRuRireR+5/nmcqRYrINJGCIg8GrlShD8AmPTljl+acKaDIKcUNTfTL636X/uz639zDzA3Lti+rGZi2pFnTmTNOJmJlzoXXIhfsmtYalGmwOcMRWTlFc339yNdKmQwRQSl7nA25vktBKVG/bp1ZWeOLYcm6Cg0fu44j5fjPiCOncSvWC2SdhCn6AuTZ85icMSfzRVbfGjXL7llhH0WvGdlrZWOwVwkOR7CfR2Io5eApGApgZQo1sXObQ7H1I8DiKFkUFtkoWMwgYENEpP2fqRXEFazJwfPgRL29wPFa+E5YGgx0/AU4yTlwQsPMI6sQS4ncAKRfrtPmWmWu0WyLowRCV+ZKzuYzeidwLENwhLzD7th1AYDK9xnyV661UD85vgupIg4gKZYTSEQodjLXry07Z2TOf2R33qDsuxdjTvm1QJ52JmJn+2P3XstRJWCGdutJ3AHyzIDiftItXvCFrNjKLrdFz02ctqwumNPKYTOhPvrtWMeuBVl8bJywBMAcuSWp9a6wh6eco1EIbOH1BBikyVYK9QZzKN/lYl9vgw/iX1GNpIEszXTjkOFxtcrfD+CEfV0dV9lgwWETSZiZ3v3ud0fMnOvT+z+4bstGRPlqQqEfx446ms6cdNIwAJgzZ87hHvEP0w6fM2ukqf/TLq0QnALmMN5AFlV8C7AFv4CyHurKy8PYhNxnjQe57hDPDt8w8DOu+K7SM+He6sImck8gbOD0gZFPKgL2aFAXmzP67BVZjQZPY3BkHQoi3O2rBGgahRl4WN1v86yMWdfVN6Cnr38pgLXNjc2/6e4r/Hr1asTt7e0KgC4WiyfU19YM+e5f/qD/+uC9pzLzKc9u394MGGY/HIWOpDFzzMxqSHX9D06cfGwKIGYVVYipiutRGe2kAd86YC8z4R7gld3Bmp8QUwRdKNDkMeMJNYP+HQBGXvViFkb8WpcuVUTET6xe/aUHVj7NPbqsd+7dm9ZWVb0+Xp0SmECDATzW3dO9I8olim2OoaT5Or1kBRsFkRcPDO3fouMqKeQ8yCL02RIqpKWTm5VhGLcmvQIIHyx/UOA99U91q5lCRq0kgefwAIkMvIwEmEgaN+zZXgP5wQM4e4StK0zi0zm5sp5XoCwM4YO9XkF/nPfYauJK5VSx0BwIMY8jhOcBwv77tW4eOO2007qIaFlEUZXW2r1UlFuoMg0ICPekQqbNV9QaMH9pmiErp6Q0VC6pjvO19eanpi6Ok1gxNGWswZFyRiAFxqAnhGlS9smRLJD1lb21V4WYwD1HAJ6nufCs+MDM7eyuNbQIZK4AffhrK9iWXkpJvYbmiiaGci7kG8KAwVZ06iDtcwhlJQHx8H6CMdKJgEiT0iXQL2/7y6S/PHDzO2aNmvUfWzs7mwY8mY4dOzGuihJwpqG07LWGTTEGkGogZSBjyrIUIxubTw9G+aqairjsh3ywnJCPOPzA/RJHg/1x6tXKSi1ahOEVAg/AG5UA1DyHLCuSe4c5uc0M1dGaguwVeQYFkeggsmRYX64JCvaQdZA5A1CAKQ0oLGQdVRQ4luH1QEUTB2l4jaVvEESC40lnYAcp24KQBoLqge9koZmMuZKb/br3bzXBgMDdXrEw7TJ3c2J/u4sH0FUe4OIHwYImc798ZBzIlZwk7ku3nVO87HajpYM9FRwedtaT4KB+DuBakc8VuqsyPCeDGEBBO1MVEWbfl4rg3aGa9C2YP3c9UaA7RWKKA9T/dkvM8T65uZYJFmc+AOepIHgaGyMsGJMsxzC64xwvIa+F6zuQBu4686BwFR+OCMaZgMC69bLY+WhAKGcpmqsbcMqE42oAFIj0o+7CQzTZ0lE3oq4BwIJntq47ubuzC7XlBLHKq+H5wS9WIVq+YMGCf9jKomE7pK71bBSKZBF4IgiM8PDhYGEm8lWQ5IEVitF7vkyQRBiYgkVoOMP5eMgoiIM8t+HiFuZn8n0XcCIM71B06BmH52UdLgA74pgQ9UWg3VZ52UggUkCPA3AUA6lUWbQKoUIusY+0SplseWmkUEaWNTU3o6u390EAZ/X29z9CinqnT0fW0tKSEJFm4gtTVketW/es2rFn5/sBvHdYQ8M5AGCNxlfdiCi1VZW2zThm0o+OmXAMyv2FNGIjO/zGdxFAXpMSKuegYkU6gSzcNDCF0E0FFDNUpjnSTONHjlr3hcsue//+rv2XLaSFmpljM09Ma37+c2bmEbc/+sBR2/bs4STJ1S55/OF7EEW32AX9akMJDABRFHVmWt+dxPHd+zr2bVI1tYqZ9UEeMPJ8KQLc8ZMMytLHp3cKHSxfccBLnkyuWqfvlZH2zjNv+VNZfnZPdV0kC2wCZWH77hVwqLVhnw+33kJnrCimiugf7DpnOUPL0oK9uwD2Gmb7vkBZOmNS1IZljArXhhgGtky6X6h2ubo+BemubMEme/Ama1si+KzMkQCUmHPcKBeD4ghRFL78VbWImZX4wYk8oDV9lr6HghGorN5s514p+ONwyO6vsVUBNUNnGbI0RZZmyCTKScbQYOEpYUMv8tycwFU0NKvRQwQRTwG0FEEa6uggPc9DW3Zr3pWyJx/1CeEUBygphAskT3KA28j9v8dhPFkYtXHr99BOMN/sOqngc69vENxrxulBm9d3cpsCdIbqujq1et0z5fufWfEbACtu37ixexlzsow5aXv44Woi0qtf2PTFYU3NKPeXtEpZjD8gg412s6srn8slWLZlzZ9tN16NbsgAoFxMF2hO+0AUcWZTXTMvvR1cY1/dkwB/1IC240fg6PKTD8sg7j4X6XL01W5+HH9Z2vkqq24KAhTrr2GJLNpXMpHJH+AQvspZrPJjBZEewAXi/LO8UmkAMiqqdIphxXB6T55vMgMCeShZUHYsglVcrQP2qY9CNmbYYzEQbLtmRwfzyxokCq6vILtkQVBONkr01eM3obovsEN+zRIcnTyvc5DlIWKBnBFuHmkoruH7LbLBOaTI09c5Pm0/hRW8cSDk8E431gzWlqdUUJkSIhL9zR6neTpDe36tcFpZPCtbOTwONXLAGb9On3rGVEJ7luvtE0gixQQF5e5xNEEgjRhmXK7OkvAwV9znIrBWNsv68/xpRucS1oJ5IKqUxQP3/1cSzot+10/y/WaGq6ptbg1ukI9Cg5dRcWSZH1GouBg6IWRZP44ePVGPGTL6a6VSaYWqU9scKwxoEiw5cOBAUz6qexuAp+5bs7ybMkAVMz2ofkg0LDf4WQCz3vqBtza8li1Y/1tapcJw0R2Ey8ELdPHqi1CUzw2KgQ+J2OVCvlS3MGdFhVxRyEAo2ezzlVtfXvuIYCPHxS7/3vY6kCWu7wq2Wr0Kx2JVuRPu4UDtPxiQTRtqO0GVlc8HIUamGJiRgBuNILLr0AlEETIsVQ01m6qiaQrYQ6I1MxQpnDB5yngAm1Ktn6rN535ERNmGDRsYAPIqxt6OA7RnfwdWbXhu+N1PLu+rq6oaB4BaWloOj19epkl60v6enuO7enrvfNsFb1wza/KxBe7po4TJHj8h6W8ESSGScYagQNIonAFByqX8kZfIkH2bxmkg1xEK/b3pmHHjaMoxk68FcAmTqgr7unr16qS9vT1Lgelrdmw9gbNiWkpT9W/f+9YLRNRtukivihZyX21t7YuNdXUXlP/zP9X40WNqmDVYVVauZOvRViI8xVBxa4Kcw9CBi0AhOrQk6ciWp+V4KW2VjKSNSsVXJedYObej9MnSU1t+Fr5mUUiylvx6lRQer97IAQVZXzI+t/fDXmu+k7HZNGAn6wnhOnQdZbbl8kWj+30lXob4yys88tI/cca4sVhloYWcQToUs4mkWCVNlndhz4fjOAKCH+HF19jcWYHhHjgzXA8fwvO9jJgQI8PQSX5b4gdK1joFtLbn9sGDGLf+vIYnOROVFGQvodCwYq79KgZgU9VcVASe90PgdIhVViEPIN5k7YCiSa6yYE14itnxN4WM4IS46cffo6gMs5wwL2MKAEsIYFzamqxDGrCWAuDCZCs7sufvCiPByxCOCTqvUFKa4kHN6vf334xf3PanD82fPbs8m6g8m6g874wz+pn5jDOnnjC0GjHQWyRVzIBSBk4NL0hk3o+L0ZBvqH+1dAlk6FhWnLGxM+15jXDWmKhgexSio4GkwtmnhT4DQbNBZ+0vB6g9+DRyyK5fSQOVqpnM/ngFzS4Nn9x5VQLEg35AkjzZp8Ha8bBdS8bBZecxKMzhbRVB0uT6LbjBrRiLW5Tbv2t7YZ1aLrVUZL/0gW3Prb4RUinBQQFNxWCkQPYByhuRiizosbJW2BMyT1bHSJ+UaHWzFUKuMs2nCPvPjNvLUdZu43EgP5D9Rl2x00nG/BEZ4NyJEINfkTnPOSJl/oZxhilNxglqnepscyXdOgxlbSBClDgC7ZTLFiS/aq3BLfCFve71w/W5XuRAHqzTzupGJcepWNlu5SQ7Uoh28rJaZLp2ezAsrYNtE665cQX4QuS3mx/rYHWQhJxz1J89G8pvcq9hhou1O/1kn2noYuW1UIIIklZtNR0qmx2jLBC7pchtFZE5lJ4IdpK7K/CD9XklBOg+nDbxeDW5bnRfPp+/phGNHfb+Q2glEBFxUlNzdKKirwAo1jXkj+/t6810mtLwhmbMOGryBq31+eOHHtNipvrwqaf/CK3SILSrKFBxAPxkMyhQgHJPZXJhKPsN/qGK54TfVeiGiukkt1DJvduH0/1CDh8AtzYqHmUjmT6Xw0dAJCISehFJlpUF86RhIgr7ABwAOLLCXBGQEtKmDDiRoeMMZmO5pK+x6xMBINLmHCVt9npwlpmfNENVLoea2poCgNqmurrPENEmALjmmmvKC5gVouju53ds3xHl89i47tns5nvumpNPkp+1tLSo1tbWQ07skTS5N19bu5dZP9ycz//utGnH7s3VVEUpQTsnJYRulWvOrHXZq0EDJt9SMxC+kOsqSr4zOFKsCVFVkuz5t0vfMbi/v/9bg+ub/sLmMPqUmaMZ5ugJum7Jve968LHHOalrpHKxiD8u/OYHmTlZM336QIn0ihsz049//OO8WrhQD6lvYGUPmpYf0QUAmwNi3XhEyTKkgJADtAIkyK8htp5iv2J88NntbwhKkMtlKjjf0tHf8ZpVLmJZ2pu8gcHB2rZ7GMkajPZQbVeRPFCeYXBOCOz2glZ4XsgqLOWUroAaAwPCGL/tr/ZrJLRnHIAgv/7hnuUVvwFM7J7r02kc+c1YLEAyYzQ/sOmiByuy19a0BZey19PLFbi5c9iYKrMlQtRFIkcCGEdWsXN4fl4oY4LtHkym4ETFGgY8eKABX1D47qDZ5wtYEMPGP87f5NZ4MJ8+jBEYVhJJCCVD4OQTPvy7toowk29+ZVFAdKqgD4BgHGKdB0+QaBDg7mUyBoJS1lixZxVyQqB8TvX0dWfXLbvn4u19XWdxf//EUrl8TUdv99U9/X3/ddz4iaqxqhYolYlSOONMnEkI3gNS0OF5Lq+yEVG31kQuMiRGDHgAqAT8wh2w9hzK9niCOGQUAcdwqfcSjTFNOR3j+cX1z68Mx2/Wugsc0KY/YpA4FoOvV2Aj7PLjRwR/5h+cwRLuk4dgkvAasQLEYBogw3xkpoKZ4JejldOKwEpYidx2Fdcjv8DM/QFgty8GHIIyvEGkPEBn2Ttmo1PCPhG5DC/v5eHAPyLPZTuXMveVwsNpeUJgANoROuPGUk/mB7DzocGcWWe0/eHMyw02hr3cp5ye9WzJA9ZrRXCB4PCgi46S/3cwE64pS+eKs0idbLfynuA+VMJ7CFsgy8OPWGT9QDqJ8072xfu5MMa8LRwn+hRwa5Os7CWZO3dNILdcf809Us3W83Cg9B3Oqcz18uNgR9NQskuf/ZuEBoH+ce+0xrlTIBToKyDTqc43Nqh6Vf0UgBcWLVuU4CUaEWlmjuvy+RU1UfLjh7Y+c8kLXTtrKR9zgdJoWM3g9LihE+8oZaWHulJ9rcWb/9CVRp1BKNX1D908I0tzkR8H+exEHmIZuI34lTLQMxGC2wYCmIoHecF9kDIP1ijLAhAhfshn+Z77i/wn4Rs4YqBIwDaG4th8Y2IB4BJDj2XQlAw6S10HxEPkhiQ8DttBzeBMA8UiGqqqMHzwUEKWabZn7AHAwoUL9Y7FiyMiWvHE2jXPx6zAjPS5XTtO2dvfe2V7e3u2cOHCV6385d5aou2N9fWt/aUS5p5y+oNTjj6GCqUiI4phzlQztOFACbGdD6NgyS1aGZ5jKPKTKsaOF9z2v4Zv1FvOPo9HNDXdWSwWH7ThfgUA/f39Z3X29FyTxDE/uWbVWzr2H6A6EFDOAI7OB/CZb5599uBXSwdpRMQf//jHUwAYNmgIq1hZUO1EsVwY9D4Ys51vt29sIL9X/FNX8rH8ckrG8mJY6ECAB/kLBeiAAdIc/GgQS0A7KGQQKVAcQcWxMYycZzPgdycLyGI075apGAch1BPeKTDgeQMHTxx6okKQZ/8dLj4KRIX73CojpaBUBEoUVBJDxRGiOIZKYlASQ+US8ztSLg1TOk0Mc+5fpg8a1mtrssHLCZiBxAgGO0DoVXSE/S/nUZY/7QQFG7LZ7oWkSJm5TRJWScwU2/2SwozBFFWQk2GjJRKtDq6qAAUhmPERAV8VOvguBAxkufdQwlgwCoKLHQAnRNHfwWnLwc+AjwEEzpkAoAGwx337fh7kCKucN0n1JnmoInBEQEzgRJmU5QhUW9+gHli1LPrVrdfciqqqDyRxzDW5fFJXXfPQjQ/dP2Hrnp1QuRwyG02oSG4NjOlDK7tXQBabog9wKzFqM84yr7ytyRM4oSrGrQiIyHq3zCL3JXLMM3hg/ypABbvhVKQSSTSC/A2knbkY8HCAUxwvcjAlfhxua0uFASo3mYVFToibH7e9yW3z9WvcOAPlPQFcDhdbMFxn1LE3tir4kWBkc0wgWyCKIvOjImVkMpvUT2LljDuym+5MVgT8j6T64WAWOfSSHMBbrmvB5+HiGZAS6HlG5p0deSl8jISYrSGqoggRRYgQI+IIkVZQZnxMDI4kQ0RZY9bxXGR+R+bgdiX0d9PqQxN0EBMOIDyFIwnH65eZ+YhxMBS195PBNfI/oamnITkHoWc/zx0uemyZmSDFYMjW/TL6z6uLSsVcKdY8XnOQzAhtZ8MFr65cNy7TLZQ55iEi+gh++jnoy0Hy3Bp3YVJFRQs7EToo2YxXl0t6SPMoGt048kki2r4cwBGkeeoFCxaoKEmeunfdI8+/2L2Xo9ocSujlE4+eHg+pqe+sSqp+cVRT04GKLv+DtvjwXwlnmFkJFaX5t2WowOMcCkBj61Xu7zH3U/hYGGa1z5LXVl7g+uNVEgWARb6WqIK83/dboja+PDC7VUAs39mr7aJzxdGDFEe1XYMnKXCdNsYcAGhCljFoKgOdGWiDAsWimOz4RRGSe6ipDgcCSiXU5asweNAglHWKXBwz2zxNZlaLFy8GM0f/fX37zL6OLiR19Xrl+vX6+rvvupyZd3Z2d5/UWF//KwAHLH1fMVMzMz3//PP5CRMmFE+YOOlrJ06ddsGqtc82UXUNc5oGuEj2M8lcGG++AASGBQMDwZGjvdeO4rUipVDu78/Gj58QT5805TdEdH3QtRQACoXCUxzHP9/Z23X5u77wubpSsZTm41iVowI2btvSCSDfs2tX7ysd9yFbC8DtwJhhI5IkzqEvK1YUNAOEly3oEV4knw4ihq9m4ccwAm15WJ5pWV2q7WryKSzOvrKykUmebT4UflcEZKnmUqmYcpqatOTMpsSxADUbFYtjIEmMAlURiIBcFEUxSGlN0FIchtgXgPGaCQKmOOi7Z2vRCvKhNYxlHYgssALfjMl+4gSMAKQAVjEAOY5BGUBU1llWyjLzYdmON5QJQpgoAeIEkSKVi+JIa4nOa3M+XKqNAU3eRH0tTUluulLwkTEzFB/99FMTijvzb4dejdywSluq2ZrnyM0W+ERGJRezNDWVJzMgSRKKY0RxYibEVkKElip07JgrtGm8ePZpvYZ/Ca5MPTweNONR5nAi4VnXVasbRIdQsD4kokE+1cwZvO4FFtT+PezBQB6Hto2Vav462HFDottm3bvxS4dlMu1ku1RZQUtCHOF7SSm00etyRIQk0d+7+bcNu7v2/tuGFze/eVeqdr7l2Fk/+sOSv178YtdujuuqVcmm8EuPjOFgB2Sf/3qQi5j2EtNR5jyBoO+BHDPrl7wBF6TXA56eTucBILEQheEU+8IyFPKf9AN2OwbbNDNti9KwA/3aXijRR8+/XhRpAigy8+UjVmScIKGssriFQEAE+AqpTgXalPlgriVNWMZpF7UWjAF4frZUMTWNvP5g9liEIivdI5PNkJLmNE1TyS5CObUyT9t9nfb5uRjIJUAcQSWxSlQcEQOZjbax0FMEbwVUsIQih9iCiRQdB+fcECwlRoUbJ+COCHH3OhToUZyJlitAASWdZpxmGplsp8mAsh2rttWfamsTEIBSoYxcAiSR0WVxhEhFKlFJpKHd3lWuMLTD7LJg0Qs9GHDnUdvK6oIFTVYcu2M1PF97TGOWdrBfkq0+FyZRyt0k1V4dlwY0RYAdWPCFPFuitawr1xn74jBmZVnkGspiJ9EsBrMk1aJviNx7HC+F+COQgY58klpcwdfi+HJLw+oCn4cjfKQDu8ENRubBEdKxJBQIWVrGUQ1DcMqEE0cys1q8fDmOoLHNhLtHl4o/3tuxm6i6huuHDlak6CYAD82bN4+k+MyRPPB/c/MGYTAvpnHFb+9F8xE670UN5CD536H7RHKfKwPx8N8LaGTLVhxcKc8EB0wePsELbemLMxAhG6IN+ADLGVlWiAcLE+SNRfncAduEgG4Gb81AxyqzMCVtSwMZMdQMQHeVQNsIyEvKkNl3SLKB0Sogp080EMcJkijRAxN9rPdDX3XVVcmYIUM/c6CrC3U1dfkd+/bhb488PP3Dl751FIADRLR/2bJlyezZs8sDJ/hIml0IhQULFsREtPrH7X9++sbBg+f2FPqyiCkmkEuZ9MaMSAY/g3aKLGAiKxB0xZwSyGOXjBEBKJcKPHvGceX3zL3wuQ8AaFu1KjdvxoySmUsmIurMxclDf31gycqn1q+ryefzWVosQacpntu2pQRg/Pijj343gMX8ms8ibAHQjqa6un1V+QQ9pYIr+Sw86Tx1gYJ36bQW2Jq1EUKbATTXFmzAAwmXR8/uAicwpTKhiggqiq1BlDLSNEahAKiYhjQNTqqTPOpra5HEEaqTPKpzOQvarPKFRnd/PwppCf3FIgrFfuzduxfFvj4gTgClsiiJORcnsYuG0IBRkP8dAjczxfYTLQIfFcop3KsX7hNw+tMaIS7CnmkoImitdSkray4VFdJUxU1N0aghw6LqqioMHzQYQ+oaEccxIhWBAKQ6Q3+5hF0d+7G74wD2dexF/+495rxVUmkuyUcRKZKKoFGkgNeryphEHuyCp1CWaSdZDL3CqA4RKjhG5JMEHR1tCOVymnG5xADHKJWBOKbBY0YmdQ2NGDloGNBX7N7T25F7oXt3HkoxFIgzmTxR85b2DgyGMtSmswpsJTEK4UAeYEEXacfLYOsTcvwAn0YN2GMIDwYDTq4McD78vTS0ADBAlrI33CucjYRgvqSvQXoVczBf5A1BKygCdndyzy2M4N/MAMVKFZj553f/uX70kFH3Vefz+OE9v0NvRy8nVbWkswwSWycLyITOigiIbeXcyKr1OXj5E5sPbjL4iUyckd2AJfPNbJwepd4ejTQ1Si1S5piTyER6QPD5go5g7PfRy/5Xsa7EmFRkjP9KjFn5DJCOo0SJ3rWqyc0d4CN1kn4qhVVMvxRKpaLpe8rG5Zhpv29L+hxFQGzHFsnnBJ9GaSfUOtAUlKaK/EuPeUyf7IBsZ4WfSHSjXeOKCGmWZlmaMVhH4JRQnachQ4cldflaVCd5NOfr0Jiv9fRhRpZpdBa7sbuvA32lIjq7O9G/fz+s0gDiKEUUU6LiSF7mKq86eofGisdATlYJfayOl3vNraIbKXCKyno374koQsY6y3TKKJcUsrKCzlDb1Bw1DmqK6qpqMLJhMOqjaigixFGMRCUgAtZv2rAbFEUjx4wYvKunE71ZET3FHvSV+tDb24tCx35jDCvFUJHORbkIMPhDzq4E+5FJI3sWpRmpSWd15/cF7ODwp0y9yGNLPJEZLOf/wupCMnzL5B0RzKY6v3Gmm6cTe6dkgJqdwegWhL3JQ+vKegZE2uvZEMJCnDlmzTm3l/1MA+6oFJNOGsxjgPc5eCakt8JH8jzHVHBEr3AJcPiVENr02Tt1/B2RBiJSQJpFI5pG60mDR33bpoNiPl6+kTmrkJ7b+cLRaZYhylLU1g7B0Y1jdxBRaUHbgtw/eqqoNGcQhv7xUAkH2M/BCLcPRiJvsIvJMgIf4l7hvtDLYP6sVPk+998tCQSSLzAGK1jSyTQRtj7jmgPeFGY76BHBtYESEyXCZhGpKAZvKQFHxeC8csoAyIASwDFBzY6AYhm8W0FVRXYfgE/Z4shTxXymUd/YgMb6+lqt0wrSdRUK09K+vgTAqu179xbKWtfHpEgryrYe2HfMH++9d8+7zz//tiVLlsSv1hgM2/Tp07mjo6N5d3//ndfdf8959z36qKqqrUVmo38hPAtnzUw7WwMmEIT+y8oXiZBlBmeprq5vjEc1NN4XATP3dXXMH9zQtCgw7MgK2xGf+skPZu7dvQeNVdUqTVOtibHRGIQjGDgXwGIY9f2qF7cxB4Hr7r/7i3X5qof3dHSAVA5iKzgaOAUAl1pkOdQpH6+FQsEekEEiixY0BysMgmrYRpJjFYGV0sVymbmnGzWDh0ajG4dhUFKtT50ygyaOGrvryc3rFp009ThMG3806mpqMKSpCc11dVCmjhk0NPb3dGHLzhexv6cDL+zcRas3PcdHDR3xrs6enslPrF6pX+zaHx3o7EDn7t0ZamuRr6kmUlA6y8waI+W8fE7ByuIToEeVysONlzzvOx6Q53AF68OpRmZd6O5iipJoyOAh6uhxR+G0acdxEscPREmyZNLYCer4CZP0xDFjUKVyiOMYgEaqNboKfVixcS09svppxMCJmunN9zz8IO/p7ojXrl+LUqmYRdVVWZzkkI/jDECtotpXHSpkZrrhobsgzi3PIeyAWygcDWC0hFBObRudzQCnWpNmzrIM5VIJKJSAYgkAo2rYsGjYyFFoyNfoSWPH09GjxnS+cGDPj8479Vz9njkX1ddDLb7hsSWNv733hrtvffz+hjjKQ2s5NS8wcALvtOFhUf4CQOB42cYMPZDwjB7MnTcc3ZmTcj385X6vk0SR4Z8hZBIj4O+gqsOAsAu4Vki44EuEdIFXRyEwkg5XAKLgogEgyhVBEr6AXesESvI1vH3fbg2dIY7zSJJ8pLU2kWBZKxFZucIgLQ836XIvkfZzJI0BQEMfR8zrmTWBM+vIMCi21NHJx005QY1qGsxZpqESk64ne9QkyyxjjYwzZFkGE5k3RXB0GFETjlImIhYpU1SEbBiONSPTGmmWQpcz7OrZp7bt3clJPk9GNrJbVnKPTDAp2P13MLwdAVmhiPHDx6lRtYNRLpYYIHuUh3F0mxo6bAxBgjUqyaY22nm1xo/OMnDGONDTSds7dqlyqQQV2WJqUmMPDFcROVjrBNg0b4JiMJh1qbcf6OlBzdBh0dARwzA434Azpx7PIxqbt23cu/03J0+cSaObh/P4IWMwrnmYPYVBIU01SqUCtnRsw+odm9X+rq4qxWo2sZqzYuOqbM3WDfGOvgPx/s4DKHTsz6ipHnEuIWJSWmce4wTGg8gFSXmkcC1bDOOzFuzexUAe+CJXCiqOQKx1qb+H8zW10eCmYRhc1YjpzUel5xw7O+osdd+SKrXiuPHT6IQxk3lIVQOUUoiVQoxY+Pm7AKpKSD+2Ycdm3tG9j57eso4eW/MkDx40ZGZdVe3bHl33VLav2BXv7NoTHdj+QgoQIV+NXK4KJonB5J0CYqgHBnG48gfq6UB3S4Vh77pjsYm8dOQgkwIEOVzdB0TIyx+Cl72SLeGo6N/r3ifORdtxb7AJLpG+eCgrgse8hq295zNA2GIUpxukT8EDK7YQsNftTncEUVVzmfb0GUBLeUyliAyAgt3fKA5yYhM4AIMmDhuvAeR3dXQcQ0TP2X1/h3XktrdDAcg6S/1v2V7YmwFEWbGMkdWNOGHc1MHMTMuXL+eFr8Jz9r+xOd1hKk0ZxnJeD7t4vLGHSiAXND7oDyuMJaWA/X2hjeDvE48TiXYe8ALPrAMjhKABDOpEGQSxB5/ad7kUE/L9EL6GZ1DyXA/kCKpLIduagaYqcDEAABHAZSDNMaLTY9DjGryTgWrTOQ1ynkZSMQjawPSqKqWiqDAon9y7d2/nTW1BlSNO0wmNjY3XAfjU2hee35dBD1XlEnL5vHp67VpeuW7N5wHcNnfu3PS1hrzt/Vlnb+/HJzU2/u3YMeOeerjqyRN0FGnOUhVuRneKI0w7CYxAGgiMrHcsdHQxAEQRCv09etLRk+JRQ0f9FMB9paxfKuSZTCC72J9ev/bT9z79VEZJzGWFGFU5cAT09PXlAXRo4H5732uDjy0tQHs7ph89hR94+mkg06CcDXg5XvEMLcCaws8DuoSpH074y43OCwcLENlUzROJq9kADDD3d3SlqqYuOWrUaMyddTIG1zbec9Hs0zfVDGlYePrYyQygn4gOXPMqhszM3wPQtHbvXr1z2+ZPPbjqmcnb9++69L6Vy7F+xzZkhf5yrrYhZq3JgtaDAHCFoSFGoQzXRV98SoxL6XKAEBWAgkhxoas7JVbJicfPwlFDRq65/PyLVs09YfYLowYN/hGAPUR0xE4QZr4EwEc+ceU/V73w/IYFqzc+d+UTG1fHtzxwT8QMJIibASzr6u/vexUkBAAmIr7+oTsHCBRLA1cM0hdQkAgwxQpMiikmlHWmdVrSKBSgKJfEUEiSHEYOHYZRzSMwddx4nDj5WBCiB0+YfOxm1FQvOOeoKUUAZSLacy2+g/f3935td3/xzLeddt7V1z18Z+fSp59o6iulGq7SienHQEPMpw+FaVCyvq2hFxhNBkeSi4CGa8FdEXrfnUwVL7wUXrA8ISjGrg2h49/DdRshGqC0vOaQKL8fpPRduw9FjxnwDC8H3T32OWTTrSzACSPh0CIwGci8I0lzmRJQBI7BpdTT1OlIL4sIZCJZRP55r62JgJqZgtYAGkg1FDGiWKHQ2ZF96K3vi778ro9dfdSQ4V/oB6LqAVPUF/zuQx/6+sxv+bD/oCtNqwYA1Mj/3SX70Ieejq6o0FXKOru3ffSXS//8n488+6TO52sUH5Qq7veYyf45IoJSEUrFHj1z3GT1H2/+yPfXjx365dO5cXBdPpdVo8b1pb9P/np5MVAsHKCooGhXX3/80JN3t1/75F2zu7t7MigVuZpFogedceiNRaUiaDCXy0XK5aqiKRMm4oypx6Mxabjtn944rycPddOkIWOXACgQ0f7fvmyPTGPmMwB8FUA93gh+ZteW6t17d7Y+uHb5hB2FPWfd+uR92LZ7B6B1mqutjzhNSQuoF0Mw9HxI5kJgxJATHtb1xcHl9t9RHCHTqS4We7m6sSk699gzUc3JXR++6N0Hjho0/K5Zw6fcCiCuy9ds7S31HzyQg1svgNaBH9blqtFd7Bu7ta9P7+/cdV5HqfNfVm/ZdNpj65fjsbXL8fy+F1Hs6wFycTlXXRuzyYENCGbG5JZxaACxl1u+MrfIvcDIsoRhS0eXYhmgBXLYAB7IVoDZECRz+Ikr4ONiuCJPnMEoqN0jeJkrt+0A4evC91q8TF5Oi+x3rKvIwRjbIXgGhx+nF6UHveMg/6HTLcEkhEal/YRAyDKtGxua1MimofcCmBoprgHwHCquPrjVnbAhZma+b9Pyt+8rduQoistcLKmxdcN45tiJS4mIlyxZ8qpx8/+2FkQIhZ2kBXt5gq+4YhK9YBCPsGEK71Hyi4srjEhh3zAgZ7KfCeKNNl9oy2qq8n3OY+NTGvzD2fVfFLZbRHKti8BYRvT2jMsOYQaItR8XGEQxaEMBPIKBGoBTSWNl08UMSKuA6LQIeDKF2gpQLgISGaHxhIIUmCJGQ320v7tzNxE5LM/Mipmpt7d3u12DQ9e+8EK5VEwRRxqklCr1dKWrNm48dfuBrreOaqq/p7W1tdfS/VUxt9zXWFu7AACuf3DJfUueXX3Cuhc2p0kS54iFnl4AAGzP/QnJz1a4Bgol9D4GwpeVYi6V6bhjJh743Lve/QIR7QOwT/rDzFV7urrGDm1oSK+5628fXLN2LeVrqhXrDLBFUboLhQTADT/561/b7H2vCT9KhPCkY49F/V11dm+aF+Yy1yYFyQp9a/A7iCa8g0C2OwEqQk88dLJMCG7ffWbSDBUzF/YfyBAn8RlnnJ2cc8LsZ0+YMvnX7zxj7mN1VdUPfq9YqOj7VYuuSoBZmDVrFmYdanCzACwHTOb9cpgU/OUgoh4APfaqzygAGfMZdz+5/Phnnt/wyVuXPzjpnuWPAUS6qiqvslIK4Qdn3IdCXuaXPK4XRXVIfUGw6TIaKopQKJdSFMvxrJmzk0tOPmvtZXMu+OFJ4ya0EVFH5XgXJbMAzJo1y4ztoFGbMb54881MRLe61zL/5Ljxk2queMNFP3r7mW+49KFVK97IGa8jorawe6+k3XbbbbmLL7540PUP3WnOkylrl3Yh+3aU6H8r06KEUcrSTBdKGrmqBEWNhkGDoqENY6JjRo8F9xS2jWoavvuCM86O9hd6vj1l3KQtF06ZAQCoq6l5qLe/EkS1LFiQe8Olo7hUVfO9mKmemdX1D99JcTlzxXO8kPNbz6Rp6SuswUEwe75Iw+TdmbQm5+QD+Sh3oNCN2qgEQ1D2vtDTDO8Q8cFTwyWymhiw+2Ff32YKKrEnAAW4xI3EEojY7xtzmQDyILsvx6V7id4ye6SUUjaqoB01wj2UHhQJ3QRYiX4LsmqkO0IpV5rY9EOiWa8lRBjoj4nEnCkmUhmQRAp9hd5sysSp6lNv/eAdU0aO/UAxfc1JKa+4MfM39/Uf+MCyzavGIIoYCqYUqlQsFhGr4NPsMyCBQrE/VW+bdUHxylMveqynv6+tvqb2za9Xv8pc/tyuH+658ZZlS6qSfBXrTNvNjX5fm8mg0KAoAiniUs/+NKlvSGaMmFR695y3rjn16Bl/mjvlpIeq4/xDP8o+W/H8qxZdlczCLEBk+ywrzIO2fLn5DxE9bD/qDr5+Hxtn8+m3TH/gkhXPr/ngrU/fP/zxVY8DSS7NJ/koyzKCDYySPdNUKheHKeHMgdFhDRMzN7AOTUP3YncX1zY3qYtPOg9zJ81+/KJTzvvSyUMn3vm3Ty4+iH5XLVqUGDE+KxDjs9x/CZTatRUvX74cZqjLASzH4vmLUyLaam/6AzP/6dyjTjjjX85+e7p03ZPnrN+96Z23r1gyY13HluTZF9ZDVVezUhG58zu1x4hORg0wyACJxtl/iRNMjGXxtZmH2PoBbNNFBfwouEI0sLhSHKSBfSiOuYG2mxW19n22nwHYkCikgSoSrQweQs4Vae7TDC2VSkMgDvi9fM4oFNwiPMDumZY8Xn6y6HP/QF/BN7AKWegq11gxZ4GDpNYChGK5Lxt/1CQaVj/0Bp1lV6hIffcgJjpEe9PkyUUA+MKNP961u7MTOeRQhI5qqLarDlU3MXOdUqrn/+0hNC3YQ+hKZ3nvbcAjoeXv/Q/BhzZtwKVFCFAYwGgBa7lFJ80tQfaXe1At3zIqkGb4aK74uMI/IUEbJlhvvY3MhBFCASGBJwgw59+YNWwWhOogYG0KfULiPTQE8+AI4IyQ5RjqFAXUA1ifgooROG9QmIZ9ry30UV1bp5g5t3TpUj1nzpyMpFxuXd1THV1dDzXW1zd29nYrZCk0K6gsQ05F6oHHHlVPrFr5jUvPOrPjrW9965sAdL0WoxAAli1blsyaNSsD8Nff3HTjP6/bvLE6SvKs08z4weT4LnbUqiA4u98iaIyZf1BUF0ApK2V1g4dExx51zHJFtHzRokXJVVddlUr/d5tt40MAqHueXN5cLvZn+foalSlAxZEqdHVmJ5x57mwAX1xTW1t+ufSBV9ImDh+NuuoqozCMt8OMw2ZC+AIq4lETSQpZRhX87fZfWS3q4LNVFmEqXhzF6O/u0cgydfoZZ8bvuvDSfe9646VfGlZVNQzAo0T00LkLzo1b57Ri7pw5mVsrNmIW0oGZo6VLl9KcOXP4cMYyszcLWpcujRb+/OdsQcXDzPybd7/xkg/95ubr/vPqO24etXbjs5yra2DSrDRndo3bVS2LFQcrKADBmoIr6uGcTlojVgp9+zqykeOOit966pzuf7503r+fNOGY3xJRCTCg4YrJk3nOnDlZON4jbTLO9tWrn5k3Y0aL/fghAv6DB9DtlTyTiPjEE08cCeCqQqnUGTFMYYRIufQ5t2jYpMFBAYWeHgwdPDyacfyxETJ0zDnpdE3gv1YlNQ//yzveFdcCNymi3X8AmT1rA9qSJUviAfNfal8IzMf8DgAduTjBn++7VZvD7LU7WFlmm2Xewv/KfLFEcTUqrEbR2g4sCBAnv482cAYZuRvwhIsMUnCpBRqWTKEs/ns1ZSv1SYwybGZdwvGti+46LCMOIViDLJCE/kxLXSoVGaVMIc5xLpdz0SxmjUNKaEt356Fnhi9vBrfW7OIKbPtgDK8T2Ri0l4gUkanOqJSCLpd40lETaGjzsO3Ft701uu2DH4zfdPGbSodItH1dW2trK40aNSr6xsN/jIio75N//uZvm4YM+dKB/V1pFJnN9wztHWqy5myk20RODWPFSpUATOkv9u9ftGhRMmvWLMyaNSt9pf1pbW3lR7ZurdK9vfFZxx7bFyPuHDFoaBGKqpGLTeEXDSBjMGkgAyjTiBCh2NerEbG6YPa5yXvPb9l/wcwz3z+6rvGWQPCoRcsWRYM2DdItLS2SKXOQrLPyLCJzGEn4ecA0pi1dulSuexDAg8z8Xx++4F3/9Itb/vDxPz5886Dntm1GUl3DAEibKh4WEpJzVJhmGMyzPfmgFxgqipCWSpkuFtScWWfSu85626NXnv7m7w+i3LWfsqto0bJFcTg2Gd+h9NZSADcDWIIlEeYgewk6EAFoa29XdpySMfSwAr6VMc9pf/yuiUufefjbNzz3QPPOnn0cxRFxBhC0i3FrJ4q8kWj+lFTLYC1aw0hwpU8ZNbQQGeH8PuQ3EphUSEAcxVr23NtvjQPK5mOIESjMgUB2s58bX0ApAGIuy8/SyhAssL78PlfzT3svE+QMamcHD8DlIe6W6zyLBDg+EE8sHRUayIcus8T3lAiAYrCKoQtljGsaReccc9L0Uppu0oiXWz4/pL623yW7u/bPGtbQ3PxvbV87f//uvajL10cZlzF99MQigPft7el4lJnvgQvn/GM3nzIafOj+lhkPhIFXfeQnOsDCnnPlSuGWkKXD62ANOfJXV3CbjQwOXBgc3CtdDJnuoFHZdmj2GfC3pFORB6zO9ZJBUQTelIJGZKAhkfFgq6DfEUDW8YSZgBoSgVYzuKMMysegiHxkMyOMaG7G0EHNpb0dBwAAbW1tdkM0U3dv7/0pMPToseOmPfDgQ2Wqb0i0ZiRJQl3dHbjmlusbLzvrzDvGHz3x00T0JesFfNWMPXv27BQA11XXPPD1q/+7fPsjD9YCxOIxMoDOEjE0eEgWuAixyvlnWwFAgU0hHUVIe/vV5BOPpYvPmfPXrwIYNGiQDo3Z4US9AB556Jmnl9772KOs6uuREcBRBESKsrSoa+vrRwCY0T5v3kqYkumvi0E4uKEBDfWSvUqOHyp4RSKfIf8PaJJWqxCkzHHgOAEbzUswm/8B3d9xIJt4zKTkXee/af8HL33bfx89ePjXiajr4VUPN9fV13Ebc9QCZEIr9yRr8BCRPnfBgvi+NQsrjMCbbrqppnlSc/TjZ17sa2tpcbQe4EBIAaCNOWpvnwciKgL4BTP/Zs7xs7656Ma2T/7upr9SFCecq8pRytrvtzGdqFinAtBoANkqmqnYq/s69+vZx82K/+0989vfe+Z5/0VE9wGglra2yPa3fLBv+VA0Z2pvb1eYNi2aVFuuQQfQkSTpvHnz+tva2nieOdNSAaB58+ahvb2dFxhHyqvmnX6jlUuaNXHGpuiHBVahYGImRKRQ6uvRMyZOU/Pf9t5rW8574/PD6+q/D6AjH8WFks7wWVwhj1YMRktLC7W0tAAtLbCWrBYgOJCcwgf5JMdKDvVTUsFggAyXe+Rf3roMkMDA5lW3tx8PlgUB3qlEEhSALQzgBwu0fK/476KlwwPUKxw1YV6UMwCD/rsULQ92SGhFRu5pUxFXHX/0NIyua8bGndtp/ZbnOJfPE2cZJAbqdIYbq32e6BtRbJKNYH9LBMb5RSsm4rXRhZljIkpjoi9HpCax0hkShTQHqLgGa3duweot6xO0t2dvAiK8CaBDm7evS2NmtWb6Glo4b2E5UVGZmd/1z79p/cKeHbt1VV1DkmWpp78tYCYgWQ7jZg1kCkCm+f51y3P9ujRmaNPg/5g/f3753AUL4jk330xHenwTM1Nra2vc3t6eveHiC982aOzYA1Vx7va7Vz3y5ce3rB9MUT5lIkIcmWq/poIHFBhRRrrQtT+bMmN68u65b9v5obmX/3J0/eDvEFE/ALVgwQK0trYSEWXzZ8/X4TutvMK89nb6+MxRNeVCbWQzJtIFv/1t1ayZM9Xym28utLa28mHkWMrM1I521d7eDiLaBmAhM/9sxuhJn/3lvX/5xJI1j+aiOE6jqiTOItkawO6HQjkmT7W8xwQklKDQ15cNqq+LPn3Fx/UHzp73rimDRrZ9pNgPtCBqa2lDi5XjA2lqHWt6wYIF8cIBegvwtZGe3Pxk04YnNnS3tLQYs4WIQ/01D8g4OLKqtbWVFy5cCCJaCmApMz8VXfu1m35+zzXDVFynsoypskps+Fa/8Eki9WwLOLE3pII0n0CmSPaD3x4ByF7C4CWy1S5Yw5It4QvVDcS4wf0S9QsCJi7w4bCziDHpHznDLwygSAaU6G+ZbvfuAU3ZJ8tecWdjYgBdLG0Ojcxtf3RwWQCNAEBHYOShxg0f1TWmYfhNRHTHwb3xbdmyZQkRlXtL/R+szeWn9KSFvp37d83QxTIoYgyubcSkERMeBnCyIrXipZ71j9Z8hFCUk8yIA3F+v4ektXjTjQZMIA0AfnbDu4Bh8pcqMRpdaoz5d4W3Qi5ByEBw3j/ztQUnwsShgRigDtdn2U8oi2+ge8MCf+PxyYAyAXUMrmJgtxkjWEMVIug1GdTpCjpiY/256sJkzl9igi4DPBJQQxRoQ2YMyWIEyivoTJOKEzzw6LIhn/7e9zZc8eZLWo8aPrzdRkQIAHp6evp7ir3UXyiQqXwWAWBkkSJEKl296bnBT6xdF584ccowwAjAl57yl20snrppE4/+zozJk7/x9HMb0qpckmgd+rcMKUyamQgjGEtYjGmI7ehTxzSAKEuBFByTUhNHjVp++qSpIzt6er7UVFf3VXk3M9O8efNUW1vbmG9fc/WIHXt3I1dbQ5mNPDIARBF27NnNOzo6CgCwdOnS1zh0mD2Elg6DGxq1lOmX5gPg1vDRA8zEkK8ZgCSTiiC3oTElxqQdi4ojlNNU63JJffiKD6p3zr34h+dPm/kdlDH5xhtv5CVLlsRnzDhj/0t1XRQjM08honX27/NhtuRISujYs46l3xNAbczRvMNEDeVzZqbVq1cnRFRk5h+cNnXGfeMGD/3BL29pP3p3Z0dWVV8fZZzKgnbVD52skNRSIrefh4LFyta1WurpUO956zvVJ6/852+cNHrCD7bv2jV50bJlyVWzZmkiygYaPYdrC5YsiUmO72auBfBJ+9XKue3tfyUiLFiw4KBI4EI60je8ZAvNfHhpEHxDQKaRVVVXq8vPu/Dxf33L5V8lopXBM9SCJUtU65w5gDH6NQC0t7ejvb39CDth+CAXJ9ACkm0fXLDb8qTbwwoBHB5gSGp0aCP6Fih8951yHnQnl9kX/QhgiccJQURM7vP+fvPzdzh1Iui0TwF12SdAAKpEhXCFrgpUkLkigj0TDqxKJb5w1tznW9/1f67Jmut/vHPj5nf8951/WXTz0juyqrgqykhDR5bOQnxUHlPi3u0MP/LvsjRzabuA69ChgNurbGWlgCiKwVUR0mqFXFwbbdqxRX+17b8uu2f9sivPmzTr2O7e3p6G7373u8suvTR6PQqbhS0oLIZ71jx54fJ1K7/4lu/+6zl3rHkYSXUNZ1nZpOQxg7WGHK1i6MGuCrgGoLVGkq/F/U8+nm/5xv/5pwumnz7z6Y1rv3bSxGNvv+8VWNF2bUkF7HvvWL+i5V9+9ZUN//qbr0xct38b52rqYtbaHiliAnUJKZSzks5Uqj76gY+qy89801fOG3/CfxHRbgBYwKwWEumFCxdi4cKFh3un62Qb8+UAxjPzYgDHAzgRwH1vmT37wR2jdiRtbW26paXlIMPQPsfJ9XYTTdsH4HPMfOf3//b7W7/zt0X5ff29WZzEUcqGpkqMFkNIB8gYZH2ZjCiXoNDbUZ488djkQ2e844bPnff+jxLRTsBmMsydm85rn/dSNAUXCtOoqmoNAdDM52/bsye/bc9OVCexOn7SsRrABwA8e+KEExeEt4e0GTjOgGbRra2tCREt++Edv96Yz9WNTPuyLMo40mSOezIPqzCfDsaH4ugKni0y1IhEL8ekYJbIyopIPoJaHTA1b5zFJ3aUlQey9Yldn2xGkqSKEkyAgQOZZISrkyfuI/Jvd+jXDdGnobpoJwmCkT3k3uEvVKrA6pVAqIJG/mOr90MbQ0ZnhatLsyVAa83IVUXjmkb1RkR3WP44bIqnRPx1Mb0+qcpdv/rFTd9at3tLOUpySV+hTx83Yboa1TD0iXKWXpmo6BRm/hsG8NA/ahuwhxDezGdhSOvfCNJiKig38B9yppBlF4mLyCZbDpSqAOLwdle0QFzLNp3IGB4B+yln0SEw67yhaj3zktKktRS0sOOwewd9ql/lMifJlCoBuiEDH63AO0qIOAFIg3IKajeDN2RQ0yMb8pfnOU63NgFD5wA6QYHGKugNZWBXBs5ixFGMTbt3RV/+9a8m3vn44/9zzqwTPr3iuQ0/P/HoidcCaOzr779w557dTx/o6wNqa6DzeejY7EuJqmuwbc+u/OK2/xn6qy9/9ZtPbt7cdML48V3Wy/iKGVzS3/r6+kYc6O7+16a6upWnTZ3e99Qzq3JxrgplXbZ1CzzYV0GKMQCfXmVLFzuauwnSIKVQ6OsvHzVuXHLRmec8CmAaAVeHKSMi1FPg5NVbn59SKpdKNXF9TgxMbVM5D3R20OpNmwgAlr7SAR+itfg/c6OGDlfQOiPlDVvnErF7ovzZbJ5fNfvdci4lOVTNkjpi6ZZEMYo9femgxqb4XW+e99zP/uXTH41J3ZUZou18uT4zMy1evji+cOyFg8cPG39Sd6Fw5c/a/zTklgeXRPO//7U3FMplcJrh+e0v3vyms87gh9at3HfG5Jm3E1HW1tYWzZs377BBGDJ7OcsA8PzOnbEqle5f+M8fO+OkGTOf+NiPvjF2a8ferKq+PtJZate2dnsLBaAao0KAK8EdssyWi1jTey67Yv8PP/Lvvx9e1/jFd7RcHrW3tz8C4IjKSktraWmJFpoCSzXrdu94x63LHr7inkcf7E9LJZx90uwT//bYQ8U3nnLGs0T03Ct47CtqRJEt/W9K8IvtFQKCTGnkquupurq2s1gs9k+86KL8xr/9rWgfoRfOnasPhoWvrjm5JPLSdTS4iAUsWF61rnKjoA0adK4gF90LikQRwGyKkoXndQHsDRu2L7XgUtKM3VlethMCSAivWHy9oqZsn7yT0AM1FrAbXO/gol+2RsvJWUFs5r5U6ivPOObY5PMtH731xDGTlVLqNzhpdNtDKx/78kODB3+l40BnGkVx7I6NsFttfAYGPK9UZBG4mKvrKjGCNF1tCtO8ThZhBFCsYiRxAuQicFUEzSklDTW0ZNWjDf3/039Ny8kXrvnUmz/4GSxcqDdNn/66eFTCRkQZM5/426W3fPcLV3/z/Ke3rkehvx+5+lqANIG10dMc0ILt+X/OCyEQn8CKCBHh1tUPxvc8t+KMC7c/fdt/3vjz77a+5SM/bV26dEfrnDks7x3YF0nPXLt2bfXUqVMvenb7lrH/vHjB+x5e88Txz257HhQpna+vUVlW9g4vAqIkRiHtSwcNborfesKclT9+9xc+mrN7/OSoqIWHyUwQfdy2alXu4mOOOauuqip5bv+e6Oql17/tj/feXK5vqLt//Jijjt6yddsTJxw16eRbVt7bf9lx5y9fjMUV9x+GtgwbTXtsw2P1B/q6aj590ftO2dW985PXPHXHB148sDdNVC7WnBndJWdAhpFXayTGOkKpp1tPO2Zq8h9v/uif3nvCxZ/o7Ov+zPr16780efLkoqT4H4am2NOx54ShTUOP2d/fe/Svl/z1B7+9/Vq64sefubCj9wD6CkUopTB00GBUR1XFoUOH5K555JYvXnnaJe0ANhKRXrRsUXLVLL/V5FBtHlHW0ma0+8wx06KGqBp7CvuR4wgcwx2XYrZKh2tfLK7weBN2NcfFaHLpyvYuLcdGwbGCuxcI9hFDTE9vdVvoZOfJEcu+3xt+JgrpeukMPm377LY+if4lMV7t2lCV/XPDZVQ8VPC/3B8O1BOc/T9E1gftIOFQUVPB9jF4tC8YTMi4jOaaWswYM3VnxqwI4Jeaa/nuj+vW7b9q1qz3rNqz8eMH0s6Ec3HW39uDqSMnlM8++qSuHuC8hppkl0SnD/e8f6QWbD/3pp78N2SSSiwhSond1+638zDYZwRKLVwUVHGnV2wGItrvaMAbAv1ovAzwhkjIxWHKTdCEmaW6qO+Pud9f7gFKxECWMLKxCqpJA3sYyCswEVQSg5/LoIcBGA1wmUBKDFrbeSWbjy04G65BwyOo7Rp4toRsb4oIESiJ9JInHtUPPL3ixFvuf+BXp86c8cmzZs/+zRXnX/DVjNMLOvr7gapqcD4H1grIMuRULu460Im1W7ZcdqC789lpo0atIaJ2NqmTr2hfhOmyIWJNTc2OB++88+tvfOMbe39xffvCmoaGSaUszdhW/3X0D4SVYxABLlK0J/heQCfHCkw6njRhAq54wyU3l0qlHY11dSsXLFjgisF3dHQ0NzY2dv/1/nta7njkYY4bG6JM2w2MmXY07uzsxOoNG8xNr0eEENBoaYkAbNi9Z/eKfEP9iVprTQTlNr7ZkTnedKjfc6tkesGCTjkD08tAI7AjFaGvqysdPXxE3PqRf9vwz2+49A1EtKWlrS2atno12xSgl0R5y5cvj+fPnl9m5hN/cv1fvt5+1+0nPLn+WWhO0f/gvRniiJFPVO3gIZc+ff0WXPfwfW+54MTZ93UX+35Rn6/5y8udYSnvnzBy5PPyGTPPqfr3mnuu+v6Xx2/p3p9WV1XHWVYONJkFuLDrTqS92RgADYaKlS4UerOLTp7z3Nf+z6feNLS6YTNaWqK2tja7zfbInRpXLboq+dX8xeWHV6/8yD99b+H81c9vPGH9rq3QtijQHx+5G0Orai99+1nn49ZHl77/Taee+4fbH3usvrq/v2/u3LmveK0MbFX2t1IERAoUR3CnkpGXRUSEJE5Ud6E7W7X9uZn5fD7bcPvtJ/f09Iz/0Ic+9Ke2tjZCkA78ejSJwEmlOjcnQCC8KRSGzugROSnVJsy3vqiMfYGddjH62adFuWXh0AXEA23uC0ARiXz2MJ7Bf5eD6TWcxHL9FE/8wDAbB9fIOEhAoeggBeiEwFkaTxwxnk48Ztq1XT1dFzTVNbwFQOe27t031FXXYP+BAxyrMApa2Q4qkiYyJEj1Mg4Xv6vUGY+S1vZ6ECwyz1Aq8tF/InDGqK6tw6Orn04ffWr5tDXPr7t1475tn5s4eMx329racu985ztLzK+ddR989sH6M6eeefaPbr3mUz+98w/nb1q3ppg0DUqqamopy5hMtQlr/IEAk6YbYAu489YA2KqjpgJpvq6eWYFvevTO8pNb1/778MbmCxfOfecJC1+iP3Y9psw8+tYnH7joG9f+/IOPrF5GXNBZVUMdZQmptFQCRTDFbAAkUYJCX386dsjw+BNvev+yT134nn/q6OiIz12wIG6dMwcvF1ElIl7Q1pZrmT79ff2l0oe/ceMv49sev/ekZ7ZtBBjoLvaBH+xN883NJ9/x/EMY/9Twyz7w359v++57Pvf7QfmGXiJaKtG5lxlX12befFczNRZyFH/w423fqvvdYzdcvn9fVzmGSjRrcxSHlSNSHYvYRMXLxb50UE0tzZ9z5W3vPeHi99E84l0/2/WVybagx6FkGZty//Hs2bPLzFz3+wdv/uJPb/3djLXbn4vTcooHVz6QISZGRNYSy4AoyjcOG3JZVVJ92T3PPfa140ZMvIaZryKivvmYjzZui+bR4Z2b04b+CzG35V7oeLFhdP0g7Ny2AyquQRYEAwS1VK5561CwuMYs3UBOQmKJXv9LzX4nyVy6Plu9INHDIOIoARjHwJUFXSSqFhZHJLmNfT9NNM9KajJvMH2wz64wVAl+vN6oc85B6d0AdVFhRFZ8I98e+gqjYgI8L3aE1TWhqlCaQCpCVu7Npk44kUYPGdtKRHrBkiXxwiPAt/M3zdbzZ2PTF67/8al7C13IqlgjyifVqmpjQtFPU2i8nnUn/jc0ZxDa7aNwSj1sgeFF5FnJfReAAVdkIAQAA5+q/L5AWXi64nKJQIlRyO55Wp6jQwjun2+64hnYN9GsA/oPDODy4EbL1xTDFIc5Jgfex0AUg0DQEUBpBKxNoYZGyKoYnNkNhAjfoz0YLgGsNLLRBBqkQNtSpM8Xgf2kclWJQkR6+frVvOK59dPuWPbE9355w7WPnXvaqft2dxyAiiKlIwWo2KSkaI2opjp7fu+e/K0PPXjsey66ZPj+ns5+IrrltTC6FeC9AHD2rFn3Tjtq/ORlz65CLl8l+70OEkqhYc1iYLP3fJnhG+CSAVlSV6uOHjX2xmqbDy7pQdJvSpIzAdz9yMqn37h7316qq6tTabkcpC8DgEJXby+e27r1dYOMRMSzrrpKEdHOd3zp0yvzdfUn9fb3ZRGFR3VyJX/JuCEyXaRzYDQ7w1GENpCQQn9XZzp+1Lj4e5/6/OZ3nHHuG4hoS2igHSqFKGxXLVqUzJ49u9zV3//hf/rBV7/62xvahnM5Q1RVlSkVoXrwkIgUzHlVhVKWEvDEs2to5bq1527fv+/cdVs35aeMPfr3CxYsiBcuXPiSQlY8urZAwSZmfsPXr/rUkk/+4ttjO9KCjuJYIcsMj1hB71RNIEOgNXK5HHo69usPvv29yXc+9Mn3Da2u3bxo2aJk/uz5ZToEUH6pdu6CBfHi+QvL//n7X3z+s7/90TceWbEMWZplcT7vTknnLMO+8h76xm9+jhOmzLi6p1T46Lyz3/jL9tb2P8m+qVf00sOQyFlHitx5XV6wGf5nYopqatRf77trRKG759kLZp/90GVnv+F37e3tWRCle1VR/kN2yclnr/hlzZrjudhdK2emQdJFnah0SUSVxor9Jdc5r7QzEgEmqniHAAwHhVgi5kCFI+n/ShO9UPnOsACpv66yZ0JDtql1mtMsqamKmmsa7qkhun/Hnj1RV9T7ucaauvf906IFV0KROcA9tjU/gsikolAbwtHcA1VyYKrS4CKPv+Tn9eDkcLTSVRjOSdMUVdU1Mee0/vUtf+Sd/Z3feWTzyuj0Ccd9a8GSBfHCuS8tR16qiew7c+qZV6ze8fwxP73td2dtemFjub5xWL6ky8iy1Oi+ChIYnWS8SA5bBjwoyNNyv9ZEIKqra8pv3b61/ONb/zB9yfrlX58z6aSbe/p7xtbX1LcP1J8rV64cNHPmzHHXL7t3wWeu/salmzau03F1I1S9isqcAWUAisBlYyxQlKDAvdmI5qHxFy798KqPnD/vje3t7Z0XXXRR830LF6ZzWltfUsgxc7x806baWUcf/Y4Nu7ee8u+//fqxty67pz7tLeukupY5IeTiHEVV1XGqddbfV8TKAxvpud275r24d+95P/3Ql37HzHUWC0Qwe44Pu6wm0ITCqlWrcjNmzEi/c/mnvz20rvnS/7z6u3nEOQaYjKFryMiKQJoQlwBkmlWSj9933pXP/tv5Vzy8btumadzGz5CpXH24sYlsKzNz9fxffvkz1z5+2wn79+7RuVxdRhGhurk5YlspFhFBxQQdgXs5zXr7O9Vv7vgjNTQ2v/vGJ+6++HeP3vC195962X8TUfeCJQvi1jmt+lDYZ+Hcuenniv0vDm8a/EJe5TWYoxBE+gQyYSK/79903Mos+UjJvkLvoJaqy4b3KtcquTCieWmYWAVgQGTQy0Hvu2MvjytwhZXnoVOI/I2mb+wDLZAUzQGnj7tsQHbP9RWaKuVy+HpZcC7j4mALwt1LgHfUuG0JwXOCRgxEIKBQwMwxx9LJQybWy17al0ZFMIZeayszt078wO8/31Ts69OquoryKsbxY6dVlTmj9vZ56lDZAP/I7RAFqoMJdccuBWB2gPcvnEfHDCTMKwwKt2AciKgIu4uxgNBZYK8jm3JmGdbtOTHfy15EA0REUQSpSnKdqFv2zGhfYPmeDsGU1rcSK4Az4Jg8+IUyuJtASWTgUZ5AvRF4TRlqVgSdaEBHgoDtijYRRZcvrQH0M1gxeIICjchB7WZkW8rgPaxyuQSISD+39QW8sHPHqSs2bER/uYg4TiJkqZFX1nOfy+dpb2cH/nzPXaPfc9Elv0OGydb7FgUz+Iobs62RPHbCd0+YOOWtK556cphOcszlMqnInvXkIsFwZZcrqpGRjxBLGWIVKRR6e7JZx50YzZpx/O/b2tqi3pNPToioYK4jvWjZsqSxtvbm9Tt2/NMjzz5bjTQt63IpARg2YcDNU3+5hAeXL+8CXp+UUcCUuV7GTJ/5xfeq1UoRhIYcxN4ghhWADnwgEPBu3IY3WftVQkRQsUJ/X286duy4+Aef/MLat512zllEtM8axi+7F4eZaTkQzyYqb9q5df7Hf/G9X/7upmtRVV2nqSFS5SyLwBopNChjU/USiMCMGiikqc6u/uMfuFRKr97deSAe1jjoN7bC7GFTb4LPU9vP55j5lNseX3rvtQ/edSyQZzCTC6Qqcvt6EOzpoShCz7696XlnnBt/7vIPfn9ITc3TLxelPFwTAPqRH339C9c8cMfXN2/bXK5qbIhyWkc6LYMzLSdaIs5XgWrr8NTzz2Wf+PG3T9t+YF/yydYrb7H7aF5TI8PoCXOwCUwAKYthZRW3ZpBSlLHm9iV35m5//OG5bXfecvqSFY9cOefE0/55y+7deUvb12wU+p0qFb11zGpkrZeHJPcoX4CAJSeP2cmd0OD3eMG7/UQWy7gFX3gFQCa12h7BIevEdMun9xv5/vqHCJUagMakCBDLKDxK9OmbHFSpNvQjGR4RSr092bSZx0WXnHneX36NVqxdteqJY2cfP5uZ6RNXfzdWcQTkYyCJbEaMdsclGDKRM6rZWjey/9b11NEoGIzTNWz2eMn2qaWvgUBZFlU8W0r02/TejFMQQdUMHY5b7/tbGbn8N9fseIGmjTzqm8ycAHjJFL7DNbv/hwD8dfmGp2/f1deRzzc165LOnBvDGc4uvRguKicA3uslebLoYjPvxEBWLqO2uiHeumsnPfzs8nfNmXRSc7GcPi63AqbA27x587KZM2fOXL5p7Uc+89tvXrzphRei2vxglCijVPnIJDKANCPSBOiCbmyqj95//uUPfOT8eTdsO7B77LyWlgMg2gNUyNJDNbIOqs5lm9ZM+8TVX3/fg6sezse5+qyqiaKMzfxqZuhArlchQamrUL79sSVD5h3Y+84bP/dzzWVOiOj6I6H9jBkzSm1tLRERLVu3+8UL73j6kVvuWb6kJldVo1gzwUY/jVEI6Byx7u3j06ef3rnwXR+/u7+/f8uUMUdvaG9vP2zFxgVs9m9vPrBj/PimEfRft//PohuW33lBZ3dPWt0wKC7rFIiATGmjP2xutzbyhKAoplyM6qpB6E9TvWTdsub95b4f3P/Mo2/b2rv1s2Nrxz468JBx0S19hcJnoyjankP8zWnjJt/48MrHmWNFDom6KJ7V294N4yKBPjAispUq8CrsvlENdnEAVyjYKkYfNJE01ABBC44daHqRvEdwtcgg7a41qobdOiCyqJesDrbXuQNw7JETAMMUH/PP1k4oGVoEm78gxyaFBirpwBQUeOYfAX+uJfyX0qyedLjB6kzKCArMKsnR0YPHdgF4lmx9iUPxVtiWL18ecWtrtqVzz0l9KE7Rxf4Sk4qOGXUMausaFipS/Je2v8AcMvb/mjTnImB9UBKNlaYaHGyAUkrZQ+y9z8ABPg6Bh1egYjxYDOHSQ938W3wie7KMzJGnBwoAGHjihNFTzhPCvnCFfa63y+zb7P3ilXDFA4IxmD8H7GVMFXQ9gaYn4DgzAjGyXskkhtoWAxs0KCKAtDEepMNMQApwyuDU/E0Mw/BFs5+KRynQyQmiU2PwiDK0LqqEoBRr3dfTpUln0GkROk3BaQpOM+hMg8Gq0N+f7ensOOuGhx8Y2tzY+BMiote6wZ+I9PxFi2Ii2nT6sdMeHTJ8uEoLhTTKNCjVjk4Qc19An801N0dk2drVyvyQIihinYviuDHOr//whRfvmjdvXvbBCRPcgXrMTC/efHPGzMNWrFn5haefXZ2Lq6uiVGuDnTIG6wzMGSKlVGd3N+bPa/lYdVUe9y1c+Pp4e2bNAhHx6OEjdRInBsBb/mCu9E67s3otzylFUET+nPWBawqA0gz0FfSIQYPj1vkfW/a208759b6urkusJ/eIQBQR8WxTqvvS717351/+9ro/pfnmZtbVsUoVQBGZvgj4t6COM41ymgJZFiVNTepPN1zLP/vTH77PzPHs2bPLrwDEcRtz1Nnbe9xX3v3Rm2ZPnFYs9fZkkWYoLRFyeyED0BqkM5AGyn196dHjj4nfOefiX04dOfozRJS+Un5lZkJbS7Rw7sL0B9de8x/3rHz865tf3JLW1jXFzFplYLDIqigC4hisCJozVNfXRrv37U2/f/XiWb+8qe1OZr5iz549U+xz1cu9+1AtTdMUwD4FFTnwDEndcULIRpMYSDWYiKoHNSLVmb77sQfyn/jpN994xyNLrxs3bNhFBw4cmODG+RoahfIslM9OZmor68JKeOH3cPajfBDAJihQ8De8cHbiNjSy5Ctyn7E9SByB44/k6AYLDP4eRWUE8MHaZcaYsuJe9FOwl8iIcTJyzEYsEClAmaIbMRNTppNzJp7Y+bbjzl7ywp4XRs06fdaYEfXNK4mIYyJWiQISAmICR2bvNYsyIgYrA+ik5L8zrtkALsi+Q2f2+H47w5JenwAhM3cSEWmtwakGUja/M7tHmBS0UighQ/XQofGtd91Qvvq+677BzP9ERK9EjlQ0uS8mte9Ab+cIHQHIR+C8AhJl98K6a6EEWzgQAa/gCaKInA+RtQZnDJ2x2cIBoIAUq17cGAH48c6t26+xz84AwFazBIBR/720bd6mrevz1U2NKFVpQs7uzbUKT5wDmlgXdZHfecYlm7552b9e3tPXV25KanYa6PPS65lNxU1wmS958cC+T7f+5SeffvDph3N1tc0ckYqyCCYlXd7rAAuQaQaUTpKq6uyZ9U+P/Xb7f70HMaqKxeL03t7eMfL8l3r3vHnt2cYdO4ZNHjpyzZWnv+lX40ePi9JyOUvYHL9FDKiMEWVAuVTQzYNHqA/OnXdXg8pvX/HCihuIqP9we9KZmVrRit7e3jEj6pveuKvnwFvuWPfQBbu3byvWxNWx1hmQKCC2+7CDKrxawx/jkWqUy2VAa1VVVc1Pb1hVvnrpX8/+0l9+9sija5d9gpnfuqCtLSf0vvnmm43VTHRXPk5OBrBu0tgJvSpRWidk9no7GefZ1rCTOIQCzCjGoLfrnCPcYVsOcKYIUecUhcuW8tXZLXZQ8kbl7hF57GSpjazBRteIzH3GOaIC6SDOauPIY9tPY7SZwRgtZZ13IugrQTmcxGF5pvnOOQfFIrbyTHSJ+dh8rkiqs1byhKODm+oKqiMrl3XT0JGx0vG9AM7e19cxz2aSHVYtMDNt2rRJE5F+bNPKhme2b2RU1SguFXj8sPE47ZhZWzVrNXTo0NekW/83tgrwI0aTY47A7AOCP623QxgsNARdRqa9gcLnhII7fK8YFuSBi/vt9qKEzFr5I88UT7eYkB4AheDUWTIImQ8DrgtD9qTtZqByBh4Xg4axUYwASGtAZ1CIodYR6DlTNMWAYFuqxwkzAmmAMgAZeymXaaCsjZIaTNAnJKCTY2AMg6ms4gyKUm0Ol05TcLkMXSqZ3/0l5Kqr1RMrn+IVK1d+LVIKTz31VPWWLVuqXyuYvOKqq7ivr6/lrFNOuX7i8JEa/aUo0XDeICcMMcC74xQyWS+f/ChkGlxTXUNvOWvOiwB4fx7Q73gAAQAASURBVOf+N/cyj7JzQ+3t7cpWSq1f+uTyo3s7DyCKY+V4DWwLCABKRVQqFaEUnR5HCXCQuHl1Tc7FHTloCOIoMsUaNMyPjNkyFw8Yq2FlWRteABpeYZDW0ARdzMrZlZe8/dkPnXfJ23/yk5/8dHBDww1E5KpKHq6JwbK9a89UZj5/3pc/+6lfXdfO1XVNpEsl0joDs3ZrWApksHhbFUCx+TvSrOI40b+5+dr6pSueuJaZ527dvXtS+J6X6so8oiwrFp+dOHrsHZfNPmtdopIoTTPNmVV8NjooDh2VMSKtmdIU73zDJZuvuvjtL6zavGqEBUFHzKuu2AJasO7FbZ+5a/kj39ywcV25Ol8dlUsFgmYXGWAy4NvsRTFDStMSkup8vH3XjtJ/Xfs/J9300JKWIUOGvLh+7/qGV5pmLQB27NixLxLRD/L5XGOmLaOIj81GbkjAgC2EwZkBNkxQtUOG4OlnV5a+e+3vT9q8+8WNgwYNet5WAXxtPE1wpp4ACknVsbDGGSRG/gbRKLI8QyK7FeBAgIcdRCbF0r3DDpkIzrgLRa5mdgBdsibsV8ZTHcpjor/LHkJzYCwHBqEYFtKT0NAwAJwi82PSPiNQYtI/KZ+gr6ezfOzE6fr9cy7/ORFtrK8dNDHi6NwlvGTA0U72v8KjAirtuEWeCAgVUog+JjY/Qs/AbAcqpPKrbhoAykBLKUuLWZYpLqVAMQWlmQHkGTv5RwToQomqa5vVT679tf7uX3/1MWY+deuuXccDr97BosForG/qUVHCLv1awZ/z6OhS6fCQJkAZQLDXHd541mJIaWhkUKSqq3NVa2fMmFEK+9Ha3hozs/r5XX8+/daVSyNqbCynsSaIgRorUGL4QgFIkgTl/h5++9xLo2++7zMrDvQeGHn7rbf+vL6+fhcRvWTaJgC4NR/jucX3/ul7tzxxh64eOgzFJKMsD5NuF9kf5WecyezbZQbilCNGnN3w1H2jFt/TPjuXy/2sSDzXvuKl5iMCgGFNTZd39fcs/tA5b71+7pRTe7ROYxXFRg+WNaJ+jbjAQG9/dPzYKX3vOfmS53p7e3edOfXMHhsdPmQjc0SErqmp2dFU3bho+YZn/m3piod13NiUlCkFcpFdW4COxEHieZytQ5NTDZQ0uJQh7StSXiVJRDn9u5v+J/3sH7/zw0c2rListaXlfa1tCxIiYjlSJJ/PP7mgbUGuFa0btu3c0t4wcnhUiHXKiQJicoahLD3v5IaJ3gd4cqCyUjYDyh3B4HiUZexOfnp5WrnOjWFGLoYQGksIeDkMshinEltVE+wFDP7yzpLAaCO4PbUkOIG1j5KSH6VL7xwwaJLvKnBz+BPgbiDIJHH8EDyLHK0d1ZRCSWcY0dCM08cfFwMYWyjoR+29h3U6EBH3Du1NmPn8rFT87PbtW6mGqiOUMkwffQwm1jb3vlI9/4/SKoSDY3YKGZ59RI591WFvw5GfbMsigsaMd8KDYi+9g3cKY8vXsBt0w4UJWZt2AQV6z/0bEtQOuApwBiIg4Xh7lyxugn9eoORI+gaRSgxkDB1nwNQ8WJWNIWc/Z84QlRPQUwpqExvsmRnPqpDEBFy9AU2SShhEEThlaNYoDwWyWQp8Rgw9gcA5DSpqqJIGnHGowVqDMiYG8ZIVyxrSLJt0/PHHT2gcNOiPRMSLFi1KLOCOmVkdKfBmZjWXKC1n2bsnjxzTdMrME7oBVqRsGoLrs58oJ7icEPOgEIqAXIxiuR+TJxxNx0+d/m0ieqTYV3y8BjhgeYHnzZuXERGveG795+9b/oRGLp/qchYyqOclAFCE7Xt392j9+q/vUUOGozpXBc5SkA0fiPhT1vVXAToGeKUHCmGlGQkTyp0d6t2XXZ58/6p/ewcRbd2/f3+ZiLqOsFu8aNGiZFT9kG03PHTfRx5Zv3pO2tefcVqOUCoBpRQoGyeFVIXzCo7MYekqMkUjiFBVWxNt27MzuuXBey8D8Hw8dOiLzJVunUM1ATaDBw/eSkRLLj7rDT84bdpxVOro1NAAlzMnLIwYICCfQ19/X/bG8y6Kr7zgko+mKdY2N47KH2kev/BuAZhwoKvr5paWlnf/7rbr/s9dDy3NqqrqoqzfGIPmPDL28wK3uiAR/3KxjHxtQ27VqpXZ4pvaLygCFzTkh4y373lVIBbwis0JFifvrAwR55CAUs3QRChlJYqbB6nlG9ZEtz96/38yc93q1atfkaF8uMZeQA/4Ak6QO0OIBEgYTleSnhReJ+tbjBIrBrxZJ1goBAth+rjrlL3fyg/291ZEfP4OLRYjVdt+yLuIKiOUCqAIfk9oZItixSZSmMslKPR3lyZOm5H74jv/5f5Tjz72C8uWLUuaaxrur62uXSRH4WQom7Vo59zZx6KuRJSKkej0aQWpIOlmck+Fw/V1IJgAJQa/O9O6oAmEzDgtOfN8AG30HlITbWPmqL+vj298/J7j17/4wqmx1htb2lqOOONBmqw93cMjGmrqfzxh6CgqFfo51srqWa7gvTCzxyxvn/Bb4fuVy8FGLpYzUCkDlTRyWmFwdWNXf6nwb1v3G0MWAHoKff/+75d+dgkAfmLzMx/cun07apKqnNsnBhhyRwocR6B8Dn2l/mzmlJnR+859x5cGVdX+fv/O/TvmzZuXHYlMYWY1dOhQYuZBf1lxxy+/f9Mv07ipgYsoURYRtM1K8keEIUirJMe7mhj5mhq1s2tPdv+GFZcDuOHF7t7r2Ry381IVpVMA2FlV9eutm154H4A1bzjxrN8cfcwx6EOxrBUAzVBlRtZXSusHNaN5yODf5qDG9ZfLz1ud8LKKmIiyREXY09MVF4mVShQ4p2y1T1QaDc4Is3MsGdGZwUrIGFlZgzWr6rrm6P5nHsv+7XdfefczO9ae0trS+qHb1q/PL1linDLMrEYdPYoX0kJ91rEnc0NNvXlBLjAIA6MwfK3tN8zROnByUGJbFetVcO+hiOH2EXocaLArBet5IL3MfYbvHfB1Jp+7hxns8lThPjNOyNDQM2+UQkw+hZVcv91r3ODh8f5LI4PgxxJQPpGQquhmZu90s5dWZLHEBK1LNHbwKD1zzNRvAPjSqEGDth7uzaIru7u7h1151pVfBHDhTU/e26lLGXL9Km2oHxajyLcDaNjb2XnaXFOR/FXr+v+NrZIYRkNabxsHTB4YddB2H5UoUQ9+Dd9agSz3W0tIjtJhDv0Y7LwSPlBOFX9LF13cL2TGQOA7k0qMUVkmDp8pKKVcXzWRSzUFWQNOQuHuWTBeKm2fpgBONXiEAk0g6FRbcGQWFyNFXFKg5RrYlJlFXBbFaSOB2oxZa1O5i8HQ5JzUkKpalBF0ppEOzpCdCPDZCnoGoJtgIi8pQCoGJzGyCJRUV9Oq5zc1zfvyFx79YftfPthQV/dHZq6ZP39+2XrmUvFQsqlC+nKNAKA3y74O4IVpk4751dijxqEvLadyvpITJvaIDwrSc2BpF3qkmDWrNMU5J57cNef44zczczRy5MjdRNQvUaJ9fX1jmXnuijVrWtY/uxbVcT6iNEOFh8AJY6MZ93V1KMZLSqlX1maZGOGI5sFZfVXeGN0C1GSeAqEGmD2qjmrELv3DpJURoBQ4iVHIStmESZP5vW98y3cAbFzCHH/lK185YmuWiHj+/PllAEN+e/N1c7Zt3JAm1VVRqlPDT5kYg2ZxyN4BmQNStqhFLoGuySHNxaCaquyhZ5/Otu7Z8b6RRL22aMwREXTBggVqwYIFuePGTbh2TPOwZUlNTaTTTKOcAWlm+8NQIGTgrGHYEPX2c9+wYsaoCQ8mCd0wqrn5BRnXkYy9ra0tqgK21dfUPPHM1o2n3frIkvEpZ4iIFLGp5Ku1tmnFGgjkjVmrdj+vMpV6qaYa2/btqlv53NqLh1c3nLRxx45hr8V7SAQTRVJwRwpIhBDWo2acONpGne1nzIjjOO7Yu4Nf2LntLADjW1tbK3NvX2lfAGfwSTfkG2f0BFEy8yLlDbfATeeKRTkgI/tcDMgQRc6AiZQHhZUAE5wNDUbZeiBbACQ6Jw4MGTURvWRI49W2OIrN/sTMbInQVidkkfnREUHHCjpSBogLILOgO0piAKT79u3Pjho3IfeN935q+ZVnXPRZMGjWrFmZdb45OVvSQJr5PYOA+1UhuSqxnHEYUngD+wzXg+4Ona+vsgmoImA5iBPobMAT7Ts0A5mGzjJoZpTTMqKqGjzx7JP6ugdv//CIESPYHoB+xD0SRxQzNxaS0rNvP2nu+KPrh+9FsUSUgilworgot0ARkXXy4xytGuAgfdsZ5RpUYpR7i1wf5XnW0dM2ATizPl9zhe2L6iv23JBL8jfeuPKehcu2PVuPXJJxlpk5cmnGVs4SQUfMVY010fw3v3ffZSed810iunnixIm7AW9oH661tbVFAPiUU0486UDa/+W2h247t3tfF+WzJFIp+3RhCjSd6MFgWwbHCroqQlqlKNVlva2wa9yS51YUZgwf3tM6ffqR6H1MJiq2T5/eR0T7W05905qTJkwvcNpPKo4Mi8UKpaxEo5pH4jMX/dNRxVJxXFKb6z4SR6K0cpqivrq6nmJiyiWmJkOsnEEojn63/17oLQaDlRliEDMYWZpRVW29WrZuVfKFth+9p6ALV5w6eOQkAf5EpGfZ/J/poyfHTdW1gE5N2rEiK48CDBMaWvaHDNRzNQFMqQVYjAsILpLpNgFD0cFGjoK1nU55rg7GZf82L3HPNHLWC0YWR5aDHYJDCMQKZv8gbBQRbg+f1oHBGshtsuUalSLHV0Jod7Ysmb6ScxrC4XuZG0cn6a84zOV6xRWpwAO5JdRZHBHARcyeeIJqQNJDRP3BnYdqCgCUUhO05n8B8NcdnXtGZcWUUUrRXNuA40Yf0wfgHcwsjpHXETj+/3/zulbZjQsD7LyDm/VmuO+swYfA+Jf0G3u992LChah9CN0afLLoAjBwUCoIh/0yF7qy5WyqWga9cgBE/taBy5BsX8QzEjriyS5uZ/CUGdBmUwcpgFUGmpZD1MhQGUFF1tBkAiuNqByDlmVQmzUojoxHy6kDcsZFgLXcYjcFHZTxVqkIlCpwppE1aGQzFPS5CfjMHPR4Ba5mEEWgJAFVJ9RLGu0PLG3+1jVXf+ryL3627Xe33XTv5m3b3sXMk5j5P/bs33+ZBbwpAIjn7JCzbD2J6xqffJKIbrz8ggu2nTrjOK0LBUYSWyVELk2S3X02ehbmXjAATSj3F7Lhw0ZEo0cMWUxE6+Yvnh9iPWpFKyHLGspZNu32B+9vyEpljjgjcmEVKwCJrOfevH9vRwdezwihpIzWVFU11lZVGfAAwEWeGC41xGM1z+1OMMIC2sgaYUnEnMTRFW96y5a3nXLm54ioPJcoZcfgL92YObntttvyzFz1q1uv++yj61cPUdU1MAtONKkHbBWOHWfAwlwTETiOoBMFqs7rF/t7osc3rDsaAJbu2XPEGNym4+ilS5cWLzntrJ2N9U3IspSVXQ/QDJXZw5m7u3H+KWeqKy64ZPEjW7fqZbwseaURMBtBLsVx/JU7Hn/wrau2buZcUxOVI0ArgpLUTM02RTMAj7L2FYHsPpwol0NnTzfv6+qciig6Np8kuVfSn4EtUpFZG5GCpAiJTcba8odABK0t2LHFVbQG5XJ4Yv0a/dS+rfuPJMXs5ZovOEDeuyt8IQLVXGDZ2TqqSGCMAIdKmS+pRc6gJPfLjkdKscM6/uQ9pj9azjQTOSGRHwqwvH3X36NlaYpSuaxVPtFxVR5JPoe4Kockn0dSnUdcnUeczyHOmZ9clAMxUl0sp+mB3qy4fQ9XZ1AfuXJ+9OOPLfzGvFPOm01Ey0BgO2+aiFJX2KVUsoena5d67jEng10esaMY3NewWsyJ1CBrp0IXmz+PCPUfvkUAkET0LVJRjWbWYmzI8RMwXfbRbjZGa8wUlXoL+qH1T87oKvW3cBurvb17Rx/pi63jkgH0RVH0ZQCF4yZMuW/IoCGqUOxPdWroJw4U53CGl3UYYDQ6D17IRmJkEKHY3amnjptMp087ZVmpXKJyX+Hry5YtSwCoYY3DNiRR9OcNu7Z9ZN3m9VlVbS2VEyAj4WlDB1ViJGVwubtHnzvj1O73nv/OM4ioeISOVwBGri1fvry6pqYxf/0Dt59/x6P36bi+ibK07IxdQpAKD7M2mQw0YUkljU0EW0cMVFdj3a4X+O61jzUws9px4O4jXkwLrUXTlK9edMqYaWVSuTiC4ogUuDpmNKqoJle97+QxU/ozyq5tTGqeNFP48s607by9ppCWmscOHfmbGeMnUblc1IoIWmhakUGhA70bVKS0xiArBbb8qSNCCqa4pjb72/IHqj9z9dfqm5vrpuzs3jncvtox8KDaxq6GXA1LBpcz8qzudrwDwBamMHQXw4/IOtG0O9OaBcvBRu0sj1akTmoCoGwAQuAnCXzEQTa1w77yLBmJyG8vLSSF1Lw6NNqo4j7Bm+SqisLoKohxKs4V8157+LTD9R7r+RCOe4HwZ2AY+ub3BiLsuxP25DE8M8ppKatrGkwNqFkKYNuCJQviSuJUNotZVW1t7WPE+OqKPevfV4qKo9I0TYtZkUY1DcMZE08qlcvlVbsatz1t7/l/BmHQHPB7aVTGGDCvTnEBME44y90UXmQZU9uIGOANOs/nlbEdYr+YgMDrF3QF1ittDDrljdFKqR9cLmC9wg4LOgEHVCqpYRdLwYJLYjBl4DQD12ngeAWtUruwvBHEMSPK8sCTGrQ2NZFOBWcU+gqo5Gwc6YahlxsmEMMYiKkCygydT6EnaBMxPDcCH5sBNQwqAxFFqK7N84H+bv3Xe+7kj33nO6e+98tf/NOnvvWNm5etXTt8yKBBpx8zYsT8zs6eD65Zs2bwXHs+0Uulks7BnIyZ1aB83S9mT5m6S9XXxUhijdikHYqnP/QeOJpbPqEsQ5Km4EIxHlrTULz83Atu7+rqGrJ4/uLUeaSJ9EJaiMH19avvWfbYex966kmm+jpKCSbKdpB3wv5bEfYc2If+QuEVGRYv1WbNmqUBIM4lNyYqYrDUsDu4D+RMweBbIsfnxnZlJJFCqbc7ffOcN/DH3n7Fwv5SEUcKGCStobe3d/qZ5557C4Crntiw+vJ9u3ZlVVV5FYJFb33AGYYCJtyHQZQHYERJEu3Zu4vXPL9xGjOPWNPenr2C1OJ44cKF6Zyz5rzptBknrqjNJd3MHCVRZNJv4gikFHSWZQ1NzdGZU096ogbRUxNqa4+ZTbPLhyDqS72L2BiRqsR8zt1PPVatoZliIo4MsVkUd6jUnREUyAhF4CiyjheiTOs+AP0hDHgtjYL/ilMq/Nb/2/5FxhJiFXFHzwEV9ZYuKZfLFyxbtqz6tfSDYaOkouhxKDkX9EVyEVmABjsv8kDjwxna4dMCIGKloVMXoXPPRQTtjX7eBlg3jMPUK3x1rcX+fsu5F6sTp01XWbEn6d+7Ky3s2J0Vd+1KC3t2pYW9u9PC/t1p4cDetNCxLy3s35v279ub1URRPLSuMT5u/OToqre/l37ziW+t/sV7Pvuvb512+hfPXXBu/FLpRxoa5kgWD5aEUD7XAe4zB8YMUeysSQp4xSSYXwJSX6emNVVTxkw2y4El7T+M/IZOFlKgjFHV0Kjuf/pR3PLovZ8HwAlXHWcuP/LULAKVc3H802Kx+Kf5b3hXYXzjCGTFUkRM4IqKOcH6Dv4Zyj6XoquDz+1PCmZKSJ08fmrnpOYRD3X29n1r6NCh3ba4VsrM0eb9u499cP2KoeWszIiUEkMEoVMJhLS/qEcMGx69/eQLbmkAftrR2/VRIkrbXqL4hRsFc8TM0ZTp00/vTdOa6x7727Devi5QRJSS3zfHWZC9hbAQB0zkJYJNazaGS5zLxbt27aIc4i8AqF48f3H5le7VLpSKmD1++s0TBo9AuVjWURQDVSbFcvyIMXkA76vN1f7YLOGX3f9OANDU19S0u2v/1JOPmvbdcyeduk2nRU0UsTH4LUsJvgsy0CoUrYtgef5nm6kUZxzpYpbd8PTSE+/d+NgnhtcN/xIAXrJkSXTzrFkZAIyqH/7VRKMEUMxMzNo7Dd32noMYy/7JntHkbL8K9SvbjBAaUAGmrER8lcOys2okL3mj0RqKXq76q+VuX/mTnbwFw+7jt1ex9JMr3+8ifAMVoL3ajTfQXL4zfg7cbeKAPIQ65Uo0dbDYshH3tMzNg4bRuKaRTxHRgVH1l9KRGHDMTPl8vvaeVY/0bT7wIsd1ORS5GI1pGKknNY35SpIkP9mDPf9vD+EhmgekgcB0TgoS1pTJ5yCqJnvJAjPLhYcFcLJjDLeQhA3CXyQMLvcGHlKq9DHI90RBJw/R3PKzjCzQXdKb3IZh768I3hHQQTG4R4P7IqDaGoYK0GUGxhHUrgy81uSe+9QUAmJGlOahV6XgjhQ0QyGrY3NekXdzuWoMhqTWkyNFSWTs4RBT45HiCECzAg0B6OgMvCWD2sqgTkUKRLUN9SiXSvrBp5fTg8uXT7n9sUennDh12pbLL7zw/svmnodjG479eF9f3zN/eeyxm8ke+cCHOLuQ5ARWoHTDg3d/ZeaUKb94evNzaXVVTplIgiGoqeIupw46hgEzEJVTINMcMXDS9JmPjWka8pGOrp71AP4TRo3J+YNg5olf/K+fjt61fx+S+jrKZO+eCMQANQnNdu7d97KHt7/Cptko8j8npBZBUeTmTPkJMdFpKQcoYp8cXzn4zQBlWVZTWx9ddsacdSNqG27d07FnFoAVfARHC8icrNy/f930xsZ/WbH1ubM27HxxaAZdRqQSCD9rz0uOz13XzHy4ZRMAujiOVf/+PVk+yc0GML69vX0n7Ly8HKEk2txT6v3JUcNG/fjkKdPzL2zdAtTUAZyavRmk0N/bw8dPnFG45Ow5PyaixwaO7UiapVMZAK556J7zdhzoaAKpEoFzIg8k8lXhoKrgGa5cV4qEhysw+SttLS0t1NbWpm5+fKnpQ2ZThNgqXJtmbbrBgehSxuvMbm6YQKjJV19BRH9sGD/+scO88ghbkGHhN+R4gCEyMLArYHE/B7JRustMvpJe6IAYAE4cISsY0b3BrGkQ5BihUB6H2SmMI9iU9Apae3t71tbWFr3xhDMuL5ZL73/m+Gc/VFVVNbGrvxcZNDRrm9pFUKQQRQpVSR5KAz19fbfOmn5cNrp59N5TJkz+KoC9RNTT0tYStc9rT2nhS7MP2yqJcsRFRYQ2OMoagNMDBDbFHxi+UIVEC0J6Orq+PkZhFEXaiTpJIwubn3yv9xUQRQl1lbr1TU/cPeTKcy4Z1VhXd/sCs3ftiKfR4oeku7t7/5jmYZ854aips5dveGYyK7tKCD7tLIgoSHl/9s9w0RlHFiGxIqRpWQ8dOoKOmzzzT0R0m7y/u7t7WE/aU0NEz3/v1t9//p6nH+GorkGlmXX+kgIii1OUQhZHXC730MlTTux+zznvaOsp9IzhUva3tra2qOUI99SZIfDQB9av+MCz29cPJ8SZzlgBOsAFcPrWRdrNE2w2AhzvmmkjpKyxfP3KLlyCqzp6ex8gomWH0vMV9Lff7+zoGN/Z131Hny5/89jxU67YtGML4nwzyrYS7thho2IA1cxcCmbipcbJAFBbW/sigBcB4NHVy67cvPuF+69/4PpivnlkLkvLJA6iUHYbP4i3VlicW97CcRhTs0Y+zqvtO7anX/jT96cv+dzVi2vyNQyDM3CpiQD3j2oeAXAGZYvVBAT1fBIuKxI0bDokfaxAoVaUSkKF4FdmyTojm31h5sw7lK3utq5ngwG1jzDaeeVAZodDl04f7HQLCGg7pSHyPahCGgBy6Y/TqU5Oe5Kw2AbuXZ4KRp/Z+xxNrMHppJbsIbD2haSlsqnarJRCWi5g0uBROHXiScOZWS3H8oOZ6uCm57XPU20tbb/e1bHzR919ByitVkr3FnD6tFkKAJM97/pIHvaP1pxByM4iBDwEAAaqHVH9YTTO2IheHAgoBss+wOAB/oX+HWwZInglDRAv3nHtvSDhcjB/kVW2coN/2UBPtlW1cD4Xh6Jth8hC+kgBBQ3qBbgWFo6aPG9dImBaBN5ThNqVgGLZcGsXSgRQFEFtZ+hejWg6g4cTNJQ5S1f23hG7vG4mQrhpxgkW+TfDp2Sl2tyXY9BkAo8CaDuDtmmU92lQSqqqphZQ4LVbn8/WvrB53P3LH3/Pb65r33/huWfd+eHLLs8+MGfOjCt6e1du3Lz5ISLaOWCW0NbWFrW0tOT2d3Ze2tzY2Hfj/Q/2rFy3pjqurUFJZ1ZBZc4DSyxgx/+bGejr6y1PnXps7tJzz1+qtR4HhXvsvgkNAK2trQpA2tHdO3ftzm1jgLRECeW0DlJsB4g/YoA0c6qzhJmHENHeIzGwjqRZodFYX1sDyeUnpwTYYXrvIbfC0Lk34T10cYz+7g68cc6F6o2nn/UNAB1RXD3S7uc8YgR3xq9/XcTChRv+zy++f/kzG9azaqijLCJjy2ht0pldigfbPsAqSrjPHBnt3ki2dt++jgMalsOP9HQeAQ9lnX6vDrji+InTu65bctfQlDVzpIgjBYoUQ6n43JmzslOOmXwNM6vW1lZJNz2SdxAA6gGGRqXSOdW5XPz1P/36Tc9ufI7zSVXCZfYyyWogcVwFmdqOh4wdZuWaPQ5Fzsl8tU0Olb/50XuV8zKTVHl1E+BARIVjCnB1q0BmD2QGLsZx/KsWs0ZeQyMz1opSixgo0P3XZIw+x9sCqHnA7Q6gwjuALADhEGAwfDpSuEY0eWOU+KD+OYOeCOp1rjJqy+K/COCbzLwYwAmA92UdppWJ6IGBHy5hjudap8hLNQVli4ppYxQS+/Vqm2b2wCr4VfGPoMqDz+KV9T5A7M3By5/gfNhmfUGSvueamS+SHDcxagnIlIJWIFJxunrP84Mf2PD0F5j5X59//vm4tbW1dKRGoZWLWUNDw940TefNOensu5dsXDFl45bNpep8dS6LrLMF7OoAhE4N20uEW1tc9VZljv2JVIy0pwNvvOAy9cGz3vKTDwFYv359fvLkyUXK5cbURnU/7+LCt+f//Mtn9HR06tr6pqiM1FV5BNgaoAqpLutBQ4bRuVNPu76W6IYjpXAg++v6isULAcQPr1t20vPbtnKuukFlnJnILDg4l5L/f+y9Z6BdR3U2/KyZfcrtRb03S5YsybYsuRssYQPG9CJRkpdQXlpIwpcEkhASJIWENBIgQIgdCD2EK0w1NuAiuVuW5KLerN7b7eWcvWfW92PqPpKNmv/kZeyre+45++w9ZZVnlVmDiLXsfHnxYnjSYiC2Rb26B/tSrdGulao/2651dHRIDLUeQ7GvY2RD67TLJ8+gXzx8NyMRADJAM9obWwyWP8uz4WrGTTAzuOZTdfXfKJYK7/3BA3cjKddnhYZCUuXMygCXVoVAb844ROTgtBkWEIAGQZMiWWigzUd2tP3TPV//qDVaZ/ZU+tcuWLDgF8w8qa6+jqCUmSybFsla29sF1OWwYlD6Tiay50GveyyPhsnImYse5zobz6T9Orawd3Ji1wVTEGENKzNdun0IoNieuvRQN1WOFpwBh4CzPbsEuJ4TgHE2QhxMYcDg19yKC3srtjg2bCPz6+PlfV7u+Tl1ulsDEoLBkOMaxw5NaR75GUtjOJu2YskKBYYeSAff3tfZBWppRfuo8WguNa0AsH+p2Sr12wPpz9A8CtIurYhqFypad4YnvqCI3P47izxj6wWA89fDexDcHsLologEmnszR2wUQIq/9nT5Qx50xBTvNvnmB+II1QtVEY/B5TITINgUcBmgICQ0g6CAVENJDb5cQBWHgFSZ96FDSqsgoCwg+wqQaxKI9RqiyuCSiA55tXs0JOCtH7ePkYwQYW9guHLlZt8RMgaGGNybQSFFNi6FmgfoqwT0eEAlKbJqRqW6uqSupZ4P9XbqXzzyUPvf/vsd77j9Qx/808989+vj+nS2YPbs2VdV+/uv3bx58zC7hwLMTEuWLFF9fX3ThaTLiejb11825/nm9uGyCiiW0oBpiCCInMDWMAUbMrMzgIRIpk2YePwtN7y8vbO39/ttTU0rAa/86Xd+53ckM5fvX/P4Wx5a/STL5lbJGlHayOlLTiDBQ0PZ6NGjRh04dexjzFxct27dBW6hMbfu6el5K4Csqb5R22osYDKpIBwRLXnBZ9fG/2Uv0hoqy3SpWCdmTZiyZnxD88+IKG1vbHzOjf9s+4TlyzUzNzYXi5882XmKCsWC1O78IUebrrS14zXLD24ePT/aohCstTk6JVNIs/Sco2RWUIv2ptYvA7ivs7vnrpbWNlRU1YBkBqrVVI8dPpqvmD77Oz19faVlAJabo0XO+jEAmHt7hwngeynUpLUbn5uWVitU0ExQKiiY09KMovfjokdOs3nh45TywLkM34O6Q4cOjWDmxWmW9UohbH9qEKrlYbsbKHzgwaqVp2BopotoBtm+RF5eN/5AKUFmOj4On1kZZAEJgwIw8NNrxqNd9obbg+hpDt6jHTzeYXKMSLcgx02dW7+X4NgJZqaOjg5JRCeJ6AEiWklED77IzyM3L705WbpypfnhpYKZ6WyMQQAoFmU4h8unMXJO3ZI7g8w5BXN6NNjMZg7PpDCtOr8YEhAuacgCb1f9J+YhVwJAwBSAsMU9iuXGwsZt6/nhDas/AGDClClThs4lQmjTLLm/Wr16qFq9+V3Xv/rw3AnTh0iIRBYTc4ZjEgqpwBbQ8FNAgDvGIzc1AsZJKwQgWLWNHC0WTLt8NYBhXYN9t02fPr3KzIXGUunpprrGP1m7df2nV21aXUgKZdJZ5qtbmn2MgMgYRQjogX5aePn14vduefO/MXNyDnujJRFx32Df6yTR1wHsX7XhCcmFhBJpj7SQVrcyhbMomf3eY/j0Y8Zp2M3K+DRNSbGq8lmCYLLVvseMof6mhqa/AvCtOlneXWxoFoqVdw+k6vxOvLR7RTUARURD102b+75PveYjH3rby95weNToYcngQF9WoERLEvboiZBlVgszQ0EdmK0lUgBFAgoEWZRyYGBQf+2xH13zyR//2wfX7dk0fnCg8y3P7t/0lb+99457f7HpkaIol1mx8pWryJ2L6mUYW2zsjLfAh+z0bmy4+cwH8mtzWlp9rJ+sAeVkoLPBDI4V9j32ADm/xBzuBSMToq7HMMAbYl7skjMeyeNgF3WEfxz5vYQ+GhgmPhoQ/Di5JvPOXePGwO4+CMNHrCuJ/ZE8UiY0e9ylGYDJh3tNsbezdTxs6+pqWLNjo0KpDlypqGmjJ9OMkZNPENHA7BEjLvw4p/+lLa868lZT1CJKsJrdz6YlMs5dGVt0FihYj0JkruVbbCHCKkvPZNp/HO5pGYQicIKw791HRCzAMt+3nYXw3h3DDCbNk6L+OkAEYYVxl/keWAEgmKPGGKgSeKSAmAvoNRUIXfTcaAhemPkqMgRLiL0CWZcGLlPgCQLMZu8F7LNc9SqKZtEbHF7QRJPtPGg6fKahoEcAYgRB9ErQUUAfUdA9mgogEi31fGqoR69as7pp464d7//+DzoOf+Tdv/eud772dd+bNWvWOiK6q6OjowjA7fHbuGMHtgHAdVdeefeUUWPmPrd/N0rlotkbahBjmHjmUMmNGZnSuq6xWUyfOOmHAO47NTDwDDNLF7onIt3T1/dPAJat3rjhlpPdndTY0iyqSpl9AXGViTxZAVKgs6cbR050No1pGfZHu3bt+ry795nI7CwbaeZXAXh00rhxBShlFI5CID2CL5xBsH10YNY3A3DToQE9cfxk+fqrb9xGRN0dHR3FTZs2ZWcbIatplbsffSSlpFhzZIntOGr4i9jTkruCNEfeQIZmk25ULpV17dfPttkUDDl59KikXCiCB/vMuYNE6O/pVdffuEguvOa6h4iosnbt2sLycziI3imC5ubmzYOVwV8f7+wZsf3wfilAmrUWeVQdfw+B/zj6nKMLfQj1fEb9gj3OPcx4cgk+1YsDv+cUvdOxRABUytXqNU8cObJhBTB4vj3xqTqnDTFIldO+oy1N52Q7RXPrZG+Qu+5t46jXFijV3JhO/zNESt2bHDmXHNC6+BahBQRq6dKlYtmyZWcFMogoW7VsocVTi3j52YTfFgJYDkhIW+UagQaskeUd8ezAL+AmP6+TAiY+XRC+RM0DttPfNr8jYGnxAaUagFQrt6yRv3vqTR+rZJXVQ5Vsd0tDw5O/KV3RNSLinoGBYn868O2Gurqn5oybds0vmx9/w5DQCmwJgs2OC7b9yJMowwcx46kiAhUEBqv9uHLqPHX9jKv+GcABUphlnZMAgIa6hsc//LVlsw4fP4xyYzOlWWqcnE72Q0NoAkSm60p1NHPExMeHF+ovO9HTedmClgXfsfvDX9RiIrNPkXbs2PGjSZMmXL79xP43VpG1M5CxFImpWcAwG+ntg11KoAdEHHjUGRP+AeZHktBEsk4r9YJnBL5QW7p0aZGIdvzLr7+1v9zaMmUwqygiImhGZ08XALijcV4Q2r3I+Nk6ncXlky69k5lXf+WRFX/2/Yd//K7V+zcg01lWkvVSa0Vaac82MZb34QkSEI4EbdqlJoIoNooDfcfwhVXffsWvNzz4ivZyA/p4COv27USaMRJZFFAqJ8j8QJxR5AfG4VOTfGjedU4wwDpO3H3iIIbFsx4XMrSXbxFH5wIafvNDbrz+W5FxF2ifAGhzVW41tJczUZDZj8rdJuip/FYtv2ZwaavOmVWrVfK6L05f9YqIgpUQX+v6L4RAmlX1mBFjxcyxk38M4Jq6pPEVAD6BgMTO2O7dsaPIzOnje9b/zSBXJMlixllFjqlvq14x8dL7AQCzN/82OvgCzUcI2Vdz0gEw+RSf4AFw1r/3ieTduX5p/V4ed09X3ACmzDdrS+zsALW24XqbFe/P1+HAoQwbKWTPBI6QHBlqMHRU4S6AP8ueTDCH0bJ/jvnhUGrYecI5gkzHNCh1zzT3YzBIKnO0xKUF8FSAqmwOKXX7AD3Zm/LlXBKQ/QXIdQR6RgNDDJQJXLCPDYVXzbctcBAMuHML2R0OrDkcmG7ngwVMVFMDzBpZi4a6FNDXSuDKBDyMoKoZJZpkQ1szeioD2fbDh8d8/G//buKHl376k3/11S+9Y9vhfdcsWbKkSqFanp4+HYqZk7mTpn3vjTffIri7hyQEOHN90r5PrBS0UqBUIVEauq+Hr5g5k5bcdvujqFS2zhg79rhbGQDMzCSkfPZg5/E/emr7JkCKzKR+vgDcYQRPLQMDg0M4fOq4kFKWbTrYBTdtzgWscKp3JuUiNJh9GkfkHSNPY45PXNlohlSMRAEYGJJzJkymV1w+758BYPHixedsDG7fvr0IADuOHfpTri+1cJZmZDPMvOfYNSKjFG1Ksk9xQpTb7zx62n6mGZPGjBUACkAovnGWzQmBbaOGjVR19XW2GwQJsNAQs8dN7RlT13ise2ho+vz5888pxcjei7+xcmW5XCy/66mtmyak4BYtoJWzKsKVXikxAiAMnlzkHLT8AoD3XPoFAGPHjj1ORCsKMmlSKgOs7PNy01O7Vd7Oc+U6E3mybNplBVIuGQ9cUFEZs/01Bu2u4wHSezpghjmb6nT55wNWfo+dE5M1cEUzIvawdOYmG34ehDBCTscyFvFSuA7wS3MuvW3Lly/XRKTO5geAi27wOe9BEb6ePmLdCjAE4pixS+tyHnf/DhygiqO5eYdQDdK7wCbg9DD5aKCJCJKt8AgfiHM9N05ShWKhgZ7evhH/8/gvJhVlEUw0LTIcXrQtsXPdXF//2JiW4auJiF+9YOGPr7t0LrK+HiUgbAVhc72fu8jONsfshGiz33agbRZRNZO3zLkhuXrSzF8T0Z6WxsZ7AYCIUmaevmbnpk89tvVpCUGpZk1kKyabI6SUyQZKNQa7utTcSTPpVfNevgYKI4uQ99hxnrUemjFjRrVYLG96Yuuzbc8fPwRRKkILbQ+eZ/NbhHGR138MchXMzXnE/n0v+5gxbvjoxkRgh0iSE3BLdZZt8+zNipnF8IaWohRkIsEAIAR2H94PANUo4nfOjcxRQnzH2rWFo52d/NGXLf6Lr77vMx/5y9d9cOeV46cnlf5eSgcHMwnJpG2U1JNRwJw+G8vyF5PhKq0UCkkJqUrV0/u3pPdvWZ09uW19CkW6SBLIlMWFsPTD/mhSENkANAW4CWfMWIMHsMX5g6HmjR6vd2COtIDNpuPItLQE6u5I9hqHn72hSa4PIf0+TmsVgK/4y2yrW1Pcb2H1CpljNuBwpnmG+b5jFkCQyyUKzxX2ee5oOBcZdVHVnH7JySRvcpotGjXXhVW0doYEqpUedeUll9PcSXMfA/C5ghQ/sF94UTq7fcaMChHpe55bJU70daEsywwkcmTDqL6mpLS2i7valtCSsy6a9/9aq1FqNXMUWfe5lEBHLN4OJESlmYyRR4FoPIgmwJ1T6CMXlI+EOTZzgSa3l8QB27DHgoMCiA1SzkMUzzNWU+RBPQVj0oEbNx5GGENRQHZrUA+bICH7YfmKxAoEXF1ENjoFpxyESJwa4FR5AZBJEYU9RSSPAGILgzIB1AkrcGu8rm6uozQRV4o61rEcDZptigxphs4UVDFFOlFDX58A1xShxwhUVQYgSUqNDSyGt/Jdv74//fL/dLztD5d/ZvWXv//dHzLzHGZ+raWBjIiyQlLYcvnkqb8eMWKUqPQPKqpmoDQDlAIrZSrpsQn7S6WBVOlSQ4Nsbml66PqpM2/pTtNXWTAl7H35Q3femTTW1X3j7sceu3T7wf0FWV/PKbGtGsbe62kMfJeCDKMEiTBUqWDf8aMAoDp7et5/Ol2fc2MpMI6Iuu5+dOUdLcOHo8qccVR23YppI7xjIrKOArbpOpRmLIWkK2dctgtA+8murttcmuW5dGjGjBkVAFi96blx/QN9EiyYMw3OlDkY2kFGdlYijMQXjs7JukSsMWgLXJBWyNJUNQ4fLoYq1fsBbF0c7e08m0ZEfOe6OxMi+m6msoosFIEkASUSaab1sOGjkhF1TY8BuB5Z9WMWXJ9zYtsT3/++IqKeh59Zkx3r6oIoFHxRhYBKOWYEv06IbC43Ty7C6lNdLqAtXrxYMrMgQZpsqlNeSVq+dbTsnGveY+y67KvSEZh7fcjiPFtuOhhhb7YVmRTJGrYoMi4wEKc9uXTXOMjpZbVz8PloqEvzd5Yggt7wjq5It3hQVmM5vkSNmenFjt15obZ79+7Wjfv2tZ8zAJYiGL7WCekLGjnjJRq6pQHTVzi/fLjWOzVi78bFbNac8RpIhOcQjKoXFgy6NHrffUFIilJ2njyutx3e8yYAR1rr67+3Aite9GD02sam+rXEUogbp13+yLj6UXskkgKqWpuDHa0TMpAXwlmEsaEYDDlSjHRwMBs3cjwun3DpdwHwHXfcUbDPEp2dnVMAXPHY1jUffW7Lc7JAdRKVzDofLd1mDK3YnOxDSJqpfPTll1yV9KnBwy0tLScB0NmmpBERf/COOxIi+u7RnuPlnoE+CBLEWgcmc9rSRgzd0Qeu0AdbQ5UzDU6NsYpMgTPNggSumjI7BfDtYU1NG891j/2tU28VcHPoMJMWABIcPHGEdnYfG8PMzYd7D48830IdRKQ/tGBBOqqtbSMtWXJo7vBpW5a/7g9vW/a2P3v/e65/8/ZL2ick1d4+SgcHFbHUQgtTbZbJGEgkEdI5Q+qlOxZFpwqcQSZJXaFYakyKhYaCVkqoVJkghGIvcbxxCeTlnjfiCGabiPsLMNllFqd5R0QICLhIGkUOFLNtmsPZzZaH2BqTDm8b3RRF0whga4D5PbIM73RjS/fOsecDMw4lW/px1xpD0f4dyRR2fyC6t38+auSNM4aj/yj+Ef764CBlL+d8HR/bVy3AVEoKowvN+6bUD3+QiPobig1rLa2ckXYt/9LRzhNvYeZ3DFYHXn7qRCfXaSmai3WYMXbydgDv6+0cmhBm8retton8yxeREzHm8n8GRspfe2ZA4R8jhIdq/oaAzZumINgDNIn9DWdYSssVzmCkQKAcU5zvbwAqmm2OeNRlp3x9ZFQQMEig4zpYmOT8oWzyVjSg6gT4pgJUSxVQMJ4TwHiHhc9yAWu7Gb4AJIMFyA0J5EOA3EEQSgAF6yFScC70sFcHEQiI18Ba5wFgublikMurSRkKKdKxCurqBHx9ETyBkFFGWjHVjx5VGCpJ/etnnua/+cY33vrxr3xpw0Prn72Rmeu6enr+eqhS+Y+T3V3vu27O3I1XXzqLs64uLlQzUDUFlIsAw88tBFDVGbcNG4klr3jNPgDEzEcsmLL2Hcs7PvjBjJmnbD+w/51HjhzWxWLB7WG0xxAFIzgnGUEQkKikVRw71SkB9DMwBxfBIKwo/i6BcNNVV9cVZQLF+nQ6d3RqD87lmEgt3Q1Wh7JRo8dgREv79wAUqECFs02b8o9hLh7t7HwbM4uV657Kek51G4WSqZpD29gdJQoAlrYReNdaHuYoAgXSBiDpoSE9dsRoLLh09jEi6rrM7m05lwk7tKuNmFnuO3JIDKYVUKEAJoEqK7SW63DNZXObADxxaPDgJwGAiM46ZdS1dWYuxPaDe2WqM8hE+oOMg0kMB51rddbpgioy4i9UP6xYscJ4ySPnU94gpZwH25/fVNshV11GA5AXWOkGgBN+hhxjR14wNuBeOaUPR1NubuCzJ8gNx8GdCHAQCDX2ppVXxnjwaUgO+FjnhE95I+dMcTwPBDR8cRsR8SJzYHXhLH9KzFyYPHnylNkTJoxn5nkbjx5thHUEMLNLnTtz82aQBVciAE8/YfEl5GQLWV1I/sMXN5kvEs6R0jo7yUcEw62jNDZnfEVZCioBqqRBzY341TOP8MotT/0jANx/5/3ntJA2O0VhOZiInn/9goUnGsoNUEMpJ1Wzhw8MYwypKLvI6UtHW3Y/u0wZSSag+/r4ZZctwCvm3nA/EfV98IMfdM/SSbHwqz5VGf/DJ+4dOdQ7SKWUBKU6FNdhDcfZihiCJC2ac6MSwA8H0t4H+RwOZzfTx+LOD30oZeZ5LXV17+g8dEgnJKVWLlMrYKzgqIkyoKzhSK6CbcZAVUNUNNTgoBozciyf6O/6LABe2rG0eK5y/UMLPpQSkT4x2JtWWQEZQ6aKKOVsUGblLQe2/QUUPtQgGj8BoO1c7n2m6cCKFWpT57F1RPT8Gy+76d5vfOQfP7J88ceXL1lw+96ZYyZLXRkU1aF+JUSihZRG3kgYWkXAPj6d0elnxeBUQ2cme8mfrWcbwUoZfzC7h6+5BJKgZ8jLS5dtE7lEPDohJymjmzgMSxAIR5bBrmtAoGfC2Rz1y/12A3Bind29ODb8GK54ocvg81ohrihWu2nEZhoFlWEmxBzTccYVzP3262HXxmN95O0I+NeEjBXLYh1dNeFKJqIdS5cuFS/mbLBODn0Ih+raW1rvOtx3csz243vHk2ak1VRPHTuFFfRnAVSb65v+MAz2t622eQ9pgB6OqI3RAx++zn9uPDIhzSXSFeZzgs+ndgrf4y92hpXHRxZ/sPd+AuH7/r6OCeIqnBzsT99P1324AAn7a32KnDcAKXzHcRmR395j9J02p78e1hDTJLSvcMWBuYjBVYJuFZDXF6EfqUKkRTPDrj8xQ7hqqIIBSZA9ElgDqOdT8BSAx5g0UqSwaS7weJF85S0LfWMXqQMcFlU4gUWA9Swa75qWGnosIMZLUBcB+zKoI/2gakGUhzfzqaya/cu3viV/8eCDn/zwO5e8472vf+PHCkkyv1Qsfr25oeHPL5kw4SgJMZpYM2tFDtB5T5kU0KUiVPeQuPKy2fSKl930VQBr2pqbM3OpT8FSAPDU9k03rnp6DVBXx646mlumGAAx4L1rgIYgRppm2Lrr+S4A8ykcY3FOntC42e/dAwCXTp6sy2tKJhVOONHsqS/qnXsVAXApoAequPSS6XjLK18tAKxrb2g5dR5dKhcScSuAUQePHC1VhipIsgwCAjoxxSq8HNaG4chrB9eb8MsZsiJVKCQFVHt66eqZs+i6WXPXuHSn5efYweVLlqTLAX7Tp/44HahWkZBRdmpwEJOunILRI8Z8hoh+fR5jBwB0cIdcQktS3HHHgmkTxr/xnkfvV+X24YlKK2ZNYswMg5OC3yR4ayP96ZtT3hejRZmYtl8cUQfCZn9YeRUwXjDuGflw5oX0h05/7SS4aQYQ1PjwEMNa8vQV05GRe15+uwgjnKzJ98NzjT1CITY4nTGJ6H7BYLVu/ovUIqOtfuvR3b/7jz+8c+nqPVsK/YMDnGUZaa2hLfB345QCkEnCw1uHYcLwMdUxje3Hr5o957s3zJjfiBUrHsmnQL3Yw+0/bnyUp0PkaMO9aTffc+4mnpCYdSiABtvv86v1kW8uFTHHV3lAl/eARZUDrKIvFAt0pPMo//LpR4Yz8wQi2n+u3XDZJIOVwS93ceW+uRNmLHjs6dWirqEZKWWev70TxX9Re553/RRMIMW61NiYzJk47flhdQ0nuof6XkdEdwPA2oNr6xvrG37/7g2P/8GmfduJiiWldSqRxPwS9GiaVbMJE8YnrS0tXyaiVec6tpqmDx07bDJtGNbBCp+r7U9bdnxGTs5TwFQwhrlQjEQmyAYGeOaYyfQ7C98IItJr1649u32vAJYuXSqWL1+ud584NGvysDH1f77in8dUT/VwQZQJmUKZirTvwB78bPX9014/+2XbB9OB/2hCY9e5Ojvj5vT1nFGj+piZnt2zZ3BEe+Hgu2667b533XTb0z9c++D8+zc9tmTt7udmPrt3C1SapqXG5oTB5MWJ4zEOBrV3EJxBFgZhZY/McpjTGmfkBaK53Du72WExWIwbW2RGrrucAE+jcWVOIq8rglHHEETWr0KxGIzYnj0ut50D4IwzGyXND9WkelIeGyO6xiP+6A0v/jV8hdIAQkN9D9O3yFZwc2N/+5TXcHH01AC53YMEgJRTnjhsFKaNnvQw24rkZ0NTj23qzN48a/SXNx7cOvnpfVu51NDAAwN9GNc6mhbPu23qUHVohCCcD/76f6Z5gzDAoQjkuoWFW1j3XkQgzuubA2XOkxzlKnviZx8KD5EuB5msZ8QSd1CYMTpBDVEHUiPXT3t/8zx3ub1TTgMHoUpwofnaTdqWAQoEHGWgSwNtbDxx9viJUAgAwBCgxxLEDQT9WBVSlc1xFHEnraXpv8MaWjCoICFPSPBxBR7GoGkMHkvgMsApgRRApP2eMDd/Pp0o56nyetkuk1MoCB5fJnNg8ihAjJYQJwF+vorsYErESVI3ohnbjx5Wn/7iv0256+5ffOn/Llm84t23v/FPABRfcc11h77385+M7h4cZBARszag2h5ST6ShE+KkVMDL5s0/Nbmu+SCZTfSJ/U1ExDsOHJhwybhx8j9+9sNPbd+/l8uyQDqzwSPtVHpedHklrxlFmSS9nadw+fTpbwdQJiJh7/8bQt4v3lbuXlleNGXR0Jjhw1EsFKyFEdIdPEQmF4m2NMzk+YMFNBKZFDUdHNvY/GUiOuXGf7b9sAC2jyDmA7jiipmXTb7vkVUoF+sSZfthHB2OWYxgjZ1+5jf5+kOw1QxluYC+7t7qmMlTiu+67Y07JPDcyZMnZw4fPnzL2Sp2tgV8jp48+aqR7e0T3rHsz97UdfwEGurqE00aGExxyegJeuKwYaeYWa7CKlpEi84dstpzMHrStNjZ11diIsXEho61ITtjZ5jZF4icNaanQGT45OQIEV6qKtQeNHhnU5BNqHnf8CaCkLpgO4jCcTAIcjoGBj49yil6j+jdBbaPTt5w4EHvIXffICfD7fCiW+TG4yJPbMC16Z+T73mnC/HFXZklK1aIFUuWqLufeOAbX31oxeJfrl4FVSj6xA/f25xH3xobqYbINMokxk0ZM/HKWaMnDn1uxZ0/+tO3feAOpdSMZ5999r937dpVOfM+5ti6Iu+tDx9ZqRGUQkjpgk3zqnVjcO17F7NZi9B5XAVycwIgANrYIeV7RBCaBVeq6TP7tk450HXi/cz8rS50dbZRW9fZ9sKm11P3YP8PxrQO3zBvyqzrnt2/ZVFFsdJMsmZGvCHoaViEqBEgMDQ0pK+8ZE4ydfSEvwYwWSl9gE1hl+LWw1sxf+z8oz969J6xx7o6SZYLSMnRvattAEAThJBAWsGVl86hV8y/cYCZ6d577y3efvvtlbOf43zLWAOJzSSyekZEogLeuKVAq04nwUTWBRgFFkDGOikUknnjZm67Yvjk0QdPHZw4tm3s/rNxlDIzrVixgnp6eoajQN+oQP3iQPeJS9KTfarcVJKpVkAiZWWgH+t3b1l4arBvT3Nd6/uI6FNsKsRecLN97ALQdfPSpc//8E/+ZNrbFrxi4tsWvOI7D+zdePRX6+77yCM718xfs38DVDXNiqUmCc22+IyRIcLyrY+vRUaTYSfrinK/4cUbQuJ89L6HoQ43BuQKd0+LsYi1yXiLv2iJ1R3F5o5OcTjTrTF5gy8YVjlhCzI1L3yYEHDHkTATQnK66zB7PiYvNqzBW3utS2GP4bx94QIfcLI/5/WjaH4i+Z7vhb8f+S1j9usaZpsRSaRDQzx94gzMmjLtawAwe9kywvLlv4lWsGTOnBTAH37u/m9u7tZ9xGWhVDWjKcNH904bMX4PEX0x+s5vC8ucoYUIIZncK0aUPOppJAArT6CWkTyxmJvYBXdgOcITtglnHbqHnBZ39pxVo+piBMcWR+Wk5Rl0pGVcBJAeFL43o+CZ1fFOXN3NRuE4YYghAX6ewVc7hnGCwHyZiAHB0BUBTEwgtIJ+sgqhy0ASwuzuYGdmNqkMNjIKocCJGb44TqDjBD1chYhhGeCMkDu2JoJPhgdrAIIbrmX2YBzCzzNXAZYaajiBhhHEIQJtTpEdr6JUKMhMKV69/rlJhw4f/vieg4ePfvhtb/+bhVdetWL2rNlXPfzYI7rY1Cy0ynxJcoOxE1QrlWzalEuS8aPH/wMR7Vva0VEkoioArFu3LgFz1t7b/VoAbU9s3jiz79gJ1dTSLFOloKXw6xTbdWFdYOecSCmF/sGBdgD/oNlXUrsgpNR0skkBwMiWYSgmBUArMBfykTeCN8i8UvGOE8sfUtDll8woF5PCEbNGZ28M+jET6e7e3rEA/nWoMvS3mhlSCFIwqUzkFIsbsStfLwiQ5I10OBVQTVWWVbna14dxkyYUP/GeDx64/aobXrNs2bLd8TPPtnsdHR2ypaEh2XZg/+Rndm4bCwZzmppck6yKGeMnCgD1ZKrKXhBg2LBzKx86cQwoGNHFsBvgHT24SfBp0249EOg9vPR0dMb0l/NpuTTAmpsyIpmDHMBwe+q8TLRnal1YX+xxQh5qnGGQXPPCkZGX+WE8cTaGcT6Rs29yd3Z4xlWiM3te7FpwAGzeOIK9F9gUN4uchAxcVItwxQrjWfjZ47+c/IuHH0zrWlqJAGlwW9ASuRJ9No1XWBmepSk27d6mNu3YXH5k/ep37Ti4e/En3vHhb8+fP//4ggULfhqlN9GyVcsAAEIKkJCmLL4grxtdBDkHvuBIJ+jC4MwIcxcf1G0fh4uXXivDvdwxGc4w9X3LYVRPHGzUIJAplEvNyeMb1vC96x76nQ/c8tauwe7sEQDrziWSZMHbSgBYt3fTzod3r120fs92Tgr1fs96LnXe4WnnHJZ2vosJdNqLG2YvGHrngtceIaLvR4+pAMAzR7Zfvr/nyNXp0FBWbGxKtK0w7XCMZkBqsyVU1pVkgywdmDls4qOrVq2Sq1evPuc0+LhVtQIlCUQioLVwoskUj/HQh2yBH7LpfInJXGGGrqSZUikG1JDAQC8tfsPb6WOve8/P0nToUL/u71qxYoU4m6JrZAq9oKmp6RSA92w8/Pydjz/zFItiHalUQUtGplNQqUE/s2MjVqy+5+UfWrhk1Ya926cB2HMhc1DbXMYKEW3r6OjYvehVi+beMnZO4y2T5vx49eFtX/zuAys+8ciOdXM3H9yBVGkuJvVMYJFlwWnlDD9nsxBF/OdoONYHbuKJQiaXz8Jy10VGYMzDFhe6DLlw7qBFLh6zkS/wBmJoGIc623uT11UR31t8G0tPzvEheSzgZGzI7nPlaILcoBgL2u+A2J55aSWhD7DE8iYKcCDSK2z64A1Zf2UImMRyzm8vIAMVpLa4RWW4YuzMdEJhRLd1CJ0dZlgK4mXc+Pov/X42qKpIkjIXGxsLoxtGHCWin3Z0dBQXL16sfmsMvnB78U31Diw5rQ8LfD01GAPAXOYYJoIdnIcgTkAHks4rNIe13a3dPcKz4DjOZsy459c8J/orRO8MBeYiBu457Ag+3MFt2CZ/RwYVBLBfgS4hcCsDqbOY3Ryxc7CAq4CebDSJXlOBHCqAEoRqkGSVLCtws4YaAqgiIZzyKjEEE+QJCZxkcCtDjQP0OADN1rucBcMIoSv54juuP0ye+eP1cUV4WAHIjMLn0QJJqwTtUFDbB0B9oEKpxHuPH9V/84V/G3XPAyu/+K3P/TO/6oaX4eFHHkpEkpg9MdKcrSg0kCSC02q1MG7YyK53v+LWHa8fGJjYXl/vPZQLFixIlzKLYc2t//HLtU998dFnngGVy0iV8pg4WvlAEA4rOgAiBJAIHD52rAKgnGb6QVzENqy1kUtJwQpQAWbl5y4Hl2OwbJvSzOW6BrS1tvy4mqVEZgHOL+5DaAZQGhgaGITWRU5TZDqDTpxiCpGfqACERUlWlTAT0owLrW3JyOGjMfPyCbh90a13fOx1S75ARM+fT7qPM3CZef3Pnlr1+d0HdyeFYpmzako6kbrc2Eh1hcImALuXLl163lFbGyDE9n3P08neHgOsY+MqNiDcq9iZ4B1azoLhPJqtWbvzbXlVGWQPRTzqu+PyR71xEA/g4nTIb9j3vclPPzuBASsnnByJDSKX3kTwaaJxvDEHTvx7LiWKPAnGUbEghm2JdHtpbtTnRSln15SgoYb6xoIaTJUWTBzt72QKtGTWhay41rYaNqNU35AQiE+lVX3HT7+XHDh1/H2f/+in1rnoigPeS1cuTQBASglZSICiBAoCgtncC9Ha54bt9g6Gd9z7gOX3ODMlTzwXY4YQHsdexXjAFxY9GKguUgVAs/lbCEL/QD+v2vjk6A/c8tYtY1qGP30+csaCQgbwV9dMmvv+9Ts3JrLUBKWVcSn4EK8TxLbDznAiQpplqn3kmGTehJlrATz8xXvuKf3Ra16T9vX1jWhsbPwAgEf/88GOP3ti89OQDY2CwaBE+PHnZIpmLjQ0CkDuAnDrxOnTe5cvWrT9ArYqcKq1YqFZs6m4rpWG1tpUErURQzcuBkx+ITFZo5jLw1qT1tZ2jCo0Ysktb8Kbr73toxOaRv67S/88l844+hXA1k/f9eU5e4/up6TU4PUzMaPAUqhKRX/+518bd8uca5ovGTPpqUOdh+YB2HchWzbi5u5hDcOUiNZtOb6lqb+n/9kbpl3drVhPX/P81vtWPPbzV92/6bE5m47spEqlqkuleihBQrM93EGEdEpzY2scBSQKv86elGqwJ8J7bJ3CPsgQ4RLz1Yg3yaHosK8vDkfYG4JJeznpjkvyoNjfm322qIvQeecRnHO6JiPNymLzmfbXBK1goAEjcsw5g9fSvJ8OD8NqsWQ0lCjrJb8VIwJJEXT1d2SAOctaRo1JCiS/D+CGk33dY4noXrtl5IyGnKWNBIDadnL/El2HObo6mCoIObGhneeMn/EjZiZatizDkiUXb//B/8KWMwi9vRWb8wBsdrX3VPiwM6IKShGzkUv78YQXmjPIBAC2GxfJMox/Xvx8Zz955eMIqgawOI5xhG9vIJjMERORV9odJm57DpcnHhyMHH47XmQCSwINCtB2hlggoGK4Rf6h7q7gCkFPBGSRwKsV0E2gRJg0Tb/HAUAdQ7QTuFOD+wTIOpi1YKBsxkC9AnIzIHcDehRDj1Pg4QQUASgy+tt6eJzQCAxIgIw831E+oZsr4QavCVzVSKEgpxLksCL01goqewZIUFHKJsmrn3k6ef1Hfx+vf8PtaBo5EgNKQ5ZLZh0EgbSGYuZiqYgrp898GMAwqfXXALwKYY+fsN6fWV/o+N7/3bX7eV1oaBSZVg4j+3LObk2j5c7TEwkcPXkCGijWJckwXMQ2srm12FxfD+gMjiDZd8KBR5Og4o90sB1UaZXHto3CY0+t/QG96/1889Kl8qHzOHuQmalnoO9/ABwYPXxE26jRw1EqNSCtVMw5kPZ4A8cCMkmQFIsol+rQ2NyMpoYGNNbVobWxGWNHjERnV9cjr375wuPXz7zi0QktLZ//BN6Oc0gRJYQwhH78+edH3DBtWvMvnn3qrT948FfTsyzNiklRKgLSLNPt7cOSoWq6loj2f/COOwrnU0zGNGMSbtr1fGWgWgFI+MIjjFhmxITi3gsKHODoiAdYi+m0uPp5t/j0DwemY6cBHChw4NLJntPuxLgY0R5bc8fLOJeu7x7htvwzovdjGucwx35IPhLEXgwb3MKRocAIUdqgQxwUckamk0k+Gyn3nAse/gs2pTOhtIJLK2Z3NqdLdbL9dwZw2BkMQJqq0gQmFAuy3DJa/2LdKr7sV9P//Z/+z5+tBvBcb6UyV3A2+T0/e889AFCURYiCABILTrVz4ETyOKYDx84MXynYpWuB7XakCAj6djHnTAT7B/FaAV7+hcivS+UPRqMSgCZFSES6/vDOxl9vXPPKV8+95lcrd+8ugWjoHMPymsxxH3VTR03+6piREz969NiJtAhZUNCmr5G+dvNFAChlSBJQg300a+ocvnXOTQ8Rkbpn+/aEiHTPwMB0AJ/JoD/73Yfurh/qH9IlUaJMaGhpx2oVkjt1g5lQFgmuveTKRgB1lSzrvcDZTtrbW2RbUxPqm9qg6qrmvFhbSdUc5Gz4RAhCQ7kBJApoLDdgeFs7po+fTN0DvT+/7fpbh6a0j//+TZNnrXV7NpcvX67PxkBbuXJlsnDhQiaQ3rhr44TZU2cnv9r05Cd+/86/bCKWiqGkFq6oDsAqQ1Iqi217dpb+9idffes3/+8/3jKufdy+pStXntO2iLNpkWEoiKgXAJ49/GzDie4TP7162vTbrp72iY4Ne99y33891HH9fZsev27LkV3QlTQt1jUm7uB5J1M8xzBgqmzaP7wxZC70EUZrlHl+9TYN57Cud5SEb7veB3xssaoG+a1UPmpHJj1c+8450BshUsrjbw/xXBfIGXXmc+H1jcVTnE8bdR0mOB1pbihAYSxRkKeWgMKcWrkZYecgN4Nsj5I/PDR1WXwkCNVqBVOHTcErL7u5AODSgjR4YQRGvKBks7SRAsBf/fTfKttOHSAq10MNDfLcy+eKayfPv4uIuINZLHmR1NPftsggNGdmAYEQzXIGAwyeIQIoIE8MgWBir+ULN6PQGCG6Zr9fo99qnCiIjRzPoDHys04z/x3XI6ohaQpFEBxvRBmwfj8Mor8BDRQEaH8KmlQAjwJ0qsHCZ6BHgsYIGD1EQLtA8jICPzcE7AeICvZ4CQ0BCX1MAE0aoizM+YFDJmzvnq8BoKBBJCAyCdrLEAcZupVNKulIAC1kzirSDKhIALlgO3O0ZlFvOZpD328GKTKltesBOa8IDGeoTVWofknl4a3YeWAfvvAfd6DY2gQqJkBi0xIFABQw1NOZXXvF5cVXvuymXxLR1w+dOPG4mXYTrl9hF623Mvj6xzduqEe1UqX6hqJR6qFMcaCteH8TfDoGEwCtkSndNlit/khrvccaLRfkCeqdP58BoK255WACSgMKDl5F5z1jD+oDrwiSgNIY0T4M733b4pZffOGrWLhwIR46R4FkQRC1NDR9gJnlu259zYK3vOyWhUNKqSzNZJpmyDgDMyNjDUFAMSmo0c3t8lDnqZ8c7j31wPj2sbKtuV6NHz1ejygUBICHnYJd3LFYdizu0OeQvsWIkvgKUh5bv3fXZ/71u19/77pnn8nq6psSnaZmmVSG+nIZs6ZMrWNmuvPOO89p7LlmQ4QTxoyZPFQZAsgGDLwCRvQiAtgu8m/RdQDhkTzg3B0uqHkIIALtxhXoPMhwT7cfGdEWAIBpF9GZyRF7xx0NAiuXIREbJ6aL5NOPjEfZ7q0K8NB905iyHkABoZKOvcbvQzQGGNsiY+yMiVxu6kvYSFh5ZUGeNQwBZxjWwiBrZAh7nIsEWAgwlCi1tKiv3/cTTGwd/qk/XPL+t/YPDX0BGoN/vvjPf7kCK1RBiKhobF5fnrY4zgBxAMtFV6N5jg6xCH1zLbl4JzcaVuGwzcGujwtiuNEEIyzukqGZQl1TYeuOzVi5YfXbmPlvyJzxeg59ME4oZm5I0/Rff+/mN+2+9+mHKod37ZOy1AhNDJbwFSJ9sTeQKbJSMeppqH9I3DB1nprYPOzp452dC4e3tj7EzMng4OBeaPzbikfvbTtw8tAluqpSLqiCB7q1VVYFIUszjGlswozxE7cAGDt2xLBlAD4Eo3HP2hgiIt1hop/bX3PFwjsWzrzxhrRa1UIIIYlMpWiljRMZBAVWI+pbkyPdJ76fpmrvFVNmzmxtbdWtorhdEn3ve/yPtxDRA0AoDGOf84LGoNvXvmiR39stZvPsV+zuOfT2L/zya7ftOrhf1xcbRYpqOD+VAS0BLRQK5Qb97Qfu4vpywzeZ+VYi2rGRNxbn0JzqOSzzWc+Xe33lmCv7YYpPrzvSdeLWGWPHX/35d3/yVxs79z/0xV9+52WPbHrshm37d0KUSpmQMtHW2Wzz2T3kCZF4BN9M0PDeiWYyKBz+gPnc/nbOMO8CcxE+SzT+VWQAxpE9COcgo5CpkUPG8LjNiKvgfHPiMv6+j2R6Oe36FxmDCM93jm2HeDm6OERSXdZHuDaIraBDghzPG4CI+pVXQnaOEgE1VJWTW8fhmslXfZ2IfumGvugMdQeiAmHN+7pPTJ/YMvzSP7/rc+85eugQmpOy6FVDdPm4S7tGt7T0AMDi0+3Z37aa5g1CH6+K01AE+SnMpYkCQdFHTOObp/6YsCyR+FvGhBEbUvl75Okpr3DO5Fc3Biv5Pntj0CtYR9w1oMPnc7tr7L0oUncufz+V4J0KNFyChIbbZOCY1eUmsE1X4IyR1THktRK6XYE2VUGVAlC0aW9MQHcC9DK4EPpLLmkcTkIwWCqwBIglZCeAUwA/r6GHM/RogEYKcAMMgyuY6KEDoU4Akpsn+De1BSP+aAdiF8uDYgZNkhBtBN6cIT1cQbG+BE4IGRRIFKzRbOddgAVRcsUll/a8bt51j3R0dMixw4dvCVPNtO7QoRIzy58++tAb7n/sUZaNzQmzMmALNZuaI5oMsBrhmUToHuwvPrxp0/7br7rq1MVIV1lkPZwJJf95xe+86a+o3DCRGZrJ7NDLg0UndEMfiQAohbbWVsy/9DIFAAuBs6zxlm/WKHRe1z+6gGH5tnTlymT28eO8ZMkSdTYuHGZONm3aJOra2kY319Xd1FrfNJSUkrX3P7d22duXf/z31u/eIera2sDVCiAFhN13VJIS5aSgiYjvuOOO8+7vissuYwCYO3nGskq1CiHDGsQy4rSN7k5x+nfs50RROO+MkuS8mr+PBiCtTPX0GifaUOAzuKEEa02bGugX2BkOctj4pE+TaU7dB/I1BogPXgI5OellHAlryNnB2ucEEGGNKudli9KInDjzW1+N69p2OeIlZnOcwUvQjEfawhpNfh28nHFrEwMcpzPsJAQ3IEFKKboq3ereTU/d1jPQc3NDuXyLexYz09+u+Kp5jmJA6PxxQmyNYgT6DDaxo5igi11Hw5m+7j26aNVpjcfH7ns0ygxxdklEusGpQdHfUUelYhpKM71+/9ZJxwZ7PlSpVI4cOnTo51OmTOk62/4Qkerr66svFAqbxzYNq04fMeHZx4vFa1ICM8VeH/eFCJsIwlBlQI0dP0lef+m8hwF8WCR0p9URWWdv57Q6Ubf10Y1rl+86sIuLzS2FTClvCDLBnx8HEiBJSLNUt7UPFz/b9PBnb7/sprcJpoP2yedMsEuMk7QPwIdrRnHmuYBjKZ4CkyOE48cPrtGLIX++bt0Tizs65GWbNvGZ0kRrM0Gsrswe3bKl6bLxY9/bVmx+BEU8/8N1993076u+d9vKtQ9npbb2pJpWAchozdkcZwUAQohCqV7/98M/njisbfiDzPxKItoaORtfMiDunAVEdH9HR8fKW2+79fpL60de/5/v/Mt7/uOJn/3XXat+/E/PdG1rP3niZFYoNkgNTU4mA5G72adyhqwpIG/LoPZ1dKFPtTSgxBh8MU06A9Re7yuJWrDgotuOmbzL3j+MAK2hye4FjJxGecMtjCUHsRH41WeJeKBC+WtddoS92OHEnI8sN4PhzTAlESB2t2c/DV6keFnKgJIMSpgWTJpbaQCeXrlyZYKFZzYGAWAVIBcRZX2DfdeNaWz5RwA/2HDg+Zm6miKpkh4zekJhdMOwVQAuW3/k+U4iOnqxUpn/t7YQIYxL4sLRBwXiQe1nZzLG7D9WOYTwdUzYtelZDjTEoCQQTu0uCXcmk2cgd511V+bTPck/IuaQwCAcCNITe14EuBhp8PzYfQWHFORuBk+XQFVHzM5G6fs7MIg0kBIyAYhZAjySQc+loMMSkiRQYJMeSgBnHMbgmIfyfQIAtsdVEBFIJZCHCOKQgm4AMBzgsQweqcF1AJuqY1GeEftNz25eAovY9bJ9EImhDc4A1USgq8sQuxh6hwbpAoQgAAoMaSZQENJqVTc1toiJI8Z+i4g22kO7c4x4SUvLZwD8/eqNG2/s7OpEY2szVbWyacQclgwIYDFHNhHQlxKdvT1818qV5rgJXLzGzHTrH/we8aGDQKGYMyJ837xgizAvM6AUWhubMHn4qAvuBxFlRIS3/eAHcsWSJWcl0BYvXkyLFy+O34D9S79YSo9VsrRs2TJgIcTm45s52it4C4BLt3cemfD9H9393W/d+5O63UcPc11zM+tqlSAdU5qfpFBEUiye77BPa4ND/VWd2ZLiZwqgeZsqpLObfiNSbrUtfrf+ovTT2UAxcHbT8sKZcuEDmzR+wf2InWiRw9o/6rQZyXmOo1e5qJ0DVNFTPO5xMjW6b84wJC/ynRz3VffO0H9+iXS3qUFINVNMUSGcCMh5gyj+Psyh1zDAWEORlonednxf/Zfv/8EVAB7ac+LQZc11TYuI6Cuf+cG/C1XNgEoGsMily9pHnwbg/PuITwmOSkq4eY7pCyEp5GK0nAiOjXrU4gKqoWv2UQ9kCsVSvV63Yz3d9fC9Cz7y6rc/3zJi2GQAn1m7dm1hwYIFL5pG7vRGY2PjEQB/zcx//JbrXvXE/eufvHbf8cOqVFeSyqfuu2khU9mGCVyfIEv7cOW02UMvv+K6rwxUKmp94zN3MzNt2rSp0NbU9tCj258d9vju59pQV2YuCnKVXyMVafZmO0eN1qgv1+O91755PIDPNjc25o5TOtfGzLQMy2g5LQeW4kU9hwwj24loN4Dd8WdvWLFg4IW+t9QZgwxaiZVy1apVoCVLuL+///319fVrAUx9eP+Glv++74d//Iv1K9sOnDyui63Dk4xTQEqTwqqsmc0AC1ssShBEIkWvTrN//uXXxu8/vv++k9Wuvx1ebL2DQNTBLJe8RIU8XMaKLeSkiehRAI8+f/D5iX9ww5v2VViP+OQPPzf318+uetfG/btRKJS0EiwUtCnozA63WcGcc0ihRmgCPnPCsaCn+WjbVIQFPFqg6EsI0TVvxmkYeo0NQPcVZjDpkDhgv2yK47zAdofc/nngdIeJew/uZlGPnUkXyRk/6NPlMVFIS3UFEl3UNT9Oe1enGJ2/0w47zSrp6HHjC20NjV8GcPL727eLOxd96AVlw6JQTf7XWVZ97a6uQ5M6s67RaZqlAMlL60fw/CmX/7Sq1AcmtIzsAnAU+WX5batp0R5Ce+CIY5Dc5pDar8Vpo8FLENl8AMgmOeSNo9NulkNNp5N2YKhgFBDbaqVOcTPMhlxzYfjt0mwsvRssEvkzKGLRWpxvyTiE4QOzMgGkE6htCjQsAbdoY3DF3T9NOdrKT1WA2wh0U2IMq60ZZK+ATCQ4MYZeju38Xg3foxyoY2YTiZDGKE4GCbxHgPYCulVDj9PAOAK3MLisTSGajG2lUjs39oHxM4MNzSAJkx6kBbRkYLaEbEnAmxRESkBJGCOYNCQEqqe6+WWLbqWbr73+6wDQ0ZH3Et657s7kDePe8I/dA31/9uiGpxXVlZiFTEjYtTyt8oQDH2ZNvUglu07MrAj0nttvv5yIVi1lFssvEtPXlcv82j/+EFxElWv65Q1ov0WKQcoqlUyjqa7BX7lw4cIL6gszY8UZqsRxPiyW++hMb1rd5BmDmbFu3bpkHQBgHew+P/Pd5XaXHfOth7pPya//8qc3PrNj0xsffO6p4Vu2bQbqG7O6cn2iKhXv7fQpdYJQKhRRdgbh/AsaPphZ3PXwfaTtGVOeU2LadXLI8XHN1IRov5sIQsxSwAviqbPtZWwPe2VM+Y8Rq0jYbsR7Py5ayw0/yNCIi2qeaKR52E4SGYhRyig5kEFB4Xs0xLD7VdweHDvnFFjH/Y4LLeTAmL0VQVxUA8c1DRulc8e1kJsPYYdaoxDijToMm7IejGVmRjEpJbsO7OYT3d1/zMxfOdh9cmxbfeOXmfkHH//65yrQDFSVSXW3hMA+8uT6ASObLW2SpfOQlBmvWIxI6aKSjZl0e4SDLaoTp7Ii7lMELEMv7Xxamk4KJXns6EG94ejzrwJw84Dig7ZQzLkcwSMAyH3d3d987bwbr33ZZQs++N8P/bTEpYShM3LFL4xjEj7DSUvBKEi5aO4N2bCk/sdUICfTaM6cOVVmrr/zgbs+sb/rUJLU1SmzJgKmIq6VMlEkxW0fKRYKKBULVSLK1vLawgJ6ccP2xRr5UtE4qzSSFStW+Pmwb/kDO4PYIaxcuVI2LWyiXZvKtISoeuLEoVnDaeyWRVjkHHyXVaHHd6y973cf2fz4goe2r6nbsH0LRKlOl+oahFJpPvvLBfOdgLOpugqMpFBMWLH+zsM/Hl/fWPqPdYe2zL9u3NwPLiFSHRs3FhfPnp2ebaXTc20u6mnnhIlo38ajGxsHenu//s+LP3H87mcf2/OZu/7tPU/v3zBWI1GJEFJDI6iHIBuD46MmowPR7FL0GkDYjhDulivs52Sbk5E1fOvOcQ12WiQovX4SPh3aBFtcn829naHu5a2IDTwORajcP2yc6uZczdg+jDC7dbz7scW3dOi+xsOZh8E1+w/dHzaTwcBqApGAGhrAlFGTcOvsl5eJSK/lteLOD+E3NbYG6SPfeuLu6/b0H5GoK+iBoUExZ9wluG70zJ90dnb+uL29vRsIdPLbduZWU2XUySQr/AJ6qSkeQDle8PtiKC4iEJQBwqV54QL23pkYbAcHDUXESeH6nMKOrkVEr4HyI2RmQBdFz/XD9ADI8WxeweaEIFsDr5+ADSlwjYASGUiT/17Y+QZ4KWoNBqRk9j3MEODxAO/SkLszUK8ESQFdYLCMUG48lpqx5udCgxMAiQZYgHoIsjuB3qlB7QyMJ/BogOvJbFRPyUa8ot7muNblllvwk5h10EqDJ2cQzRK8QUH2AEgESCvoLFPNrS1yRHvLPTdNmfHOgWr10wB+D0AfM5Mg4kO9M3jcuHHH/v0nP5y9de9emTTWm5MHWdijOXRNP+CFaa5kvfVGQSuVFIpJW0PdnwBYNXbdnRIXaQOWIIFhLa3RO27fYnxVZFH48uemIqG4SClc/un2oOZVq1ZhFYDlixap80+BsHRkmMWDGWZuATASgNp0cPcf7jx44LLP/uDrr3pk6was374Jh44dA5hUXesIqbIsUWkVcTq42fhOhiYSYfZTArggi3D5ck3Ll+N7D/yclFYI/ByPJQ9Qc0Etz+TR394YjNfowiOEzBw6lsfQp6fU+NxJeMBtlPvFoRsf2QHn5sNXPbV/RRI/JxNPUweRLAr2a1S5zhct4JAy6r7uq+KFtNXwPQ9b/P39S3cEzUVs2qY0u7lx6+GKyPioZm4dIu+26x+zBV5knXlEm3ZtGUtE6sjJYyMyrbJEyD86MnTqIQKATJsjiIhtUQnzXTN1FNbFArVoUxOcnDbT5S6C77vf63YRmhOgWrsa9FQTochXCyAbTQugl+3/DJ2Y4jJcLvDqbetbf7lx9RWvmXvd+o6ODrnkLLMdAA/mNIBOAL/8646v/KRx2PB3DqohLUhIt35s94WSNsUx0t5edcVlVyTXzp73TQDFe7Zv59dMn17FMlDfYP/nAGx4fMvaa08eO8GNI0bIqq5Cuy1gHrw7nQNT4IWJBvsG0FpuujJN03KC5FcrV65MFi06jzNWbevo6JCLFy+mVVgFrArvr3qB65etWoXlixad0Qh1KxP3h5nHAricmWlH56Glq3duaPzL73/uurUHtrQ/8/xzONF5ApDltNzcmmhWIlNpiPISItqzz3AkaElEkwYBolRu5K+u+IZ6bMOaD3xn/d0zl8x59WeI6D77NWX74gy389RdZ26RYUhE1Aeg7+alS5PXXnHDykkjp3z371b8670/fvbXk6rIVCEpSEPfZ4AKloY5eh2LJivJglMoxgCI6gz4eYsrjDrd5LCVc5w5CWgDEGz3YhPDhdPYnUsaYUNiCo4Ll3IayeB4f99pgB5B/8X4N6cm3YfuWo85T186cro/6mM+YOT0dpgLoRiCiFOBZEzdyJ457VP+FQDPx/yz4qWlS5cSgPv7hk79w/EjBzlpbJYCArPHXnIKQH17e/shtucln839/l9uZzAI3csz7KvxeS5AyLEMQDCX2mdBhCsg4PWXpbqo5qcH9oYn3L668PSQtmGBizMKyLNPvpvOi8Kmz+6KGrsqR9Q+4pTrWyT87MnXIdVJQyQEPkzQWwExR4JTfwo0csfj2n4Ep5BRVlzV0GWCnivAkwE6oEF7NUS3gEwTIAE4yno3/YwY0RpIAYxzdKyFOdMQMIVq6IiAPqxA9RloJEFPFOBhbJ6REkhF6TFge76dEUBhjgKg5FRDjQDE9RJYr0DHAFkQYKUpY6am+ubJAFYPDAw8W2FOmDkBwBs2bpSzZ89Olyl10x99+XO3Hz98SNWNGplkOjPeeg804hVwoCkad7zkUmJgcAAHjx3tA2C2mV+kJogwvL3d0LL1OIdtUbFQDXrDVIQDfPXPi9Bcym0Eikz/QFCsy8ipq7Nurtutx/s7P37gyFGxbe9u/aUffvf1fVk6Y/Xm53Dw5DHs7TqB40cOKRQLXCzVU11ji9CZkkpZec1O+YQ1YzJFhkiIC8Lzbty7d+9unTx58vxv3fezAUFkU2y8UAl0CwpnR+XvFClhcZo8ILo4RofWoR5lWHr2Dwt7TOILnHxyvEs1BH6eLbYZ3N/+bYdUIjkb02pcJIFriStS8A6AiFhKmNv6kmQUxuiLM3jgYnzIHsDYa2Kb66Vo5DrJee3B5Kko6Ke8qvPfd9sSnO4Smok4UXtOHeeOjU+8YVT7iOkwOnbOpNaxs3567JdIikVpZAnM1vOYEHUk9U4DYnBPjOaEYsTpde5FC6lqHaK3QDBCEfjFrbkvNoMwV66LWpjZlPX1Yv3eLfz09vVLmfkHdJ4Vh3nlymTghuv+9sDJE3et2rT6XY/ueFqUynWocgZN8IdciwwogDitVOnysVMPv2zy5f9KREMdHR0S06dj3/v2tUwsT0zv3/rULfc986iS9Q1CV1OTccNhu0ugXTtiTUDKlFVTFCBGMnNKRLx27drzZloiwvlEzqxeTVDLosaC0KlK33cyHZi2dtt69d9P3P3B7ccOlLft21naf+wAdhzfh2OnjgPQWjY0o9wykjR0QVkLT5Dj/RCNinnAOG4JrmiUw30pp1Q3YkSyfu+O7A++vvxlq6568mfrD2z74txxM/65q6/v8rbPNT30UkdqoqqkRETZqsWLn1w0Z04fM9+y9IcTHvjCfd+c1FepZEWRJJmTPz7jLcrecPIzivA5p02Y8GAkGWPISj4yFUN9sMFzro301W59pQj7uHk1ITw/t+T3GtvnuUw4dtIhQk/kqiRbOavpjMVqjLylPO86Bw8QZGRNaqifa/ssN1CPq3MbBmPCsf/YwQtNEMQoygLdOPmqCoCJu3fvPkVEXb9pz9+qVavk8uXLs4/85ccn7Ow6MFVpxTodUpeMmyaGNQ/7IhEd6ti40Z9//dv24q3GILQaJQIOgVjdP5GgjHSQa7VSKaRoUZ4mPCEHYOE24Rrit6xWgwwIzmMS3nMM6/rpcY7njBjR1Hw3wmDm0jyYdLeIoK7tmwAzQwgJ7FDgZoAnErgCkIxu4XOkoqp7IBNhBGxVUAHVSMAcgrhEAEcZtJ8hThC4Ko1BJ2DPl7P2gL0Zk7bFZwLQc8M0js0MAIGlPRFmIAHvZNAeBR6hgckEGi2AOjIxIsUWyMcLSnCCBkDIdU81dB1AVyXg5zLgmASVC2JoMOXv/+Luyy6fMu2977/9Da8koq6IJBQAbDiwb/mDTzwBFBJklQqcgKAIDDo6cSkUDnzEKRUMAEIizRQOnzwugItqDwIEjBkxGoLIRhVsT+JIQQzk4/c142IZhE4o9ler13JBzH7ymbW0Z99+Hjdy1Kue3rb5lQODQ5pZC79cMFEQpRUynSHNMqSZQiWtoFJNMVQZwvGeLjp86gSfOHGikIGb9h8/hmPdnTh69CgGBwcY5QKhUFSFYhENze2SmaGUguLU9QmuGEZIGbQKy2rCalrFYLViR3HuK+PGvaZ/zcBkTH42EfIFNiTmFVWtkyhEx+j0r503jHvhFidRBL6PacEJ2UDHL7Ab5EJ6EZ7pcBtqjlDwcgT+byOGhfdSx3fy/uaIzHNyBxH/eisq8mg7/eEiMEE8es9y1LuXpOXSYBHWKPdMhwedg4ryc+nXisg67418LxRLYveR/aXPf/NLPz31igP7r5g0HQ9tXXfzdx74cXu/SlGoK5pNAS6l1jnwfFSZIhWcQ1C5HvpyGBYwwsomMKIawBfQFFyIMPBI7DzwM0B+7G42AziEpysigiQhKkM96bP7Nk/uGex/J5i/vX3HjtKMGTMqOJe2cGEpHeg+OGPM+KevmjJr8xPb183SYFPyCwCUBmkGVTQylXJLc6ucPW7mZgC/c6q3a1t7U+t/M7M4ngzKicDj31/58090pf1SFKRKhZIhDMZ+/QPGYHvcDUNAgDWnCkiZmdatOz/N4wq99HP12hIKs9ft2aQ7e7vF0MAAevv70VvpRap0bl2JiRRX+eGNq/+sVKobUa2kXEkHqa8yiJ6BPhzr6aTnj+3lnsHe9hNDfdh9/BD27d6JylDF0KuUSpRLXCo3SkgITQylq8Gw8+N1BoNZb21xRew8JjdD0a6dSlpBsa4hOdHdrb5697fK63dv+vOP3PZ7H37DvFs/h+VYefjk4dlUbDwxqrHxOHDxI4V+nux9F82Z07d06dKEzHm7rywUCyv/6Z47xw2lWoNIeD3NHEmgKHOCIsc4wY85h7ciL0gsLyPkGH0Wl2MhP9faGpVE7HdxeacbAivG6aJmnO7JeTzsjFhnoMJ9ywEFH6CJvu8wqlOa7mXOCLTcHst2DrrBPcc5P3O2hHuQpRkiQlVVeNLYsbh8wvSfAHht26hhLwPwGRhqfUGJtshGwPce37N80+GtGg1lzQN9uHzsdLx6zk0EAFNnz34p1cn/quYNQhKixh50Rl9QSp4sY+qLGwVQ4KMo7k4118aEFxuKrvm9/DWecs4xLBBI0xFupDw5+twRdQx+YhBjmc6nA1qlT9ZrE3tRHOETMzQxhJLAMxkoEVCjFZBy5DEPrOb4zMtS95Gwz6wyVFFBTwPEFED0COAYzFbYLoAHjdHmjlwwESurpBxzu5mJ8xojYxmCQUWCVBLysIQ+psFtGjxZgMYKcAMDqYY/fz1Km6r1T4PYVCEtpBBXJdDrM+CoRqlQpFPd3dmyr355clOh8ANm/ofBwcHXQIiNqVKPNdfXH/n8XT8Yv3PH81wWkriSQhWEOZ/LLR0jINgcdTivVxBWRAKZ0jh89CgudmNmjGxpQ0FIaKUgtN3RkzMIY8ENG6VVAAO9Q2FP2qrz74PYf+zY1ImjRu38s3//3Pv3D/R+YN/e3agODaK/txcDAwO2D5Y3XQobs6lMpjSYNTRMxVitGRmAFAy49NwsS5EkgExQKpdkfWO9gNbQzJKZkQ1VPFg4YxpmpLjcfEgp0Ts0iBM9tsr8BVjqS+YsSQGcXPHwfWVDhjW0GJG4+zMnOXLYmgP+du/xRXJY+y45tR8pWE+zcd9DL8MmfvOevuAuWfBqGN8/0wMRqjHmognz+MwDRM5dm+s9wTtyKLjDrQh2Xmz3JZfOFKCSyxJBdF/hAMNLoMqZGWmaqTMhFbdX7gUf69KRYcdq54zBloSYiBlPbF2HZ3dunFDWjG5S7SwlJw11xIj2vzrZbToF5xALys9PGWJD0V8f0y8oSoG9CE1Ka1+y1YV+AnD6urjISJib4Ag1fwsQqKpRKNbTmh0b5J13//c0XvyBa3rGjXsNgGW11S9frBFRP4AvAcAPVt+3+hebHp35/MHdSibFArLMiF5ltk1Uhvpp7ozpePO1r1o7lFZeR5T8lJnlIRwqLRg388RDh58/cqDv+FUDA91ZsbVdau0Vn5eN7LNuDO+QrRCbqRSKuSgE99oI4TlPs0udZOYZ31/9i4e/9cTPi11qCJXBfrBSUGkGrTPjjPSTC++Y7PrlfyLLFAiAYo1Ua6TMSFlBkwbSVIOhIAsoNtUndU2NxKyhWUvNGgoqZFs43ONl5QvI10iEGdJz2UV2/zFgjq3iDJKFTOqa+LH1a7J1Wze0vOLy65d//8lf3Dq6ffQ3AHzHrnkt/HtJ2vLly7OV5ozEHcw87/ljh1Z/c+X3JxaLjRqZElqGdGM32DPtskaUoeYmJJafXrrnQuXRBRE+9hE+53Dy2x2CAedTMO3NHQ73zhb7RKv1/WeUk2NRFp6TcbHMoWgMTg2dVpog2sHs5XNe44Z5CJPh8T/7UfhJYgC6QMgGe7Mb5ry5eN3Ua+4HcH8hkZfYG59RJrjI4bYT+8bNGDbhyMd/8jnq6uoR9aqkhpAlUxvHHx9VaLm3o6NDzj+Hfcr/r7fkhT+KBDo5LxAsoTldZogg4J2IfXyEL2/teQ8+5ffJ5FknEJpnhSh5nV6I4OBIMkCWPMygiPHisVL+d8RoOeVm++W9o877IjVEVQLrMvA1AnqYPUyWkGd2C/biSnxhL0/Ym8ZDDEUaqlmD2giYBohBgE8B1Amgl0E9APURULV2E3NO/vjqUx6ARs2lAxQBCQGcElCdGnqXAk1l8EQBlMkYtm59Qy4BPCczTAl1RdCJgpwrwbqK9IBCqa4uOXD8aPbnX/j8ZcOHj7j9FfMWoKe///eI6LMK+MNndm6dUentThubWwuZVmZetVtLCxrd6lN+P6pZ/+iswoSQZlXsPXLYvHGentozNdaMtuZmlJIEA2kVUAo+pS+KoHAMgKzzAELgVFcXjvZ2mc9WrTrfbjQ0NtT/A4C3PbF5Q9+GA3vStFpNBYmCJFPCxRfwsDROjHBmlBAmxYvgjcUEQOJ40GimgmZjPGpmcObSQePUkdjAsYO1AMKl1vlmz3jTANLsvGsthLZ0KfGyZbj36dUnCkkBWmkzrlhRR1g1FhG+t57tnaMHXqmLi3AIPABXnNBEh2tS93x3OMhHO/fhMycbLtK2uai+fFDGvjfRO25hY4PHvwp8KTj3rdxebC91CVH6lLlHqALt/jXu71DowCoVC1bcz0XK5LVTwETLljEzt37k3z/dzFnGJAs56Zjbn+1eRWkkRi6Ffe4ECqmerM1rzSiV6qGhuV+CSkkdKwIxa5ua5h8W6RpCftZjug56KTbMYrXieftipBoDRs4BqCXEuOqrW8sIJiLMXNDBHjsyoyRLcs+h3dh1cv+nAHytpaFhmQV35+T+YOYCDND77s/XPvjenTs2k2goQaXWYNMMnRDAmX7by1+nZgwb9/jJgYEvDW9sdMdDDDBzsmLtg597es+WempqVAxN1jyDK9BBLgXOqT1lioYhJQwMDeBo17G9Y1qGfaRrcHDN5//hH3b9phS3MzUyxwrV7z91qPirX3ZUMGGiAKcw1dwijO4tDdsPAJKkqTVOVm8mAkSEkiiataojwawFsznPUOnUL0+M6cycuoWCp6mQcRFPfnw9vKHihs2aTSITm3VQWlG51FAAg+956kGxds+mm+9b/+jN//dVS97MzP9STAqPpCrD0pUrk2ULF17AnvgXb9bpkHUPDU3v7u9d/OV3/8XfVWX2tf/+yfeyhsZ2UUVm9o6ewT71YgmON8lDUuMgNlflsw8ohq0+TTS6A3JbnsjNoZM5lOciy0g+tmifyfEiWv3hi1HF+FtzwOWmQyAmk2btxuhyXN19EegE/jGuj3H2ltmv6/FnhJkdfeQnM9xPETTV1yUjkpbdjZBPE9EpAE+ZLp6ZFlatWiWZGZ2DvX8KYOOuI3vm9Z7o5qZyk2huaMecsdPXAnjrq1776rcQ0V/8dg/h2TUv7dnXp3K/7Y97iQhQ5FAE/Ht5oRHnEoefM206jY2MIHztnrvYS0VAbfqiEd3kHwMATDp0PwJb5KopIW8jkb+vG6P9iZQrcXjfMBNbsGzGyQUNGiLQWg15QgAFB8bJG78kbCqAFxIMFs6/wx5we9RQIXA/gysaKmHwSIaewdDzAHUdkN3AyK5lZFcC6hINPUZBt2XQ9RlAKThLgUoKDCrQkIKoaIjUTCTZPV5MDC4xRFEg6ZegDRJ4UkEc0BCJBMq2YqTbExbPv2Z7nAUDFYZiBbpUgttSVPr6UVcsJXv27y//9Ze/9Lv9WVYURPub6uvn/Gjl/VetfPIpUHOzyGDO1kFu3SMhwtFakV/+4Nwns9chUxkOnTxOzEwXM2VUs0ZDfT0XpYTKMuvB1zE3ICJGH8FmNmtfGarg8NETAM4/QghgKFPpNwHg8mnTaPjwYYVCfUOhVFcuJMVECiFIEBFpJtKaoBTB/iatCVoRa02sNOlMk84U6UyRyjLKVEZKZ6SU8nvvwtyGv8MAkee1mo6Si1BKcxOlFfor55YRdqa2ePNmIiK+98lHP1VXLAC6RrZ7wyQPqIlcygpF9TYCwA+Du3hbWuJaJAzYyO1p8fXo4liy0MXrDhOERDAyI+mWfy4QepYH/E6GG6dMYEZvo7h93c4b7WmGwm8GGDo8Pc5YcIZq/N4Z+nKRmlvsce0tre2qmgbLztNEnLgb6b9oaXLOTAt6w85ecx/FGhpETIRMK2KtAJ1BK2VCv5pzw2MXZXFHG1g+cvMYMjXyP16fOqXGbKI+F6P5aAlF/wU1HPs0zNrXYoZofAC0AKpaEZJCtnrvJqzZtelPAeDee+8953NpiChdsmKJEEQPjm4a1tHY0EJ6MFVJakAtESGtDGSXzJgl50+/4odE9LPhDQ0HmVl0D3XP6Bsa+DgAeuCZR646ceokSlQUYV1MZN39kGJQpsGZAjIFpApSC+o52QlZV3pNMUleBs6usuf+na8LQ7Q0NoOaWgv1pfpCsVhXKCXlQkmWCgVZKBREUkhEUkgoKSQsC0VKCgXIglAQpJiQMSHVpFNFOssoS1PK0ozSNEWmMigrL4UgCEk2I8w5yAnO2YEaKeXoi4ks1qqBf2SxkWawMj+x8mZrWCitoFhRqa6RT/X0qP+657/1Oz//sTcu/8VXHl6ze30HM5eWL1qUEREv7uiQ/MKVs8+7OadDc6m0e6Cn7z8big3f+p0Fr//q+IlTxZAeUHFSlad0gsVt0d8WVzp9aLZQ1mJnM0s6mkuO8IGfc1AIrljM6+RpjH8979m59SId9m8TFfBTz4jGwm6XD/n76Uje+ULHsVK3lYUDKxNC2h/ZLKhADWRllI7qJoTtVQG4+bEh6GWVpdzW1C7mTb7yGBHtXLp0aWIj5y/YFi5cqA/hULGxUDdm9f4NE/Z2HZpIJLh/sJ9nTpxJc6fMulspdaAkil/r6Oi4aEUG/7e3aNJ/w3xRUAixmo6VhHvn9FcxI4TvBwGEiPIcsHCKxX7gac8K7Egysf1+rI+CERoZMLmL7TWeIcN4AihzRmkYP6Lu+Gc5eyYhyEEBWscQRwlcNqF7JgAJmXRNgWAU5tJsCMwCrAmkyCg1CzRIEahqjC5UGJyyKTbTqqHHMdRUjWwuQ10DqOsBfaP5Udcy1DyGmqmhJihkwzJkDRlYaKPkqgTKJEglAElQSULWFSB7y8D6ArCGIU4BVAegDEDCnsUk4KsiKAJSNtXzBpUBIzMluL4K1TeAciHRa9aslp/9+h0va6yvfwBAw9Y9uz5w4PnndVIsSSVEfh4ckPQ0UYPGrOEYDDILgljjwJHD1YvpXVy6dGkyWKmIPUcOLxve1g6uVHW4uwOxztsXgSQCNDGQSHR39+DZ7VtsrGjVefWDiNKRLe13A8C4UWOUhIBibQtgWGVNBCYBU4WMQuXD0Nucke1/XJpZpJAAC1Djbzre9OA0b7T7WYgmQRAhTVOc6ukSF2yo2wMU25ubdalUhotmOT4EHKDJA3afWecUUo6cAqnoixSSc9ycl5Iup4BOL1zJtd+9iC1S9qbVFNPxMjaaJ9dPt5YiImoLCin67dc7FuMefPgFQaxq2H7mD1aHh465/0JHL9J0EGkYx8KmXft27yrU1wlWypm0dihk5TuFnkTKw6WLx45L99unIdvh+iqhDONwZVjDkT2gYj+9dn6F+YE0c89SQEgJkSRMUrCwZ7+ZZ5i94ZyQ0S9xOOIiNAFhqyR7JRh+fPUd8o7WsK8MwcAHPGgGAA0FWa6j7ft30t1rHpjNzHW333575TcBwNrGzMmKJSt0b1/fpz762nfKOZMuRdbXi4QJiQYKSQJoLeeOn8m3zrj6f07wieaVK1cmq1atEs2l5iNFIS5fs2fjX6/Zv6lEzKnMmEjBRP8yNucBO6PQLZddQ9YMacmid6B/JoC/39P9/C8A4DyiELx06VIBoKunt2dXIgukKhlzFdDK0plzNji60QzWOp8dbOUZWVpjxYCKMETEi0YeWgwi3FKGtE+Q3SIT4avgdIj4HmG5c+aiMxqMNWXpWoAFQROTKCSybli72N91Ui37zr9g8Vf+v8V/9D9/t+v+Pc/8ATO3rliyRBERr1y5MsFLYxhmY8eOPU5E2Wsvv/H333H9bWtEvQSIMqkAYaNqAZZYv5HfL2d1K1E0fiAHp909EOYdTna6eeXISea0rVfF+e/568jJRuukoyCrg1Ea6zxrv/luO/kugvyKjLqAodkvrtcNTKhxCfixu/o35tk1wSMOF3L0OSlCwgJcGcTMUZP0NdPm/A0zJ7Nnz3bF816s8TgaN1AsFN759L6tb950ZCeL9nquFqs0c+T4E/NGTt+29eTJb9TV1e1cvHixvpi48H9z8xTsz9uuVcARvZ5OCrCMQ16pvdisO9Vy5ueQxXiOyPECV1LQRx7UcV445mBZnji9l8Yqs9Ajo/ACqBQ5wBlSZBEpuCD02AInLhDkkIRYKyD3CVBJAAX7JcE2XTQY15FdAbLRMWgjzFnx6ftCyHiDCAApgFIGpQxkdlwS4DKgWwk8hqCnEPQcAXU1Qb1MQC0kZDcxqtcysisYaqqCatfgAkFrCaQSAkVIUYI4XgdaXQZtSEApAfUWqNjJJ00G4CgGZQqkNVDV0EUGzSogKypoEkJJ0t/40Y8nfOfeX8w61tfzll89tVpAUAZi6ESCpTDpf5EnLqcGfMjKzLmZLrsomiFJyurJU/r6K+fdxsyX//mtt+pzBRhnaq9//euJiPQl48YfHtY6DEhTo1zdvqxchAkRLQhoIYBCEV39Pfif+37eDVxIxiiwcvfuMgBcf/nlDU0N9dBDQ6DMHG3h6dvjNQqGIpDbhxvB7cALOoDc4N2rBZcWQLjIkv84UhxO0CNgeWaNg8eODRqBfP5FFzoWd2hmvva1177ssqIoaBATkQieWwTg4gG2kzjs9gBHUd2aF6JGypxvMzzNNXNH/pdLRUPUmxDlcSDC+FwuuDFsMQREwMM/HsYBQN6AI+fkQdT9SL67b5usotgYD0YTe8PxDKABFGR7DmAi8FHOqjD64GKlz7rGzKJUKhfZpkfFNF8zS+E7MCDNBzKdocfI05UbrP+eMx7DunuB7/WInRthHTlCmCNbCgKimKDKqcqgqKpSyqAVWeJw+7W8HPJy8sLLjCqYbgiRREAyNxt2OEEexIyfiya6y+wcJCxkX3cXbz2695YKcAszjzmXlFEbPdJ9fX2jSuXS6ye3j00uGzNtS7GpQWpJmkgAGtzY1EK3XH7dJgBXyr7CJxYtWpQtXLgQRNRTKJT+7LsP333JrmP7E1EoUKpSsFKA0kaf2bXxow5MY/hGJuhXFTy9Y8NeACMnN0/7N9u3wrnMMxHx5tlIiGjX3sNH7mlubadsqKIo1UCqwJkCZ9o4XD0ecF2JZbmVz3A5U/GPo7MoawscnYHJXq475OVd/55U2YtUZ0BCwBuRQQ47AWY+98XwJAGJAAoCnBBSkUHWF2Td6OHY2XlYf+n+/x778W8v+9If/s/fPrVy39MfZ+bRixYtykDEK3llcjEjhu5ePUM9M4/3d139iTd86NlFV1wns2o/CrJgZG/ekwZ4XoPXqbF5FM+r14kcZjMGNIGVKPrXzrqHpGFdzRRHfGZvQoI8ngQcfraGKtkBuPt5bO5uwP5alxPh5F8YctChsf7MQd/IioxlfBhSjRMtGjkpIGEBDA3ilfNeIWY0j99GRBkWLz7Dqp3eli5dKph59ANbnxxe0SlS0rrc1iont0/aQkQPzBk1qu98Urj/X255VZvXxbkWz6gHXTAEqzkoPe9XdalzFOiKa24fBSbgGM7v4YgkcdinYu/uhLXlBZHrjwW5OU9WDcDwipM9sOWIeQgMdhva4vfcfZzXnGNBQPZ9gIuA5ATJsxLJJokE0uzJiw0bx6DxJDDMWYb+J5pAB0Bsp9gbTZQrX05usRj+Hs7LycTgMkOPYOgpGmqOQnYNI7s5Q3pzFdmCKtQlCqo9A0sNEgRZTSC3lSAeLkLsTCAgjZDP2KSL2hQRZjLrL8ikjowi0MwSUmgU6hvE4YMH+Y4Vd73r2/fd+4ZnNqwn2dyYsCCIQgKS0ni7XbTQC0XAzbwnULeuHFQfERGnKVMihwOot+W7L0iBMLNcsGBB2t/ff+1lk6fOLpAA0oyEVr56qFehZFJwPJgrSHBBQpZLdLy/BwuvvuEDpWIRD5mUovNqCydPrjKznDJyzA+rfQN9qGZSV1PmagYoHQw6R9NWyQcyojwpedYI8+340EcKA9lFyiJsWI+BvE8DsYqJWUMKKfo6O/WwpqaXMfO0MYfGqPMx1IlIr1ixQgB4qq6lbuuEMWMElGKX9hR7Rz0494xgpUosCqJx5RT4xWhxfrPnw4jHvfKO0gGj/9x3L1p3ACBam5pPPKAnv46c/20uAvspIrcNNTKiKVAHR2Og8KT8mkS/Sefknzcm/HpenKKZcSMizczs5HXOoMrDs2DYRJeCIyDoQKEjNddvC6IDcIqGzYA/O8wNnRyPkgHOUoALAtXBPj191FR5+bBL9s4aNrXaWG6QaSU1wcdMm6OOqtpkaWiXCHbhMyYBCCEgHI/lADJ5QBo7ZAJaDAZjWFoOWWaVDEmhkZ/cvJZ/9uR97wfwqa7erneaeavdeXt6I3v8zpo1a048d/S5VwC497XXLHykpdyEiqqAihIDlf7sqktnZzfNmf+fAP5TktwDACuWrGBmFj2otOw+uf+dXaeOI0lEosAmiqsDjsnDY1dHwcyHkBJ9uooNB7cXAezVWfqQvfBc90LSZZugmfnNc8bPbJIsoasZRKpNeqp1DLOGjzK7PeqOXjSFv8mdRSns5xzkcS4jEBS2wfgolF21yGEREIeH+wgEHRO2o3vO6WYQGWNQWpq2v0lIMBFSpVAoF0VdYz0/e2BH9h/3fXf6x/7zU//8J//z96uf2rN+KTO3LiKTStrBFy2VlAAgEUkbazVlfOvID7fXtfy63NaQqHooXRAg6RzUTrflvyzs/OSHHxnQNqTsHCHsmRzwsDvnCAxyg0SYT4d/HFvFGWzMTvIGnaej57FfQ7u67JGjvSbIXkMbnsDCYO1nORvP/yb/LB1ybU+baiKCIAHhHLj2ZgKASjPdMnKMGNc44n4An+4e6n7DYkC/mBxgZnriiSfKy5cv14/u3/S2E+nJcVDVVKlUjK8fpl85+8aUmeXSlUuT3xqD59ZqdoxbkRBhGdMot9DMbKtRcyB4d731TgjLRMFws15mDs/x0cDIAHCAIhTVioVVXie5z4NydleG3wIhzZX9/fLAKw8DEBjUGWkEsKA8oxLsHg8RDEUrKjQILBmCEshtCeSjAsnxBKKY2EOWw729BygWJBz1lANY5NouurmPVZCA1eYwkckCzIHyBasoNJlKpVWY9NNMgRMFblHgSRmyKytQN6VQN6bQV1TAkysQrRlEH0CrCeIRQHYKs99dmyIKBCvEJMz+TWHOY6NpBDFOQFUVlZoa6ekd2xq++L3vXlmRDJFIQYm0ysIZJRHF2fnOB+FqDDG3GpoBIWj//gNaARO6h4ZmLMMyvtAoITM3auJPNJbqGupKpZCy4712iAwMk95FggApQQWJQrlI1SxFZ0/XLUOViqslez79EESke3p6rr103LRrk1TvExACmQKyzHi2ndTOgVxhjVXygNMZcc6BaC2G8NpqHq9MHF1aQMGeyzj6rl2g6KgSVhoEEtWeXlbQUwGMW7ZsWY6Fz7UREU8dOUkPb2kxgsd6qE/XQRa8uIib9+Z6f3ngH2XHcNGiUKcPL8gXF2GKJ9a+fIl2OEQZQYB/Gf71H5FfVU8GhiWNJDX+Lxdxzo/SyWyXSupuGAPQGnvI/+XuH97MSTkA4qIdq3d682jJ/mkyNAIARjD2vH6ys+P0mruVcHPAnr9yYI/yeoqjuc51h03GR6IJeijDoisXip/91VceeubfVvzk4c9+81NvuvaWXw5rbiRdTRUUh31tmQIybWTBRWzO+I/pJrB8xPvxXEREdbprw8jPoizSoaNH+MGNT8wG8IWTx07eY+X1WXNCU1MTLRi3YKB3oBevnr/w4I2zroIe6geXE0aBC3NGzxi4YvzMrxHRkebGxq8zsxjx+yOIiPQDTz/2mWf3b2OUS1mmVCB6R4wx4CB4Q4sFwJJABUHZ4IBOZGEWgHvaW9q/beX0OS/A8uXLMwBzZ0ybmo1pGwauphAudVVpe/SHjnCTpbOYCCUDwlQ9j50LwXxyRoRN1dbWwe2WlBxOsk4Jr3iFJUure60OJIY5P06TcRJH9/Loy2Ikk9oMQEZOSbjumzGmmaJSqZQkjQ16w5Hd6ov3f2viB7796WWf+snnd2w5uesTzFy/hEwq6YXqdReNri/WPzGyaVhHqjLcctmNW0aPHoeKUAoJcnwLwDvfY1nuYBzsWOLCZOSwsZ07v1YijhrGxhdBwBpM7JSTdTbXCGrhqrH7e8Pbo+TnHP5LzonlcbZdgNh3CedUyAP9vG0YI2Vmk7bsb+HoiwM2yH03j2AZBJISQ9V+PWfyLNww7ertaZpuRYb0NxlxRMQ33HDDIDOXHt/81Cue2bkJ9eVWyb39dN2Ma8RV42b9ARGp2cd/e9zEubY46RmxovONAkEBQTD4ayMaMURpiDzod87dPi5wkGsUQGv+8bHRFgg8l4ETXc+5bzgA69IdnLc3r8h8551h6xmQwj3t30zhc+f0cboxDqobr4kCEkAcl6BHCfQMQwxJkzYBAAogRYAmbzjnO2UEv08lrVknc4HbUAwL/O2Pi2J6I8EKidjTyzARyaowBWwGyfxmDd1chZqSQs3LoK9VoCsziAkafCwFPzAIuVNBCAGGS2UxNEJwkQEBlRBojgS3MrggkSXMB08c01QqGcPYgaQzsW2tcq4Bb14huveFQGdPDx06ebKxuVRqXoZl5y0MbJqBOjU42KY1vw5A17CmJqsFRZhPO/+BVEwaDkkCSQEWEqJUxGPrn+1ySug8lRkDQJXolAR2v2XRK9t01ZzdmHPmWhp3vOQVcqzbnOJneG+u4xKPg+w/+RQPGwViRGrjNKkfyQYLZhjYsneXBtBPlFdt59IW2zSSeqAwedwEgtYmKutDNxbUeB63vY7AuHmnVu6Yjuvz69bpjU01V1dJ2CtoHw20YtBPXSw8/U1MBY6L0SI+CdkM7pFRlNLKPlc3wEXBHBm5DIoY+LlCMw4s+eFwPvnSvMW58VLogblnjkZr5uKlamcINjjNFXof6S/3eY3iiaOvgWWsxvL7xTkCXhHQYrbFuTQ4VUBFgaoKWf+gGtc8vPLxN773D2YOH7cFwMeGt7Z+6VsfXr5s/px5vZkaZCHJFrDm3P4yVyD4QqpYAQB0tPfIFbqJIhkh8mGnw2ajRMofVmAEI4aMUaUli0xleuOhndO3Hzvw7mnTpnWvAM4pvWvBggUZABw+2XV3gyzIuVNn3N82aqQY5MG0vaWVXzH/xjUAKswsNm7cWATQesWCeR8ZZJ723VU/n3rs8HGUsxJRqkNEJ97kmwuLGKOGEwFdEuA6SRo66037Rx7oO/lyZqYVmza9SNX205uLdg0wT6im6fU3XHLF99qLTd1EkMSCYfcBBkekDg7iAIr8T4wQ3NxHu8+87PbAzYl/f38/WEQQP8A1d53SQMZQlVRn3b0qPX4iTbt7M2Gdw7DOEHKGiaMdwNC/0ztag5X2TnClGZlWolBfJ4uNDfq5/TvUZ3965/D3/ecn/+lLq765hZk/xswjiEgv7lgsL4LDV2zn7SUAeN28RTtG17VlyFJJUganOiEYgxFkDHssQxQxSDv4VH2DPaNMAzYyhOz74aYRL0Ur6TPV/K3ZBhGcUzp831/ml5hydEE2K8XQjrABDTeGSIqRdebFtBWAgb2ZdbCexq3mgflCO5G8iC7TBQBSJ5eNmU6zh026s1gs/n1LY8u95vanO1aYmZbyUjEwMDCxmlU/AeB9z+3duqjSNYCGapFKSQPmT569E8CNnYODUzZt2sQvRXGi/81N5F84sysmbafkHCFSAF4UqM0JjXgvkt+bEb12QgZwqQxBiToxFDBBEEq5tEEOuikHIhxjOmKNBso2n5spEGzc3PNCn6JnOkL2HQ0dJqfwoqiRZyxmsFLQUoNSAm0GcH8VYrOGqACU2HtYYWw8Ky7kRmF1KDyL4vRRNuPKhdIoLwiCWohmmMlEClmE9FRnmCqAMgYqBAww9JBCWqgiHZNCz1WgGwVoUgK1ZRB4bgBCWUXp5sj2mxLzcN0G0KUJdIFBJUmF+qIgWzAhBqv59XBoOWg6ly4TgJmjVSvgCgU63nmSu7q6RgKYSBRr9vNrslotgnEEACaNHWeIoyBrjEKKBKdbA3vMgyDSWmUDyMZtPbD37WZ6zq28uv0OM7Mc0dy8FUD3rCnTHm5paUE1y7Rw+44IId3W9oXPZH95neN404L1aH69QjmDwPd8GYOliIm93gCANAOkwK69u8Vz+3aNZeZh69atO9+Aj7755psTABtOnDqxqtzWJrIsUw5whuF5l0zuNWqW6vS7n2evalvNeYahLxps6k7itDXxyjjS/BfFHjS8zla72wRrxDPgwZ4D9eDcp2Y9KYqc2XXWLmIML/cDDQQd4p5tXkc6xf/Lpy1KvqDFWdsH594cz0Y9cn+HlXAgyV0SdTTHA/n7MeCNC45401QSDfdju18cmQalGpQqkGbO+vrFG+ctpLdeedNXth069Nedg70vJ6IKEa3uPdW9UzQ1JqogmEvGwWiK0Nj5Uhd+7JaSrmhqRDM5mnQEwzV/+8kJ3+NoTZmgJSEjhmxsEk9seppXPvvEhyUEFgPnCuCYmenSiRMPVavVq9503aufamtsGeSeU+LV199CN8+9/ktEpNYBcmhoiHfs2NHfXNcoduzf9afbDuyaX+kdYFnVUvgAYV5IcEwT0kQ0qCDAJYmsQEBzg3hq53p+dOPqFgDJpuPHz0eKEA8MsGa1tozk+utmXtlHrKAo3orjrozkPBDRk9E7wcBwWh9RVggAcrV+LX/GSxiBMX/Uhttu4gzTzNKpYqjBQRQI4opL5sglr15cuPqy+UlaHQQcRdh9g2x1vauC6YvbRPd31V1NER+CzhhZpkSxVJTlxgZ+YuO69I/u/NuJb/jK73/hW4/9eBUzz12xZIU6H12am3giPYNmVAFgfPPor4hK2geSEmx7STVY1+lXSxl5WW5Aio/8O7kXkbNbSnLOtigbwTjFbOACEZaMdbpfsuDA9Xzm7w2/tu5vXx3aRo+dhAo8GfNtuK/DjDG0CU5iNy/hK2ZO8gjejDvwkc8YZEbGGZfqG3DrzBsPA9i9du3awm9KGV+GZTwEoECFV288/vzs9ce2FEiz6u/tUfOmXynmjp35y1SlbxesXm6r/r50CSb/C1sU446EIWpW2QkYiv60FziicQrQQxt7K44YykX/yIfZAtH7lEkrodjf3z3BPVKfTrsxoCFnOCEIHxiBZLJ9XBQwugsBHPfbzoHzADnB4D0iTvl7hgJMhUfHyvBMxjZSopGBJEN2CYjVGej+FLRdQ1RhCrqQxZIOMbjnmRADyO8Aj2bdKwN4gU/+68YwCQd5UfRj76FhjEBbhYzcPgUFe7ivVQRVBlcYSitkzQp8BUHe3AwuJOAtgxC9gEhCZMSV2YckaBbQUwg8zubTx8CIYZ/Nft2d59Ad6Ob3OcROBq+0Itol0qW6snh003MPEdGPFnd0nPe5M85LLaXsHRoYeCOAFczYWWhuIi2F5oI0ewxs+e44MgVLWwyAtCbJkru6Oss/XfXAlcwsT3R2vvU8vVa0m7k8MDR0w23XXLfp8ukzFZRiWSjY/Rky5He5Zp0H8bw5JRHbHo524PjbvQ+dw8vkIsAOx7OjMwp0aD8gAFAaQhRw+NBhdHZ1/SmAPxkxfvwEO0fnNAdExJe+61Iioq6SLOxtaGwg7Q7jepEW75PIAfpoDojsXqmL0NgCLqcsgz4XFgiYNyO9mv9t+8YXw0AlmPManaHm1sf9Yufki4DHGW5ixKGwGM46zRClmHmkY+gtOBKCYwwwAMqBhrh5mgQQquuFD9VLkE4rXH/dszzruAhekDnwY7AL4+jfGbOIcJ/3bNnIgHB7drRVJQHABZlm0gIp0xAKSPt61KXTZ9E7bnnD14ayKmaOG3eivb75kcWLF0tmLuqCKFIigKIMP4kpzGVSw+iceOtMTSqYCA6fWYQ6J6OrQ5Rz0AJhn7WlDWIBsmfHuvRLkUhSWaof2PhEKWN1MxGdczXAVatWSQDcn1W+dtWUWd3Xzbq6m5KCnD9x7oHhpfpKV1/fbfMBNX/+/IzL5eFSSvHDR++Zs/vQHk7KZWSs8imSLqPA7QcXVs67n0SYKKFgFOrq5N5De+hkT+efAdDLFi7U5yLXXMZEQ0PDgf29+/8ZQN2iy6/bNnLECKpWBrSLf5k0VWHEuY+6WZnrb+YWxiEn8rzmazg4ZG9llKfHyInuznAkbaKR5PStZpDSkBmDh4b0iNZW/P7t71758z//z5/+4A/+9YM//P++8rfvftniisoySpCwMbIDBmG7tcY76ijgRZ/CaCurm+MrAJVmSCsVKpbrC6VyA//8gV9k//erf3nZn3T8/frnDm77S2a+6SdbHm26oCiQpbYsyxqnDZ9EGMxAKZsaCYpDcICdQ8/Qb3yEkUuldSolGFBBprLFzx5es4c4JjvFrVGNZ5YsznQGns/EigzrXLDFyeDIMRX6YNc+NmQjvOshGBlZbboUgwVLTxyZBpZfhP1x940xB/ztzXySBqSW0AO96fVXXIcrp8752ooVK/p3lcv0YpjNyYb2+vp9EPjTH629r+3owMkGLkg9QKkc1zyqumjivPuLSfGVLfWN37Lf+e2h9OfQTi8qE1v2lkhr1bdTmLHH1350xtfGWCRH/d6Iy323Bsf679VeQA6IBFpzn8Z4x2xuc96w+Ps4w2/KoZJghJ4uZ+gMr8I75DvtecEOlhhG0CYaskCQXaTlGgVelYK2MGhQQBQlUJamlLhLtNcUJssK0fi3T0GyYMvn5+dATjSZuX6Fj7x88AocvkQ6cUhLhSaoFFANGjS3HmJSI9CpgC4FEW3ENl5VGKOwzMAMAS4r5PDFGQCqP4MwnkRvBFoBxTWdtjKrmmboGei/aLvBmpqajo0aNeo5IjqslNpVbG0VShKjIG3Kq8jPcTyj2pxXVSdkYfeeXTjZ1/tRAA1FKR8+137YFNasdWhodF+l8siIlmH/ctUllz4vG5qEKhUVFxITuSSyleMorG9kvAWm4fDazatdi5BiFK0DrCJwfF/z293PAZBgIBOKsoBjQ/14eMPT3QCmtTTUf9r27JzSq0ybDwC4bu6V7c3levs8l9sQlBHY7buxnbLe55xTwX4LNsIqhOHQc+/TmVokR3IRlOh3bGnn6Nx8T1+0gzDiRmFNfUqriwI6xGHBWUQPod8MByv8HRnBCrC0wN6atYxJ4ck+JfUFG+dZylgX5z/kF2jaEayoFZSR0ov0UPgdPovFaHCyuM8jPQrkB1T7SHuRSBkiA+tqyu+69Y1Hbpw2d/+Jrq5XMnPCzHUrVqxQx4a6fqe5qXmmGhxKRSKFcQaR34ctwOgfGhy88BlyjnWBQKPhUzfEmCpq1X9uP1Ek611BK1JMhaSE5w7uaH54y9o/Yebrj3R1TYX57lmB/EWLFmUAcP9zG38N4N/mTbnsx9dffpOa0jb2ywDSwbR3K2DA5Mim9pHHek899eCGxy4ZGOxnFCSpAswB9n7vfX4PHbnq4Yj348Evo2alH962TgB45fkYtDb7I5kxfEbP0NDQQ1dOmfcv189YUNUqhUgKTMIUODH9I+/fZQpzS0A41iQmTGazz9/Legv67VoEDGEGlJ/wyKCwr4QGJBN0pV/PmTQD//iOT6ye0Djy5yd7utKJw0e+/asfXv7lV1xxQ0+1pycr6gSURQ5dP2nWzPCq2/6n2Tqj2UcjKQUoBVRVIUszKjW0JMRSf/57X84++PW//rv/eeKn73zTrJt6l5iCYxfadHu5GRjKTIGmqg5nLNdiJT89ESP7yFhglTO7ZewdXD0Kqv3I0ptlOV0bgXfOVgpfMrzo4nJWBrsj0+Ac5/G2CULuXGlnyMX0EFgA8foRkTl1zPbBB3Bqo9l+kvKCjgAIDSQsGBpy9ogpvTMax65csmSJwuzZv9GBv2LFCsHMCYBTJ/tPvfX4/j2a6osJJVosnHmtAHAvM9NvU0XPr52xqIxrAbJEQiYi/Hit80QKLzyDw9SqDa9344s58AIMwfrIYc2NyQsV93bscUIAtC4aSf6ySCdxdE8LgCxAMNdHe5Mc3uXItIzG4DwxPs3Ce5Zh0qqivR1unFk1RZVTkapKVuiTXNhEkA8zaC1A+wAxBAhhPZK58+Qs0LafeS9hvF/QjscblOxmLQKdfh7dGlJQMG6tTgOy9hESoMTcn1lBjyDQ1HogScDdmTH441QRAUARdDuAiQKsVTRHUeoDO6AZPvN42ik6wEeX89FCDSKBvqEBbNz7PJiZLsOmC04VYGZa2rG0yMw0aczoRhIEJDKqhppXBGAYD6vdD6SVgkpTgMAr1zzZuGXPgcuam5uPL8urgd/YHMhoq6vbM6q19VdENDB98tRlkydNEkNagYqFiBYD18ICMormyxn8gQ7gnTtnngO7Kpa/amW8iTRz2DvEFhwSgROBpL4s+jpPZP0DvYsArNYyWWrTQs7Zczd//nz09fWNmTlh2pPD24ZBK01SuMi8PRDX8hzbs7pIh/Ga/SrRTyQUJEQCoFEQXTi4oBonlJunyKByoiU38YyQunuRmhD2XMrTQjjhkVG34bsdi4LIIAg4KNAMRWOy4uQ0D7mXTVG6fX5+zqR5gJBjeXGb0ze+b7UKzF9Uc/0ZONeDWqtWPJ+ALf+YN4NEpZz6c/qFCxKDfZ1q4aJXF9696M2/BvAjkvIwEWUrNm1SALDymUfkya6TEknsT3EPlWJwcAjXzrzicwCwfPny868wI5W1BUPBZiNvNRwN5yuEBBntukSRfsyDTSs3iVGuK8vte3dg5fon3gCgp66Fus8rwHn9gSoRDb3hqpuf++zvfiKZMXLCz4jogTFtY/a41MLW1oY3P7br2Y/t6Tw4hkhqkCZ2RpbPdICPYPo9+UCkW13WDkGkTMSJ2n50V2nltrWLmfkvu3p7/5CZ688xUpgxMx3p6dk4oqGhbc64S38wbPQYCdZaCmEOkU+EjRJSjRODvB4Me/MQzit0ss/TcoRhCN6R7M9GtudgciwM7HmXkEa3I5EMIbHjyIHuI6eO/DxJaONApfLJ+qT43PI3/9GjV156ZaF/oCclISNDNRIBDqq4yJpmT1umUJ02R1jFGQwAUs6goUV98/Bk9TNrsr/56b///r/88mt/c9eSt6uVK1eeh4MxzAcAM2+Z9kePsE1ltWvkaT3AI/Z6N94P6KaOnSMdAIkog8zKGlN4xsXtEObcC4qQfmme4ZzQOant9U3sSnPOGh8Btmvs6MHXAeDY5o2zF9y2q9jREwxDAFFWX/STi1jGPB++JzSBleaGplY5a9SMAwCuONnbtXgJ0YtWIWdmmjp1qiCi7LH9G17+8PNrS6hvQGWoX106bRZmj73kywDkqlWr5Lk6Zn7bTKuZfEcMZi6dkjMGlxESxAibbGNKiJoHQzZdwRAee+IxH1sGOoPhAQTCDRaD/YRdKgOin8j4oZCuSm4oVtBzzFg2A9NFv9iO15ft9SwWQTuOUlst4WsOUM+Nk62R4oflNmIDSPv68eH/8279yfd+6ODsqTMTzUQVVdVJlujifgn5ZAZaWQE9VQXtZIhTBGiTFsT1AlwnwSWrHITZq0Zk0nFM2ifZoytgDp9XGqRCmpMHer4aGWxFT7vvjSwAi9C/Ky/ujXOCSYUSZt41aei2BFRfBAYZlJk5d6kU0Pb1ZAY3K3DGNjXF9SlGXnmk5ONUXh7nYSNZiSaYUa2m6O7uJiLi5UuWV3GBjYh41SZoIuLR7cOPJoUiMmHm3RGYieYAOj5aQGlT/S9VUNUMRInacXAvntj89DJmLl67Y8dvzJU/U7OeL3nz0qXJR9/wtp9NGzH6maJMiJU2FQeZfcqPDZCHYkQxaPBS3HplEaWVWrBvltqCIjg+QgTmLM8pwBxyy6bSodaG9gVBFxOoYkJcLusth/c37Tl5bG97ff3edevWiXMV2MwsPjh/fkZCPDZ99Pi9jSw7EyFlKF5A3pCJnR85kMQwZ4wpNv1UCqqaoiiKaG1sHgTwX5v27z91rutS20xaUZgvI8ICwPJKOVob7ziy0U1mvvC6MmxPVvAGaigGRP4SC/Adbg+SLIwFgNuD7XjOR5WFuz449eBBSORkctfY9fEOKVD4mKIH+v4xXpISrP4MhEh627kyz81pnRrTnr2qBBAZ23mn4GnzyCH+rgmAEBCJjVBLgZSHsrYxo8Xvv+6dz0xuGfH7RLR9WFPTRgAYcfy4ZmbaeGBP25Guk0AirMwJ3QczJ4lEZ3/PTwFg8eLFF0ZBueiS1bPeuI30ttfR7D4ODoFgdcMAW9MlJoJOBKqSgZJUv970pN60f+fCFmo5+ekHHzzncvFLaIkCgEvHTr3jxolXvWnSsDEnbGRV9lZ651bSyhMAen+55tGrDxw8jFKhXorM9Sv0LyrNEWEVN8TgYCPNQFWhTjYkG3dsxc+euG8egHlMup+IBnAOGRA2A4QTKZPB6tA7PnD72783f+plQ9lQPyeFQm4vnjNGPdvU4B+TmXxaXpTHJgGbu3RucxOXjkoCIAlAAqIgWBSEpoTMPtWSyWBCKQFLjSoqg2PGjDnW2tC6tqFcvouIvnPT9Cvf84nXf2DN6JEjC2m1mhW1gIA1Mn2dFQ40pWOdZd6nKJvDBQDYOcETgVQq1A1rS7YceD67a9tDf/3grnUfW7RoUXbP9ntKL2ZQnLl5HhVA6BecjEKYW9f1oFuCUecnHwgXk5WbDucSwKRN1I+15RPy7BP2ZbPXY8HYR9BtkcysdfQZuOskbHDVke+L6x0HevZ/Oswbfc5BZ4Dc0DkapX22e07OAoyEJANEDBIMJIRK1s+zxl+KGy+Z/00AqxOivt+4UkS8YMGClJnf+dTuZ99/4MRhlEsNmiuDfM3Uy7Nrp1y1iogGm5qa6Dfd67ftzO30lFGPZuCNK2GNP1NRLnAH136Z/ddsc4qxhnAdcoMlIYqEWgQa3FPi5xgDyPEoe7rzgo4N4XuecZGvmnt6JvF/RaCDYPOhjRDzBiNpuGPAY6MzGm2OOUxzJaM1VKZ0U2Mjbpp7xfav/MUnx3/+z//i43/6f96zedGC6wQpLQY7jyvOMp0MSJXslxAbAVoLyKcAsQEQuwTESQEaksaAK0lwOTGCuiiAAgEJmdQXgo9isdXSPlJgj0Ywsf/4/AGyKapkDUxhSilz2ChCNq/dHWXg11QzdJ0ENZaMUdinIJyBqQFUAV1WoIkMzlJjSGi/igYAw5TNhrD56N5rW5MT7wUPbFEGW3Jdaxw4erLCzOM6ezrfAnPfCwJFCy0a/Z8H7vt0Y6kEpdkM3FfUI5/Kagxg048QiQNKSTHpOnhQP7NzyysBXHP7jBmV89nfSOb8LTVy9mwGMPTGa27899GNLSLtHaSkkoGqpmobolLltTVMPOdF+35yABzB2+jmWJABCsLup3HARAgBZq2rnSdV2j+oSINd1ThiQyNaMArNjXLNluf4qY3r38HMxV27duml574uTESsmT5fVywOXDd7LrIsy++hjZRTrJ78wO0IWRuDnRWD0xT1xSJ2HTvyN0S05dVXXjlwjv3Kd9KCArJzFp8RauRUoHnAyj0fFYwByYU3b4PyC93XyodYngI+YswatrBFLDthZUl8D9hBBu9wAJ81hqKBXdCszVxR2O/t9sXEXSU3iRe7uShL7JTSDO32Ttk+uwiKYxxmP1QPugMgzMMh1nElLCsvhQjyLDFyOBECRVkAp1Xxkd95n1g8/5a/J6J+W2SBmFksMqmRDe3llr86uH8/ylxKhOJgjwsAgjkpFvDcnh2rAOCyyy47b2CklMlTDGZFjSAxiwhbO9kXyoibmTfOK0knWSzdZVqjUKyj53ZvwjN7t3ycmSdvPn6cz1duMzMVCvTT5ubm43b/EDeVmjZorU/sOH5gxCMb17SQgpZKe4eyM0bIOpod6HXOZ3bXWQMA2shYQyuaskqFn31+47x9nSe+U6RkA5vD6c+ai53xO2H48AP3b9j09gktI1cuvu41K8dPnpwMySzjgtW9cKn4CMvhI/eB9hwOIYfgtXNSw9cpYA4GgsFCJvWYEwIKElRMOJMpZcVMKKm1KBlHNErGMEw5Q291kJiZ7tm+vcTMgpklER1/1/W33fbeRW9f19hcn2RFaEPnxuksXL/8dhR4OWGMIvL7lM3kwKfLIjFnc+qSRCXJUGhtFo9veCr74j3/9YfdzMNun3F75ZwLzVjarCvV9R3tPckoCrNn0+Eb2MmOyN/pR58VYG9EwmGpkFNJbrOh++3YQTj86WQNR+dpi5xeNk4I4HQfSQhc+D7CBG8cPnPPMGsd+qvth0E3BT5lL/Acbg9jdnNGcKo37DN1wpGi+/rsQhDAJsKtiwI66+eFl12rrxw57TkieiKqLnra+rloe1dXV1t3f/dnAMx6bMe6cb2nunVjWqC6+rbC5ObxO+qBhu6Bvv9jjcbfFpM5j1aTMhq98JLFqQTzXk6+R1aYBwKOZiJBFd+aomuCMRDu5aJ47puBBWLlCy/IOOpj3HVHhCF1kn2/zFesV95FsizhBw9xrApdh+NUn2CwhE+Rz9v2ESPj9VLVIW5ta0elmv77vhPHL3nVtdf+y99/9KOf/N7fffbjX/3Usi3vXvwuObxpuNCKZUVVtSyXIEQRsq+EZG8JckMB4gmJ5BHzI59gyHUacpOG3Kkh9jPEEYY4CYhuhuhj0CBM1NAKLEokhPspFyDqCqCcUSnM/jgLmLSOGBoCEDJvTLo5cNFCAaCxBPQDOJpBagFhIzRcZWAMAa323KxIwFGk8AD49fD0RAif22ppzm1moytisLePP/KGNy8A8FWScgT7fK0Lb7ff+nIe3tCkMVSBUNpUW3N7DGJPfcQfLgoLpSHK9bj38YfFk1s2/RkzLzze2/kKS2fnBHyYWaxYskTtP3Vk1kfetHj7DVNnPy1SRVzNNCopKNWW3mB1hKNjFxkXNXPM+Wui3zGYcN5Cl5YphEClrzerEwXxlle9Uc6aOEWmlQp5HiA3D4xioSCOnDpBq7c8+wYAesmSJWr5OSpuB5qaGuq+REQ/bmhq++6YkSMxODiYant4c5h7Qm5/ZySnclpdayBTIAjd0lBSzCw6OjrO2/pgZmFqjjhPfuRYE0BkeZn5RJAzvk8MkBSQUrK40LMwGBAy8etNuY9i/rJpZ8Fq9fPlpDCHW4ZZ5EjuR6YD4lcWHHBOcXi/tf0roq3cj1lGeZHtQWaTWxHzba29HKfJ4rTPKKRQ2zHm7x+Bqhi420uNHBYh8lNf4P5qT3rDjQv1u25+7e8S0YqVK1cm8+fPZyLinv7+V1eq1bsAvPnBpx8+KTJADCqgqjzdg8gXlxrR3tYEAFh4/nMkBA+SSwPgkNYWDc7OhZs/zv32q5tTjvlJMvvUGYKE6O/p5pVbnpoMYHTH4sV6xYoV5yW3iYhXmsig20fEp06dmlgulh/+5dMPX32s61gbJQXOSFOIwDskHJx7IcYSxkfMpuBaZuSNYo1qWgUVy3rD3s387ft/uLi+vr5MROn5FrN4w4IFA0RU/b+L3vrh+eNn79IqJSESLZy6dDLCZoAw+5VxQwjjcXgmcqaSlem+gItLL3XrIQSYWavqIM0bPrP75cMuf3pEQ6tQWmlzHIMAkgQD1SEc7ToOANjfs1Lb/ZOqwxRzO/XZxX90y22zXv6MIg0hEiW1CNllAaDB0xc7A8S855zNbJOVOJe2apyTQkOIVNDmI3um/WLdr97CzC/vHOxcCJy9XnXyfrAyeMORvpNFFKT2OEhYd1aAGrHwq0G2UaSw5j0vSxAMrCCR86EP/01yeREBV3teiwdAkb6xa++L9AHeueWKrsfsGEvs4DwNGNdgMidfYuxOwVHm7ufHVNsC7nbzkXKq6keMTCa3jnsGwMNLOzqKL2bAERGvXbu2cKClpb8+KTc/eXRr5UDv0RlaMVfTlKYNG8+vnnPTKgDlKmdb7ddeopN9/3c3zzQmcyxaUr+AFPOA/cz8qo0+RF8Ob7sc9fCRLywQ8qntB1YYw/XFGQlwzGIilBxd4r0QrisO09RQJ5M1HinyaFgg5LcNMRDON7DjcNUu/a2tdzMCLiGsHoMEy6gMkNbGKKpUaOzwUbjuinkjGqW8feXKlcnuAwf2jm0b9i+/d9ttN31r6bL5X/rUX3/1o29/97PXX7lAKK3NnrUiwCUGFQDBAjRgIoVyv4TcRpDPCsg1BPmYgHyUIB8hJI+QMRofFUgek5BPSMjVAvIJgnxCQD5JSJ4Ckmc05AYFuTlDsk1B7tNIjmvIHkBWCJIkRLEAKkmgJI2HThB0Lk0hpMk6g5iGlwEm8LGqnU4NZIAuMTDVnPNDkPB7Iony5OfpIwjNUCWNvKJjNkBIQaGtsYXmXzZnGoC7Whua7wCQnE8kLm7Lli0DAPzeTbcV5s2aK9DTZ4zZamYjkyps3Lf0YaIuZFJ6rfFcbKynfUeO8Nfv+eFkAKIymHZyrTY/i+Y8aBOHjdlIRA9/7o//4h9fe+NCGuruzEQiTTEb5tovRXtNkQcKPu3Yzr+n6bDXDsqeF5Vl4DSDBFA5cUrNnzM/+eof//Xzd/3Nv1z3oTe+/T1zL7m0R6lMUyJND7RJV9ZpRgBnT+7chE0H9/8fZm4+duzYGADe+3e2bffu3WUAuHr25Q+PbWxJde8gmT2bto+xY8qm97KwxY4EeWcHE8CJBKopTZ84VSyce81VA+nAfHt20fmYIJqItDKJfF4m+Qh8LAS9sEBAGjWGEIOKAArn0Y9cKwihhBCBJuwzOX6mN5I5yFnWHpz5kBjY+3CCTnD0EkAo4DJJHO868Op0AcVdyeEsb1DocG9pC5wsvNDJsI2I9GC1Ug2lAq1SsgMIsRZEEU8LTK0TBQ6wuu+6cUfL6UC2XU8Pwnx6HgjFYgFDfd3pvCuvKnzwlYs/Oad98vc6NnYUF5mIoGJmyVn2JDNfV9HZ7U/v3Gok2lAGGsqAqrIZAabLJAV0qOpzPs0uK1+iWCnWROwMIc3+AjeOF5ll+3+sjJ2jxNKMBkgTREUhKTfh/nWP8g9W3/8+KLzj1be/+ndtP87Z07+IKLMOpASAYME3Aiit3rT2ppPHjiApl6X2Sx94zuMWa+1TtLRkHch+X5l1QrFmFDgRJ4+d0o9uXfO2w5WukX1DA3/VW+m9vKOjQ56LfHPXnjp1auLBnoP9H7/9vf9429ybZfVEV1ZKJahqjibhlH3xFYPPyVceJXckkghyzq+Dc4bDFtxyR55oDaQKxSpAPami3gHx3kXvzH7y/331Hx76m//+84/ctGRzmSUlKXEyxIAW6Brqw7YjewQR8aFdbX6MS5YsUWt5bYGIun/w0c8t//RrPywqnacUSRHMJWd8hmnPOcb8vjdhcVuUfm9SDMhkoaQaRRRw4MQRvevo3t8F8K5KRblU3bPSq0uWmFTjzUd2vrtXZvUoUsYihPp9FpmlE39UhFXduSwUD5IjOekcqXF3HG4BPIiOTDh4LOwALcHi3rxx6aNxMNjLRQu5ZuhOH3kMFZluflHIYVubI0RBXudgeu6mHDC8dzzE+gQeb4BMMRmpJbhSxbRhE/TLp1+3kYgGV43YpH8TTps/f342h6iaFItLn93x3JKnd23mUluj6Kl2qkVX3Eg3jJ/7IyL6rxENrWvM1Px2D+H5NHHaC9f8BjNHpvSCSiAG8y7Fwn4QFKF9s+a2p7Gte5oPhZP7ZVIY8wrGETHyRiBzrjiUsVvcvYxQEa46IeXTfNxlUdm44LWKWC4+gyYnNPx75PfmCSJIEoAG5sy4dHDG2NF1vYODhUWLFmVTJ0x4buPGjUUiOnXw4MG+ty26ee+dn/qLee957eu/3trYxIpNbX136K9mBaYMWqRgoYCCBhc1dJGBAttqcwLEEqTF/8/enwfcVVX34/Bn7XPuvc+U58lMyMAQCFNAhjCPCSogCqI2ca5aFay1am0dWqsJjnWqnWwb/Vpnq0kVxQEFJQFkDnOYAgRIyEDmPPNz7zl7/f7Ye629zk2IgLbvHy9HyfM8956zz95r+Kxhr703XDOHG8jgdmZwWzO4rTnclgxuk4N7AnBrCNn9BHcPQHd4uFta8DeMorx+GP6mEeD2MdD9JWg94Podcs6R12KA6CiUfpYEF9ctyg5h7D1oSj1s0729BccEOIYvGTyNwOMRnAwIvgnDhB8MEsMlACn8FOfeOVBOoBAI8ZFHHT48d86cG8bGcBOHnaj+GFsO88JlCzMAT0zq7L623ujkcqRZUrMAlSn4UjEmBMOchd3hOM/gO2vgzrorcipWPf7oMT+4/qqDZ06detcfsviZmTNmdjMm9q179yv/5OuHH3NcfXT37qKR1YIxjdujw8VdCJ3M5sr272JMqGL4NO3BBMchmcFFCW62UG+WyAbHytGnt5cLTjsr+8yff+Bjbzr/5fOJ6NYPv+nt3/rYO95926RJU1AUpXclwIUPDuvQGDp87u65//7GFSuv/nMAr6h1d5wB6Lbxz3bMdPDBB49u2rnzoPPmHt+cNn7yk0R5hsJ7FEWQPTXKYSgiK+wCTZDF7G89Rwlfdk6ayKcdN+/eGvDjz994211Llizh51J2JE7c6tWrJzLzy3KX1x0orgNElFtSgylrgGxZDQA9iys43YSiLDaXzFu893+QYevo7OxzSPirJe/C97iFOkWnUrDNOcE+MrvQks7M2zO0gkyF75MMJdcgwCeZ4IgrsWioXojvsE5FcMLZPa9dRva8mNktW7gQzHzqUYccflSrf6B0BDlPQ0fASJsuiHOa7IR8Lv+JtwpDj1BsSYButiTroux/WZ5jeLC/mHPA7Po/vPEDd73l9Jd/Z+mqpbWFcxcWkfYMAOPHj99Zc+6H67dvOqheqx9UjrZKLkviIjjyuhGGDyCZZ8+/Wkocs1ZZ/m1Z+lEwnJ4/Fx2AtDLJ2E0gyXrFVorjC0h5sPq0slas8Gi4ulu/4Qm/dtMTb0CGjb3dvd+OJYjPO6EXZ+rKiX0TD77p4bsPvfGRexidXd5TCc4IXpbKS/c16GPdEI7FMZd+q0kKI3MAssJTo95Ntzx8Z8d3V175tu5G5zljLX/iokWLyuXPod55yZIlBABdXV0N1+qYetaRx3/1FUed9eXDZh5aHxrc3co4Azc9qCgDtlrMEB/cbN7jhfDqi0gJI8WZQQ9XlMibjLxFPLJrV9lweXb5m/9m53+98WMXT+rpPhrANZe/6i//7TUnnU+j23f5vAlgzGN4eBgPPvnwMABcvmhRywa+J9KJrcUrFudE9NOPnPfOD3/gVX9eH9u6zbsmynyEQWNeg2mSJSqyYYoLiVTIZjoRdxixEihW56DpwWMFuFmgNTzk7lhz7yiA9U9tf+JZBwTM7B5e9/AMZnbfvm65f3LLU6BGB9nglBEhKZaRti9RYKSDIlLGJ1WiK3bEknhBRpJN0KIupO+cYjFIno8bg0nJrYHDlMITWx6fN5MU4T6fgu9AoGoAKq1xCMI1k2CpyCm0TPOJnDChgtKs/ZeOuJJQRwYMDdGCY892x+x30BIAWDl/yT7trVR6xZ8jV919/cxW2aQxV5QdE/uyo/af8ziANUt5VW0ZL3uhVPQPuPYBVpHxFQOQTIAmGiQQtI9SckBVRoywkP1AA0nx5dIHWka0lzaScHsFxPaJkXSvjQ5Z2xblrOwmZcYiiTZx6Mh2NG7GQfIRp+fVW3AE1HJwvY4iQzlhxnTMnLH/LwFMHvN+bWiO86OPPrrJzDRjxowN969d+9/Do6O0/+TJqw6eOYPK0bHSIToUccYlbBYDY7Tijlwu/pczfA3xP4av+fhfCZ+X8FkBnxUo8xI+C/8h80DOICLkVEde1n02Uudsex143AH3AXyrB9/i4e4D8o0E1yJQjUBZNDAF4iYjMR9VemB8DtfIgF0ejsMeFFwDMJ3hUcbNTyT7JY6T7DBmBcM6FtFo5A6o5WhlVHRPnkrje8Zd20F0ZUcHPUIpS/wHXUTEH579YUdEu95w/oX3H3fscVk5NFzmZdzBUrqkBtkkA7IsBKt5DmQ5Gn3j8rvXPsLLfvPbz3Z2dGDBggXlc50hM/3yRORvvfXWB1522hnv+OAb37rklJNPywcGdjddZ8NnjVoo7c0zDT5Ue0nTO4AxC6FdiRtjwMBADkLNsx/etbNwLss++Gfvyb760c+88/xjjv8UET21Zs2axuadTx9/6PQD/72zq7vwRekcM7go4FsFfKtE5skNbdte3r7mvpN2DAz0Tuju/Z9ly5ZlC+K28c/2YmZXq9dbAF70mrNfcuukceOoHBnjWovhfDKyFGVHs6Jxh1iq5XBZhka9jnJ0mE8+fl52zgknf4GIts2dP5+fq8zI/TeOjg4A+E3m3E966l3Mo01GS3as8yH5EQ0/1N5GgEEMxsLZcm5srDVa83xNWZYrDzrooN3PZ8Zy8eLFrvAlalntivG9E9gXpZnMoopO6YBZnA9JlkG/51g6Lv2vAL9no557OiPhi/gW9ZRSE3veGjaJQnMM0yZMoaMOPboEgPnz5z9XMrRfWZwROHTalP2mliMj3pVE8CYubzdURnFEN+yaS3GEtGIhaRLUToodi7MatSaj4R1Gt21pHj7z4PxL7/z7e8874tTziejpS+ddWrQlJJiZyeX5lq9c8Z0bBkeGgdyVDIb3EWNbJVzLA60Wujq7+PD9D4pO1POnF4NdX+/4gfHdfSnZoqEZVX62K4zOsZrqGrkx2ckkP94xCjAxkb/h4Tu7H9v29JFEVsieY98jpm7lreP6RwY+D+C+71135f47R/trtUadw+YkJkAyM5jB9yc4K99JQewgw3+OUNQc0F13u4d2N69dfePLH9r6+M8m9/T91zJeXV/0HALaeJA2Ojo6Hpk+efKD5yxenP/Fy17/gbecfckX5s4+vDa6fWuzo+W8K0Nf9EzCLOB1DPVCLCF6LlU8MaihuL+Ai2vCXZZxsxgrx/p30YKTz84+88a/vuqj57/zYCK6qmTM6B8evAHAjt7OceBmwRhj5KXLdm7ajNMOPu4NzPybDf39k5Ac9jCWBZcXK1asyDvq+ec//5q//puPvPIvs+ZAf1aMNr1jCnIb15+CkI5Lchr+VWbnyUN38EarBMYKYLQExoJfMaV3Qg6ga79x+019tvQGUJ88cb+jARzw9O6dl23btIW7inrNGY5ZP1d0P0BYJVJKM4ha2daOs5QmSzTKlHfIM6RjVwfXCmB8zlZYwKftY0I/0i7Ae6yBrHzmjT9gB2t+11k/gs4GQirtJFgl+brNV7cBZxqnLwvfPb6PDps06wYAs3c1h05CwLhntHFx7wRPRPzLh276u8dHN46H41arOUZzJs1ysyfN+hwRrZuwfK2XzaVeuJ7ftecaQltOaT5WL4uTUtikZ1IcG7VZkUhhoBpTGwiI0xobsv9TQbVBAqJw2w1kzD9W2EkW0DKwxxSnWWYmuivKzCwls2z0UtSvopZGl0K2G3GGiDIH192BUS7pmMOOcK8848VfBvCeaRMmXIEwbs0GE9HQ0Yccsg4ALjrjjI3HHnBgEyMjLisZKIoQDHoPsCkLjIOUDJscMJv4afgag0rd9bRVwhdlKLWLu1R6B4yNjaBA6Zplk8Zag0WLWoXPs7KedXI+WAc9DtBtHtn1HnQnI9vAcEU0NgKVBCCLMxLjcqATIaPnQ3lfOZXBjRaoWWjJUzqzaE8/QJ0uF3ZYRR7W4WS1HCV7mjZtGr32pRfeBoBWrVr1B5fa2WvevHkFM7vjD5nzhZMOOeyerFHPuVEv5eBiTefBGAFdExGlmACUnjoanf63d98++bLPL/l67hxTOIeKOK57eQ7dYgA49dRT+89evDh/5wUXX/7Fv/jgx9+26I31kZERNzoy0srzPMyEM0xgIkehJKdBAkA9yiTP4Oo58nqdS4didGSgKEDuvJe+Iv+vz3zp7s+/+68unTNp6v9btnp1nZmzwz760WJ89/hDr7rthrf0b99ez8hxWZZq1NgBLS5RH9+HFbfcUP7y1pXvZebxs2fPds9lzETE999/fz65u3vDwNAQ3nzexYMnHfmibX5s2LssZ50lUXlHSJ7YoycQNsPx3vtJU/fLXzf/wkeP2f/AHyxjzp6L81ZhBDNdOm9eAWBGb+fE6yf09BGGRsNGR80i7DgrW5mHkYT/sjBjSXkGynOgkQPsaeZ+09wB06ZP8t5PIOf2rhC/55o+fXrmvcfE7r5lB848iHhsjElkwdQ16s6R5ofFca16kLWmshYlTilzAsb00zoDBrPVTiChqDzFiDsJRrx2nphA1HD55ncseEU3Mze2zp//nIJ1ey1evNgB8LtHd88BUIwOj3giIkkGVtamV47yiQGg7sqcHCQZv6i7XbHMZD4Dx2QeIwOhaLV4eOsWPvesl9S/9p5P33fR3DPnE9HWOCPWPkZetGiRA/C90dGxuQP9/cjyLCuFap7DeW8lgJEWZkydQYdPnUVExPOfB51EHwtf3L1fV9+ZRx0wp47RVhyyGHw1yNWNxWSschnTbT9W5zH+FwpLSuTj+vLr7rqJb7l/1V9Ffvjni+WLFy92jYFGh0P+ut3NkZ7Htz511u6h/rJer2cSEKr3Y45CsTMaOttp65rjpmqgUAWCmgPXHYqaR33ixNqvbv9N+ZUrv/0JZj5nER3dtDR9Ln1nZrru8suLS5curX3sVZd+6KOvetfnXnbGefWh4d2uWbSKRt6BWh7Pn82c6mzYpIrN0Q0x2+EQxlxzcB01ZI0aWr5ZNJvDdMgBB2fvXXjZwP+77FNfe+/5b7qYiHav5tX1nOlNk7r7zr7ijpUfWrbyZ6h3jnPNoglHzjUHhuEoOxPAEa45dEhMYlTGuWDBgmLhwoVZTvSlz77+r+a8Y8HrVk3sG+eau3eNdXEDjhx8Fio3KJb1q/clM2oe8TxkQGaqw/mAHsSEsiiop6MbL5535nYAfb1dvadGe/p7Z4oWLV/UmtQz/tc/uWPFJ39z/62Oao3SN1vVo39MGYct17SlklWX1wq6hoKxGUE6JD9W0T2VjBJgjkKxPY6bGlbWA1KCa46JeAnYpO091NO81/jLYPGX5cY0Fp0+iSDO7Xck572NZul5zgmjxVBx3OHH8tmHnnJLURTn+FaxP5H2tHKJ3oyMjBy8Y3DHscx87EPrHvnzBx591I3Px9cw3MxOPPBYnHfYKTc/PTg4beHCRf75JthfuMJV2Rq5SkkRTw3f8Mz3yidG0DS7I4a2KiBhHZ48lSa95d32ryTEbAQ4GGWdPjeLW8RIy3R2+jyKvmyrz9jH+4C0xItCiSiJiTBDo+jYiBMkK6fZx3p+h1ZRtiaMn1x78SmnX33cIQfeRuHcIbeP0jRHRFd+8Xvfubana9z5Y6NjpSs5C2tPYLQ79Se821LQqKTekGiUHMI4W0pBaTMCPv4XH2gVQyOPPLZ+3X6+lk1au+VpPLlpA7bt2g449pTnvqfekZejTfBjY/BrS2C8Ax2cATMyoEGJ79Gh5A4CSoT1DwxwB8BTCH53CUeZjakgu2wRkeEZ0u5Z0QASAzkR02iTTjzwkK2XnH72PwLAicE5/6NdRMRLly7NL7vssvXrtm5esmFg9xU/+dWVzY4JkzIuWnGhfmKlBMQB/2OphndhTx5CNlw2/bX33/1nv7n3Dj5n7nHvI6Ih/AHlrdddfnkBwJ119NGf3LGj//r9eif+y/UP3/uim265AfC+yDo6UW905FJKgti/kEshXW8CR/DM3BobK5rDYwRGPnP6rHze2S/FuUef8NC7XvXaT9WBHxHR6OIVK3I88EC5ZPly5mXLLrrl4QePuPLm371y5/YtZUdPX1b6UstdZNdbV8uzgcHBYvlN1x75kuNPedWJJ574jXh+1LMe+9y5c1vMTDt27LhiXHd3x1nzTr1yw+7tv7j3gXtaXRMm1JpFMy3p8mFrb3iKJT+hxLh0VLSGR3Dx2S+5/10ve81LiMgvXrz4+ZJfr9HRUXf2ccdNP/aQw/pX3XN7N4EYzZKkdFePkLJZewqBUFQAdi7DsYcdNdaRZVdQnm+MOPGcA9VLL73UX3bZZXTM7MP4sBmzRn7LXEfmGOwVMqW8LOwebao+gISXKjIEKSsmsJ0UBAwqhgw1qe5KJQZHDJXjK5LjFL0Qme1wBBfWNvnOCePzI2Ye/EhXlh25cefG/RZNnLHuudJBrosuuigjotaOod0XAvhk/8AAMWUZMSGsl01LCBgIPJEBUmWEscttdsU4kHqSZUwoOh/AoDU0UvBgP/fuN6X2+te9ffRDb/qL98yuT7qCiHbuozySli9fXgLoHje+78KxXTu4MXFKVpSF8saVDEfMDhkdMmnGIIDmpoGBqTf09GzneKTBc6EVM9MdGze+Yl7XuOXTxk+9qXfqlDOHx5reZZTppmlRhq29sRKhMyiRTqkH1rlGpQooQ4bh5gCuuefGGW885+UziWg9nsfmEETEixcvpt7e3q3MfOTV99104x1PPdCZd3X5Mot998m3EXmNY7eUgKxv4SinumGW6EL0oB0RyJdU7+jhH636dd+MSftdzswX33z/zTkR7fg99r5yXX755f7yyy8HAHz1sstai1cszt90+is+8vi2Te6rhx3/1h/fetWUB598CPBZkecNdo1a7jJHvhU2yYqKF/z9jMCUgTKAC8/N4dEChBrI4bjDjs3POfT4becfd873X3bkaUuJ6AEAWMbLsqNDMLth3c6tH3rrv33whG1bN5X1zr6sRU0QOUajg+56/N61wGv/Las3Gs80luXLl8tGM48y80vOvem0X3115X+fuvLW68qstw+NrCMrqNQjdnTXV0kayC629qzbyDXuzLkY3umPmXXywEuPPf1fBwYGHurr7dsaZX6fmLls2bJs0aJFJTMf8+avfujip556oqz1TciaHGYc5YgYORtQj0uRgA2J/zaaSTgRfUYbSIGSfFV3XjN+MJlyfaMnCL6ug/Ez4/OeWX0kfS7qKckHEH9VZDq5AsYzVt+QOI0k7fXB5m4FvIrrL5fYYMWFaH95rKydNfskOmbK7OVEdLvev3d+ZQAKdnzquFrvu3aODFzzk7t/01krwNmoL6dN2j+f2TvjawBen/viCSIsXbr0qzUArb209cL1LC4NCMtSq4zjFYFQF8+KQFnjB408qlPo8WJOwhhvp+g4s0gtpUxHeCQ5KUlNouJRSkJIlttHISefHBiYn5LVodhG5XEkh0WdFaOEmi2MpWe6tXZbP5hSfyRIRMnI2MM5+KHB4dob/uTi5sf/9K2fIKLWihUrcnqGXciWLVuWLVy40G/v7z+1o7v7+6vXPnrBN5cv8+MmT3JjZUGUZzomIMzAUfoz0o7iom2O9iyAQNJ/KSkI0OZk458s96VvudHm0Pr/+OCH5/YPDx8L4C33PPrEhnvWPHTGU7u3vuTmu+8ct2bDU27NIw8yHHGto871rCMrdpcoVzOwheEOJGC/DL4W6/3j5gEMH0BSZs/2z+HXt8K5cGCwrG1zQPKqQj+lFFPQjhmgWo7B/oHWycfNq7/lFZd8HsDw0qVL88uI/uiAcNlll7WWMWezs+wn317x2489umH9J1ffe3erZ9y4vFWU5OMuq2BOZUiByCHD6TzABO8Z9UaHu/ehB8b+5crlb++ody9j5pt3Dw7+W825j3Z1dW0MQ37O5a7+nMWL84kTe69j5vMe3rTp0mXX/OJvbll9d++djz6EzevXecATcsfIalaAEUt0CezZ1Rpu9qyDa4cfcDCOOHD2yJxZB/7nWy685MEp3d1fe9/w6wAAK1asyOeH8spyeGx4Uf/I0Jmf/vbX3nzLjTcUneN6M1+WIXtOVl/CwS7dEydmP7/+t8UPjj3pX5j5ASK6bQWvyOdjfvlsxmzuuR8AmHncjMlTr/3Et//13MfWr2319E7MS19S4T1QlqmExgN1JjQHh4oW+/zDf/5+fPA1b/4AEW1h5mfUx2dzkYBHZ+daZv7TC88696cr77/jzY89+lizu9ZRL1oeZV02oiIQuzQDlUmZJtBsjbYOOHh2bfr06V8goo3Lwtri53WeJhGV5yw+Jyei3/7TT7/7m55Jk18+WhQ+cy7zlBJwlcAMpP/KOm82GO3ZV3YDrKTwOOg34vM+uDZwJO/ghLkQ9yPZB7EyPgPQU8fI7l3+iGmHl++8+LXLANy6s5XveD50kOvEE09sAcDE7r5/ZuaRg2Yc8Ak0siljxVhB9TzLnHOyRkhnyh2hZF8G58kGsAZvPcOxc569l4A6JCEY3PLwzSYw1nRotnjGQYfmLz3+NXjNuS/f8oqjz/w2gF/HYOEZ18rJplZXPXLr4K2r7/Do6SSfuYCViNhOQLM1Vk6aMs0dut+B/wNgXYP57YuIPhtn2J41Hhr9GmbmD84//vQZP7lj5dV3P3ofNWo9YY5C7TOSLdRsApvco/DW7KQoycc2ehITqCjJsWvds+nR7t89fNdfMvP3B4aH3tzb3fPXzyWwlTVHS5YscQDGfnTbr6dtHd7FjUY3Si5iAJ+SFsGcxljNbo7ECDbLV9dtVadbWP0f70tkLs837d5RfvmX3zxrzkGHff01x517451r1nwvzgA/5+AcAC6ff3m5cNmy7MDJ0z7EzP96/snz3/mLm3/9V6ueXN2zZvtGbNjyFPz2AQ/vCCUxCp+Y4JiQBw+l0TfJnXDosbX9uyfhZfPm737pCWf+52F9+3+NiB4Dqri+a3DX4r7uvnv+5vtf/ty1t/wW3Z3js2arBZ+FMzOREZ7ctikrgBn1Wm31vvofA6+MiHYz84VHHzr3sn+Z+s3PXnn/ddiy+XFPvb1cz+rEIFf6QvEibf4XKZ0Fv6buHVytgeHtm1rHnHRK/X0XX7p8IvXeAICebeB9/5T7iZnrX7z6m3/7i9uv7a3Vu0vynpBB/Tld7w2kWWKN/KIf4kWew8ceYZNC+cweQwRwPE4L4LDttOKr3mOCOfucAItUHChOx66Q53TMhPix0TcOzbWtKbQVZnLMBSc/nqNcA8aX1P4kOqSaF5kppernnPz7omyW+02fkb1o5hHfy8jdvopX1eZhXvlM/BKb3NXo+gEz//DK1df9eO3Qhp6sq17sGu7nC2af6//8pa9d1yzLx8o63QEAGzdufKFk9A+4zAxh2iHScDv+FoRXRLMtbNSfqroikJJF5OjUxxm9IKesazE0oQqk9IYB4NS2vTF8o+4E2YWuSSjVcOlzrEbMvkYnHzmtt0L8uxoot+E5SVkrJ+J4D+eAosVla7SZLbrggv7XnbfgfCK6JQLWMzqfCxcu9ETEjz/++EOTentXv+WiV/7d2s2bPnP9bbcWnRPHZ62iFdROHS0Zs9Sei2ZHt0sZxqrwSanjQCkYPJflbnS42brx3rsO+vntN7x1/fbt10zt7dl47KEHfe/kI+d8aazVGtd/yZ9cuvrJx4+47Z5733H1zTfQbQ/eh+1bny7yyX0ub3S4YncJf58HrSvhDiDwfgQf13mqY0AcMrQTAJpE4M0MqjmznsMEEqA0exEsL1wRjj0YGdzd7OnqqV9w8ulXvOyU0/91yZIldPnll/+vZYcWEZXnnHNO/oZzFnzqm7/5hf9aVv/0jTesaOVTJmU5nCtkVliP7TAXI9CAgNI30dHXV//xb65qPbZ27Rev+af/XD6+0XFPvd7xFKAOzXO+rrs8rNsgoqcBfJKZv7J5cOBv71hz3yHbtu981X2PPIRtg/3UPzyMVtFCEXdHzZ3DuEYHjp5zGI3v6N7V1TPu+xefuQATOzv/gYjWvys0T8uWLXNRPgsAGCuKRfUsO/29n//k639+08rx9b4+Ln1JlGdp/OIsEsXdYD1RZyf+cfl3e6b0Tfq7eq32ygUU1hE+R6fPrVy50hHRADNf2DOu61df+dkP5l9743WM3BV5R4dz5MLcY7OF1vCIbzWbdMicI/Pzzjznob9/7Vu/2oPaDftKzjyXiwECs9u5c+ePX33GgoW/vvWG323ZsPnMgZGhorOrOy+5RKWukEg3TcgYqLvMN8da9VPnHDXwvgsX3frGoVdMn9Ldven5OpEAsHLJSk+XE/35xW9cfN/6tRd9/Yrvlx2TJnOzGCMDhQY3AGKvAaBN8jEYjpzCi3WEtfwzrjdXfeVUq1FBcclQx3sEl5wn1Op1jPTvaM46aHb9z1/++h+ffsBR//Z8xv5MV+T3VwdaY7P+9u3v+/t//e+vu9Gihdbu/iJsyAUt5QURahMn5E6P2DENMcLGWWCMDQ6j1tmZOTnShRxq9Tr6+jqx/7jJOGT/WTjzRSfSQfvP+tFLjzplbR341KJFi4Y+8e//3rWv2QxmpjvuuCO7/PLLfS91XrB5eJdDT5fnmiMqs5BIKxlUzzC2fTtd9IpXu7csuOhLAB7bNm5zqJaIgfBzvaKdeqCW1x74q//63PUPb157dgvUqlFWK7hMR61Z/lISjXjOCrSEPjrZSD80ScsczzotGR2N7tp9D63G7x668x1nHn78LczlbyXAwx7Gd+9X1JcSAO7a+Nj77n/6icncKgvu4FryaUyLhBQIIjnhxi83jVsiITovkRLEKIoWumpd2fbt28vP/vBf/+SASTP4pDmH+1VPPLD8DmAbMz+jA/zMAwIvx6JyYZhpWw/g48z8L5sGdvz9ysdurz29bdsrtw32z3h045PY1b+LyrJEWRTIsgzdXd3Yb/wkzJ5xAB0wefrm4484+scHd0//dQNYQUQDALBw2cLsqIVH8XzM90TkH9u87pi+7r6JX/7Vdy//158ubWWd47LCs+NarPbIw8LF/tHhrgL4bQfV1i0Oa8CekT9EVEZZ3wngH5j5wdevv/svlt101Ut/cde12LB7M3h4pHCNbhc3RSJQzIsGaGEAXHqP0daQx5h355zzsvqHLnrHrRceccbfxmDWPxva/vMv/7nxvgXvG3v5ute++6qHfvf6nTt3Nrt6+uoFlWYiIfZb5cPw3MhyGp+GcBBUjOM2jRmfrRKQVcI7mJy5OMUpSIYNWDVcDfrI0AkcZoRqKkhf43vVJzd9QCoz3cP3N/6xxXsz8kQcQxLxMYnj7qLOYWRwp3/JgouyS449/yoPxtr719KJR5+4T37FoNEDOPbOjQ++fMOmx8vuyftlnnKcPufEof27J30lyhSAtA73hev5XRoQhr3Sg4FLszOUtga2GTJ7GbxXpx2STaEksDajqGkNo1ttCraX1wR1sMKNENHZsIhUwdJ7bBlIWrC7Z/vhZywk4dR+ooEddPxOh5uiyAYRhkZGyo68nr35la/Z/bFLL/2zg6ZOfSqWx+0zgyHO38EHH7wrfvTZb/76KpDnz1x3yw2tjp7ejB25gj1kdz8mCWIT+BBbhy7NkAoopLUfAFym4NE5rie7e80ad/s997//7Lnzup566qlrZs2atRlAFg3IlwCAmb/09ktedeTv7r7zw7++6cZTvn/1L7B15w5fH98HInKt7QVoSwu0XwF3mAP3AFzEUoS4C75vlMhmOvBWBrlcD2s1HKw6pwywZ+QEDO/YXu43cVL9nz682L/u3Jd+gojGmDmTUpv/reu6664rli5dWnvrS17+mdsefph/MPfozyz9n+9haKi/1TF+Yo2zmPhwLoToCuSRN7JupmhRR1bLHln3+DGnv2UR/fzfv/E9Zr525R13LCKibc931mrBggUFM9PyUHa8A8AHCYBnPgovfblK/sDYGJpoAqijp9GAqfkZIKKn9K/Fix0vWeKIqIiZXvfru+/uevHRR7884+y0v/jHz/3pN3/1owmNRs3DOcfkYtJBGkhJB1DYLrye5fn69U+W//6j7118x2MPf+PoWQff+eCTT/4PEW1i5ho9ixneaPh9dFzHmPmCU+Ye943//tVPX7XigTs67nvwfuwcHoRnRnd3J2bPOdKdcNjReMW5F/zywuNO+rMYND9rJ/PZ9IeZs4kTJ947ODz8sqUf+PjHOl39oz+77dqXrH1kDWqN7pI6a1lYd80Ah3O58ixDi8tydNcOfsVp57o/u+CSdwN4cHjbthEATM+Eu8+hTwDue8/LX//Jnbt2fuzH1/0Kja5unzvnyqJA2FwgeBNKiFgenypCUvCn/JQgEPFzW3LK4VtPvlIZxZA2BVBjhh1A5nIUZeGbW7bwnEMPr39y0fvWv/aMCz6yP782WwjQHyNoB1Q/akT0MWa+cnbftE+u27h+1iEHHXrUWKtZnd0H4e6HV9/cKlsjAvQeiOutSzATee/5oP1mHrtl19aHWuzHGnmOjlo3Zu0/3R936BFuZt9+2w/db/riwI5QkifX8uXLB/bV12gLWszsrrj9t2/f0RoAuusMyuAKIGsSckc8uGtreeJpZ+ZvPO/VHwfw0KLly2n5okVjfwidiMivXr26fvTRRxefe/NffXLKhInX/O03Pl9rdTbKRr2WNctCvWWdAQ5PpjiLoBU/6g+0i3O0ox6I6/oIJUq/YvXNE9549oXbD5g4/bqlq1bVLnsWga0kT4aHhw90NXdMI2/c8Z5vfPrI+x9/OMtrHczNIjkcbGasWXodczbGX0j6p149kgPdFj1E/6MoC9R7xmV3rLmn/PA3P7XwPy79BOYdeOT/E1zb14zwvq7lAX9p+fLljoi2AXh/bO8TACYDKHcUYwfX2P/NYGu06Kl15fVa9i8N5GsQQtcdRLRJ2ovVSOJQ1QC0NuzYcOb0CdMv+O1Dq477t19+/UWt0nPe0UEFyrDe2SHMEJaOqZ5NGG4210/q6FgDAL/P8lJcL//VO+7Iieinjaz209Gi+dJbT7v4Qz+48edznhx9+sBb7rsVmwZ3AkUTGG22wvbQnlGr5dTV6cbl3Tj+uBPdxcecU7z8tPPfcHjntJ8R0fDvS5zprPHKJe59C9439uCOzce86+sf+vvr7r+5bEyeUCvKAmkOzTaT5KRazQBNftm7JUkiZfgh2xG/sfJGgogRb8RHk2BQAsEor1YOHaClrPJW41KnkK3iK6fZ8BQcAnYPDiviOusvFYJtM4OGPJUAkdt+I4TdReG97xjXl582/fj1ncgev3vTpu5jp00bxu+5TqSg99+69Rfzfrn62pw6Osqh4f7y2EOOzU8+5OhPUyi3bywBWpc/10TLC9ceV5ohJNZzX/bc7ieWjqYYSUHTTFJJJgcpPIzAK6+Q4ExkkG2+Qf61RkYejJ/bd4kzIlPhBMQJ+zgc0v5JkFiZLIx/kI6JTP+D6dfpeqoKvawZFPwRBQ7FnOwHBofdrBmzsr983eue/OAb3vx6AHdt2bnl8AULFjzFvyeT1n4tXrEif+uCBZ/93T130rdm7P/pH/70J+gfa/rGuG7H8PB5loJh0xeDWpVSVyU1pWArwRsAl9FIa5h/esOKOe98zWsenzhx4raYfSsB0MqVK7OVAIjoIQAP1fP8irFW69Xnn3LKJ37wm6vnXnnL77BraKDV2dVVK4sCWOdQbimRzXHgAxwKVwZXMi7q52kZaIIHRsM6QuFgKAH2YB8DLGbkntEaGS2GR0fys08/M/vTi1/9w9ed+9IvE9E9z2bdwB/ruuyyy1oA3MmHH/5ZZr7j8BkHfOaqO2+e99MVvwF3NVDv6g6Rb+nj4ndZ/xABWjayKL0rmP2jO584+iP/9oXPfv5df/3k/Hnz3vzw5id/SkRrFy9e7JbEYOy59E8y5HGGIT/xxBPLdmd0X9fSpUtr8+bNw7x588KOh0uWkKy5oCVLkH3ik0ObhvoP+8hX/vFPv3X1FRNcT7cP00chocRMqpd2pzOKm9mUZYmunt7sppuvLz73X//+1i++78M/PWzmzD/ZuHHjlUT05HOZFYtBDxHRGIA3MPMJl73m9Qfe98BDl2/c/vS4ZnMM+02cyuMmTbj85AMOeYKIrgO0PKokIixbtiybMmUKLXiOO57upS8lM7stW7Z8pWy5/f/p/R95+6vuP/+r//TNpafdct8dvZsH+n29s8tpOQ6BR3YMYFLv+OxNf/I2vPnFF77txEOP/u4f0oe99QnBJfn4A0884SZ0jHvXT6/7+aRt27aBunrKWi3PmMuQXCLE9YxImEgJZ20ST65KEGBq1zl+KmVMYSmQ7MIXH46Z49ZYsyx27XKTp+7vLnr5K/C+hX9257EzDrmEiNY/3zWUv4cmrfCDbgdwATN3AXhJ6FHV/HWc99orx8p9xyLMfGjd5Y+2+Pd0czHcqotWZVGv9um8Rud51tbdu88goh+8/nPv2z7aGkNOWWBJXsfo2FALu4eyF591fv7al1yy5MWHnfhJMAiL/jhJjrj7tSOi3zDzpWBc/vkffW3/rbueRq2np3R5npUIpfCyUVXF2QTQ7m2KY8kxKeD1LoLPAc8lXGeHv/Ox1XTbQ/d8gZnPJqLRZ4sJzEyjGM3RpG814f/j4fUPv27Xlu3cM2583vIFOEswzLZPMpNj1sXYkmqZcdHKJ8jusvIYp0qoDPCuRNeEidmK+24q/+qbn1r4kYsuXcfMN61Zv+ZWItogfX2us//t2H4H7kBMbj0db3kIwFXP9PyqVatqa9eu9bHSozR9GIt9euond/yWv/jbb5y99un1zY7eCfWSm2HH6riuNmNHIFcUeVnbsGPdR4d5+CO7d425/SdMeILDcU/PWP4vSQ7ZxIuIrgFwDTPPADDvF3df/87Hdqw/+oEnHpxIXfXegeFBdHZ0AmOM6VP3e+K4GUeMHnf4iz5+cOeUJ4notmdDxwA7Wivlf/fUw8d99If/8JtbHrtrUkdnr2cwsXN63IgVXc1fxafThB+nSQCWqggJnCiUbYJNQAekyQuplUrlqFLqWUmshddAlgixk2TLnjolVR76PhlAWwAnpa9ql2U/osqUJEETgG16rMXfxh5UCvoqcUGkUeYwNjbEpxx9sjv+wKM+WqI8edr4zs1EtPaZeBcD+NrGrRuPnj5l+hF/s+zzH9iwbh331cfR7oFt/vzDTxl7yUEnb+RwzET5QjD4x7lMyShJegwJKqECocFP/Ke9qMg6Bpr9jcKp7bD53gR34XYfsxxG5M3zqWBVBDAKqGqoVbXqZbMWGtjFsIyrA0gZGlMYnmrJOW1IJvFu7CdlhLHmGOqUu7e86k+KC8845x/eduEFH/vQG/9UXn5P7O9zEtzLzz23OGfxOfmZx57wmV1jY09MmDjljTfddNOFN99/D2fjekjOqFEljQPxMtZAVM1mxd5HHnIaZzRoZVkQsqx47OnNXf/xo/+55CNvfOtVoWmtzZfyPrd8+XJatGiRJ6IfN+r1H4+Ojb3+89/8xluvvP3G8266+040OhvgBsO1HHB/CTcA1I6poegso+tF4D4CZubwjxFcRnFntMgYz4AvQRGkR0ZHMW385HzhwjfteO+b3nztodOmvyEGBM96wf4f8fKLQ/nZ1cx85+sufuV7/3vez/7mR9dd03nTYw9SM2Mm50gy0bqjrp4d5eHDMQmus7Pb/+THV5QPrFkz7TPv/sB5rzn7xTf39/fP7H17742X0+VC7wzh8PNn7UCI8Y3Pq6O7ZC/32s9MJjsmI9Uhd/VPf9r/8LbrL3zbp//uQ7+47bpxja4eD0dOEzi+avLC7iNpy20p4W41m+iYOMl996qftHYM7PqHb37mC6+fOnXqG3cO7m4C+MeYRX9WAZpknpeEcx3vBHBn7rIrankeUzSMsSI49YsXL86XLFniEWm5dOnS2qJFi3S8SwD8IcYlyuEggEc2bNlywjlzj7/3nC/853V///V/P+57v16+aP3Tm8sadWTFSIuZRuniU8/Gqxa87Oq3vuTi/yCin5j1lMBzSBzt62Jmnr9kSX7UQQf9PTP/5znHn/Kdq2+89qzf3rsq27RrG2q1GmBKRQPwemj5NqdMdsBlSrAeY0YfwVDw22IuOGzlr8lDwe56hubgAO8/af/skgtfjxefcMbvXnPagq/kzv2gZMZiXvy/qdfMzG5+SLgMA7jyGe5z5yw+Z69bol+3EjhnPkBEj+5533zMDz+wJJ6zRUT+xMv3XSJlr9HR0byeZ+9m5vVv+tLfHDO2a5BrnZ2uzIBmcwRz9j+g9vY/XciLzrrw47MnTvvkpUuX1pbi0qJa0vWHXUTk46YgX2PmHxw36/Arlt921YuvvPu67OnBXcjrtbiRiewzoNGWSQal/rDnaHvVsUhOdbynltXzbU9vKK978PYTX3PaBQv7R/tXEdGDkpTaR1+lice4WXz2R3fdcNRjW57qgcvKslXkXKvuiSAJCwBgDglgitmLiuKFm6Ez5AyAXCVp7WylkgvttLhE98TJ2VV3XV9s2Lnlr9//8rcd9bazXr19cHTwuIe2P3VrnOV7XpfF9sW82C2JCL58+XKaMmWKEnzr1q0cZwHlOcE6kiqUnSMDC3ry+qvyvL7kXd/5zJwbHr35bx546tGiPnlKvSyaAPKg5C76ZSXgshp2Du3EDU/c9fgxUw79F+rNX7l01dI6Pcv1+4tiMAqEWbsYJG/IKbuyUa9jcHT4KAAX9bfGit5aIwewprveeQWDMdIKk9+y38K+bKLEYU9s2XDCgVOm89+t/ObIkv/53K9/e/8tk7Kso8yIMx+DJME28RN1GZFOCsRfiVNSQISjEibGDbRsL1Q4KM0egsOGMDrLmErsdY9EintXUDyyC+LSiZ3lILuo9ttLkKktq3deoU4FrQnJZ5RRxX80MaIxZhqz/s2JfmFLhTAuXyf44WE+/+izytP3P/oRIvqO+CPPEAw6IvI7xgaOGD9uwi8f7l/3+ds33DuntWOk7O7uoGlTZubHTD3sagAv2rTzJddNn/jcksgvXM980bIVK3oWzp//13/xmc/M/f5vrl441BwtiFwIFPdmV7jyA+k+SkqVxBqgZxbItL6EU7tUvU+rMlhlTUWcbCqlklaJWZOYpdAGEDMhWhJlR5EUTI6CtrPyKX5NKiQAQuTgfctP6O6hj73z3Y+955JXXwZgNhF9Y8WKFTR//nzZkvk5OfSh22mB/N986EP/0dPVde8DGzZv+dS/f/nbP7j211lHd48rSy+pJmhppVlTCVBlrUOFoCSjTvTNMsLIrt188bnnjy777Bf/xI+M3NfV1bV+b4EXM9MdQH7iokV+wz/9U2P69Onvv/3RB2d/+Cv/svCm++7tdY7YU9goGS2G34+BYwlFXxG2j645uM0OdDvBeRccU8+g0oN9GQ9EZpTNFsZ39fgl7//gf7/nktc80Wq1+tfv2PGtcr/+XXMwp4W9OM//FwCxYsWKfMECXQO330irdcS//XTZssu/+R+TCyKC9yQBINtAV7IRHHhRq+UYGhn2s6ZNd+eddMZ/feE9f3XFhO7eX23bveMdt2+59RsXHnahZHD3mYH9Y1wRrGXGlbbu3Hnu5PHjBwDcteyGa6/+/Pe+Nv+uRx5EravbI5x8Kc8BSKZCjakEhxIQMgOlBxUMDrEczT/+uCe/+P6P/emLZh1w6PwlL/72dZdfp4Hwc5khYuZs5cqVtKBtti86D1FlQ6D52GOP9c2ePfutA6Ojzebo6ObJ8SiYP4BudqtzJiK/4q67xr/o4INPmdjXd8JrP/FX71t+zc8n13r6KBsZwXve8Padn7j0Aws7gOuJqDQz8Yj9fN485r2sQ42zxS1mfiOAo/7lJz88/hPf/Kfzdo+NUAbnOOO4u2bEBZuwkyDOrpliMfkmsRa9pr2VX7HMEDKQuwxjzSF/xIGHui+86+9+/vK5p34ZgQ4FAIr3/p8Y+EirvW5T/2ySEv8bCalVq1bVTjzxxNbw8PDHfSObuOiz733fL1f82k/qneR2uSYOmX7gyBfe8qFvXzzvrE8Q0cbFixe7T3ziE75q0/YuB88n2SAzOhEbzvvGbb9+z99+63MXbBva4TLk5L3Z3VJsdJtNVkeT0veV+yg8m7eA5uhIOXf2nGzpez6z5LSDj7n1/vXrb5s7a9bO3zezuhxwQytX1t46f/74d/znx6/49m+WncK1hidCxhmFkmD19CVptQeFVKCVnjqMiGwxyaqBgjG1qjgx6VzLcgwPDZa9ec29/1XveOADF73zqr68a/jJzZu/+esNVz516bxL/f9VdUscU5BXBt36xOr9Tj7gyHfDuWlfv+mncz7/s6/Mf2z3VuRZnQtfxnm16FcQAAprfYm5rDVq2SGTDvzlHR//4e053IsQZiZH16xfc+3KLSu3TFg7wS9cuFB8H9rXGBfzYjcf890CWhBPbH3my25+s5exyex6lIVv1t5w1ptfXc+yw35878qTPvmTf1pw79oHOvN6j+eMHLu4g6mIhElMWPd0j/cAVf9Y/SnjyIqPKptlGBmS5JhMblRUkqyOkCZXJI8SXT1NVFAFfKUSLrWVsgF7GUs7TOs97b572zMmYAWQKvKkT0A87olQ+mYxY/I0+vqbP3fDeXNOuXDlyiWtBQsu/724umz1svrCuQs7P/Djz/3D16///rvKYZTDg/34k5cuypa+bck5XYWb0Bxp3tjb27vthYDwj3O59Ev8VQUjOgDyt2yIIHUSioTxdqSMRAJ7I7URfJk5gazmVxKa6mLXKNTiP4YALwIxiVFrt3VV0aUY7EQ0qgaoewkGIb568Fzj1rmhT860qT0WgMwdt0ZH6LRjjivec8mrX0pE127duXMNgHLBggUFhUM1n5cTT/FQzssvv7xoev9Pa9etu3vuzP1/eOoxx/7lwTNnZmNlUYb1f5wCDsi2wZFezvQZlodIOwlKIMYMNAvkWe5vufeuzu9e88vXd3Z2fm7nwMCSQDbO2/s3D/BYvrzsGT/+mG27d51/0qFH/vdJxxxXGxsZKlwtC8dE1DKgswa3LQdWAdn2BpBnQFmAxxdAj4crUD0rMUaplOcox4b5ogUvHnvPJa/5z607tt6/duva/zpk2rSnD6PDxiJ9uf2/50rr53MtiGv2Ii2e7qzVnn7rea/45qH7zxxrDg4jLzjsdtl+aCdROIogc6BaDS1H6JzY5zYM7vI/ue2GP/vTT/3td2+4f9XPJ/dNfPrCwy4c27R164J7n7x3AhFpuRkz1+zM3/O9mDljZj3vS+R187ZtL202mx+dPH78GQ8/veHN7/jyp+7+yy8tmX/HIw9yR2c3UJSOywIoyzBLIGdfxVle1THVZxjHicAZAZkjOJTX3XHHge/+7Ed+9LO7bpq5csnKd+0e3P0WLFyowSCHcxp/79lSRFS2B4PM7BYuXEiRdsXjjz9+0ODQ0NWzZ89e8O2Vv57zd9/5yr+vevyRv2Pmj2wd2jUvPkNtbWSR3rV2HbDvlv8uu+yy7NFHH516xty5LyrKchDAz8eGRnajo+GaYyP+kEMOoUUXXPyBTqIVMsaIFX8U+d2bPsgGI1t37nxq92D/+e+95LXfvfCM+VkxPOhrtRpALizZiUfAhHCP1J/RlLHNqAvkCO4zV1FYSgTNDLLzAJpF2dfRRWfMPelnL5976uPbd+48hoiK1cx14Hntsvu8r0ifYm//Pcvn/+izmAPzBhjM1NnZec8199y6Zs1Tj3LdNdiNet+FDO99xZsfvHjeWbdu2rb1PUA4VqM9GIx92xsuPmfayowOLSIiol+97eTz3/faMy/IyuFh7/IM7FyyK3JkhxxW7O3vnI4P0LNQoTad4vMdnT302PaNuOqOG14FYOa4en28OPrP1Eci4kVE5RtOP/2QTf3b3/foxsdPbTVbcPU8Qy67HsdkhZddf8WdifYyxYqApZSVeTAIMqPe7odQhHnW8bWaTXTUO7OhsZK/uOyrcy/8+J++/qe3/3rOgdOmnXPpvEtPI6Ly0qVLFcvj7N0fC9ulLcVOIvIPr3t4BoNPOfmguZMe2rIOr//aXx/9oW9/Yv6jGzZyrayjbBXkSg4bF0W+IY7Jg1ESspGhUTz0xEMXnv+pNy1+yz++d/rK1Tf/fX9z9PDDZh32F5fOu/SoRYsWleK/tAdvq1atqlleXk6X+7i5mNg2x8y1eF+l/xEnS3ufYDIR8apVq2oiC29b8LbRwWJo/7/96T+++F1LP3Th3Y883FnLe5kZjryHK6N8SgWP8DrymWPytl23wiFBwautZNNNGjQlOqBrDXUOMJaikT4nD5i5Pkql+DHUi++TyZDwblEvRgpsxXdN3UjyG3RNbDOiDlT9eQsRoh+qn1yVd5lplx1QxXd2nlCnHDw8mJ0398zsvDmn/B0RjWzdOnef+BN5mi+cu7AFYOrm/q2X9e/eyc0ucNeUPjd32uyVE9B5R0et46e9vb3bhO/7avOF69ld6tikgzAjs9vIa3MFlvQpmDNZJAYq5/eocLalKDTNoUirgspRo1iFPylRUKgo7NJdXRPIFRxPSRmTPVHdjRP89ndxeuLDDG8sRNJ9Nrs0ORCQZVTP8zEA/dsHBuZu37Vr7abt248GgHq9jpHdu5ujo6O7HnjggcGLL7749y6mBYBf33139+mHHHLw7tHRVv/Y2DaX50Nd9frQHQ8+OP3p/p1b+8b1wm98GtyRxV08U1modJnj2G2JQfg/q0Mn36mxZKDeaLgd27f67//sp+e8/aUXXpPX3A4i4nP2cl4bEZXrNm8+ZsPWreuOPPDA+V9e9oOH/+273+jMu7t8qyhIwJA8g3Ig689QrvJwx+bgKU1wVgB9Hnia4HKvIEwgsCO4WgZkhJnTZzQAjH3ntyt/8trTT5+1eceO/ZnHGKib3oSNUur1Ov7lqqvWXL5o0fPatv85XERE/NiGDQdM7e3t29Xf/92JvT1fH9/Z5XmsSUQ1AGFHcElMqBBGoGUXzij0DNS7Ol2/Hyt/fsetfQ8+veH8qZ192dV33v6aaZMnPz4Nk08umacN7N79/S9/+ct3PVN5TjSez+Q47ZFZjX+XC5cty5YvWlQODe2+qKur92gA7v4nn5j83at/dvbPbrz2+AfWrYXLct/R0emKoqmzPQBUz3VccfaIjWECguGK0bNuIkQ1yrKuOt/86EOTP/ofX778rnMf+uVHX/fOFbxs2Xm7hwZOevyRx/6FiHa1DyRmip+JKYX53QPwG7ZsOWv6lCmLAKzbsHPnDZ/9wTe+/O1fX3HQ+g1P+p07d+06//iTtte8+wsAf7aX9kpUN4SqgNmKFSvyk0877T1djUYngH4i+srSpUsPBLBg6sSJIz+76fqFD61/4rD6KPsx8nmr2RybVOueOjQ09On+0f7/LguXZ7mPfa5zT71O9zz11JNnHnnkPjce2dvQAfCa9etn7j9+/PjBZpMBoKdepx2jO3b85Pb7t3d0dLy6s7MxD8CEST3jwvBqWSjNtjBNdkOFiBHMCTskt8RQ7IyxYbgnyrpiZuyeKxlF0fJd3ROzCZ29jzebxbGTJkz4yyc2bbryIKLHEfyt/79eExKdYyLgp9+/+erv7myOUb2rgcIDnfUGZkyaWgI4Y//JU96+devWb02ZMuUR7IVu655ed+iErgkdg81BiFw9vmPHhhcdeODO59onIuKFCxdi8erFEwEc0lXvDGx24WBxwKcA0ARSsq5YLCjDSfogfBb2R4vV5gTvAMoyGhndVaxe/8DBwy3cc+C0aWuxEPusFnhsw4YDxnV2Hliv12f88ncrz7x33cPsxvV4eM5ktg7Riec2PyfFg3HO2yc4k+9ZPxC/gROeQbwjHxPXyc6CgcIXyGo1V5bMNz9yz4z3/L/Fr7/1kXsXvmj6EX/GzPsR0dNfvewypTOe4aiQfc1mx6uSeG5va/22bTNnTpo0BcC41U+tnfIvv/zmJTc/eNubHt6yHgU7X683XNkcAzmIlkddjjSJ2A4OJ1r4kv21d/yOa42OU66841ocNfPwDx+w3/7XvvLUl00e5uFPd6JzG4DzPTDv+pUrP7lgwYJRABQrFWgfMzsMgOfNm7ePoSZsB8LuoecdfF79yCOPHGDmnhFg4uL//tLHz//M2xY9tH3duMHBobKj0e0KlGFgyjwTAMYEAXvxJ1GZPaR4vJTiHcVju6LsJj8U6gNDJiKYk1/M1bJSramjSt1caEv9N2jJM3sfy5QZzsUWvPgXCJUebbOdoofpc7tZDarVc+ofpn0/WPRGhqOdTO3ocRogOGb4ZrOYut/++ZxJB14JYHDX0K5547v67txXVYXl6Y/v+8177tq4mqmjUbRGB90Jc06iV8176b1ENLRmzZrGYYcd9gdtnvXCVb3MpjJQwLSu5B6lP78nDk+lneb+9vYYunNdeEZyIlCg1UcEqKUmeo89eWN71PY6lsBQMh928xkYiU79km7L816TJpKpSYuAmTkEgoy4ENn5DVue9v2jox+c2NMzNrGnJ0NwIEOXenq2A7j3kEMOeayro2OY9ihZTdfQyAh1d3byecceOwXAn/T09PTPAG4CcCGmTcO0adNWfu3Kn3zi8SfWoZ5ljsqIbBrPC2gpMXR8JhRMcQnrUuHwOQElgdDRgdvvuWvWF7//rUv+5g1v+UZnowMrlyzx3Z/7XHt/HYBXAxj9zm+vWfiV731zztjgsM+7O13ZtmufHC7vhgm4o4A/rgbsPxYCQldCie6cjonrOTBuHN358ANNAFM+sHDhiQDOQWUNbOViALRk4cJ//nxHR9Ptg9bP7bIxFsvYqbuzk2dPnz4PwPEArvnpLb879OEnn+ygPOeCC/KV0KGto1G+SZIx3iNzWZb39fLjW7fwhnzHS979z5/GyYce8fS8OUf84q0Xvfq4iX19A0uWLBlcsmTJuU/vfPr6aROnrV62bFlteQxYfl/50eLFi/MH5j7AL9n5Evf973+fr7jyipdN6J1wQGej4yvdnV1odPWOv/L2G6f9/PrfvvT2h1YfufqJR1E0m9zRNY6Z2HlfAs6poVDZY2jWPVHIko4rOwzr586hdI4afb1838Yn/ZM//s6Fq9bcd+6bz33FrQvPPG/Jcccddzgzn7h158571zz9wN3Txk/r/Nsb7ty+YN+bwLhly5blixYtKrbu2jpvct/kgwHsv2nHDv7Xq5Yf/6sbV5x/70OrJ5KreVdrlJt2bXrJA5vX/2BirWvpo5s2TX1k0yZ+6KGHOO/L3cDmgeYBs2efPrG39+DY9qbcuR93dnSijKXA8+fPx/b+3dMe37Kpc/WTj0z5sy9f/vcf/9ZX3rNu+9P+sY3rak9sXD/5qc2bubOrw6Fo+oHhofojW9cdcvD+pzzd1dW1sI1cHoA744gjvtfV0TkwNDJM3Z1dJjpL9E04GXR+aHSYujs6ec7MmScBOLYnuedZT0/P7977sgPuRpCTv1379Kazf/fAPaCOTirZK35UzYBJranznLZEsDAfcJi0XD25/JKMCujjCcizWrZj+xa/e2zwrHo9/z6AlQdOm3ZEV6Pj8aHREXR3dO6DtTroCtn2vkvgMz/5XK72FtufTyO0n+3Zj72/d8/WhkZHXHdHlx8aHT7tsm9/ZuH2gR2+u7fHlSXzMDdx/UOr+i6ZN/9bALZMnjx5tLPR4YdHR6i7oysF4AzMmjrrxQD270GPysExPT1XdjY6dw5HWbGcrvK8eg2NjsSwADN3l80ptz+ymuFyYi2Bl7Gk50kiMREfmREhQjprGGZ3GQ9PAHOLslqDbn/kvt7r7rv+M8z8CgCt7o4uQ/HUr+6OLp49ffqZAI4AwD+69eopA/393NHopgJldf08pEuSBAV0HRYn+6heiTjuWgsbv6s4xqwfWhusdHDRBmWOGp3jeONYv//sz7+aHzRl5rdv23B/84p7V37rkmPO+Q8AdwOYCeDi/v7+q/v6+h5bvGxZ/kAV2/c5c71w2bLsqCn30wNbH+Aze96Wv/dlL3sHgPt6Oruvnzlp0tgvHrj5tb9bfetbr7zl6kkb+jfnu3cP+kZHN3JiV3Ir9N0Hmqj/lXb/Cb5YjG/IwzW6x4PZ+wEu6abH7szv3Npz3k3r78X/+90P3378zCMfPvnoeb9YcPBJv7vw/JeNdje6MDg6hNFW691E9O8A8Ms1t/TO7p5Vv/fGG/sBlMufYZzLli3LlgMAluPTZ3564lV3X9X/5rPffMSE7glnImyqsxLAu+/of7L8zK/+31uuefDGQ+7Z8LDb2d+PWtZRNjq7s7JoKW6x0dAkHm2+kAR+4n+qzOr2d5XEgYPsLp58xxQIUiqxBGDPva5UyZnnk4akvTHkfSnYk8mMNJOZ+mmD3eSHte+0UZnMiT1iLSYw98Z2dTZQP257HwFcIx4rhumEKXMHX33KBV+6//77H54wYUKO7vFc1Q5twxGRHxwcPH6gNTJh2vjJ/a/+58uOeeLJJ9342vh81+B2d9oBx+9+0dTZVzy9a9chU/v6nnFTmheu53fpGsL3fu5zc7979a8XDo6NFOQoV+ZqRgMVwAuBn3wPaKDBQKqjTkZSBIjMNphpgarJzIj4m3YkqDPyamYNY/AjM2Dtzn8lxQPYcgDzdogV1UA1PiZ6YrWTYzvhttgxCvmVC046eey0ucc+kDfq8SSHQJfMZVmeZY08y2rOuZoMIC1Gl1IT8eU9vOfWyFhzN7nMNWq1zpGx0aGMCE9ufbrzu7+48vAtu3dTo1YPGzookLWNXWluHZTKQNJHcbBSk07kUBSFr2XOnXz4EeWpx8/beOyhh9O4jk4OAQHQbLUwNDqCrTu2bbv74Ycn/PqWGw/atnVr2dHdnXn24DwLr4rneEngQ47gWkDZWaA8uQCoAN2SIx/NdbdbEIGyMINGLgPGWrjwlDOfeMnxJzVHW63hzDH7KGMUD1d1cKDwSnTUOyZkjrJwUGwsnSXDs0gTLWP2AdjEc5LknpDIgbX8lh0BnuE9o+QSw2OjA0Wz2dw1OND6yYrfnHT/k48jr9UDCpvZdzJyKMExDE3g4nmMAIgygH05OjrKPDKWT+rrxZHTpmPOoYff9dITTx877rDDrz1y1sGbOmv1fxstUkK51WpdkOd57+DIiE0lc2dnJwF4guLubPoF8xu2DQ/OvfK639S2DQ287ppbb5ixducW9/i6deDS+0a9A47Ilb405VViUEURg9zs4TirD5UMYTCMyekKh7MT4AiulsOXvhwbHsom9vTh8P1nPP6qM1+8/cxj5v36tCOP3Q6gGwAT0ae51XoF8rxrcGQQWZYBJZBlGZxzvlar/Q8AdNbqGGiOvefuRx4446q7bz3y+7+68uBNozt6d/UPorPeyVSWVIKYW2P8oTe946FPvv7PvwjgICRLmANYA2C0v2iesHb94/zYuieGhlvlcaXjU+9ec3+5cec2t2XXdtfV3TVj1+AAtg7uRv/oMLZs2awRFiHztTx3viyQuZzL1hidPGcuXnLsqXf2jeulWpYhVC9xmC32QEet3ptlVBdccxRk27lM6egi/T17MHv4MsywjzWbA6Ot5pgIMHtGXss6wdwxMjqy1TlXu371ncf96rbrUO8el5w/u3IgqYlwU4O6KMJtfLfeMlTXmMz9AMiHZFrRHONpk6bQxcedvW7G5P22dnV0djc6OrqdI2RZHra3JwdHqdwvyawX2TV4H3/GocjqVqUdBZxwEYeSwx86xxw2Y4CePJtwUjbN0USjF9zwEX+ijVKHK2CX2jT1xeRA+WgTY0KBmXWHboZHxiCXOV758Kr9/vuWq+rIHDuXEYFQeKAvy/n1p1645uCpMwc66o2J9Syv+YqdCy8cazZ3ee8L6Zf3HrVarSfPsw5COIOUornPYqImYKCHj/gmSxG4ZBRlQSPN5uiP7rimcfva+2a5Wj2MhKBlhcRiU630pL5JkJUkqmrbBTQcZWgO7uZzjz2LXnf6RRuzWlbmNQeHLM6KJFvMAEZGRgZaXIyu27F5+jdW/mja9m07OK/VyRNrGbT4sdaJT1baOhnyVdrOruJCkLgWadZI/Ib2q/JRpLHLCC53aBZNLkeG6eBZh+DAzslDLznh7B3HzTpyw2HTZ187Z+qs9XXK/7NlChOYeTKAcwdHRjjLKk1zZ72TAPyMiEbM/S8e9sW5dz26es5Du9ad+sPrfpJtHNo2/f61DwGco+bqRZZleVkW2jcta1QKVGmiBFR9jkN3hKyewROXBQqUXGSu5nDI9NnoK7LBOdNnb7vkpPOzjPH9F804ojVn2kFrACwHcDaAMwF8Qio7mHl/AGchBMIZgHVEdIsZ1wcBXF0CZz2xbeO01esfmrx+YOv519z7u76t5c4Jtz50F3wB5PVGkVOela3EI2tPAAEAAElEQVSCZE0bm5OlJRCS5URVDynhHSXhVT4rtnHbPXKjHj6fBMfEZFFtrDOb/O3gx6bPBEMtxkj/terL+q/CprZYiapc1XY0UWPdQfO1drnyWVIkOVfcJntdRlwMDeAfXvW3/Z+4+L3jh1uj2Ncl+2VsHx6ePr5We+PDu56a+fr//Mv3PProY5y5rDz44Nn55a/6q09dPHfB1F1jgysmdY37wXPdY+CFa9/XXgLC0YIIucQLZFexEswMICpHHIRbkrugMi4CyBKw6R2mG8k4sJVIa7SNQ2lnCdUA69S8EfiocEmQOcmwKifpu8Cp7FVqb6SXpONy+rw4QlJb7cFojo6iu9EFysU6JOXW4KOM6bZoaNW11qxcAAVHObI8D/Xn8dBzogyjRRMlgDyvgX2ZnDSdWbVwbsYqmELinCkxlKlqzON3lDnAOW6OjZGr5eio1ZC7DBJEc1mibHk4BoabowCRr9XrIXhwBIqBoJSQmbAgnAM9RmhOGYV7EYEfJmSbcnAuhjYc8B7GHcoqy7JEzROyjIIDUnr1NG2gR0QovI/vjXsrO9JgV55Rh1IdGRm63elWhVnb0YOqOfDGOYLzhLJsYaTVQq3WCO+obFUe5EilXoJAkX2K9oDEFAHgcJZbBofR0ZGiHB51te5O111v4NAZs3D8kUeC6vXbjj/kyMHjDj8yd0WxYv8Jkwb6+vr6ypILD08+0IOImXf075xSy+pH3/PkY/zk1k3uvkce5h27th+/Y2Sw9+GNT2HLtu0oyxbI1Vpd9Ubuy4J8WaohqOhSVSvDbyxOpWCCca0tJqjzRKlcS2iLcD7f2FjLc1m6BgMHTpmGc084FaPgGxeee/7uSR3dv+vt7Cn3mzSlJ8vCRiTeexRFge1DA25geOCM9Tu25r9ddWtjYHDg1BsfvBvrd21Hiz3yPC+zLMu8LyAbnRSjLb/fhAnuree+Ysv+E6fd3vKl2zXcz9t2bKPdAwPUHBk+rX90pG/Ttqexc2gAI80x9I8OoSAK5cC5AxfNApQxKEfuMtTyWg7niUuAiyIke0iCBYfR4VF01mtBD0IcEugWsbLgAt5zCsKzhCdKPwHhKMchseThKIOT6b442+7Zo/Ql8ixD6QuMjoz6Rvc453VH0YhnZsG0zpqIDYg8FV2uZJpjV5Kki82QD1PpYFANQmtszLvCu85GPQQiHkAWZSTqfxhrsguKdYSU9ZZSJiLVIV2yEIPB9ot09zxOa5YhY0zyrvLLbSP2AJPMLCE5iiLsbQ6S0FQb5FD6FSJRsQlGeYgxyi1knd3sckdwAafJOZSe4VolGlmGsmyFNXElRbyQBC4jz/OA4fpSh7JshV0IhWlyDrjiVGRkiXicBAMcj5eIPG05D6Ja2E1QiZTsRnKaw5jV3lDa2RPRiSax/BxlJc4fEHtQ5tAcHvK1vOHymkvYKIk04RcA50KwPzQ6jBI517OcZJx2RkMxysouhAasfozKc3oN0myh9Rcc5AD1PRPSlvXWPkUSOcBlOUZGRwtuFbnLCL1d3Th82iE4dtZhGGZ/80kHHzNy7pEn1saGR345VDbvetEBc84omQu4CJbeo/CeW+VYfuOae38zZdyEizeP7Dj5pofuKkaHB8/aNLg1v3fjo3h611a0wEDLt7rqPblnT94XYV0nEutAbHbRTOzUBLnqYBiLozROphjsZg6UZ+CMeLQ1WgBUIxAa7DBlwiQc0DkVpxx6LDbt3Hp/17jeDcfOPKI4cuqBjUMmz6hvGdn147GRsUcOmLT/Kc1Wq1mvZbVdQwNPUY1OHimLwx/Z8GS5+qk1wxu2b55Qy7LTHtzwCJ7YuQk7hnejRSXgudXROS4ngHwZMJ4lyyt9V1bESjDlJ5KfEv92Vp+T6LbZNFFdwTpK8R2sHQzUrPgqkeYVn5dEJ0y1BXnTNyhG6GSK+nfpjzRRkrBX+CQgJ+8L8isYZ/TYyLGWxFaIYcYVaZyB0BzrL46be3z+76/99KdOm37kkti3fVcv8WL3wHLkyxYuefdHfvKlS75y/XfOKlvkR0aHskUnX7zjh+/84vEDIwOzi85xd08k2v3CDOEf9zIB4T/M/e41V6eAUMs4Q3bCzhAmoJRp6CAFrItk5fs254ETMMtiWjJGRo2tKSUh/Sc8F74375HvkzbEj9KUt0m8JP9JHjVynxQ8ijcn40UkfUV0crztoSp4ljn2RKznujgxPkgvto6ACQgrQOFCNls65uOriML2P57JeV+C2CfDpkRONNHabn23oafSJWX4DfUAY3xdnjEciU1QAlLMHBP7SCVP3vvES4LutkbmvTrDygRflsCBjIxqKNb5EEwLysUxAwA5B5e5eDRh3PSHw+wHQ8AsjIIj6W11MVHcHEh4EOmiGxkZOagEhPEbEUt2In+VAcVNeQBmBN4IRUnWU0FLRGV8Fd2IVBOnR/mqa3IYWdi8wbe4RKvZZPgWN8ZPzMc1OtDdaKCnqwt1cmNdtYbPXRaOtihKMANDzVEMDg82ao2GGxgaxFDRxCgXGBkdARhl3tGJel4nKj2xL8n7Mjk3ohcUZV1nNIQ88TMrF4kCYCNTkhyoENw4SgDFA8tDAbkvS24OjzBGRlCfMD7bb8Ik9I4bh1bpxyb3TfDjOjvhKEPhCwwPj2Lrru1g9p1DYyPYPjSAscH+El3d1NnVpTK6x2yTIzRHm5yVJU0ePx4Mh8KXKIoWSu8xNDgAFEWJvA5yDlmeIavVyGVZytgSnDgfHJ18Zq+8YwShdAjJDcocEOK0oD9MZv2s6F+SC3VEFS9FLiLGMFe+SnwjdUbZRUxmB2K40hfG6OueoTo7zqmJCFWsL7aFoUEuWMvqA10NJnN0TphDoEoUNpgJOiAGBGkdd9LdIC8wVKDUbEwYqcMCpFxNEET9IiTdUkBHaSh7OLmGrFW/yNod48BZelfnS83yB3VB5d9IQbtxRdzggkDBUc0yAnkNBgGKO1oA5JyXRKLam7j2Kdnr+JyjypIml241V3SAES0Ai0zJf/GugE/EXKoeqViInyv8MLzUDWrFJrF1KVjlizg1QAjHEXlHYRJVcFqSHZRonmYbibz3lILYhOft1UMVm4TEOwjOIbXNUVA0Sa42TjBO+gZr6jVhHDAzUFj8DJE7RwRix0zgwpcoi1EGF6iPn5D1ZA1M6OhBZ60B9kAjq4+Mq3Vpm56BwpfYOrYLmXOdJZfYOdqP4bKF4aHdAHyJeic1sgbgmdgz6SYxkECB0/iNLqXxRUxWI5jG68RPiv+Fag8R15AsAxyDwd4zWq0xxtgYMDzK1N2dd3Z0YlxHF7qyBuqNDuSNGspWgdFWc8RlDmXpkbOrdXZ25EMjwxgeG8FoMYrhsVG0BncXqNUJjQ7U6w0iZ1JB0R7pUgbhP1lbhD0wQploZEU3fyEkWWD5PNFDsFqJIVSMdk9KT0VSdYJFZdrifJSR+G4vv6viGJozNOmcLK81E9USf7HnyT/cS/WHjjt1p7r0Jj2jss9A1gQyynyLB/H+V1+27QsXfPC8y7562QNLL11aPtO6wdi2o3CM2LGbBne9+K3f+OsvXX3PNWXWO5F6XN19++1ffOTVR80/rAQ/UxMvXH/gpWuwkqcvGQNx/OINxupV/ECkW+wf1t+reCkV62kuyQruZVFterDNGdIXtU2ACwqA1CCoAw5o1iR+kQznXrpUNd8skz7xs9An0jYAX3pSt9nFrK0Yu6iAIWAKVjLYtQgh0VFiQ0zySGtyPMBcoiT5DHpvwIhozolDwEoQpEjQVOELEmqwBbtwo2QJAcAXRTCfAvj6eIJAhYUszKJSzKDGh8zd1mEDKHMoN5bgWhmcZGFFzBazLHQuS3BZUryUrgxZC2JnoKELw9OoUlAnY1f5jJ97OcGRw3LGdNhyMhqyHiBZm4TKahQMjTSr52JPTEJL6KTyKM6EzFxKMy72iT2YyGVZhtq4HlCWwZdluXtkCDuGB+G3Pw0UZQNFCTTLsAOoL+N5gA7Ic4BQZvUaXL0Gl9fQ1dnjAGS+LFGOjdqlMoAM15iXqsGqkBOiFUnA0uyA6OEeMmibY2gQ5cEg7wkAdXZ3w43rRcFFual/B9bv3g5krrFmyzqos8ocV+0SwFxmLkOeZejqnZB5MMqxprIOINUhiu9qZBkhz3j70ICn6NGEJAKhc1yfA3EGKRUMHYWPh5azYicncYpOgtIz6hnLYd6tAgR2gbpB2CT44TjznKAlZnkhDrMAbRwvWBMnKldI2WORKZFnFldeSqDR7sKkT6QtSi/UjHIKPIzsirNh5aIiVKx4XAJwokAU3B4ChU0tWOhl3BpStIyFXxRn14J+qKOnjyglKiRLhIneFISO5p72g9aFnxXaSyVJOyYitC/JVON0i9BpgG1sI2fhXtnxkLkIMuDjMwS4kgSrnCRdtSxVjbdxDpmDHTK44y13ZEUPRSySj4z3aEvWZITtpcDWaiergHZnIMImR7ykBK8Ul1BQVVw8e3CJlC2NskygFNVSequHTzMrXH1v6ikpZMiT4LauWlthPtegTrREMU0CzMhTyeLuAaaSSBdWhfXYHFabU5451Oo9oMyhKH25uzWMHSP9Qc5b7OC5E2UZVxVycEiyHKjlgGOGI59nOYgIjcY4R4TMlx6+WeiANeBXKQibo1SUltLZd4mNIivpCw+xYVAWJQxk+GYJRhm8G8+oI4NrdIMaPSh96Vutgre3dmMrwvpRhN2nHTLXqX3xHtjhy9BFBweCcxk6xk/Og8/k4bkEl6KLpDhtk1RWfhX1mAApmY8ywGkAMJvxy2ATOxkA+ajGKdA0DMeeV9KToLPJN6reRYnce4zB/sKmWi8Jre3FHq9Wu2EHssfbU/t7G4aW3lKlWecIrWKMZ04/0J1wwDH/ihbGf3jhh7uIaPfeWpFrOUC7du2aCGD8Nfde92c3P3I3Orsm0Uj/7vLi817vLjzy7A+XYKxZs6YxZ86c5gszg3/8K23K4Y1MUJz6jQy3uKizhXIrjOgoqhpHgYwhSmkGbZX1sWoGg/cqzQLkpgOVpindwSLzpHXVkqFpN1zi4Mjh4TJamUOSjI5HnNFhVhDXoZOM2yipOBRkDGocoJ7PK52XbJYBFN3RjyuqaRNagl6wiRfJgqVsU8wCSvmAKDiFUTFISxeFxtDxOAVOnUgz45YNJizGpXEmQAOSIxsMUfA6SIwiu7BBqBA7OiVyT5XdZJxs0vInHZeOL8mGiCbDHPCqffSJ5rHvGm7HDpIsIreRi8qcaVy0IW4ikGZ2hLgy++IqPFR55dQHQFxhF3tDSbc8o2gVQKsAETIHQkYEonrYdLXGoIZkSTkpd2gw82IH2aMY8xVa6XopgjHuRo+VTlWmi3QpzyvZTmM0LFzAyJDwTvsp4RJQMsP7EkwuyzKHPAs7zzrnKrPA8AwuGVyWmTjVpSRgwuDA8JUZStFjH6M6B1dZnePhwWV0oSUBwOIMJrKyluWwypAEd3Jp/sDHyglKZYsUaQEWrLJ0ZY1P2t2NJIZVPTTFHFXVrHKrcpPocirvlgA18YYCUTSekoGxeWEorRdthZZAhVZsyYCEgPFGcpVx60Zee2BA/DfKpg5b+CqOm0KhcboqCglowkwNG1e+J/Aes2lq8yjRJT3ajglt96Su7YF3Qmf5PPnd0Z5IwjTS3leqZUIDSgu2lArjrOpZsgf2xiDXNhCvfmepYAha+TbWAUS6RmpJ0jEGgpWEIZDsXBybkcDUT+Gd0iq+1yMlMCtq0IZlarCR7BHSd4kiDC3Hc0lbkt3kNOOqAQPDe2OvTPIi3G8x0GoHILszCs5z6cNyiHBoE5y4ajUKM+wQuUmyomkV9lmomgkHn7NRqKo9ikInCde2GSYVNIZJYgp1KOGCPePYmgSupE+Ul8yhXyAgLOl1yMjBuZAIkuUhFX1xDK5zxj4+izBjFtYSU1rbLyRpe6sk1CoWK7Im2V6TUPaCuTER1y5DzBV5Q8RxJ7xg8bOSPdTHmfU94k+yA8AmGSaSKX00elLB5QiOrPJm+qssS7wSG5ZYZOyg0S8SaopNqDSXcEFdzXiDB8M3MhQj/bj45LfQ64+64Eoiupf3cVwMx+NVRkdHZxW17NsAPvatW38yrhxpcmfe4TvGT3XnzD7xnhzYdNO6mzrnzJoz+kIw+L9zmV0aPQih9C8df2ONBVWzEG3s0D/VvgnwsrYEROERB9hkM2xDMrOVZLqtDMk8QkYhQmusCc8gzD49zbElATIxUPKZ9FG/MoEBSLf5BULWkhzpWO1OnWRAIfxM9Eqln4iBDMV+hZm94IwzGC4CPwejj7Qtt3Xw01uFTyw9SnXhnOgkBHYkgErKExm3lMDINsRpdyoBMKFtclIS4QQfJSBKYKgBNgjELs5ShP7YcuJKMiGexipdEHOkRalGDgOnvTHaIkdxnLFhL9n3SGsBSUACTSPrEXh9Bfg4IaEhvfA1jZo1eSA3MJIxUJahCqo6g6XtRseESFupsFwJzykraoAdbOgsDqjyKOghtclqIqvoiHAufBTYkhwIdWwgCQyZGZZ+BAbLOKuks05LdKhMAMssM0aSCWX4IpQ9MkqDE3FGXeRU5U4bEsFKOGKJT2zkNt5vIUp02kYsMDPYhleqLwyTYDZlP8JFUSajn17GXMlEJySMr00dI4MBQjbhjcgkp4SRbacS6JF5ziQzOG6TK7Ii+kXMCesA2UMhPu8V02TGPfQ70C+VYNnZfQUPk5gzQVwSXWg6bS+pa06viT8Tr4VH9mYRN3G6qm5jtAEVHWgLABX0UOFjoL+ZMRe6RfxSObR9IXGik/4IbhF5lS3mhCXCb+agkx5hVpAq7QsxElaoFBjsgQYtJtFn5MUYYrUBSQyT7Is8ejXGpm0GNBFpE6iCc4b6ieHJOddkDNisCwi2KumrYKUNKxPGpSSmwdSox1Y8iDjIvwbiUd9N1U3lAXiwJvBSL9S2kQ0UQn+DLTM7FjCr3ghucZzTZURPjZK+Wv8iGZLID6Eth7HKGFTaRXdVhpOvlRKsBMk3M3PFV1BbZuRGeCT3qz3Tf6HVMoKb3kWeeADkdWOopLhJthJPKY3B4EXCehUdpCPL2H5sMMJMJAivEMTLm/cmPDG+cTKo4ak22dAkD1CpuiIgVDERxZx0xEJ2lSScLFWSqo40kSBjg+pzoGEMCpWRltei94lM2iP184Q+EQ0FN+J7ZBkYQGn9qJLCoSib5aQZ++P8I864HcCG1atX1/EMx6gEspHncObqk8z81m/d+cv3rRveeECZcbF7rN+96tRXuFcd/9JPo4mBmZiJF4LB/72rbdt+AaD4lwFWcWCtkFrhIXmAgbR2j6SRBOIqpOZdcgvEWZYMhXye9DvIZHqxmgZO9+p98QNWgDLZVLKbxvAeGZ0UochPMYhiREm/UsNtvPqqw2/KxsShoNAWt80+KaCwcWTg4wymoZ3BPVIqpM9MBBV4AaFDopOBrWobxvIngxKDXlsmFPsmBE3JSqEnDMAauKYE6GKgkxGnMF6Wv5JBCMVlnMYcbSoiLUmMFachSFCqfQkll8Z+kqGjoa0YkUiElMUWBzUFFckMUagzdRLgBHmT75M8AqmELIxHgn413qS9tuYDyZ4kA5buMTipossp8WL0NTlV5jkj7yIvynPRDzEChqZACuKCrnJqtz1oRnI00giTTthgMLQldNIv0/vi2tFK7lGywGz5InKnTNexVAMywyfts09YZ8aQHPYq5dn+QalvKT+REiVpBiss6QnnmkUZtmOKNHLGuRAdsACqQbDBYVI8psif6CwYiUnoJvfEd1YIUQ3qZYBe+EjybLjXMcGL3FCSNXHEk+4YR11kQ9mU5v50DZBxqKztUB2QryJpBJ9t4GUfSyKRvhccgfbH0jjJZIXXgrE2IiJjRlApMhQw0jYiJCQ7ZXmhNzmkwGRvo0Gik9A5CrUdr48f6AZb8i2lsQrtFUcFaxQbYcBX+iOywVqVI82rfGj/rPVBulFsh7YDTbiQbrhmKB77oskEpGDbbg6iSYZIvPZ3S1uukqSWRCTv2U9jWyobicj5b2qvKdHKVlRQYqKG/1w91xDp7oAbzlJN2k/WAbDYC1STDfFzzaNEhHbmXkrYpBZaxiJQWeFRshsq11SlVcpBsOKrCLsEyfaSeVJJLEpYDPOZtKv+EqDl3RKwsdIHSHgZscDqGSXa6H4XEvBUbGTVNlElKIzIxcpSSNVHyqUT4FKqxxonTRqLvChuGXrFcQTS2cRKCtq1b6LzJPwwNlT4Lkl/FRYjQ5V3mokOpAeSbSH9zvmwy/fIyG568ekXunMOPWsxEW2PO4FWGb3nRVFed9702Kp3PfrYQ9yYMJHyBujo/Q65ZWLW8yvK6bmeyfvC9RwvV/mrYmSS09D2ZbsOV54QYAyyx5WWSASSq20QwjodyRil95F8mt5CsquVWHxW608REMRB0Yw325EkA5kUQN4hO2JW+2ZHSOl1OhZmDzmKiWKfNGhV58+AhR2xpTmHPpjQINHLrEcg7U+iUyVolY/lOY4gKfdYejjTmm5eIg9LCUICPlmLbkEisCIaeuZYji9AFNrXkiudzRVjIuOKjHOA7gpIlobJ6Ei6gGQvcSUfV2v8jXHU15FCo2FKNWMWvpK7zH/GwAimU5SDsDFNzP0LsEcKeqVP3ACIDYXFwFk/gZEcKmM4AlXjDIZkTLVLbFUhjj3sOKj9ZnOfGmmvtNMkhlUOwGTxk6xEaUhNx2ETx5HbvrN9Bm1/SNPmpYbU7XmjChaERbXBUWRWQ1jhkxmSiJo4E4YkUIZWgEmy26xws7f2TSPQgIlE1wjMXp0zIpEVYXhyWkXjLJFtIkwdGH01R3mASbLEL9X+svKGLU28abwyrqRf1n9NvKgicupumzy6al91LBa2LEeZ1YGWTXk48sC+J9GcUxsGi7VvbOgoz/g0bhP2ht5rX7n6XFtknoL5+I/YGbkd6RfZgos8wgwLsx5tI68SUVHnWPsbNZJt8tASoso770UXDD2kUtrQJ5XXp3+EnNzebgWoDDapMrTppNlsizXZ2XYZdkbKV+RvD5kxv1sUcqhMvCvfOH4euugBMzMe+LRnn1LQYenQJuPxWa4QS5JYZhdb68lLYqdNj+wAZT5a9VtxKL1aL0+qQyT66+PvapjZyHmii/pDz4Bfym5rLwBNwKidkl4a9UoWVGTW9L6C65TcP6ncMfIWkmWIY1ISRXWIPGLTYZV3QlJCw0gkmyA+iyBmEH2VQKWR9FvyOqkT6Tt1DayqxN8Ejyv8UyPmjKQJa9g8a5gjesKUdkBmSRQBWgLPiY62uUohQAWY9XVVWVYYjtgT8SRtkubBPtkx9TdVduKEQel9V+c4OmbiIb/tBtbuGtk1m4jKfZWMRtp7IvI3bVj9iZseu72OvF6ODfb74w96ES4+7oJbiGhgDa9p7KuNF64//EozhDY0NKgcZIbNV9bQtl1GsHSmT7IsqrAms8Vmxg5QSEnZvqR1FbtM4nSyWNKkShoEcAJno8SV0IJM1kkWBhNkczKAJKublFe6VSk5g8wasipHsm7i/CWgkOyR7DbGkPHEs7Wkz0DoDLkKIAvuC7ClbH8CfzuDIeCmPoeAvFCDpD3jXEa+ya6clh02b8Z7ZH5liwXNL0N2BJXtuUnkQYwHpWyunVlLdKYEdFYWxSBzeC+RS6Q3Zl34lyaYYsbQzDboLIrZIkJfxQDIq8MKpZN8L2PxKpvWeRFDEWQzHGiSghDRAygtRGZkswJbzqOiQ5EPEqyT9joZ0dQB/SDxUQxs4qfOfEvbnN4BkuSAyB+rnEWhM86MSQDZbDzbe1O3dLMUyGZEyuJEF5bzITk5NsIbxDa8/G6stUuDtrJguBL/YM2owuCWkjtmRCmy267r1Ua04VQmJfgjjpJ8DDKYxJzeqxlYo6+qA6zDsvgS2Mnaj5TUaMdEw5m4Bpoqn4kMGolwAR91PKKzNqlkXqol6LHP0qYmONI0MFJgRto2oh7bgF36ph8YeicxIO0GmVGlrqX3qFPszBi8tVGRY/ockDbNMP8YLOJ2/kQeK/+ApNtgwy9q+95iO+1hHxSfEbFW3qHctRYOIEO4iqOeRgkFUfmG7Tlt6U7pY1rzm/oeEh129oPCOmrdQRV6n+ALVcgiYyelvZ2VSmk88UlCWykoTLpb7bkZqfDT3gZoEK2TGKaJ0IdQJSGbuyWbEeSCZQ2dyL1WNYSCEYrJXGmrMltI4lRLGV6ypbawI+1BYCW70ptUyaC2ID7CIZHr9LxEM/urci18SfxLMBqSWorvitn6BiTdYm0/8b1akWPL38NzqRQaqnMGz2B1SLpnwc68Pz6xR8JZcT1+K+1Efqi+MOkuvgKgZDoSukhxLIlOwr/2CgGY9znEoIkQS0WTXFgyavDrYoJZBm70SHHdJvTZ4oXRZ+1z+rdSNiz3J3CDaTXOelPy4wylQYKNDOQZRgd2Fq8+95L6W89e9HMAu1uDreqkU9vF8diIGx+9e+rphxxb/9Nv/d2hT6xfj143Dv3D2/MXzz6lOH7a7GvWrVvXOQuzRuX+fbX5wvX8Lw0IJYMZ8KKqfFasxCApMBtYCApmm2ejcGJzUtuaHTTvkJJNycyzwc50WZOn5jI2UT0MNNWwx2l5GDcwKnsoiQvBipYyhYHG9RjJACnMqvPgKuWgVmPVSJMYeKjTH/qVAiI2z1bA1AGyg4OWoIjyklXSaKAprc1QkBNDAMTdKqUwJbwzGelQDihrqITsUmpK0VFRkBM+iPMHgq6XUzIkYBePOGXfDK+NQ6tjN/ZZA08jMwnU03P6zopvQInWQHRw2xw+pbnAowVPpDFLAKeJDoApBcFi3NPF6uykwFacgmiAIA5QcoSS5hl4N3qZLGMagfI7MB3JdCV6ST+ojYb2TVqypWoizobQRzopTozhb/JVtM+sUyAsYmoyzGKIk65qkEAw+htZKrPyYkztCwnQo2EYWtYSxslGUFjvTY6wOLnCpgQ6BJMVRnqd8WD01+RHWEwyQYg4JhB6Cg6QOpjetKznQonuqAGXVwdJZfUEWJ0eQnLebbmc4rbcb50DSs4SOG5nJPRng/hGbnTMdnz6HujvSb2jHttET0yGKcZWgiRDA5A6IMk2JCsl2Ljn+mWYfwW3kgOZxpeequiOIIRiikfa+cKAVfWFZgzyO1fjeh1ruzMXZUKEKiaHUj+1Y7BLAQR+SYKSqFe24iGwKSF4XHgb+Uhpg46qMW+z7RZvKPUDnIJrIK7xS/00IqI2LAkKVBdUvkl4k/CnKvu2g/EzTu9PFoGSHdNm47fKHiUwNDFWwXORM6m7DP2XzeOIEM/+5KpYUOqDrGUTfKwG6ek9qlNib2AwBTC2j5VvLHQy0i6pWYvlyXAYnJWEn+JEOhpTumd1qNKM0kWaEyy1NjbZ0bAOU7ogDEGcfU4MkWdVTDhpZSUhh9SODchS4GaS4/KyKI8y+aDr4VVGyIzb2oUoWyIXsb86ZkqyIETnOBiWipOKDCesVhtCkQReJgiEp3uRD8GOQBSVJ+PhVQPwSOe9hfMJe6iCWTaZk2YIjY8YFbok5qyeZWccNG/tzK5J1xLRZmljH0Fcxswoy/J1TwxsnvXgUw+d3xwYQwMOxx92Ap0794yvAJg6furkLxDRe+IGNM/U1gvXH3i1lYySAWr7edt/lh+qN0GIzAQHFMYi8nEEgDa7Un1XbJ4rYBK7JnJqslMVPK00Ic9JBwVkEhgyQlsESoZIXyRgWwXTuDF8GDEn8CeK5ZRieOJsgziu+oyQWICDjZHSclE2Nkk+k8GnQCR0Pxh2Vk1PbUiBYQCZBFapqsUYrnA6mnE8tdVkwKTj0h3pJ+KrpQxEnAOZNYpb+HN6Y6Q9ELwPp66FGKgwQGdmC8IdDg6OXDysXhDaiKVkqV14XmQoZSpJjvoC2MzUiTy4BNbWACaeW+lKAwnPCI2t3Jkzp2x70n7ki50JUNk3mXqV4WR1U4CerLUG90RVo6RN6L0mAIT1WySLGsbLJDphHBqj5+1QwPaV0nAsISaVB45jFBmJ75WZQoMJ1l9Mgm8CZIpHaoGNoUsuSupe0mOlIWKAqy+IgQynJ6XUSmSHBRvItGdBLMquvjm2re0ou6pOhhG4lHE1IwFMvwwG6uyCTahYvhsvPtwveu2VlwxA1wlRCjhTYFx1IBBlgrUfnBJ5EOyUl8oRAIkfwsaKZKoeJuxnhlb9aQmcpYsmoWTI1fZZPhMZhrxYCM9tDpXIlehA9Qo8S8G97b/iuNBesYhhp7M15lRdiPcbZ86Ci01Ciu6KPRX9FHxnBWlhPZnEaEqUJFGT91pkgtLeUkDtkdCVOTnlUWDCc5T4YEqlNYFDSYfC64UHrBjhkkIa28hhcxeVp2RNFEtU16TPXEEAGIqH5F6ig2ChUs8k/CiaEz2fMfaOXJRBlzBCOiD67iqwk4J87S6L2WBoWZKIj9BMvtNbDL8qSiQDF/sGE3AloU26R2qzpTMW78g0lAKxRBQNrixKSBJDxgJSGx7GZPwPTv4JfGg7bGCV7JHFjWpZfOShya4IzdRviR0W/y49p2ge/BSHyneV9hErQ+wMurShMh2xgQST7E7JyY6k5yIfIn019c7cxk5pLyVFLX+UvgZz7fpwbaZ9dGSeFl0S+VKcCDy049CJAov/ADLvkCNDMbirPPekF2dnHnLKpUR076pVq2rYxxXLSMs71q7tzrLsvm/d8KMTHx54CtmUrmKgPobzjj57+NxDT/wGEX2zOTj8d3H8z3iO4QvXH36ZklE9SVRxDUgCrf+yfBYNkTpCImzJ6xGlttkGmQmQJ1OJFJt7LKpbgU4dU6UgBMHV/iVjIpkXVWJBYIJmOxgE3RkBISljnUFNomXV7IhCIIkSmueQQDF2L4J5deaNjJNN0j8CGA6ks06iiELL+H6PsBWzJQMSrXTb92hsZAZSygW8OOMkQB88DcdmJ1SQCaAjPbydUYhjttGBLd1hS5cInEJ/UNqhlMSkiFwQpOxGJUVJnwKdtK5Ano13czJgyhGZfbPWQ3icJFrlIwmM8FjAMZR8knPaH5tRth5JmiVJfBSBEPmTGWi5dFdCZgVcPUcpdRLGjISPXEq4KJ0r5oV1SHvICsw4kfgn8iOfC63T7KqV80RD+U43s5G/wdqW6pUIsEsyajuXVJPi5H+UW/EDolyKXyFjV6fDiAYhzRIoDQ0x0kyW0W+lu5XpRPs9uKFlO6RGX88UBMUZE6G3GPTE9xAQJ/1K9BcHJcg3Rzkg5Vn8W7HVzAyK/JjxpWoJGQRDj94R8svsDBJttb8s7XnDa4PQRgZJn01OhW1ZN4KKfZU+2YRTwkLoeHTHRqW+VFLYz6S/UgkhWCbjFhxPwWWSDYvnqU+GCtqeHbjIuXwoe04qh7naosq3iKZ8Hk+ohNI60VVllVHVQYMlqPAz8cLHzVnIvF/lXXkmySgzJy1JM4vTQsbE6XSP0tZAqlCF0/u0BFUESzCCQtBZ4Z3lp4xKlJht22xobnhH6S97xVxqCniQgs60BAPaT9FrCZAVd+IoA29k9s5plajgpOCcyFhlEzbbPU7fqV2w/RZMI0lUJD0M9j3Yp2qii5GOuahyxofdrVI/xda2vVupL5ggiQXRPTYypZgGpQsUs5IGpCQNVG6SnFX7wOR1jKlyID5nMLOCQ4aPhnq6Y3mSpcQAQrILSNAdfxfdUQsPklNVQWqHYFuUXUUjvR3JloJkjHMcgMz2a7+N3VGBiphqcFIrg4Xe0TexkmPtl+AhCwap0av2vTIpa8TGFUBOYM4yXnjCeZtPnnH4qbuHdg/1dvXezvGweezlMrOGu+/a+gjftPneMwdGd5dZvYNmH3RIds7hJ/6IiO5dvHixmzx5cv/e2njh+uNee6/vVYHgts8iLGm6IjopMbBhjk6+JwU8cVxEgFhSbhScoJTdI8jUu6bl7LukEzY7FhqUrkAyQZLBELA2OJn6wQmkQEnVCBwyfi7+HTUh6GroozgLaiSENppCTcikJoIS8ClNmCoMEFPqwJB1OxUHCErWeM5deK0zQV0KImRBVQJWUAZHYWGzzrDF5xLwE9IGKUCawYrnLjoBWOk0mY6J2ao6rbpQOXQ8MUG4w4Z/QgmKB8Nz9X2StVP5EucaBJbZOLLti2NcdYD0fSzb+ETax0cdUrDsuCI6IAorS4mgWeIgx2kE4o5w3PBEZjQkYNDMs6VE1IVg8GLfI20968iNYTSOv90WnKWPog+IJWSRGmQ4QEEn7RES6kBydGqMAkn8Kx2RNkn7YrEhGiGX1ELV0Ki4NWrynLzIqfwYOgJGzhMv5bEw9gRjQYU4iWeUF32/S2MnTuu0Er8ijwEzk5aIQOnFSfTU1hF0Ropiuy7hWqoQoHR/fL9ksSnKA9n2E6RGOQtd8CbBRjIOkYvYXpJXQ6RIRx+f4Yh7ok6KwoLXMn6VeYPLOnMUHVIrC+2XcY4UjyJ+GGroT9F52ahJ9APMqWKDkgMjM1BpPiNqu2CKyJuP40J6rzwhel3J/KsetAmijNKYTxsoQDRWbYNsNGW1O82cSMbem+/EdoaftsBYdF0cRMHuxDtQOCtNTIIRAjP2qM9mNjT1PcmC7FaaqCpUs/ZBWow6p2+RGcEK4kAwz9vPHMzTkeTOBp4CT7LpmYcke9PMoQcrj+UyNI+0kJXKNjGhR4SANaEk+KHYomNNzSHiqjyXjoGINKNka9vlHV4MIEUZTRpk7WTCgXiHQ9S7QGn1TTjhbYBTRpoiFa4GSZNA1lZLhecT/oQEV+BfJRER4S4EzqwBr/cs4qc6YyxS8gUVaNq4pPgvdHI6rqStySanPQkSHxlppk0MEIuMC82ITHvBbirKS1hjMFB1QPHeB/kDa5KpzVhCHTeOmzxFTNPN9MQ2qd/EKhlJXcV+VMRO7Z3QNel2olMFa9S2scEHEZZEKkk4JPURPfdAAxga6+fzzji/tmDO8a8pxsbuybLamURUYi8xRpwZBDNP2j68fRYzT/nN7dd9+uaH7sx76n3kh0ax4LBTdr7syLM+tpjZzV0ydy9S8cL1v3Hlz/xVRczUYVAd1LuMW0LmOa6KZDJAATGqQUV6DVtZJPOsKC2LopkvIgBpMNk+BtbXmhKb1HalzEDAV52aZAhTdtACteCBT+CTIrnKmGRhtgYtpj+SRQtgKpsFpHJDu3mLtKEuAsejnp1kydqYFFVXjoomM8YwftIMoi1dCtlHQLJykjmFvCeRF2BWWobPorEjpZz2RE27OIDikLM5boISjZP3ZQwhjHES2ilj7fsimFtHkaV9k/UVMyu+gXk+zOJJNjoFd8xxAwwzFnWA4kCqRjT9VK2J/FI7JFekL7nEp6QkqXPK5ignGryo0NnvrUGQBiiSuSobid9Uab+qX9JGdFaEvm3QAcAEUMFIt1+KI9GqpZyr9CkZQDG+Rivbrkh7rnQh8dUEIXK7GNPUqqVb+DIEEoaWpsvGfFY/jLLGsfO6nkMwQmUjfa74Y4xw+/3aXUM7kRFOA006SxLcxbvSx0g7CXJl7FUtivyglIkP8iZYUiFCwANp2+CJlJiqKEc+Bb2UJFjku447fGZ8NaTwIfE0kDjJq3yXziADDLilH5w+0JmndqGqOOzpLDAWDDfYAtMfGWrFBoKqmSBRoTbFVjMC4ZN5RhkISDm3ZFyUJ20sET6qHBkbpe2K7lFIjCrNbOWHaS09U72U7aqvpE+l78xTeo/RXZEhfZwTPrN9SfyKktKn8kKVAtX5ZI/bA2OLQW00s02Z27ULht/kDLkU9Kk6WxR5JCXBdj0rCwEMX2y5pHXKpQOa0rQqG2nE9kENFs1Q42Zo8p70ucEDa2vUSUsBpwa7kVwOZrwSYALJd7MdMMNN77Ozl/JN6p8knJM3sad+p2EKb5ICte+TYOlnExri/0jfdSxScaR2P3yniUZwpdItQTdp8BswI+mFJPaMphiRNIKeAGOv9s2OSZ9hVOipu5TKs0Z3VP703WIzqEIbAGAHtDIuuyZ2uXkzj15xaO+hq4moH8DPY7sF9nIxsxvBSHen6/zQluFd26586LrjmzuHi85GN8+cNCs/97DTbwVw8Pnrb37q9AMWjeytjReuP/5Vid6rCpTQLygKRb88ZmIrwtXehsy+GRFsM8QVQ0TQiaN2f9Mm2lO0YB6P1ja9R15XnXWIibNoANqBPxkDycDYMavRINIAwK4JYsSMNczDlN5H2nDKzLMXAIrF820BhfSLZc94pFmYCi3i5dUKAVqnXwH/mPvUuorYvpaFiduS3lXxFdhuOZwydVVLIUZQOC+zO4GWtrqq8pBPbdngieP/lO5VsUNKAAi4sWbnlBUK4MIemdUNTg6rcYg04jgbx/p2ZaSuGbEyHMdKFDK+6phqVynwWgWLtV8wbdtLkwYwRpH0G20XbIJ3MS5tVqFq+qMMAsY4mgAovlOasaLYbpwl861/61fR+Kiqil5RatDobppoY/OfoZ1SoZJr1Y6pSJrBMjOkQlN4o+PjSiMQfU3ODKHtRdBkkYwPlAIPA0jJ4TNPWFxrczaqBLbvlbFxbMkwWR81zqzounzGpr3EiEQvDRyq5p3bdF6bF6xQLEyBrSIGJWnguCBI+WRJpZoWv2UGMyX8rJgJC0Dpv0jt9q6m/tpnKb2rfQZQCE4A9BgwtqbK9FGeFLykdiyzlKSqTEUaVNJP6Us77AQRLPTmCvlU+2V4Zrq/vaxSsTlWtejr2uRMXmrppuus0x172HmSsUl/5U9G3F2UUp/bsDs8Q0BlpkfusTNBhihm3JYoDNa13wTsMSehoiO6GIkg7q2+Wuxl1AtiIQQiLyhussSpbCTKrwT0muxF9JfkHQoTbck9qcDRpGiVSBZjKxhszEl4Ltm8PTb6ShAVZTnu1yzH9bQFldpUAsWEK7E9V7kn6YO+1ogWEMdn8V9Fv6Io0N+UpsIboUCVfu2yxdJm+yUYJn2uqGyaIbPHblhaoEL99vaTXoc/q5hrsuTVe0xrqrqmn2inqR2f2knRCzOgPRKuIlt7kmXPy9pyVZaK/Mq4MgZqyOCH+/1pc0+ht5++8CYi6l/x+OMdvLesrzZLfAfuyLqoa11no/OnX73uB+fds/6+zqyrg3aN7MwWHHUGveG4C34D4JaxWac944H2L1x//MvMELZpsHxiwMWLREfFtthsDVpbA+n79I9m6PRLDYqiIWQxKOYtxulI1rut7wRImVfKjKFSJkd7KJxk6VLHXTQ0duZCPgPCOgwpTw01cRJcSeATwdWeiycKxbIcKmXEjasAyVBLdlTKTRmSkY99ZtYAVcnAFodYLZEab8lytWVQK/Elmb5Itl6zY9aIGjBigpThBlpy8nEpscrCucamyhhSRqWZTksbwysSIyjlTUiyymx/1X4BDC9OChHkfBEJGkLzHrK5EMc+BbCmGGwmI+RikJoCSiVJ1eBpn8ycVtvMc2UmICmZOhpCRC1jg5kVTfYhOgRQRzGtARXDGRM6MstmlTi+k0yfUxZUGMiV28MsKWkflENKEKEnwzphur4w/qu6pzSKLZEZGMzsgtnZNcmL0LZNDoxsS+lzJT9FoexakgOJBokHcb83wzGRuXhf7KdXWhuvwoCiSoroVYxcnRpb066FNyGSkROw7HDMEY9I+S+OQyWLHemWDv5OuAKihElOWC00kaI5SF4ryUQcTzp0PfKfzQMk/E7vVFyI9BRcsOPQwFPkByLT+hboHEYETE+sAWzQ3aQ7huNRFlnHIzKia60iP3SWWp7mUGdh7YdglUBQSlLoQ7F9D67IBitBqV0fE7HMz8RPweSUoE06I7wL+OvMN1BeGiuhMqo4D2VO7J5JPsT+eqWKrzjroX+iX77ymqQnnPBdWNVmAc1XCUpAWrIpI67qq5GHPT6DZZbeIzwWTAUnuqYusn4WPjJ6FzFJ7CsHENBeVKSbZYSGj2qrfJIpnS0UfGNUQL6S6I3jM1UT7Tpf/S3xm+L4w480PlVOKeNMAFTVbflUdNZgH1d0Lr1f91tQuZeAuSIowpp0saIuZLZfbZzIgemTlq1a+nCQVxkvEGFDjw1h5Vo6cD0G/CoHkX6KoRSX0aBCA7VTmjxvn1tzFfwRzJEKKh2twZM97I9+IrYi+ZPCI72zfc147LtySXlfnQxoQ83kFzHgSiDjjJucZa888sX9s7qm3jg4Onphd6NxFX7PdSKd2AKA27auGbv28VtP6x/Y5Wu9411XXy9ddPT8DQCWEtHgvgLLF64//lXZX0nNhmS4kGY2RLB0yt6wySyfCIDK5jk2M3XMVbWwpaOmnj3VrsusD9J3AkjGg04zYQQTXaTPdDzm1fY36aO2lZyOFIRKPzg26UxfOfnbYC0zgDgWESxC4FINCtrB1nZZy/4omaxINnVKkuFiM1bzvugU6Vt9ooI6ZmKw9NO4IkQ9o9SXFIgAxC5RlVj7mcw1dHwKr9GgaTDVPiYN8qC2y66tg/lp+ScyEZuvGM9otUDk4nrLZK4DwMUZCgKkjj/NLIb+eD2fMG3WYwOI1A+R58h34b164MLc6qY0BCW1SBtSQ5ToLMrA8r6UNVX5UXlQxUFyKKqG2scZ1VTexPqY7qjJDB8P1E7b2beNVRwMAB5ex6XGUQJa9mrAbPcCWZKsSSCftnSXsUVasZUraD9VNvdGT8964K44DRKiMns9AFhkVVgKSvQVZ0ATQIpzFNWP0uxBMqP6r6y5sbxVx0vGrNod1xnBjinJrOCrfVNo1jiUbB094X+iikyB6BomSjqoWXPtgXmME6YofU1HRG9FTnR9uY4x0p9lva7wNmEEOHGYEZ00JiMLIovhc11rQ3EGm6G7FlonmlV3jd2SUVRF2jhjUJ2PzVXIIXLDcWCyZgz6ndXD9sajXrHwzsq7kjtQhwSx0dY5qF6SeQ9TPMmMqljF2rIwwugfErbJexis/BM+iTxC+ioMZcFgi7Uia1AeCfFJ7QCBDFkU++UZJP00rq3KjqwVTcJlngObd8MAhOiukR0kPKaYKJEqlootQgzkdayp/YrrrnqANAMl8s1CX2G2aXMv2QHBt4QpJjBpkwOVO+OL6fCNfCVqy60pyAg0kI5GySNBroh5SL6QTWwQqsjBxi5Y0Q2iE+ikdE9dqlyKj+anwKi9XyuhZJymxDoszTFSZW0ZuYr4sNJT/k6yq8jnUweEBslvBpKuBB1IiCl9i/eS6S9CH9nr1EIFb8U3Tglhaw+svFf5q7LP1Y/SUybhz2Jn0w1pt2cP1ByGh3eU5x53jnvNMef9tNUqZ5dFIcR4xouZs/W7N5/KzK/76apffeb2B+/y3bXxvrVjV/HyE17M5x19xseJaHDVqlU1spnEF67/9WvPNYRGE1lFJCm/XGp7sYcuJtMnWVgYvFT1YFSdk9S8GEB9JycF13s00kICBX1eDGPKQFlnU34KYKtxUWyPg1PQYAVwNVqOAxCqU242UiLJ20gmEAr0nKxlbN5rEBg+CzuMpsxRAnbpcdo0g9OncXdUJumqGG1O2S7NJCc0UHqqoZfxi4G24WKER+PI2EygGnYGJNMebK0ErVCaSf0/xBaLSUxkj/cTQD71wQS8FX5DsobWfZDZMHOnGEl9F8M6irYQ0hq9ZDBYZ04k2BMLkuRWxm/lBkgBM9TASrBUyUqbccJQ3152hi3JVBq5lMMi3Zbu5/S8BDl7VpmYZIHaBONAKXWqxkfkVhguf1bWwNhRCd6wyHb83oqcclPaDC3IrJ4OkhIP9XfVLYMZ2gkzcLIvle/QNnbpm+7gY8aU5iZIhVpwycxbKKlsEqDqYMTOQhJGyWlJfbVyqlRmpFJeTm0Kj8nMaFd4Lhl3oazagCo9Uv8FQ1F5LtEzfOEkWRbljRXFzFPijKu8GNzSd0s/ucIiO8uOaC9kYwrS56L1iuMWnAtyzSmAY7mdwyygSS6l77Qb5kpCwoZkBIr9EK4SyNLUlk3o0a1p3MoCO04ZGycbpTMuEUe0TYvFse2EtZaz0nakio1CScxbascSQlXXdjWOIM1aJfonvqUHFKdJfwMZ3bOkVqzmhMt2za09R7iapW67NACU2ZCkxTKyCtpoXxiSAhV5V5sqfGeGzsZwFfdElqw9guJTFcMswQmo2DFJaJChMYFhcr0gxVIJOuQ1XGlHNTjqarIoFnMNiUQ+jU1PP0wHKuNMs0p7zP6bHmvOlFO/kw2Tn0ZybYCrn2lzSQeMngiBdd00VXUo8MnIYvgA4kcpDVXtY3UHc9zoL8kSeM9zXEMFRkpzBXGpEDHu5I70fnsZvFQclfdb/BE/ybRrOSQfCWSbHul7hM+ofqOyUDhmqjn6k3kXPDm9Z9JniejB9u62X8uWLcsAZJMb4//8yeEt66++97rTx3aOYHxHX0aN8fTyo85+vBf1nduGhmZO7u5+il84iP7/9HrmXUY1EBF1I0hddwCeZzgOpN2ZIALJxpLinanxMkqYEEvBrILV2jejcHv8TAAh6mLzMWwRzGhJyrobALIIwVYxU7aUOaw3C++NWymqByrBnwFXlvaDIXGIGxxGugaqGbrG2Z80+xZ/smRD40wbV0dlTFnonwHzhBBtKGEJzbFPCgJsMn7Vtkj4WgnQYvNmpkRmLDXbLIFm24wVEcGpgyRGw2QgFbASL+KDSrPww8wtiCESo+PSbIF5sXFAzPcMSeBpn+R1qdxFxpysUyI5V+7RuFICLg0GEfkpWdXkMbHtVxsXlF3mf6HPyViw6YBIo9VPiEGR9tQgsvZfA0ROY2rvhDhOOuMTPBntXxKx5KEkJ9kYHMWQJH/pnCSoPqYZAetwVnvGQgvT71SFYjBAZjPEudf3pv4rJOh/6X5nM/5p6Hv0Q50S+d6Is2bGK1oMpJ0Pw3/G5dY7GRx3c62OP43U0C/2J81eC1oIP6pPqtQIflFlMZaWU7UvJAr9ovQ+SjsiJzyO79CgNNoH85zeVWnezJKCI/yynheXFC388GxkSWcIAgXFcdcHKAYeqtdV+8E6IASaK06loDklHkWfAJ15UQIl5kvfvKKW9DVSRXFb2muTEWMDDCpGepJ0Kg2RqjrD7fiv77ISm8av8mzB0dA36YfVbGnIYI21TRD5TYkqqtBcbuP0btZRysBS86qw1cv21u5KnsbHYpghOBUCB1cdCye+Bsco9kECFcFeMvwT3imuxHFW+J5Q3lbgBLoHojilY9JrEtBJpmuP4XPs7x5JDZjqCiMbtvpK7QDrm0Pf1TAIRlR1t5qYiExVUUxjrdqWJMXKmTbZASUq6UfVISlV05x26B9X3pPGmAYlNCeBp6TXRLophfgoohMVOpuOeKGPbia1FzyxSaj4jV2bncaX5N2KulKeqlBsZ0BlV1sdnwzZDJ+kP+addg+ErABqnKPYvaM8/5TzsnPnnvEOInpwxYoVOTPvPaYIbdDChQtBREVnR8db/mPFd1529+aHqD5pHG8d21xcfOpL+XUnvOIbw2PDflJX13YOR1bwM7X3wvXHv9IMoYcuoBatkuyGOprxCgK0J9DaG8j8vkc9uTHACTQMqO+hTunbtD2+sS2EJOQRXEWpKiV9Eb1I3xERWwCZkJKaYggSjKmDUGnBghTL2FmNtoClDQR04MbhUDAljlmbpPqOUn9D5rlq8u3YKuv4FIA4GaZkOdJnSOuKWGnB0EBYs5zJoUjPI71LQIfSwBzZfiaDpPX2QmMy9zCg2UpK/beOWwgwEl04rgdUEBdHwdhsaCAdd/TW76uyCOGf5aeOUiwDEg9M1hOWv6A2PpkMvBdDFLOEhsLWviZLY/TN9DmZX/2zYhUdRJZEfqpNhfUfEKseP5T1LMrZ2N+kag4SxAp9yYyB9+gHvAQOqcxYN00RgwvhaxqnZnZV2LgyBvVDzPmY7QRJQbzwINKefZI965wTkDYSsW5EwDLRCdL7jeMipVXSHKf3hf+TiE8y+lGuq2wmQwcZF4tNTlik4siVD5SOZHHFZMrJNpJoZuc5q/ouTQc9r1R8xL8ptqX9YzszGkcsuMiGZqrvlJ63Q1dOJh6GpBoqFRHyQHxDfK/Yj/g2XVKXGtZ6i6TaFXpHQQQQ1zgCOmuWOio/BDtYbYsIlQ3uglykYyyUhopnSIFVbNeKarpPpFRkgPS+QI40rkRsoYkEBrFtkUGRiSiXitxJ2BQHogSkdqM9SbIlv0Z+R4bpLEw1yo9jYVg7r31xbfUbQlMmkwCEEknkTpegmNFX7VH6TFAu9cHoXZQDiu3qu8ighOiyYk7URktnVVVjd6JdVmzj6iva/a0kwpEvRp+kokllRZITkcc63vicJhG18fhdlFMVf+1npFC8rxJcOllNHO1zpIcNrqIgpNnVytgNXsWbvQ490SAFrEnVyHygfLQzq/KsSx+o3TFiVaV1wmehmV23SgTdwExkiCL2sn0e9p2i66q1kXGkepWkOSpk7J8m3yoUSd5J8n3axhWfIyMXUE5VKJvey/LCOO6IGc4T2JfFhElT6DUvOu+Gw3pmrN7Wv+2oSeMm7XOGMAZ3JQBc/eQdF//dLz4/t0Cr8I2cxk+fVnvjaa/c0AC+TB3dg/tq54Xrf+8y0bzZTksEQKb1xTBEcLe+I/RXq0SmlKtiGO0d6WdQZLFEe14JxMxncrtmPERwRYVMZyteBSNlb1kVUUGR9CPoTARZBZQMqZR8OYQySLnPqxI6Q09SJU+gr3SLtOXoDDGROaqM25RWyqaEcmI1QruV7LhRapvFCzaM1bDJnIMcVq+zSgoEyRbozJ7ldzQ6CmQ2Q6oglQykzWQmORDjoCYNldkwYad8Fo1MkslowCgCtYwvfp58u9AfMga6Yn1tb0jkJQK3CRKVJpXxuoqNTmWhSgXogYEkwWBoxa6r0hCPbb/ifdIFpZ0SNNBaExGir5Toox1LLeo5WJajaXAg3X5RvooZYk6BnJas2EvZZvgHgpzTFOTYpIHaMUJFO3JcAk7NdNqx2/Ehib1qWHRAJYjg+Hw8qzHcb1Aj6iAiVSH3RwZJwChZtApFK16c9Msl/Y9yR2yHSPp4OH8MxnHg9J3gHCVuMZLswfA4IUPovGKslRszPg0EFLIlsEtfqp8oOibNkCSqzDsTCeJrY5/3AvEazLarYeWeNGL9TMaiIBD67b2p3ECic3LMTecgNA7OY6IqqzjZ/5zRn6SpRkejnCbsifrnWGVY7Y9iuZA46jBkOKZPUdH0QHeLnCpySR+kS2IH7dqztA6O9cw24U04bsKSJ1kfjv0QvpO8U/UUkCUGdiZU7iPTZ/2OGRWSoipDIKFBdbw2yEPEe7BQL2K8Bp6mZWZUXseWe1yhX8A3Mrro5a7YNUM7JFwWapAZeeIGp+EbrLDHSlloE1uva82t/kdbTYRYhmglNfWC7TNIbYbETpIP+5za+zRaHSNHXQcZ/rXJXZR0xVUrr2E8SdOUjpQ+M9mGKl5Fu9Y+oVCRfdMPwQ3BrAQylA4dFsrFdvV/nJ7VmcFIwCR6FKsTEo/bM1rim9gu2veZ7op5UP1M7VSMUEW+IDw2HNrT5xa6S/fkvirJKjZT32t6SAw0MoyN7HAvP+ml2dtPevUnAIw0qJGTXcdiLpk1HBgbO2bn0O73M/O8b1zz33/18BNrG73UR9w/jAuPefHIhYef8X4iGlzFq2rtbbxw/d9c+ziHMBnpYFGNs2VZTlYCqgVHrI6mZJQpNVi5UZ6kKgBSbMOIWSXDZfoZnFJFqcow9D1o89ei0dXF8wEj4cm8U8BDM1iJBnY2o30zGut8pAAGqGT5KwoPODiT8YwZXKFvNEqVzBEBhLguKPa1muU2GVWZAYQlZvxRtWRVZ0Kzd6w0Zvus3KxnIMqIKRlIltySEr3CA4jhESMcf+HIMHX2jXypMSNlRhq4gKymO8J9Jodc7Tu1PcoJinUGQoNCaGZTiCe+J8fznKrrRpJcc3qB8oaUR5bWymG9x7JNxg/ztI4uCa6RHZudFXfLOK3mPW3qksQ/tlkpebOzJHac8TWxF0hPJ6OqGd3UpSStBiYSr1CRuz2LDjRNW5lpEZrqbJW8V/VYHPTU8eCc+dRPSu8lMaoqr1R5n8h4ZS0J4n0KCCpUej+pkldpFL5jaB21tpkSFPJsoo/tC2tQz2CQD8+RwVdue57Z0i9hi+ovgJB68vF7SmItYzQYl5I9VTpWMVi6beRffhFsN2NLlDAOviFvelC+2wP4K7gnv4os7BmktMl9bEwrOsCadDCiBCGg9HMPuSWLa211MpUqDTNAM7OSvrOoQWq72Pwt2Kb4RKYNwb8oAMYfT9/FfypIaowzK1FhHzDJRexpmtt1XXRQZMHwtILJRqYkyLJIo/1OgpnGgyQ3CYEtTUn7lfTbPpfoA5DKkWAtKGFZwo8wIybP66BiDyQRaEVevhcnPtlvS17SkVn9t3QJbDdtEdSPkuSXJJZklEoDkJHrhPdUeV+Sf6l4qCijwVAWSyP41x5IUXrMzrSmnlXlpKLjEP1NHVO3RkvSufJocCE40VH5R8nfsSKtsiAyH6pwqtUEwi/pn5mxJBLYNAMN79UkK5KtsjSENi8EFXC2Q5b3yfshhIfoYGhSeG5ss8JLNXyPdTTafLMcLacddGC2aN4FtwG4noiaAO6N7e6xloyIPDPTeqx/dKqbeugP7/r13FXr75vf2jlcNlDng6Ye6C45ev7/AFi/bPWy+ol0YrO9jReu/5urGhCy/ZmMIhslqjjVkjlWAEzZsIpzIsDCtnlr3JIzV1FyI/cqtkZhK/32UbgpAavNwFaBIwWoFfzg6l1qCI0Dp7t0xo55jg4XojGJtVO2nUryjEPACXClVElGLesUmBGyfixOQwVVdYTVjgo9LUC3B2qxnwIyZEqZkABVzWebBU8lW4pjFX5w3HM7tSg0SI5Jykxa+kg/kKQo0j3RFerM2ucrxl54FYHVEXS2I4F5opUaU+vkCdDuNeEljaSSF+njHvehTTYqgYk3d4oRkbDGWIxKVpItwavdMYaKSV2ixE+T0CHDm4pz0+7cMaDWK47Z5lyq6QlxiPQ1Zgz2QzG2MgvDSWcrAaaMG0iObSjv08M/aC98iqpin9dZWLIhb3QP2LwGQKX8E3K/uBLxmJIKv5NsAkizpdqnPXEjjCVslKR6KEMx5UyVtxvbTzAsoZQ8ElJXnagUbOg38eF2B0dxR2kgjqUyPLTESc81kIU41vEInjaW2H9TdtvM2IkAS8JM8UIGbe4l43ym15ikmHWsZUykmAgGWEugEyZ5QnKUlfbGaBG0rZT4qDqttjyzPajWUEqBM+lpgpl2wiXssv2yyawKSqm+GAlQHqWbrOOe/HCDdZxIr/01iS4hQApwIj+NoiuSmKA78NjIWlVINAkC02LKNjgQcSqykPFTkvEqr6XhFPCJrWnXEotbioeKf2J77P2URFaDxjZZkD6qDslz5h6LkZrNbZ9fRQqcBAwMzasCAGhFUKUnnJKSMPyw/fWcjmBIresrjERXyAAJotUmqAJEe0ECGtW+GzqzVi/EvlecJqseRlAM9tjN90AUNnixHI58T48EOqsMWUxU7Qq8qpz1qfRQxilNrJw7iI/CoepD5MOqt2CE8iS+tT0bZchRIYbIp1X+Np+limIVy4H2Jtt5q6+Id+QlkOc5hgZ3+jde/Ge4aM6CTxJRk5lzAH5vwaC5sgPogBFmXnnj2ju3P7pxje8eN9nt3rkDbzlhES087vxPAehfOHfhXg+yf+H6v7lSQJh28ojSDZPRNjLIgLHiIIjCpJuMvqVnkAxwO0ja8Emzyu0AqMYHkG2i06yIPq2hpVVsVQrBIa68DFIimYwujPNFqnh2N0hVqTgYMUTBWZHF5xwcDVhnNwU7DF8ph+HYJ0bcQVFobUDcEC8CjDhH1nG3pU3RkTWzAvIyeV8YUzpZKmWeUxCj49NUfhy+Imr8yDnbeJsbAgVyzcrarKBQnIQO6XlPkkmNxz+I0VdjFeUGFEtfhXd7AVlxmNRxEuZHEkrgbWXD8EhkS3mg/bY9aZsZAdLuYaZPGiDGd1J8qaZXTOChCRc95BeIpqfNuUnGRanqoJ+pZJAx8IyUoTRBv3X8UnspIBdHyEpbOkdL+JxkKrUjznHKZlaTu6y0C9Di9N6k4S5u6CctmxCK5e1BNwKMMEBVp0Z7qkFVQo/gjDLkLLdUmmcagBAv/WqhS8erUNF2SBkYWZ4BAEoun9FBFEFP/TXnShHpDIDKcZuMVUZr8I6Ft6qDaSyKoZzmUVj6poNoa7A62AqlY1eVjs6Fkt0SXEmQBDYYbN8Db6V/EthUUSaVE0eMEZ2TNXuVxIc8ZhJnAhvReVUdb3s2yXOUF0m0Ufo0YbV5wuiVNJyGFX/zAcNdRkoPz6zYpvfp9JEZP0VtIHNPIhpYz2Iz7ViZFXFjMl9ZzTWBuIhplD3FK004Ci+sWleDXNMx+0G0ty7iByWM2EOH5QFzLixFztluJE5V/Au5L3HII0V/kZ8sa02hspnOeBQMTzprd1h3IA2cpC1N6FL1PYnC6W+91/RJ9TrKZCotNjS0yYoKXQwdGbDrRNlHHaU2fmskI1LPOk4n/VGCkj5PBocSJyrWKo3T2A2xzbrWVIJOkyC1Vi/QX3gpPkTSKkkK+gr/ONKFTGALUf7EH2PXvcRfMekvcgbhv/bdjNelXxMfBddtP6LckHDdJrwqwKdjZyu45gZ5hvV+o4MyRGnM0NBGnjJO4StRhrHhYX/Y4cfWXvuiC28EMLxjx44DiehJ/j3nBRJRwcyzfnDHNR+94vZfkUPDD430+2OOOT5/0ymv+BoRrdnX8y9c/zdXCggloFOd46pfaQXafkCiWvK3xTVOhl2fEpDbAxYqIJBi0aQU+oxmd5LBr6hNfEBFuc0hUn+XyABNMlLqCOmYwk8n32nwkFyC5F7EAArRgIQpKg0mTfFQMGAG1hRCiK0PaAIxEgIogFQ3SeDK7+InEMw26kjPS5fZjBjmfer/CDWYUZnFAWDMZDI0hsYUwTFl3uXL1G8xOM5s161GMb5dAkBGdNyYdTbFOnKBXcYQGHnkCP4qGzJjxDLeOE41XmmsgZaJPilQlvHJdzAJAySjrTSiPVilZdGVPlOiI6oz2UXZYs9lCQCOMueyzKkxVj4aBqsfEeURxEXZLJ2nPGS3GSUYmcukQ5G11tgk/ZKAryL3FN/MMI5b9fGk+YnvqteamGDErXAM5BhlEKlQR6H6XfpKsvasz7flQ4zO6sjS74aHMhOpZexCZ05UT0lkUvmNCqAt61mFMnYitHzhm8PDIVKp1bhW7yCUpcpmcrKk35HWNoA2/ot+b1A3xfcpiSJyF25goyNCV1YcCOSMtDVJQpUVlQ+5N+k5G34EmxJe3mq2PEaaDmUJNBpca3SQOKwWnqDtmKBJ5IDs0CVdIg5VxGIgjIEA9j5WGFQa17YqEmE6ILxikSXBVmvbElgKCNiXpN5HgthSTcvfsIV3GE1RtoCxkdAXB6CzG66zofeT7WgFY4T/nOifXp2qWKR6wfJb1KkCqrFFHWzUU5Ezg1fGPFVpqIEBEiS188HMdNvgxZLU5OpiO3ZwRsflF4NDTHvSKrzW0Mm2qbckmapWQQm2xPcxEi00iNxjoKlb+m4y8meDCcMLE2BWS0UZxGnRJxngtaV/ETRM4sXYF02MwuBbu4rLOD3s1hO6a7DQAIJNBK38Uj0VjDDH38RPkp21Scnkgyn/5UbLokiP6lFM5h792HBWXmln/yrZA2v4FUD1/TbZS9qWEJSAOFmmvHYUJ/PUqqT+SXBvbBqRTzxJvYFYj9RGMgKSNAn0MsGgCcaTbdJX73lZTDd4V2TwZVbya0+6aPNJ+89ddNlXL9u69NKlZaQd79lMAIXt27ePyzvrXwbw8A/u+Nmrnn5ig5/QNZF2tnbR20585dBJM47+3vbh4Vm/7ezcuDDMNO7R1gvX/81lSkbbeWCyyQIRongRCKXGOt4OyOd7e5PeRtX2mCu3JKfSfppAwLgdbUBMttcVA1ExalGxWQBpj6CQzJbOAlpxt0yZLYm7E8puagHATHaJgtGQnf0g3bPKGbNYdsLAcoLiroyaCYx9CrXwckg64u6PKSOaGjEOQdwZL4CwBDNI3yMCUHQyqkF7pJc6iEgBMadXpUygGUT80sUyFHV1ElIpXzJnoNZkytj0AfqeFJClYDnJi+J65StW1E6QbhxupAw0Cd/F4YuZ1srOdxyluC1YryQhKM2spJ8ykPCJF9amboS/XUosyN8AUPgWxnd0U193b174AoMjQxgYHkKcAkyOhUV6gngWIEdolQVNnTApHxsZRulLZu+po7sbw76JZlmGTG0lkBVjwtGhlhkGp5lX0VsQTEmn6HMaR6CZizxOtEjBg8hJvJvsrEOiUZI/kQ05I4xFvcJfFTAi7au9KtJjeZD8FOvvxfu4+mzkfTWIAkjLhUx7zMiIMNYcxfiOXnfq3FMG+7p6/J2P3N/7yPYNaHQ04H3FLav2VHTd2M2QyEBbNVmU1yhkaYfhpHvBH3LqBAjNCOqBJe+KlbBVksrrJNCQ2+UX3WodyODQHBtBX0evO+nIkwcnj+vzqx67v/fRrRu51tmgsOutTceZWXQWG2G0NvbJxaRXBd9V56EHiztxfnU4ckOiB8y7UqLCYL3qrJGIOFbdbEyw3pbfRlm3bBBnizzHPYrC+8piFDMnT+PzTjyrVc9q9Uatjt+uuRP3P7UGWb0ebJAcEk3KgITPCnfGVqquRCrKdBBg4ELkQButSl/FBmiKLj2qdojTQ5RoqfGKnQ2CeARknjepU7Et8q/JjlUCxnSTMrGCI+3gIXJm5V6DRoKunhKbE5O70kzohje0iu8UNTUYnDZds5hCCafQnsgzMmaT38a+CMvFb7HPs9FV0vcl3VQSSbd9ShCEYEYCikh1l2jGhqnKfwOUerafHQ6ndwGsZb/CM+MWBVpb3kZdspMDSY6quKxVAeqPWKNh5dJYJDP7TFY/EWTRCQHs7C6pVYzvJcD6WdJvBRLSMVpZZCS5SAQxAboOUnhpBp4QEkwOFf6b5kj613bt1b4I3cSPZyBjgnMOY8P9fPoxp2evO/b8rxLRxmXLlmW/p0wUANykSZOGAPz3V2//yTtvWHPb1Kyzoxwc24WTjz3JvXzuOV8rUNTzzL9kEdE3mDlD3In0hev//jIBYdLc9mMikpMZ8dBkTKwRFeMT7I0BpnBbykCCjFG1BjX8Yh5XoZRsnPojlS62CbV10g16VBzEaBiJq0Cr8NGWLUr9iM9JX/dwsFL/GYBuOqCZFq5klkMwCQAOuvuiYIwZXlDPsIbCsCYFZ6heIfCSPonBIwU1JYJtzvgLWiZaeQ/b1mENZnguTleG16jxEMedFPHTZxbeQtPRUJPwPL3RgZJxVKeGtb9I2GtYTJV2EmWNwyKOiJlOJOeS40GmxMjKEJI8i4xac96eTSSQlo3K+6U0OLk47f2kMJEcU7kdVKNPvesD60497Ki7R0aGsaF/x+Hv/9JnDt+05WmfdzRciDCNHEJo4+GynMcGB3na5Gm7vvTnf/2r4w89fKFnrvV2duP6B+/Fu7/0KTQRZl6Zvc7EQgybyogzY4v/cnXkwksJmpXiFOUmMmpvxrDitFSzQ8koE1QXrIOgptIoOpu2YXhhP2GfZFPkWUajTos8xVGvK9wWQ5qO7KiMQz2z4GD4osWTu8bR37/uXTe/7zVv+h6A7Hf33rng/Us/c/Gd69ag3uhyzF4rAESWiQhwGQvOes/kyzLRjwjgEuyT0xCck+RQcKSj8Sn03LVENla819tN1jkMkQ3JjB6qdx7pH10GB4IvmzxpXB/9/aK/uOUvL3rjdzMgu2vtgy/+8He+fPE1d9/qOzo6XImUHZeEHsm/Fvvid2zkTGeuvIxVuOSSbmtSSbAxJTMiseKRS2ksok+ahIod0VlNkSsyeJgoEPrBye1P1LF2MDAkA3ExNsanH3HsyNf/8lNvBHAPgEM/uvw/rln9yN2cd3RSS3BExMrasXY9aoc/yGc2lKnyVgXd9CwRPv2it4ldsbMU4c/4fEooppFbIgl9I9/0pdFesk3IESr2xPuQIq04vWlGU0v6GBXqS5tiW00HlDNSkc6MmFQg7bfaDCSI0gAt/hFEJZ6jawwqC8WjbClOVWiebKkN8kWrCfFIqkq7hlMagMcxikAY/404JK4dBSwOO6MTJHEhfdDHbeLIAq7hIWBw3WQ/hA9yXKOZ3NKEusikTYKrDLXRiQwvItmN7Ee8YzLvFxtmbAoZ7I78F1qojJhxC8YIj7QNc5/2hUQm0ySI+H7p3igJlo8c8VY26jPYlALjyjx1lLUk/+2bY6XwWtqSyRHWb60MS4WAYyArAEfMGYj/9NRLNh81dfa/M3O2ZC+wYi8yx0ww811X3H31y3YMbClrfeMYrZxedvRZ9x02cdZf26CSiF4IBv9/eLk9fjFOjlwpE8/mJ6mCWNNX/ds0aW4RgQeMkwMBvAh34uBLJt7oshouY4gVJhlJyJkjKMb/9D7pEsPO2Nn6wjTzEe8WZyh+Fvod1woaYJOh6ueKr+m5YFsMPZVO0eWMW8iHWyRAdDquVCNvRiPZP9N3pmRE9cBj7VZy/rSvYgitmktgwbacJ7Qo21mTcxoMKq2JFThZ+xTHF9/FlEobWPsmzp2VHQrlpERh5oykP6zPxwghPMImS8/GwFm5lOSE9EGjSGvZk7xEZoQREKmDCEtDovQYorPgLTFlQPYe83zlg0gVWeRPDiW47B0/Hq70Pz/h8CNeecZxJ7xy2oQJ/zVp4kRwWZZKSAAkB4t6D9cqUPOEsR3by3kvOsH9+P9j773j9SqqvfHvmr338zynpickBJLQQq+hFwkgvQhKRxSl2EXsXhUQvRYsV71XBcUGVxEQRJAmEHpvodcQ0tvJSU5/nr33rN8fM2vN7BP0vn+9P+/7Yesh5zzP3rNn1qz1XXVm/v0ni06be/j922wyK9tu080WvLp4Eb7000sxODSAlAkorctQe4Mipq/ynmoaoSNrsEZopPIZKVASI4XhdqaV+ziSNWUaTyTLgf4sPBRkgQU+Ko5coHf8P5VJZn9YuZfzKMgTJge6rkWdH530UfF83TwIiI/qkJwwK6YxyCTI+/rssXvMxaffe8ZvV6/rubQF++P9dtz15uP3nlvy0IipcSKEd2d7pQaUJsjZojk0QM2iSSPDg5TbHCZLXQDDOOOO1QCJscVjqTJokBd3pw9GKbsFTFae0jkQ4ysEM4IxIm3CLbixFlRaoLQwRCgG+uwRe87F+cec/tu169d+h4Ef77LZNr8/brcD3qhnmaE0YSQGSBOwMVEfPR0ra5v8NzJPEmyLLJ+qtAm+SpsGxLKuMO4++Qyjp02EE0Z3e3VtSZBKkZij96iuMz44Jzgd8ZIhICEgJXBGQGqALCHYohw/dkLHiC3eRUQLAbw13Bp081dYUMFAGes3VHi7Ij86927OxMGInXnm+IG3+XWU/h5FVtcuRZmhSp88BisfRW2zyEyUM6HQrLxSNmJTyRMM8sY9RfgkD43uaoUXvP5xbYre58pNgvMxcxABbALWkOhs/d7ZBUYdgSCLEVtGohWwTOYyppNWQcYTjKozpIEQncfweVUuxdGJ5juyI+Q1qq/J82o8V3CypuvE5XUiViT2RAjS6A1CIyGzv9+pgEDnCr+R0TFUQymRrRDbLFE/9B6WVbPQ+VFlFc+J/zc+ZqyqUUKwX+NpymQEUh6naLyBSKREDASP129qv+VHaGgo6FfmQPtRV4wD4fVBbrR6L4rCcuT8yoAii8wty81SDPWvKU856H3p6bsf9ysiWvnkk0+ai/9BdlBKRfv7+ycvW7NsG2Ye87WbfnLRs0te7GpLOzjvW0cHb79fcurex36diOwTzJnPDL5z/f98RRnCsEA6MLQ3uoAANHqJEMaIEH0sQhBFYvTjikKotqsmiuIaafORlRWAVBfEhAbC+33/FVC8EvD6yQkx62fSf1ESXs9pa7EYyno6gjgoUK/aNcEK1AJ2HJNVFJ8OSVRHlRKQPvhnBFQ0WFltJHosqtNShfv2Ct8oUIi6jeQ8UnyxQhMlXtEiFM133JdI4cdOoiCXi9BHfBTRTxAurnwKpYrRu6MrXivi+u4mRzPE4vRXtL90Vz6TEjG//pKDHFSi3nHfIwUrLcWLviXh8DZT4A3VmJeFNvKRzwiB0bRl27x581IAGGyNdNjEAI0aqJYiHJdg1TGvZSmGenuL7XfaJf3KB8+9ce/td9gcwM8BXH/J76/o/fE1v92sZ80a2+jqMmWzpYqpEnGUjojc+LGKqhMjoGI96JhkDEHONE4ayS0gqiueCTeGmMUlMBDaivoQ01MVYbhPjdXKfI/KSBMQdpbzcix3xsGAuOv6qApHdZbFemAGbAkwYf1gH5pl3tVWayzlopiCtFZb3bceKC24KOAWnSQAeScyb2HG+Mk4eLs5vYmldV1dnV03z3944qvL30ItrcGWZYSb8mofxPBzuMHqDGHPSMAitKzcyt7Ycb5NNb/E2hYFWgcVErAzybC2fz1yoKuz1rY0L/KNa2nWfH310lVJLdu8NMRgP7nC9yaUYlagLhqf8JcEkyrrxkluFlmNeCWeJhLOjo13GkUJjx3spV++VLat4pFjhehp9cIovJvCe5Cw2+CtZmANo2bS8sILLzQAGrAGaJbgVglwqTo3ntcNS+ij91ZUZTx+iuZTBx7mdJTzAH/eanCKorEj3AaWrHHMW4E/bNSFEBiT/8QFgmEMypsVh4O9KcAqZtqXkF6K9G+Q82hQEBJJZ1RXCbPJ1HrnnvRpN5/BP/X8Q5ItCuNXc5t1+qIxxBkd+RyBH1VWfdtM1WFor6SPOpWKz6H9kDGXjm8QQJIRqqq1lQCszk/M8hVhGeVseB5RcijfRHNc1crVMcRGQMziygZSMRReqijAFOgQiBKcv0p7Mg+sgSBpLR6ns/24ym8VRzACwOg3x7eBAIG9Yp3JEJs8DoHFDqS+RUV+lI3nl4loP0gC2jEVYiFE9LlAMKFVDhUbzZiVHrfd3L91mto35vG8dA7NyfGPLwLArRompXk6oWdk/QceXTL/7NVLV5ZdWTt1dm1k3rvzu+/fYty019cPrt+zG3gMePtpf+f6v3uZyl8Va1UiThZWtraNFP4/vfy9o4MkbEWJ8D9pQ8A2CCHeFiSqgr1BgzRqPPKEYBiH2JcKmEhs9BNKDxhqsEMEPwIeDwwaMYrfHSlLEUWJLDoFHgz/yrbz0Ts4erdm5iJjhwnah6qhJhNRnRCN6KmCls678xBJ25EhRtFC/S48E+98qSCqBI/miuR9nhqBYP7dkRISknvekXeFTKU4ePJ4NFYP1toPX46rvCVdUa0s8xLRJZrASvQuUgDCexsoIc9/4uhV1qYFoupkSIQ7flZvsRyyM0Qwxti5c+cWc+fOLZIss6aeAfUM1KgBjRpQT0G1DEmSIqvVMNRqFlvtvFP6rU989vET9nrXH1et63kewI0X/+YXa37xl6s/3NPTW3Y02o3Nc5/V4UpWDswgyzAyJ5ApokAwMn6n4tGS6rkmVpqBSoH2/vuKjaB0iPgmWFHBuPO8QPo2xzhBNXoskzEpD5HPLMGXWMayIq9XptZ1nKTvDxPKkkE03ujzfC3Rb3UULWDzArWObnPL4w/gMz/7zsfWDPWtWt23bvEXrvjRWX+897YsbXTYIi9cJigvQK0SacvCDg5jzqZbN3/56W+c/ovPXHzZpWd//tQ5M7Zew8MtpC3LlLsyX3d+dsQ/8osEfqRfMlU6BlRoVhUDma+I7znwia4HlS+F/xMDl/EjWEOojxtn7nrhcXzwv772seWDa9cMt5qLv3/z775x24tP7N2y1kq1ZoQYlX/1ivjAsajwqnwd42OEN577lM8YIesczWdIIlT5NHBP2JBFeUXx39PDOrlhGwKc2phPk1BCDvMNueyg/CSyNy744osvduBlARQluLAuOxjLaIV9o8nl6OdtrmDwiuwKAfzDOu0hOxIUndwdJDoOuAVMrk5kjPjaX3+pca2Bw4ANvsORbqxQ1N3NEa4LnUV3MaCxTsE17b2Qk6N+oRJYEDpoP2RsHOFZHEyVQRs4GaCqiRGRTscU1udzTOZwqQxTLAJVAdGJ4PCBKBavu8PSE0eUDeQrFnM4O9DxeMDZaITQDGV0vE7QvZE8Cx4SqaxUDScR4w0ZtsIqnv4q4/Hz+hspDgQdMKpNZzgh/p/yfvw+jHKYBc85qoyhwK9qm0CwKZorQMFW14JKmzL/ZEY9EF5LlUmPmEp7Govo242jAvTVtmX8FkgLQs2mXI6M4NT93zN44k5HfIuI8gNx4D9AE9+MO3cwmVDvemHSuEkPfuOOy9/98NJnG20TxmJtax0fs8cROHvvE38C4DXbsq/40tJ/2uY71/+dKzp2IvrUc2iINqHCcMrAVQ739wUVMfqqGNrCkxwxqwiIZ8x/7jhKM65zPFp4Rq2DjIdBIJARZ0IEUCKEUQSGnWQYf58mrURiEEoExTjUTQj82zSCHH6BAye32Yq2GQM0+XyWKlcC+egciKIov1caMCC/EDyse7fSsG8zVuLi2MXgxzoGy5ofhc6ERqaiZsMs6WxU5kvo6RdikEwLNlwArVF0IkDWYflMTphZCrQlQtimmsP8jaJheJohxxSw9ECMdh/tj3ky3tSmwkcEXYPk3htI6D6J5ly1amw4EOJovLPlGOHlVa5lv+ug2wm9BJclrC39s2z+/tzjjmaJcSV2IAAGsIw0NRjs7y122Gab9JKPfOamY3fb90EAV08eO+HH37vq1+2/u+Uv5y5bvqxstLcnLS5D9NFHL3VDpdAZ97kvJzTGG/vKh9YbLBx4VDI7FZwgNSiUrLHdxZLVcvzuNmizwYCAPB89VInG622jMEyix/JZkAnjmZP9+1lLdUO39G92RhRzJPe+v5qtkbVFceRdLIcEICIqGPjNbTdu9vBL8zezAN5YtggjeY4sSw0X1vGZLg8kwBKGW4NDq9b3bDF5zITvlMCX16zv6WPLE7lZglGCE1Iec6+M+Gw0Rkb0kTWRlbLbGAc8n4YdfMlXV7CuvxSY06y4lJ36NbBsAGuIYIHrHrxj1rNvvjKro97Ai8sWoL/VtPWsZqwPSGgARGfZy71fVxOvP3J98VRiuJI+A5dZHKUGFEfkGeuLZUlkTKBaxkQKn0IvJSMD4ZxRRw/yldrkeVEy+0wMThACfhWPPOpb5JQmqYEFOuV7I2OJPQUK2Qztr6oncgEeJt0wONwHj4UhgxxfUtlSzTzEWTFEeB4FIkUvSOZEA5mk97kAWShfjLFSdYXXjUarQUiXAIS1w6IjxcExTq/LeAIIqI4R35kp1l4xnsicCU0iyhgj5jQk+yL0FmdA9RZQDUoopZ3uH52qVztAP47/CLpNNqeRuWQvh5qhpCAzEox0dHXHlpDPojmG8EdpbYDGYdjaVlCGCoEU3TSaVn62lZZaryQ8wdA5BoKOUB6S4CiHcQaui8evk1ntLwcbQbKpsbg5He6X/EQqYYNjMiIcCDaZG4gFtDQYvozYPRuyhmIPxNnuOOPo3mIrPBKGJ7xWXYpiI14J+k1yz+RVbKicUDIKrXjUe/wdqhrJjYFSg6GBteU+u+2Xvm+Xd3+ciB6ex/NSIvofzwqUtYC/vO/P77/rlYd3HRwYLigj3mGnXbKjdtrvYiK67pprrklOOumkdf7+DVjwnev//vU2B9MTghUeG65ecNS88TBSkdEIxEYbH9Et8a+6JiSymYICAgKPj+aXoGCkH3IGHm/QIEdPQAEpblEjVghgHiOgliyJgMvugcYZA0GhBUNajQYFXEcfWb8hUTVxgBFTVuikQC84xBArJ2QbwyQocErUW0ghxgtxlG2MFKT+N3IKoCewBeUfz58a4ZFaVTCMDTlRvRyVbkC0qFeS7PrH1hsC/jzBoN5dmx4MKUZIyN+kfRFyS5/Ce0QpRwyhu14KLRGUh+iE8KfnlWAsixFQddbl/kgRRV6PBgBUz3Lor/CvGH4+E2C5gC1y2KL0fST7t6cetta6NVqwpeq2JE0xONBXbLXZlumPP/fV5+fO3vn862+9tXXCEUe88Mtb/nLmz2/584kL16wo28d0J4XNoZsq+BEpPVWVOZ5KjWN6C0ar2SwtSndehUmsqSWcpqkxDGML3xfNysUCF8koSeZBlCWAxHBelmVZ5kBpCdYCABMZJCahLE0TWTLpsiti/AT+HJUpsczWMggJjCGGAVsYk8KCbSsfsZyXhDRNYMvC1GvIarWEmKgsy8BrwueCkwTEO2sGY5B0R0KOnAK3IYx/1hCyJEGSJvalNYssgShppKgnJimK3BnG1r0rsbBpwWSYiS1xPau1rLUjiTEjNSRJWgD1xABkkYOtt1w0MkEmivap7MUyK1+w4mXYwddzMQOJSVAUZVkUTebCdRnWWiTGJlmGtK2WICEqrY0qBtw29SR0s84SNI2keHn1YmOLghtZDW0mS8pWy+GD3xjJEc0ABtYZtKVNySSwTGBGQikKW5at4WGGZfeS1Nha2jBpakxprcoeszv3kAGb57nlogVYJLBlCZMgTTMkxqQ2HDSmY1e+9fhAxoCJLPsonYFJUJQg/46yKG0+0rTIC19qYSw1MmT1RuIsJSndE9nwRr1kL0owavVkyfLl/SlwuXxqksQ5xKqJ/MDY4QwDgPEYnhISMihKLotWzig5gfGluIaKpFZDkpiEmUmOIhgVk4yuwP9Cm5D9qdoFaoCLDEoLkbEsBmsgbSBwzIqqd9WAFp0TnCxCZOBKiRyF90VsXwmKxDpFNZ8oOQk6iq6I767YDRxZ56jiWEw9mWYE3R+BbQyLqmfdLbHeU2WlDwXaEUIZYPT+6JFgv8QYpvsyh+CnvrJKH/lF9J/2j1UDApUejLoqBAl/G9WhcQi66rgHB5qqDwd1GvDfEQvx/gQxfcSRUgz0fFI9SomiSQkd1o2zoGwS+s2o8pQEH8QukJukRZEZlnGI/ofqxHBPLAMiX2F8hPjdYQ7cK8X5G+X2C/7EtPR/GhCQADkXZceUsemZ+x3/2j5Td/7TZU9clh2IA/+pMzhv3rx07ty5xbr+dSd3tnXa0377xZ+/+OJz+YTuiUlfc4jO2Omo1Sdsf8hdS1avnr3xxImvMTO94wz+61zqECZisGiEMjKCNHRQFfiInTa4AvhCDSkxmGMlIGwaA5hGDsXAHv0M0ajeCChXncuKjRP1KSiP6vcaFELIkhlR2GofhD6EE32sZgbYAy10a34EoJe/KSgbpbWFRo+1rBbQCLQc0ItoDEoDZrhza6iieOK5AuKciiMMQSKrFSiUToa5tOGYi1hpiFNkY/rIM9EMiZOnZZGipGzgAQFcpZGMU/qiTmdwOGOFWVF2/j1xGaz66FEpYbBlbMUgcP9ESpdi+rCOhW2k4EU5ksy1zF+k5BBLEfR9GP1d9Ll21GdOuLDg0rpj5nM+6Nb5j3TmI8NAswlOEjAzsqyGwXW9xXabbZ1+60Mff2Du7J2/WbB944Qjjtj9m1f+cq+r7/v7iW/1rCjaxo1Jc1sCJYF0p0obVXypMHglWdqhwUFGq0moN8zMTWcmG0+ajFarhYGymaxrjmDluh7YslVmnZ2E0houfabL2kjYwrzoJBABhngkb1nkRTJ5o2npmEYD7SZDZlLkRY4169djff96DKxaXZrubqRZmnBhQX5zGiY4R0R2ZTVAWRSoJYnpau8wbC2G8xGUREiTDEMDA1zP6mbGlOlmXL0dAwNDeaOzka0eWI8Vq1cBKMtaV7cha0mccJkgChMbggsyb7Ew+GyIGLKQfVJMgpIYeT5ssiQz1jJsmaMkgBK30YkBw3IJA2uaIwXs0ADKvOhkyx3GmAaA9pG+vqLoWYf++gjlNkfW2W6oVoM1ACVJFIyodF9xV4I08VKT0XiXwKC0hW31rkNj7LhkyuSN0JW1wTZbZb29PRkYGTL9w0NYPbgOMChrXR3EzEYz+SKbXrbKooW0rKc8OIy2LEMxPIgCQELG85qbPzYENhYJYDhndHV2msHBfphGCiayQ33r0Nk1Ntlsoy1QLxKUXGKgHDLLe1djeLBpG91jiNkSA0hMipGRIU6TxGw0YZKZ3DEW5dAI0ixN140MYO1gH/oG+sp6e0diixIu241QPu3pZg2hzJuop6npaG83uc0xNDKMens7yrK0I33rOcvak9kzNjOdlAEM5IbNivWrsWrtGqCeca2zw+0Ma30mnWPDlF25GIzp7+9v1mq1Z/wM2jRLgCwBMgMUXvtYQQ/WjKxJDQpry3xokDrGjkumT9oI7TZBmZctWM6KjNL1zQGsWbcaaG+Utaye2DwP+oUjGSUdOuI1awGnBb9i3GTFRN2+Xu5XPR0UbzCoTfTO4BRYHywMRwOockCs6zhGWRId5/lexdJnq1Ro/VhU9/jApea0ImdLFVxsf6g2iTQoK9TpZ2JfcWw3jTJM5LlIj+j9UdYpPO2DzyRyFgKdIZQnGUmH51XbKdJNotN0hLE2jwKD6qz4/oq+iwwp9owp98faLewWG56X6Lebh+h4F6GRx1hTCWRHjBnRX7odqWyIUy8OoOuTp6E4VZHtocHeaP5kTnSchOBEUuCEYENKBZjPk1q/e6ncKYFDiuci5iA/C1y1WULFmNhF/v1CDjVElaxhLuPMNIe3qrzAVTgkFkiSBEND6/jIfU7Kz971fT+5/MnLh87d7dz/8YzAAw88kPymMqu/feevLvnr/Nsbbe1d5bqBdXzonANx5q7H/GCkGGnvbm/fgYheYWY9Sfud6///q3rsRCxFlSsSNgpAEz3p7Yjqs2JQgKot6v3x7aNe6ZRDBITOSggAj2DUxMAufVQ1RXGbIvyh94bikbhxVevOq0oQECfIH7rqhd/969/HVtcbsagpbxRCQFyK2WNDTTFVSu6cAFeytJGgB5CgkPnSZ1lBy7Wk0CazWQEgeZe0HJwuUTZuEsMy52h8SqCQDdTIKgn2xMoiUkARfygws5JW/1NFjADKfph6RyVbygyQBTjsVBYr4cAaYW4kM6x0kjnx86r8FvGu3KefeWNllCqscKsCPoKSVu0fv0Jox6HfhiwBQIHiWEOUFcMjQCuH4REkaYqhvt5i001npN8466OPvm+fA/f/+/xnph+4444/vvzmGy7573tvP/zlJYuK9s6utLClo70hEIwv/YsCD2CgLGHSBCNDw2VKlOyx/Q44dJ/9sdsW29kp4ybcvtUmM9YNDA/NW7Zq+YyHXnyp68W3XjtgYe/Kne958SlQmtgsS40tSug5Tl7pkERnmeF2eiy4VbRo5qazkj1nbzcydcyEy9+z97vGbzZ1062zNKXV69a8+uTzLw0+89rLY4fyoff9+b47sHagD/W6P7NP1/eRz04RSi7tuK5uc+rco57LWvbpZt7C6tbQnrc/dd/s9QP9dr8ddjPbb7zZfScccOTizSdPXfrkCy/91zZbzPr3R59/hpf1rDrmmTdfGfO3h+9BsyzKRqMtKcvSBW0o0EmMLDXgRm0sJQYRu0f85X7JYHDSu45bO2vC5NW1NGtfsW5tefVDt81c29fHaZKQ5ZJrxtCBO+/5yj477trobHRu3N3R+UCa1p4G8HsAz59/ytljjz/oyCK3XJItk/6+gef/8tT9Y59a+MJMk/iN7qV0MuK9ytqVyPIUWWIAVDISQ2gOD9r2eod537EnYctJ0+/cfZudVszeZMbMLabO3G9576rnX37z1fn3P/3MwLpm/+EvrFgw4+7nHgNnxIYSrXVyIkQoi4Ib9Rodv8chjx25/V57rO9fv2DRmlXJb+/584xVPb2cJQmJY1+WbA3YvHvnfZ4+YJtdkxeWLHxm3Phxh/32/usnDyM3Jx5yDDbt2ujGsw47uafB5tm82epcM9g7+9bH7tn6pdULd7/hgb8j7WrnJEloZGA9b7vpVrTdlFmPHLz97vOP2vOQcf396/+S1bL9FixfUvvFzVelq/P+Dz7w7KNlraMroZZ1fMWspYqGCEVrxG4xawtz6v5HP7V62fLnx02cMPnVtYsP//P9N5ft3d3J8Yceh20mbP7kKe868tWGSZ6zjJFGVt/1unl/s0vWrX7fAy8/1f7ws49aM6YLxhiXSWe4YI8IXgLAWqRJSq1Wq52IhgAgyVKgZkCZLw3366rZn2FoLMOkBs2BPkycPC159x6HoWy1rjzn2FPLSY3uB25/5qlbd5sxc3qjXv/0z27471U2KT71yKJXkoVvvZJnY8entrSkh4l7LFR+CZPodApHmKzJ6Ai84KHXs7tkop0aDxkQdT4FwUlfo1fIAnqeZYq+3xBVtQeVj8SJEOcA2pYxAafdL2HTslhf+sFXbJHYJnB6QPRQqCJx8UkKmanIGRChIy+T0pq8cpTZHihT0Y/SF3EGgsEVfvVtc6hIincaVe0Y9UED5X5+jMxD7NRLZyjk+uDpish2kw1pwsX6XxJ6Cl0q0+btj8iWCTvDQ22dOBigY6Hqm0b7QHJTbBEpwdQeYMXKqLOIrY5gCUH1tIjDBvyjcuL7GWX/5O6wTjTMubM5GbDiRMaDkTbliajCTN/LiKga+qnOrMifC0g1h/rznXfcM/vQbif8LAH+8r5tT5lDRA8zs6F/cvYgEeUA8MSqV7b/2+v37TMy2N9Ku7pNV/d48945h90xtXvSd0fd/z+dY/jO9X/xUocw2rPDXaNKFOIsW3wpKMWgEn0Xb7xQ5fIKx6qQxO2o1gCjKjJVY15BUCwavYOCMANQ50oGETm3oczTbyXubwsHzlcBmQiQU8WD6oig14ZIV5DHAAjq5onSENjVQ++j0XJkwEXebCUyGq2r0HIrlm8DjcN8xQohii7KHGi604SoqaeH9ovkffD2pPScpNlAA4FcK++jCmAKLaLG/DsiVDfCC8FpcbdaF0FmOeNIIpGOL6L9VoMDGnSusl9cPhMMDQFcEhZS3pBWqYq+2nc3FRGdIr4KxoVkZUXhBQVN4Rfn8JSu46IvLNn5JfMOxAzkJRICRtatLzadsUn6xdM/9NcT9jnw0aG8+XKWZnMv+PH3Bv7y5IOHv9mzqmjr6kzzMnd0sgxYvz5PjoEQjmGLNMswtG5dOX3y1OSDx7z3xWP2O/ire2y+1atwZ6O9BOC1Cd1ju2dMmfba3jvs9iyA+/pHRiZc8rtffPy3f79hx7XNoTJtNJKytDCGXcbdj4d89jBv5mXGSI7Y412rTjvyhCvO2P/gKwF0ENETzLwpgDOnTpj0TWauAdgFwDe3n7XlhT/50+/f88byhVTr7HQbbUS4QoZQ5sPl5E1nmffsd/A1B++w+zcB4L9uuvZ7j77wxOfOOeqkkS+cfO5vJ7V13E1Ef2bm9242deNTiOgMxw88E8C47/7ust9cedffdnpp0evI2hrg0gV7dI2uylHAASgPuYyH8ofILQNkmduylE7c95DXD991n/sAzHx24avD815+fGZP33qbpElSwpYdHd3pzttsc+uXT/vIPAA7AngVwD1ENM/384MAdoBj/RTAwjUjfRc8veD5mUiSkJaLMTiWc+FZyTSJYBHDkEFreAibTZ1pPnvaOQ9+7N3v+y2AHiK6gZmnAfjRpuOnnOx0B08A8PvV/Wu3/ervfvrZq+++cevBMufEEsmygNQSiuaI7eock+w0c6tfnHrwUbsDuOfFRW/Ub5k/b8byVWtszSQJmF1VqC/P/PCRJ+fH7Tn33UTU8+BL82+99YFbDz/6kBMeufS0z/8EQE9bVrtjOG99CMAYYOY39ttmFwaw2yUzfv7r7/758o7BoSE+Zu9Dim+c8umf7jx983kA+gHsgAkTNwFw5RbTNn3q0N322X35+p5V37/5qi/88Pc/zuvt3RmVVo18st4gHhouN5023Xzh1I/8tovSnzLzjj++/Q+H337njclFp3zi2c8e/sEfALgKwKYA9iSiPyksMP/7qr6eC391659P/e4ffoa+YtjWktQw28oabSSOUVIrM+MuY4wcSwGw21iGy9LdUbod25rrBrHT7B35A0eefMNnjj71VwBGiOgeZp6904zZHwLwBhGdzsxzAPzshkfuPPfvzz78uctuvBJUb3BiDLGB7jETZ41GMVCkzj3niz5SHecxlUfxmjzHwVGoGrnCsFXDIgpdBliO+0BAFIEMTl304qqegTf4qz1zepYgAUBRhbrG3utDjBIt0YEh80lQkVJnJRjg8SAUOyKDSp8jswHtQiCWIhskFvOQpYxeAACwNthzFPWVVd9GQWy4Hc1NjHXeKQyj0TfqO0nJrLk4bz+MorXQVawHqaQgrpQw63mRwg7ab2ejIPor2Fjx3L9NAAwRj0gfSUYSbhO7J4yJgl5nzwfeoIhUkKdT4FtdWhA7oRz4VeyOil3g/45tLeFJpaE8HE1zMJtCYLtKeD9n7GRAA88WKBNrqZFkR25zwMuHb7XvD4hoCYAlrt1/eNSEISLbO7j+/LHt3T2n//Jzn370scd5fG1ytnZdD8466AP0od3fc+VR/SumLHllydrddtuN/0/WIr5z/d+91CF0+1GIxQLEHBTW18nXHvg5vt8xXxyxCQDt29PoEgKQRQAobStYMoKfF62bGx1pcrzMgfGjjEsUO0MAWdEb/j0UxihvAYeaccRPe2cuqg1UkIoCc9G4gbCcxw/IOy86AgWQqPQUgPHrb7R8kQCC7FYWO3cYdZkItFF1ioX0kVOss6rRMNKsh5C0GjGFjl2HwQBkZyxP18raC39P2LURESh6kNRyowCKRoBOI1lUHTMB8GeJhSrLiJfYBiU9yiGOOq6ALp9IBrGyblIGG/G98MwG9+q4RikUoW00ddon1SiBtkTkMgbGgJIEJk3AZCwA1NP6b2554oGvN7IaKE0w1Bwqpk6dlH7zE599+v2HHf3JhcuXbztz6tSdf/aXa39y83OPve/NnpVFe6M9LYscsmkHS9ma5wV3hrJTsEmSYmj9+vJdc/ZKvnzGuTcdtsuexzebzS8CWN20xc9eXbp457sfvn/KlEmTkxkbbdS79zY7bzs8MvKegd7eQ7933vl3bDl95p8u/uPP9lg2sK6s1+qJVSUKEBtQYlEWBXe0tSUfe89pay4485z3Ts7aNm61Rj4CU+u965nHt/3Lo/ce+sbCBfzXB+7+49Le1f+98bhJc4qimPipk88cPmDnPf/8+Z9/5313PnZ/0dbelZZl4TcdCdn7Zl5g5Zo1nededm6GJ4Ely5eM+/IHP0XnHXLcCQAWNMvytMdee/GEmx+7N5k5c2a5bGj9GVPbul9ZsmTJ8o4JHT1f/MB5f9pysy1u+uxPLvnMwrWr6416I2XZfATwZc9x9sOCYKIIbTSnPnvpKnwIZVGip3dt1ixaHcMjzfrKtatRlBZUS8EmBRlGboCSzZRW2eocauVNsthyTH9/O4BBAFjR07O6s7u7uW6wzw4ND5VTx0/ctKRkapEXqNUxiqmxwe+6A57KsuNTA4OiaJYzpk7jb374Mzecut/hH/7hD39YXHDBBWe+sHLx+2+Yf+9hDz392KorH7rl99tM3fQlAE8MDA2dPKlr/OTLPnHh6QP9A7++/sHbdmDLbP0WPSgAykvkRY6V/b1j+oeHUBZF27KelfVmKwclSWS2MQyRycsSpXNeBnDiicnrS97sOv+95+ITR5++96WnfX5ab3//5x99/YWfPrd8wVNtbe2XbTF2owVr+9b9x/jusTO/duJHL3516YKLFvWsrH3n/V88YtspGx9cWnvxm6uXmZ586FW0iuHJU6f+aVbbuMkr167ZbtqESV/sGxoaWNmz4hv/fcvVZa19TEKFX6sq0SYiDA838fqiN7p/M+83DQBjyKQ49fDTbv/KUecc/jl7Fl4b6tlk7fKV31g90JPd9swDczfeZOa3th+/8czhkeELJndPGPeVk8+9vGZozg+uu2LX1evWWlNLHX1krWfidsUxaXUTcBYeSuDOLfS6yZSAMQk3B3v51MNPNN87+8t/nD5uUrMsy08mSfLUsr7e99303IMTnn71+XLaxEnbzl/86nFFUbwKAMfvdcjM4/c65BPDa/s//4eHbplhDLhMiFiyeoidCgrKSnS+YHOMXxG+8qh7I5UJ0ShqfgcPRu8XxiSQP6hbMLxayeN9iMpF0W8VvRwse6VsnHUUI1miueFWb6hrNynY80ZC0E5ru25Htoq0EXwDZ2MIFRQYobSolFaOGk88rrBTt9Cdg65l6Weo5NF5jWgVspt+3ihYS5rdrATtY/sgsrtkuBSeDRAUZl0IrZlKcZLiwEhse0lWLbIFpJ8VO8+PN+xiKuos2HfS9tsVP1oO45UEAvv50SpN6a/YaTEdSIIEpF+4YjCpBqpirYxR5rEy06Oj1qOt2Cg5ULFDhMqep6himEaXiJ2nrykYqUkx3LeqOGr/I+kTB5z+NSJa8ARzthtQ/KNyUV8iaubxPDMW3ev//Mydx9z+6oMz6406Dw4P2B1mbktnzjn2KgDzUTY65syZs5JHR2Heuf4lrsqmMiJ/ynYeOKtcEAAj/BUxeIR4WuoRpbO1bQF7aWSU3RKewAbvE8VYiV0qEEg3ou98JlABMXImImgJ4KUOMFXez5G3Ju6O0EgbJIr6KKVionD8ThGiMJU2HmSJfDzY90UymBptlUye/BbKMAJN/Ll5ADQTqdMSspIxEMjYSNAKDOvCgp6e7nM1SEThIBQYhYPaI8VUUe4hmhpn/Yy/1yKig75HwM2qUeAyZKzKhORvuTuONnK0OQ27jEccmRWaKr7Ky9nzG9vAAVEWiMQoQFDoUTFpZBtRhQ0ZDAhdtRfQuSIAoYRDWMrzFLnMNWUpsiTzXWK6a/6jlLW1g0tbzNh8i7ZPn/j+e95/2NE/sta+tcnkqWd9+gfffuX2l5786mtLF7UaHR21nAs3IuuVyagougRyEjLIm81yq01m0cUf+sRfjp6z3/EDe+6e8j33LLzp0Qd+/h9/+vX0VxcvHNtq5kiJkBiD2ZvMeO6L53z8sv223uWHlvmEc456zwnPvfHKJ35/780HDedFidQkstgfDCBNLVote/Z7z1j8nbM+tetrb701bfKMGYc9veCN8T/5y5Xve/yNF6flqUHebCElwvh6xxFnHHrcy+cdfuID1rZW7zx79h/OOuz4v/cO91/25AvPlY2OjoSthdt1l4DUIMlS1Gt1e/l5l+cAMP+Lrw63ZdnpAB695Jpff/bW++Z9uLfZP3VoZAgJCJt0Tzxtn+13eumC9597eUe96zgAB56w/8FXrFzX85cf3XDl6QuWLSrStJaqMh6V/RBDUDgK/haVbyKVJ4BgyHA9rdkiLTlN6xaUoEwMTEIgk6WDg8O487EHT330+acO7123vjh8jwOGvv6hTz3IzPsCeOBLP7/0d7c8ck9bR1s7t8qcCjK8emDdeMoy2LJU8Q08GHEtRdhgAMC4JZiOFznJaskpBx//zKn7Hf4igL4LLrhg7uevuPTQh1+ff8LidatRsMUfH70TE9q7MXPclMd+9tGvD3S2tz8JYNKFH/704ueWvbrTc6++XKb1BpxjFQrXs6xepolBQjVryNgQmPDETAlsuWxrb0/eXL70agDM11xjFvesMs0y3/eNdSvnXH7nX276yfW/wUBreKN6rb7VOJOefNK7j/3b+cd9IFs32HfnuM4x37//pSe3GBwZrG87ZeN597z27LE/uuoXW81f+Epn0l7fObcWm0/a6IydZ275sf8456uXL1657L1dbW2P7b/VLv929/yHL1nV21tmSZoU5HgKloGWgUkM6rVaedbcs0ZOaJ1cHrbrPq2z9jvikq+d/MktLrvz2s9+7N+/cM6SgdXJcHMYtigxvXvi2btvvs1T//HRi7bJ8/ziWq32fWY+d2X/us/+8NpfbIakTmSZkJDbKVhKQkdZcZF9HNbJEsGYDM2eXnvUgUcm//HJCz85uTFmYasovjrcas3/9p9/eci8Zx/ca8XQejRtjiRNMLbWge02nrX4Kyd+5O4dN95yUX+r//bffOl7I4PfHv7WdY/ePiHLOpMK10TR4Ko1IA6Ax1wPfLEejWWC5I8NxhXbFJGuM2GJByp6FqGSQeDbZ7NEBbDeow+rvlPdouWVMbZH/Y2rkygY3UISdZQJPpBqwjwBkMCQajLR9+LIxnQVB0qkU3DSv4y14VhHSrukYw7H71CwLUYfhRG3G5SV/4fDzFP0leBXbA/GNlcYpfZJhyh000yUJzR0YUnlffoGGV9k18W63ul4P2FhGsHCbdpenCCQPkZBPHnKjx+IdtaOySa9kc4IlleuONMZ0VEoIwzNUDlRi0RtKN8/T6a4okgCyhS9rfKbyJy+EeGI8dCZwNNQoiExBkWzaadstEntvP1Of2lq+4QbLrzwwnSOLwP9R5d3FAsAWN7f8/g1L9/+656hFUW9c6zhGqUfPeT9vbtuvNUH7YbPvHP9i12jDqZHxDgR6yhw/JMrtoF0jYEYuZHQCFgr8FffGV+Kd3FfxCGLDpQRR0HLHj1AV9oRzFFwlRsRS4cfiwcYkH8PhYyaAomUT8TAJqIdFFF1DaRsziLllxHJAAXn+AgF1r55QFFHKQCMC3qKqSeLucOcBcXnDy33PdX/CDjJ+CClUl55+MUgQcHKpARgItmGP6IPQRQwAqCPYqSYbQAAlsBSlaCKltRYkHcboiii5vviFbitaCFUaClbRwelJnxo/Hs9fe2o6K7/N2blDYwj356WSbnegPQgZ4R7YmUnBGDo0lKNLnu7R3lFnHQ4UH3k5ecxzIWdsskmbV8/91NPffTwY+YesueczWZvvPljL738wu7zl7z+sVcWvt7sHDeh3ixbowwRUZCRkDFAJQNg25HVzIeOft/8d223y3M9/et6amn2w2/94Yqtf/XXq7dfuHARkiwrDYNRFDBAsmT5ih0Koh9872Ofu2H32dt/1pcWrlvas+rA6x+6jetjxoJLVx6XpSkG1/fh8N32Tz/3ntM/A2DvLWfMeP33t9/00uW3X/eVB19/3qSNhgXcriBsGYuaq8a8ePmP9nxz2dKun37sC3uuWbdmz9OOOHbVsv6eV19Z/OZWrcRYYmM0C1CUyGoZ6o0aAOCaa65Jdtxsy2sBLLjgFz98+IbH7tp64eIlMJZLcMnUslhYLDAPPP3oNsvWrv7Rdz/y+asmjZ1w1oIFC67/6DEnddzz9CO7vbH8rdmoJ5aL0kRCq/RTGY4MTXV0wOE4TGYAFmytluuTYcCWbhMnY8ClBSUGT735IlIy45oDw5g8fvJAqzWySyPt/CaAr73w1mt4buHLk9sbHWiiRJk6yUuzusOuYDmECQ5cDl13JDLqNyYZGR4stt18m2xC96RLylarRqm55Dd3/fWz1z1519ELly0uavUGrDGwBCxd20PPLl64R/+P/m1w+9k7fG3z7kk/uP25++e8vmYJpx1tiXZCwMq6HXE3uIiAlACTgLIEKEvb3t2Z/OauP1//uRPObC1es2av8R1djzZ5ePFnf/PjZ//44O1jCzCSVmnRKu2rQ31YNdhz9LiucVd/6ODjv9/b23vg2LFjXwOw130vPfnQV3/7gz0ffORBpLV2WLaFMQkWv/Z6umjx4sv+Pv+RXTaePPUjPf3rcN7hJ51654uPmuvuuZXburpRcgEm6+YuT2HSBG31Bvr7h+emFj+d1TXx5p6hwakf+8VFVzy28LnZq5av5CRJC5cNZlq8dGny0DOP7l5rtON7Z32hp3dg/fyC7Y4XnPDBz977whOXPv7CU+jo6EKeMjgjIEmAUnYfQqL0sXBml+ch58MbtMrhfLNtts4+cNgpv57SNvY/Han5zY9dfsntv7/vho3zwtqsXrOcODxdma/CSwte3qRneOi0i049/4Q9p29et8AP/u20T7z4xKJXpizqXcn1pAbnCEf8HWEqKoatqoPKd1WTjyMHI9gGYsRW9LXIL+LlDt7hi3QjAZqhp6gvmqEjwG3KptrSaUkJguk6t6Cnq+MIjgUhwl3jR8Cjs25vY8jYCLuD0hHPIFKMVd0SE3MDjSn4QYDmxiIdFbzaUNouOO/uFbAPdoq8MrJyICnAYKeJvqoYZf61tmKruTmKDJxoXMpKGly3YhUFuwzOxtNyUpI5DpSmmKiCbxHmar5tA1ulWuavZk3c14iXww6lYSBihxGF4ydMFMS2nl6kxJDmOGoz3pEhMlak2m10BwmaKYXalTFxwxyr7RmPTcalRJFm3X1lDZyPDNv37/vBnmO2mXs2ufME6eKLL8bbXbJDKDNPXDuw9uDxneMf/dbff3Ht9ff+1Xa2jaeBgfXlCXOO7Pvofid94rTBo+eMaW9/xpGO3gb837n+Fa4oEGIrto38uMtHJWLJeTuwl+fUwKANGBZMYT0dIjnW6PmGr6gY4bqWSwBN3DAO72YRXqo+S74MI3KW4miLH6oCluw+6T53UVvrwTzU7zOInPHOOq7I0PfvUOXijUUWWlBUvkGkNfx6zIcfi55TygGcwtoLG5wjUSyqb7xrJl6HV7bBHzbQHUyFjl6RBsUcopVhjVlcRiyQJlAEOE3oxsF+c4bAMh6MmfUwYJ/EAxuGLGBxSsBEbRNk3YYYEhpptG43OhdBM3q/xkv9AYTK295xA8Fty09+7iK+UP6g8G884rhUR1nXWdXQbGvwhCNzXJ/S0k3leQrzNvp6G3MDpTF244lTzAVnnP3whw454uD5r702e7NJG5/cHBo6aqfttrvszHcf+8bkyVPrI2VeGH8si3tfmB+3FonBRQnOS1BpMdy33u6+9Q50ykFHfHN4eGB9mmarr39wHl91zy1nLFy8uOzq6oLJkgSZSamRpdxWo/buTr7nrjvyX91y/fEA7lnau2pXALvOmbXlQ7Wskdq8ZFMwqASKZlFuNGGyOXD73f80bdzENQBuaRXFh/50/20/fOitV6izayynMCZlpMZympY2ba/VUILKa+++ZdtbHn/ohfFjx59aWHvDKQcftWKzmbNGcoCStgaokYLaMiBLYUyK1GQxyRZfes1vH7/81j9tvXD58lZ7o44sS5M0zdK0rZY2xnSa2pgx5e+vv8b+5NqrzkiS5LbxG2/c3d/ff8zxBx9x3Q5bbUPNZrNIk0T5T7kgNiooGEae2cOPtU4mSkYZT6qFc5bKEijcD+cl6mkdWVqHadSQtdUKLs0IgBzAYOeYbk7Hj0E6tpNr3R1odHag1tEGJG63SRVhz0FyLqL2V4HAMTCX7ES31UJXvQ3bbjYzS2q1PyVJ9vVHXniq463lK8qO9m4k1qRJiTSxSOsmSbIksfe+/HTHXc8+8OBXbvzJXrc+c0/aNETcSMGZAafGbciTuHJ2mxfQnhG7KvfEr5GrpUAtBTVq4CzBlIkbdQHAJhMnPtLRaPv8FXfe/MJV9940ltKkrGcZqC0z6K6nHdOmpm8ueKN4c/XyU5h5ChucB+DSvtZw509u++OeDz5wd2vM2EkwjRpMZyNNa2na1TnGvtmzgq++9+ZDCbh8QtdYAHhtfX/f37onjaM8Q4l6AqqlQD0DGhmZJEE9radI7G2NemM7puT4z/zskp/c9sids3uWr2m1N9rJ1NLUJElq0jRpqzfQ6BxTXnrlL+y3r/7517o7Ojdi5henjp1038Fz9v3rxE2mUrPOBdcTv923I0uzaNkkSQZV1osSyAsno4UFtSyyMmFucrrv1rutO3HO3Ct7+9dfwszjLv7Dzy+68dn7Ni5rWas+ptNwZlIiSlOmNEuStLN7LN/9+D3Z3U/fd1OtVvtLXrbqO82YfcbUMZNvrXe0UVlDiZTcfEgQyusSqcyQf2P7QPWGFwDR74j1RoRnYe1VaFOOY4pBz90mRoboH7EzRF+G7KLeyiE452ssFHsdDMonHuchpYUG1bV7HOkpVt0tdoG8N+xgGZacKARQsAvY8z0pIUQ3BetL3qf4EV+aCeKgyzgEEdk7RNIBBvm1z6xqk73dEus2scqELlrFqlPhQ99yP0W6W+aZwr3Q91EYOcv4oN85csTr8VkdLNdeZD8FtohmR+y7iuUV9DLHlPX3VOzdKv86+oXQhWwSJMSjqO14CYjqbz9H+pk/hifYbN5uU4NN5nR08kUsGbHjZPMe0udUxhDGrse5IdiKoyZZB5+UBjXKkPetL4/a/4j0s4d++CoieuiyJ55I/4dNXwwz13vQ0xrfOX6v+xc8efF1z96xtWkl1vY1sfOsXbIvHvaRuxIyfxixzSYRFRdddNHbmTHvXP8ilzqE9h9NOwEhtDX638jRGP1YhISxIIrQIgYbBVlx6oLyiC8BTEaEUuIniIGui3uiLJsa79JKVZEJgpHvjKEY7Dl6LxTMdQxqFMZwpbDqQMV6gZbIpLYW4jmW3ZlZRhSvByBCUEDBjbAhwuXRQGGD/IcUaB7PxwYbYJA8H9NIemi1AXFiJbrIRJH/JA5YhQM8fWIlLHNP3kGSLcBlICz/D8PlQP3YnFDuUHhhD7S+nUgBxXwTNhoIAC18p0YLifIWg0IcWjFaArbGa0+Ul0WZIygL16eQGRTe32CRvSroAPYs//E/JorjFHkz+fARJzz9hRNOfTcRrdt61qzJJq0d0tXV1UNEz37oyOOOPfvdxyzKLKco2brzCl1miv35hWStNzBLoNUC5xYYHMSBO80pZoydsKS9veuHNUq2/tO82898+dVXW432TttsjhQJwyYgS0wllVTQSKvsmDDR3vrIA/lNTz504aTOcZ8H8P2Jkyf+9/QJU5APjdikZBgCms0B3mnWVnzmEce8uX79+hcHhgdO+eH1VzVfWLVsUlYkI9w3bGmoWfBwXvBIUXCzKDA4XHQmGVauXZP/9q6buw3MQ6kxmD5h8o27br7NYJIYQpayzqN3sKx1a9dPOumk8s3VK/a86ZG7NxocGcjb2ttqOVlw6gUvMe6EAUaSjBtnr394Hv/tkXu+1ZGld2b12s/fs/fcsr2kpTVjUgPyMGVC1pagpXwaGY7n18IfYwA9W5IRjqfhsnQZ1KYFWtY5Z8yw1sKyhbUl2JZAAgKQATCpcVUMlsj9QHhZfiSw4jFFDPAYDi274oHSAkUJGimAFplVq1chpWSHoZHhF5pF/thnTjx7h4O23i0ZXLwiHV7ZY5u9/SUP5iWapc0sm1qS8IsLXi5G8sLWusa6TVAMgVIDkxlQlrjgizFIIx52pywQSBwQOVohMe4IDh9RJiIs7119yc1P3dNVtFollZwUI01wqwRaFnmrBerqSh5/+Vn7ClAapq8B+PuTbzy37Z1P3m/r0zbJmqYEUnLtpgZFCkrrKT3yynwDYMeRZvNRAPM3nTqtp9bIUKCUPVHgq5w4MwkSmJy5PMXC/mnes488eM+rT0wtSirqplYrytIbyI7eOVsgSxJ0NsrbX3x81iuLFlxeS9LtiOiJd+202w+7OrpHioQNJ+TgqWDCwFA5adz4rrIsT/ZkSmyrAFoF0CqBVgkqGDYvMabRQe/aZreFAHYd29n91Z7h/o/c+sz9h6/rWV90op6gWRQouUCLC4zYEiNlgWbBaZLk9776NBasXf7ztet6diOiBUfuedCazvZ2NKlk55x6XeJxK2iu6sURWEmgTJIZscEafvV6U41y9tURHBr3a6/EPqCIaUOWz92jQVDtoX8Xhewh+yBYnM3TTWV8UG60FhPnIThDXl79+DRTKDrf08D6Uo9qIDQY/E7vRO2yks9pOuagZyiyUxA5JICWclaWfIjjom+NgpmKEdEMeto5B9nZGlLlIjo+zKHYEdLvqsMXikB9P/2aaaHdBnyjTq9zpFlpQWH+1Jjx9pQfU3WyAt+Etfwc0SXYeaKjNdgLn00LmjoocyN2pP/O2jAvnszBpuK4N/51FOgavnGOL4c+iW0lVk6YG68n/D2VUlShg/wWBWziNkRiI7dVfyMiGALKVrPcaMom6em7HjVvo7aJX36Cn8jOmzPnfyoVLYmoOQETRgBc8P27fnPyM6/Ot2ZsG3F3Zt632+HP7bHxtufsf+EB6UZd458DgIsvvvidXUX/ha+glUdLKiDLyaIS9Ei4KDxXZVCoEzO6bFNZVNPepP9ULh/tI18bo9k8RAARt8tq+0TAJ4Av7w6aSbOCXpiZIgXG8KAvjoXiZXinRHIEGTk4hgRZfBw5iFTta0yRypIKBYQIZDiMWzHQ/67w6iQ7cn/gHQdEpa7RazHaEYmiSQrmcArLl52F4JIANUZd3lggcYbcwBx9wxArsxf1jSUq5ydBeI/Z7e5nZKAUJsRhtgXYaqRSy0lIehStNNVMnMKh9pViJgNAkQMeBxNYjp6QTLdQzxv4xNJWpFwQKThE8hHRQB3B0cJUJXE4Ew3AZZddlh2w7c7fOW3/g/aY/9Yrk5l5lyM+fe57vvLrn+45lA/ttn79+n2ardYTXz/t3M/sNWPLN8tmE5SXllulO8esKF02KsoYwjJaI8PF2ClT06njJ90J4MmBoaEvvrZy+Y9W9KyaXSuLWs0gq6Vp2hoeNs2hYZMYJFlGqUlMWq/V6k1uZg889XjNHRextjx4z/3SLTaZCZQl0iSVQHU6Y+JGI1O7x/507NixvZ1tnTfVTHLhW6+8arqyWltSFklWcJoWnGbWphkjTcmkCdmkrZZkw62BsSv61793cHDwGAC/2XaL2U/UG3XktrAguF1HywJlUSp8MfPe9z375DGLVq0iohS2yGHIbdaDLAWyDFTPAENoa2ukryx+g5557eXTa1ntjUatbhomtVPGTVpNTIZLG7CD4JA0XvqlkfJR8scASnY/FjFnu6v0jrrwnHEOEtUzIMtQq9XC5iMAsqQGSgyQECiBYptR4833w0BL0StA5PmVbQkUDOQWGMnRMHXz1qJFeHPpwjPbG21ra0m6+7Ybz/zPT7/nQ4d99/yvF8fuc6DZZeaWydhGe2KbI2ZozZpiZGS4bG+0mzqMsa2W5ynPxn4cXE+QJAkSI2ENC0MpkloGaqRAPXEOOggRCBAzJ8yMVWt7Dly2YhmTNSgHR4CRAhjOgZEc1HRn6S1bs8L89I//WavVai0Al67qXcMwZKhuwG0J0EhBtQRcT4FaQrnN0dXVNRPAXv3DA08QUTGhY8y4slW4XXhlvnIGWgW4ZNiy5O6O7hsMzEfvnP8orV21qkwbGeWJBSfkxpuQc3AbKYrMgLra8fzy1+13r7nCMDNdeOGF5vBt931oy4nTWrDWGCZQwaCCgaGm7W7vbrSAd/mpNhLAcdljCyoZw0MDxRabzsIw+BtlnrestauffvOlM1c013V2ttdTwzapJ2lapyStGUqzhJIaUZoPDZmivx9PPftE+eyrL82dOmHqqwBw5O771yc0xgDDTR13iBNShN9RoExxNQIujuYPiHQCq04ToFYd6Q1orYZRx4OEDaLgXBAnxWTtYyxv0n+xOYTnJVMT5QwpOIpqMrv9ffxdBOM7V9n9WoN+oRSRooDpaFtIHnPd4eh30rOIIea7lkiKXeDHpI4F1P9jMNTJ3OB9VV1G0X8DjSANRe+L7BGOnIt/sARM62AozHG8F0WwX8Q9EW6CGnKyuZznFqWPlo2qMVntg3yk//pfInVcuVucT2lJ5krbkud9l0F+t9WI/u47CjdE9A5TENk5gM5RbEqTBACieR1l3mlmsaJVCBqQZAr0UjpLq8FECWaQDyDYeoK86LPnHHjS8Km7HP0NImruht3+oePG7uxADLYG9yyYPw3gvK/c/ON77nj6/lp3bRxG1vby4TscgPMPev+PiKj3ogMvAl/IGyzLfOf617t0DaEDZRFI/RBBwqJLwdBCw6eIolDxAx6tFG8UKfQFo3RJUC48Gtz/QfPukgPcUQHfEFnzzkEMlGwrAEj6Ti9Wo/RckG92QmgjsIgzb9FDsp5XHCNVTHKT6E1RohGdKuUPo9qXCJXU37uP4/xZValS9FpSBReBfOzhxQgUNWBi+kUOa0h3Rc9KU+JgIXzO8eckPQ/ZCzAHhUvxmDiyY221nYqj6Zxl/SysZA/0J1Ilp9m4yPGrcA39g7NTI1aOt5IOPO4/0+mO5tcILSvCFiZNn3ffaZTRMoyJ2iEa8X3f6yfX/OHc55a8eeBtzz+B/oH+7//qsxfOK619PDGm9sNPfOGSz/78+7+++7EHba2tA1zYML0UKEzGgIsSne1dmD5hUpOIir6+visGBgfnnjD30J123HRWkaRZWhYlTZ04cQdDSNas732pKMoRJAalIdvZ2WG2nzrz8VZRJG1tbcnY+vj2KeMnOmMt9bTMLWZNmgoAw17BdG+58fT7vvuxz2y5tGftM0lZtpWwTJZl5yFHx8SAy7zcfPpmSas5/HjnpKk3AzAf+Mklfx4/Zvxhy9astEliEjDrtvxUqmCd+NaypUN9/YPg3IKpdCWMhoCEwH53VTKeFwl45MXnkqHh4T90trUdAQBbbbJpeuvj98ImNbe6S7JuKnOxFvczWMEcdiWZ1oLTwFWxfUMEt6ssQTd7QZoAhYGpxbk1ZaaoH7G5EGe+Iz5V6wcqb1ohUDJKIrcRcqssf3bt7yZuN3XGTfvtsMf89QMDrxyz577lMXvue2L/cacla9atPevWx+YNvvTG61uho77zY88/hReWvI6h1nCZdXQYtpbcGmLfvwSg1CDNUmRJgoQIBYA0yZAmqeONROjlnB9bWjSbIyURlcxsHnnx6b6yWRLnfu4kEwPAsAEKRqvZxMbpmPb29vbXmXlZPa2Ns2XpSlH9mOW4FUc/i7Ioi9Ja6mxr34ZA6Olb24sSwHAJkA2BmFZBZZGjIEr7RooLAXx02kbTp+QDA7Y2aZLhkr0z6PnKkHNwCailSdq7fg1tsskmHwHws4svvnjpRRddNGbrTWbRHfPvg0Ed3PJ4zkCetwCLgcA63lD22Vw2Bmg2MaatC3O32719MMv+2ChbTbLlpHMOft8ha9asLJiQEhEMA+ASDFBZFjyhe+xmMzaeMYNLxmYbTd8NAIZarX2Xr1315vJFS1YZSidxbgFZ3xUg6Z9cMe9zeECwjyR7xBW+Dzoz0in+OcHgiNmVs+OT75zuhtoborxl0UfYcVscwOBkucOIRVaMm2+RW9W7PsMe91WDsNA+VTNz8d++rUgfas9jmnIYYeUuRqUkcrRDxr6PG06Sl2tvF8UbmWi2SZw10b9GDbDIuSIdX7AunJ6WNgIMUqVN0XPigFdwScyLKhJW7YJgZIXn1XELNJZpCRlboUfgO/ex0Da0NZp3WOnEMFHdrNAwMlO1H3GWWCqP4vnw/lcoYotnyq/dDuZTxFujdHRsFwvto7+iqQ82Bccv9DxkLNyuout78+MOOj77wN4nfIHcETUp/Q9HQjBz1tfX19ueYes7Xnm459rHbz2Ahy1bNO2u281J37vjYd/pQO2R3oHencd1jnuGmQ0u/mctvnP9K1yVXUYhaWzhNkXZ6BagssEK4luj+5SdBTQ1vBE/O8pBk0cgwBGBPDyMRAZ8tQusRr7j+/DfWGDEeats1iICymFsJH2LAS+iQVgfMCoDFQO8GnhcIWNVgQX9FeBS3mn9mkX3qZHDvaOIbHU/rFHjjL+JFIhGTGMAj8lBUOUnhwuTV66ug1LmFlSDDCou9RDNE+bf01rKOBDRWpVjBN6ChtpIFE31tIiHzvqMB2cp+/RtVxSZOIOxEo0NgGrqNnATh08iNRTxLIfgeKRYKHJKg/IJKj+MJKJpBcG9MjcGic8QjRs3zj7//POd22233f5fvPy/9v3j7TceuHx9b5HVGnTjww+8a987bxnzoXcftctLb700becttz7qjIOOvuaJZ+cf3z8ybOtJllpmcGJcNlTK9gwBsGjraMPYzk4AQHd392oA1/ifiI+4ASAlogG8zXVWkmJwaGinDHgxb+X9puR2ahbMxK400cIAGPbrFFYw87nH7D33iwBuIKKb3q7N+Po084SiKL6Qpun3NpkwmbMkrUa6KSz099dAQkm3YXaZ0VKCoD69J3srkjwPrBvu55FWa0xnWxsBgLU+nM5OLitBsGinqBjqQrRXMt/sN1ZxtJZ6hPCb6zsZOAcJ7DOAicOAsM1IJYgBeY8YRWpojQKD0ZcGYgBO4A+JYCSdHcmzb77e9smfXvKx9x14+J8+cPiJ241BZwFgm+6scQozz/vYkadNhDtzj25/7P7khTdf+febnrxvlwdfnQ9KEwcgBt5Bco6SSQxMmqoDaxLISSeuO3JIe17SSP8gtpw9Y9qDzB8moisefOHJzFrvoCVR38HurE5DSLMMHZ2ZEKbN1XnJ/Hj6M4ASACyQF0iY0rzIOU2zgyzbj/zgr785cOBv13Fi6kmJMhilhXVmsuGyu5H+OzMvGRwe+iG11Ts4Mc5LSXyKyxDkTD82DlStLTCSt8YDqPn+2Yxqri+FK91mMpHO2mCyhFkgQQ9bWrRntY4xRD0Afulv/Pd/NuXMfKC/pwTwTInyi21ZNm18V9eYMY22rnXrBihtNGB9pQtp9psiFRe0bIxfsUpWeRKnIM4UAaGUrhKFjmwFIlSPZJAMY9AL+ntkACtmVvDUP6/vCDaD6xsgG5kwYpslsm5CmiZS5NHfsUIPKkjHF45P8v327fNoDyOiqh55ICSoeBWi60WThK6EbCV0jBqEjDJhztmNXq1TEOsoCg6j9BdQuyhafr+B2ag2V/RetVGY4hmpkKAaYuWg4+Ul8ovwmerUYFhp39XZk/sCzgZ7gSI48ZVDYtMo047W1uI0V62MSupRRuwDb0Ifx28h6Ospi0jAqvYMom4gWooS/0uofsrxE4FFGQxjDcqysBO6Jphz57z3vs3HTr/qsssuy+B3DP1Hl9fXFsCrzHzzbx6/7srXV7+Wt00cbwYH+3H8Dge/ePpuR/6ciBaNeuad61/8CgfTWzFGqrqINPMhoOs/V4vHl/oJoEnUB8GoDThJiCTZN+T/5arQ6deM8G5IG9UG4qxgBDf6mzQUFiyPKtWUJ0jWNCjyeoMyjmhGdCBRWKJbIqElZ+wF0PGEFQAQmddMmJQYCPhJhK26S1pVMUUg4GlfKRH1nxsBU4qUQ/SMU1wM6BmHiIA+Uqr+M5Vs9mqLIwdUcTBAvJzDGLFMZJtx5Fh6+hCDYNwGM3EWjShkKZmj82jdeY1x9lnIw/Ice4eWhaf9G4l1RzLdKAhx3lWnx82NlKbG/CMKSacz4ldIZtr3SZSKV1w8WntuIIN+rsi4A6tT3X0QL7zwQnLiiSc2P/PT73/4+gfvee/i1Svz9lo9s60ca3qXFD/+79/s/Ic7bzlj86mbnw7g8LOOfs8PX1y88OmfXfeHPfJWqzD1NLUJQMYvpDcAkgRkGFlWQ71WI2ama6+91myz46579WPoxNeXLyqNRWJhcdnfrhtilPzr265vYyTGJIQExq0dI+YSlq+8628vJo3aAc+/+UafSbOuopkzJwwUFs2RkX4Ahyxbu/Y5ajbX3P/0k59YtH5VX72eHH3VvJsPhnVOkkEKGHcwdwq3HAsmxU2PP5SUXNSuf2Te959a/Pou6/rXg4CECc6xNQQkieuPu0pjXF5BlbiNSqKtibboVgOCAVjh09I6M1MPahb+UI4fhVOxQQAvZ+LQMFdF2B8OL5swVU0kUv6K/EG3o6614YcdBoQNc0NplOIfi3ESXxTkSYxNw2iM6cQzSxfYRbdcffKfH57XnLvz7r1prX7ty8ve/PFIa2S4UWvkAGaixCuH7bH/Y4ftsf/Xjt3/0B0///PvfOimJ+/bLKnXYDM2suGHW5dWDWOJbyOHraOwfkdNC7Y5j+nqbAfwnYLZ3vfso+uSJNXsG3xgiAhONpDAJASgCWbJKfuXW/ZrZlnbhwWQW5S2AAM0ODTAY7vG/ry7oxP50DAaHXW3xpI88YlgDIHYWHaHMV/xrq+cNbex0eTTm0VeJGTSMOWRLMsgrUUrb4lBBQAmL1tud1mv64wHiizNYAw6dYaIfNDGRCWLbmjDZbH+eebaBCBbt+SN0xetX7Ptmv4em5nU1ROwO/Iot4yiaOE391xfNFv5fcYk3Nlo7wBh05GRoWbf8NAwJUkbrGxUhkhXoYrjokY82IqOUghUZgu2gKpPcvMRc7io1HgnEzUrEAd79W7tSOgHItENNgULxmvQJhjJYiDLWlvV9hzu0bdJH9ixntoLwTJQPaLBGq8sIh/O66+gQMhvjaq7V0byqp9F74gzWe7oKCFYdW4C2SkmjJ9DehvVw36+SYmjh8JHCi+eNxBFeMdVPtFOESqdqlRDRe1IH0QXx3Op9o9bM6n98++Vd2rfrIzFPS/8KZMQWvQheDIQT61qywV818/Y3y/2yCj+lLB2mPCIxESu6CBqUXlrFK2jdEOY90hnCPGUbBxTPXwZ2COqDMsMWoO9/JlTvpocufWB5xHRmmv4moT+8XmDhojs8PDwZsNla99xHd1vnfKrzx9996JHx3U1xpf9A732rMNOzz528BkXENGiy564LDtvznn/dB3iO9e/1hUOpgcQiab/3UbOg4BkDEhVkyI2kFUZVgxluY08SMd8FyG3CgUCM0cZpfCPF2eJ1I/K4ilABD0BKTEgfd4rnaiDUqbg7glHEegzFiFaplG4GLwZYbMIrvo0YqBJvyMFqsUs/gPiauw1ZMCgxyJUM6GAlmiwkFK1NmQnWd3wxwNICJ4Fx1+OiwiqhCMak/IFM/vzV0kjYLHSd7eJcwvoDqtkK46ihh2kLQqr7mJ4jLkFDC2pU/0vgQE1JJSgEUD7khsBfjXM3UNaUqsZw0jhVRTbKCWHmJbykTwf/lT1KEGKDZSyPCdEi7/wu6k6Y7d45IWnPn/v/Mffu+jNN5u1rs563mqBSkZHrT2Z/9z88oobr73ywF33/I/xXd1LhoeH00s/ev616/rWzbjq7zdPQb3GCTG5NU9wGRxDIGToa41gwcrl+c6zZjMz22v/fuuB1z1y96efXvgS2jraYUuXkXFLD62nt4WxDCq9U2MIVLpjQJauWeW2yGcmYmIUJQZGhtsB3JWV5bvHTJq03Xf/+OtP3PL0Q2h0NlBw6eeXZEJAbF0CxpcgIkmRlyWYGWsH12P98ACyWmqY2ZU9pYkrRaREiPe9shj5XpokLmMVT0rJAMI2525BnsXEMWNraZo2Zf4Xr1peIk1BJnHA4cvNAjBW+VT4I5bJaFFjRb5LZr+pA/vspecUgtsIqHDrZePLsv+85Z1M8m0gDnBEgSJlKwrMyNGriIK9bAzKhNE+rtv0lcPl00tfrT/91gsbTeye8Ml7nngArcHmij133GX9RmMmPHvG4e+dtcWU6e8baTaHtpi26eduuORnfzrzh19+48rbr7P1ieNd9pPCe2JKOf6xbg2j9TusOufNNAf77b7b73oEgB8nwC1pmp1Zgt3GM/XU95PCv5wCaYIHnn6y71NHfGB7AEe38lZPSmZsq1WASqsON+X+TIBonZxxkeyHR5oje7vFpaQlxa5sN0WSpqhHXrkhJEmSgKRAMVqPC9msx8IFdIZHMGXseAOgzswJgOHlq1c7lCQGMrg1iB11s36ov5kC98tUU5r4cSdA4jLMVDaSlWt7wEXrPVsW+eVpmv3xluee2uy399/w7lXrelBLE9jUgEwCNu5MVralX6sKR/OyhAWhyAsUNsfydWuR1uuQI3NAgKwA4oiPgnNVhUNlMzUdeENDNiiEgP1x4FBEJJKdSmZM3hLd7PoguinMqfTReFlwfROg5tAhBeZIH2oQJehteZmcB2zlLBmiCM/FQYnsGsR9pxAM1Y6SVuQArGsXAa2ajzonhI4IrvTUD9R20wwj+z5toKNQsenkqKp4rjSTKhqbALW4Khm4aEjCN7qnQ4Q72s/QDw3KCw19oiD4j95SjegZHMaY30LzwbaT047dcw4lY6a0oVSUhC4BHMUOMp7txN7RoUtAnhCy2qzTou3Kd/E+BaEPo/40wdEM446Gx9XnyPMa601hTly/GEnpgqsj/euLA3bdLz1tryPOB/DGPOZ07j8pFSV3DIV59LXX1uw8a9bArS/cd9Srg299pHftQKuOJNl62pbZMbMP+P74tGPeO87g/84rlIwaM+orlYp/8KiKVvgk0gJqPsdRLqf2RjUrgswbCER4izRLFWCJIyAhSxW1x/Hf2qNRAsP6fQVbPfiTLGRXwOcNKEJkohpv9153/vho54xUSI03H1iNNmkL2m/nFEkUEOqUWI5KCJSu8EowlHZoTCxCI83o+fe6bZYRaOIpoEkCP7Hq2IpC8Z+rrkN1fYIYpHLwvU6ulMyI8pem1DmKLYqIISqlJRyiq6JvR/OUNhXRMOqDwjw7J9hExobSKxqT0oXDv4TIPhHl6LMAYffSaEyIbRqXBQ2ZzLfJ2Pi5cu+3YC5h8wJ53oSP4vFNj97bNtLKLTEMtXLPeEDLltTo6jJ33XNX/uNrfv+J75x3/tTekZG90NX1x++c99nzX1jw6iWPLnp9cqOtzRRcEpswH2maUe+6tbx06dLJzDyBiHpeXvj6wz+8+eqh1xYvoVpHe1qCfRkcvLFAYPab1OQFkJeMocHCNLoSw2wIlCbGEFsLMinAlpeuXJoB2HLSpEl/Zeb1jfa2V15bsnhWvaMDI2gRJeQUohpqQguGSVLYoYECJgHq7SnZ0mS1WgKw39zFAEkKyowaJUQ0/Ku/XteV1TKLNAWTcbJgGUwlgrEBECxnWZ1mz5i1dGxHx2bNVovrtVqysnd1JwyxqSWAd1oVRgT/YlZUBufow398OYfRuuxVCVcqCnYORStHURSID3EqSwvbKn1fyjAnwlERxmlnPZbop7KJB0h3/AQAqiXIOS/zwbU26+hO29obgK2jd2h98VjPSkaabTT/tjc26qjVZt/82N04Ze4xz3zufWd/eOHSpfWZG2886dDd9r727y88cmLP8GBJJkm8zeV2TY12MC4tuwBDXjo58k5+WRZl5/jx2ff+ePnPTtrz4JuJaO2DLz7FqBmgPQXS1AGmlGgYAgonX/0bdQKuLLPdWmttaV37hciUzw7DrUP0aI80rSUArupo69wPYEZqCCZ1DmGWAmUGk6RI00wMpEknXfrZnJYbaygBlaWrBGa4oF3BILbgEigot1nWThPauhYBeJOIyrXNge0XrFicwjJbApAacGoYYzqSVb1r1iYm+aNMdVJL/HEcCZAzqADqpsMsWrEYq9f2nLL1xBnLWq2RU7aeNfuZ53/zatG7vp9TIhQ1AurRukZh1pJB1oCH+i1GmhZdExKQNWk9Sw05hGIpFUUFxnxBD3kM9TCsVjv7oKkEPeOApW/LM3sohSTFUG3PRPdEeKkczRFGS0BWMj82+pyhDo57t+uI6hNneSMEaMTlMZAjLYIfI7gMkAk2gigBragRMnsjXBoIekOqALzcVXSk/0y/DU7HBpVa0T1WdD5BA8NV8yIsg4m3sgpr2qJ+WtEHoQJLS1zJaJ+gNCSln/rZEcbo3HPUcbENo3mMYTTOOYQsqDCHn0vWniMQhZT2FaaLS/xVr1NMRP1XnGby/9MKB20y4jcJuiFcEtgGAaw5BQl6+ECDON1ic6gJ7u8JYB3kRSE84hXlI0CqjsIyBelzsHkMG3Ce24033SQ9/5CzXphVn/7M6tWrZ82dPPnVCy+80PyznUB96Wffm8uXP33xvF//x9NLXizrEzoSmxfJJw55f8/x2xz8NSJqMTOdh/P+UTPvXP+iV8SCgN8PPXzrgaWy5TGo4oyJMRs9AAFUHsWURNCIX7X8Y/QvAt6k4KLNQxRM1DhB+xhkwz+voMXhNV5REMhHQF2dmDqRHO6u7DqleOOErmqoesUDBpM7ukJGSALAqnCCYMMDqJQgykG7Wmbi21WAZ/ZJMXkuUsIsyoMdgFUy/+wj8fJWoaU+CgU1mXOCblE9KsEQcFn/9P0zQakqZzDUAQUQrSEMYOzeG+glE6+OkpSFSc9lnryhLeulZOttjplPeRhyowd56b3VuWEOdJAggSobHbDny1HrPuL1IqJ4SZHZz7zqJq+SZV+LijpBRDt25WT+TDrOc4CtYebJ+cjICTBJR160DKN02b3E7ZppMgMGqD5pkvnpn65MP//TS6/aaNKkwcGR4bsnjO268pJzPvkf+2y/UzI0PFSYJAHL2XetAolFMrhiZTlSFvsDmPHg689Mnj1j82kbd45/0Ji0UUuypJYkWT1NsrYsy+pZltVrWdbI6llne2eWZfWkq9FeO/TgI9o7O9rrRMiSVPbUB1CUBMtFT9+67M3VK8/rHx78dlEW35iz9fZ3brPF5rU8b6IzrWU1MllmTFZP06yeZVmtVs9q9UbW0dGZ2eYIHbzn3La9t9m1DQNDWS2pJVxYWCm3ZHZZQmNg0hDsOmTf/S/fccYWhgeHKa1lvlTPnf3HZQGbFzAwGB4eLGZNmoZtN9/q8jzP9+0b7H/o0TdeGayP6di8VZa5NY4JRFELD4Yt7Ku8UbFuJDlp3PNa+ZyQ36wK6lhzMweGc/BQDrRycFECJRh+nUdRFIzCArnfObZ0mcKwVtHtIqvBIdkvAwhll/LjnBFwSuCaQauvD+PTzuS4vQ7P2gpDtnTWeZrV0saY7qzW2c71MZ1c1jL75KvPjVxx9/U7/9ctfzxl2qRJt/f29/1i+xlbvrXZtI2Rt5qcMoH8OrmytMgLOffWoCxyFK3cjbVVuPMX2YIMIUkNkjRlIlrLzGSS1Jo0jY6mAGA81vldOBmM237/7WEAgwDYFhZlnrvz+/Ii2lnXT4khFFyU9TRFq9W6F8A9C1cseqxt4jgqa6ZEPXXZSP/OJE1QlMXQ2r617wLw8LfO+uxOW4zfxOSDQ6hR6jbD8RLMbEGtAvUSKPv6y8032YKOmPOuFwD8tiiKf7t//pNnrsuH2lFyTtZ6gHT8kmSpKW3ZoTzkKmLdeY2Zm6eklnILBeY9/9griTHfb9QaY3bdauv7d5qxxVoQp21dnWktq2VZkmU1436ytJYltXpW7+7OuMyTXbfbrX768We0JQ2qJZ31lBoJODNA5vkxDvRFejpgf5yV8t+J8+LHovZCdKduSIJ4OiInhiMdtcFWShxsE4LqboX52BkhgNgo9oNCv0KfRCF77NbKB69PpCpI8Z80ERxsCXmfswdkWYD8V9bhhdoXHQrEM2bDFRqrHUW+5ojh1x5HPx5u1Lbh4AzGTgTke1R/Aq0ie0cD77G/4XXnqPUSatcJeTjoWyWJ6FKxIyTASyx7TkH0ukyNIwtDzo/W93ob0o2b/X5PwaIhQM9cZA72ZmzExesrpaPaDMPtPi12JQmue0iVOfHBjmD7RfRl4UlVDJ5fIUZw9HyFvL5/0m/5I+I7it4V65iYCrG+kcu6NssUtokRe/weh71y/NaHHEVE90+aNOk14B8fC8Fup2fT19c3iZm3uvKFvz7xwsLnN+0yXWj2DfEhW+yz9ON7n3bqmv7+mddcc03ydm28c/3rX6aWZU5MopMWlPOrbtfbX2LgApCwREjDRwa/F0phVlnHFSuEt2vXrZtAJCkSbSTtL8n9ClZRGyZujsPv/jbL5JfzxKUKHrT1Ay9mHpicjtD4qEYwAbgz4jYgWCSYfqCGguITwXcOlYsyVlRstBW1KBYIpclCo3V+HARx64NTqrsbeMdK1kqo8RzPB7Mvq6q04OcjKnEVoATgdpxl3SRAavIDOEUk0CU9PMrIkOcC1onzHzDRZWOtzo04ylb7DjaQlWJhcxvhS6PKyPXFR8LFsIhLSaUj8TQKOaGvdx9xREsdUxyGCE4sycyo0xoZ7CyOI0V0CX1gZnDJCYAtTJLtn6amvQQAKYOs+VK6Rg3cVgN1NJKh1LRue/HJwy677YZ9O9vajyOi/OA5ez/5wblH3tOd1NKif7BMmyUw3AJGWuD+ARCldO2dt/D8t948aKfpW10I4MoffebLfz9mzj40sGwxk0FJJmFrDNgY74imdmBwOO9I6+ajR5+84vILvnHRaQcd/dC0iZNhrbWU+OBLaVHv6E4efuk53PnYgzt2Ntonpkl6wPHvevfex+7xrhVp3qoNrVtfUm7ZFHAlkZaQsOGEUQ729OKAHfdOLzn9Uz/41okf++lus2ajWN/HRtafeacI1kGSgQEz0zUPXdM2Y/zkR8886r1/3mLGFunwqtWtjBKbmgQmSVBjg7o1PDw0UJStIjt17lH957z7hG/UarWDJo2bcMhfH7z7qIdfnI9aV0daeGxR0ZcotzBqZEAgsCokGAVjQMYgjXaMNWTcTptpZKRZGVMppYfMZBtw1R22nmUZ54VNTYaUDIwxbABmleFqf8h4bpP+GOlP+DFkYFsj9sBd9saXD//Adb/++Le/8ZEDT7Tl8AjlpiyonjFqCZAZ4pQoqaWmMXEC+ps5L125qo0MpQRKhou8KCyDihJoFqCRAtQqUBQ5hvMmpKze+t1grT+KA0SuWjN1u6smWQZmJiLixJ9rKBUtDJfNQOmzcSVoXX9f82//9cgerVZrNwADzDAsZczwc5AQkBJQM0AtA6cJJ8Yws32ViF5ZNbBuQWNMF7hmGJk/MN7V7VErzwE2XVlS/y2AzbecOO3nR+98wFUzJ01PB/rX56lJbEYGCaVIkxRZUuOhwYHWlOkzs2P3PPiG6eMnTwFwWpIkH7/2/tv2WLLgddSonpJ3hEWvlVwCiBLC3nJWAzwh2ARUtIbzp958cXbv0MDUdf39/90wtZc+efyHfrnrtttT/6plTcPGZjnBFAzKGWkLyIbZNpetLHbZegfzzdM/f+cVH/3ORR855KTV3W0NIEmYsgQkY95QfUWMPeoSG4DhZYGDQS5NRZiq2TUSeCW4bIzTA1aDLT5gp/YFqbOjcqZZZ6+/Y4ePHPaL58LqwIWgqMTuQlARYC4BNqqnxYD3pzFtcAJvSDyFeXTk4qBLSX58fwAwrHNsFLf8S9RJMCqqzsTQ0LIbg9hLkQsmL4ud8+AmhDC+u41UN4UBBR0VHDoJ5stYTGikos/jSiWn8wVmpJfyI2+IbUcOXYCkvIJPFxwjtVskG6d2IsMwaTU5IdhZMh4JPEsWOFCF/dE/UIdTymWNUE/4jYTbuCoq3oGXvTW0W4Hi3maImKei56E8Odo2FvtBjaL4R8fpH9YmDVJLqKGGfHBdcdLB700veNeHP0VEb132xGX/cN1gdCV0ElFXV9fYX86/6Zs/uOuKCeVQUbZ6B8tjdz00/dzBH/wigGWNLHn3SSedVFYG8871v+Yyt7zwwghGTx5Xf1cQ4DhLwwps+jg7UXdyKpIo4jLqLZES0Pvf5tJIUPScRloU8BEMstHOxyhFJBEXopD9QgRwlfYif0Dr5vUOVV8QBSjvkzLT2FAMfQiAbCLaOfgwXil5ZadZsQDaTKKCBKCD8nMAKW5PpAz1uOqKZSo9B4hgovHKOXoOT4yO1DfvCUK6E7tleGPSaAxAHGpnw0RzIoYu+wNeo4ylLKqW3ysqgt3vsnaAPNILD1Zj1FGUOVKcotSCIxcUgcyyNCLOXVhL6dui6E5vPKgKrvCL+0Uz1FXLxWVJQ7M6RlIF49swxm30kibOUTAG1tqSiB6yMPcXoKGkVgNqGVCvuZ8scVmElGBh0ehoy55//eXiir/++UvzXnxxr1ar9SsAd374yOMf/cixJz1Ts5TYweFSDr3mZo62rJ489vijfNvD91zaUW/beSTPn91k4uTVXzrj3PPPPunMpA2UDPX10nD/umJkcKAc7u0tWiNNs8cWs7OvfuC8l7577vlzZo4df/HV//bv+x62/9yVLWKiep1Rz4C2DElHw/QN9fPNj927X1+Zv1ra8pn+4cH7Lzr709++4MyPLJ81eUrSWr+eRlauKFrr15fN3p5ieG0vtRVI9t1yx/LiMz56xT5bbPW5ubvv/sRFHzn/qpnTN6FW/0BBuXM+uOUyara0UsLLB+100IS8KB496V3vfvnjx5/xs8P3P6Rmi8KMDPbZ5uBAMbRuXTHS209bTpyWfvOTX+j78hkf+UGz1Tydmfd+etGi/R597bkDBoeGrSEyzNCIK0QONSgQ5CRkCLw1FDntlKXIkrqvHrBIsxQkc+0cLp+x85uIkMHKdT21EsWr1to/A+g6dv93r5m50UZm3crF+WDvmnKkfz2NDA2S9ecZuv3gYmwTuQkYUIEEMrClLcd0jKNz3veBhz53+tknTujquPATp56z1xdO+UjPrPFT0uZgP42s7y1aQwNlc2SgGFjXUxQDw419t9qJP3rC++9qFvkVY7u67nr5rQU7vPHmAk44pWI4B48UQLNEmVvkLLUE1ruhjreRRkGNWg1US5G48xWDCmF2Y/IZR+QFuFUAIwVMq8RAX19rSsfYHWu12lUAGgwwkXHbmRrvaGbuPEI0MveTJE6EDXUxc9JWb9TJZ01B7B3zEsgLZgaazea6Rq324cGRoQd7e3sXf+P0j/74vXsd9ttdN98+s8NN01zbW+YDfUVzsK8YKkZo++23rZ1zwql/++6Zn/1mb/+6F0trn3n41eeueeKN+fs1mwVnnBg3HvabA3nnMAan2IK27pjv3BYwbZ1m3iMP4sIr/2ObsV1dF64b7Jv2nn0OnXXB8Wf/9eADD2sUrWEztKanGOldWzTXrCmGl64q64OlOWrfw9Mvn/bJnxyx0153GsL7//Psr/3bcXsdjrx/CJnbwnUDsy4yWRWT/V+oBhKly6P1etDnOqGj9CyJ/HCwIyrn5rLoKECdx5iRCUHv+nuDjeAj31x1MGQMwYkxMJLZZOsDkKPsCe0Og/1+C8zkdZp3IuMAI1FwbDkav+M8pZnSMyK62FlKZ6WVaElE/WNts9I2s/eHRRsGPafrPEVHasQomkOxuXzwPNCAIIo1TFPUJnNYCSJjkaUj8o4Ig7hCj9Bf7VsFtnQS/bxFTmXENxt6O0EfyzIb4qjM2BhV1w4WSW0GRwbpbAgyCfYb5RHhA0K8WZDSwFDYXZlic5EDrdWhR3DI5X0QGybwJWI+HSUWxiRoNgeKzTbbqnbKLkf8x6yOyff+n671I6LCXIvyueWvnPLre64+sa+nt2jVmDsmjq0dOnPP3x8wY7cbieiFrraOn/r739lV9H/hlX7pqKM2A1CAS89hzthWAxWAQ6TAaLEBPnqdoea2OCwQdlimzUOcDQECeZd/DP720CZV1QpRuA/R76EnAvYezKJ1aXFPBSridWBOCTnFRvBrFtUrC95EKI9QaA3te0XCiAXTA7eUkkTjDRlTVmAgkK49CD6LBbGJIE/cVOlzGL/7WhRGROf44piYkosLxK848izv4/jhQB+WvgvH+J5FEeAotuuaJN8iu75KJ+OtuV13HMHcM0qdaN2m0e+C4pcREUKdP0DkF5YzRjl3FD1fpWNYIC7BDv1GJlDHrGOpWG860WpwhF15I3MmFqWY4Q3gFnq5LGCZQHY4vP76x+7bPq3XnUOYmsjBdWvjwAC3mtSeNpJnXn6h47Krr7jrgAu//8v+4aFnyGDSd8/99H+v7e2ZdcUNfxxTa+9ksiVxYlASkHZ34dtX/Jfdasstxx+/237vXbhw4dAeW23/+W1nbP7+GZOmH7Vi7ar3Lurvydb3DWDG5KnYfJMZL8zZdrvvH7XdHrObzeavmfmML/3xV2fccO8d45K2zCJLEjDBcgLLFo1JE3Dz/XcW37/61xd/4/TzLsqYtqE8v/gbH/j4b/fdZY9trvrL1Zv1tYa2XLZmDaZNmoKONOvdc86eT566z7ufmTZuwm+HhvpPAbDtTXffuf/SJYs5SdOEmy2oAZk3kTebsKVNmHljIlqydv36C7va24c/c+Jpdz+44LW/zrrxmq+uHejdb31rxNSyDJtPnrZ6x212+OUHDzjs/uFW6z+H8tbmtUbbj39+w+8/NO/h+4t6d3diR3KNqMd4osZcJUggcuImmAzANvF75SQwKQGABZkWpaY0SeI2LzGJcyAtwxq3tg42K1cPrut44Pn5ex4754D3Pfj6M5NPPfCIb1z65ytueubVF44eGBrC+Ebn8nXNke4bHrijw2Q1B8fG8a8GkyjqoxpTji/JWpgkNX196/nqW2/YbmnfqnPGJl0H1hvZFt865eMXTp+6yZjX33rlowtXLZu+ZM0qEBgzx22EjSdvfN+Zc4+9b5Mx43tHRkbuALDp3c88en7PihWcdY1LLBcuk+fP0uzpWztAZAoQ9xGZjjTL3CZEmT+YPnXrlEict5jMeQk0c0fTsvRrLkvnIOYuANC0RQ7gCQCPwtCZbOB25wRcZjD16d00AXJbjp0w1hTA5TYvXiOi8oLfXQou2Z3X6XdwJQtgpMDIyAgs8aS1a9de1ejo+HZ9XOcnCls8/r3TPl4+dcDh//27O/88Y3Vfz369+RDGdYzFNtM2Xbbbtrv+19Fb7/nE+sH+IyaMGf8RAKf/561//O7Lb76QZ2PGpM3Sagkxl263VVt1CFtuox0GFwBydn0qGVlJydDwkL3tiXlH37r3wcURO+7dHBoZOeT0/Y+8Y+b0GcfdtOXtX3pryZt7L1u/Fu1ZHZtMnIKNNtr4lk+/98OPTEja7l62cln7tCnTbvnhXX869u9PP8hpWxuXbIl1XYTVDFnQcQi6z8Pg28mCc4KqmE7xnb4NjrBSAr6uzaDpHDZT0APaES9fkhWRDJIYx+KIySsq69Th6S5bhkbfCYRHYKxr8GIrHZHeo/CKSDX4I5siJ4JZEs6IjyZSE0Of5/CMvi6st1OqiT5j0ZcxPoWKF9GF5PscV+AoeSA0ki2Xwyxoia6+1I+LfF9Fv3l6BT0v9NPhRB+4+SSO+SCaL1QD8RT1hyudripP6WIIciN8z/ABaCivvG12VegiQX6KWvc0p+prK2wUDUH7qW9R3pF+VphO6U7xIHVeI3miYHO7d0kGNSQUYICmaeVjx3dnx+144F9OmH3QZ/wE/1PHjZlTABjOh/esZW1bnvTLC77w6JNP8Pj6GLO+bx195qiPFx/f/6Q/EdEAM6f3APhnG9O8c/1rX+n4MWO+AuBxInKHeJEFONHoVnC2yHGOgI46QBxxeLUMtOJLyWdhL4EKMMTHVmh0nQCwqS4oBsNaURrhmThKIkZ7pX0OEAh4JWV8z2wAGHk5GQO/EzRUMA1F73CgIQffOjkN0q7jlbVi/iADQkwzVoAFRDI5tKXvR4jqyZgV2N3f1gZA0bdw6JeJgMspWil30M77XntDiW1Acg5HXzijyikCE6+hI+Pa5KDyNUPHgSgBoJwCtjIOpVOsTCXeF8Ba6Gchzi6CYyj8EylDiazqLHo+0I15hEiGNZLsnvNlRXLmIozyaFCOPvwhznCkc1RxByKHgen3VOGJis4SPguhc+f2kkFeMIiITzzxxIQ5N5QQkPhz3aysj/I7BFu4cjxmYqLy+vvuaP/8T799yA/P/8r2S1evvNqY7FP/dtZ51zy/6I2zHnnqiay9o5NzYmJDSNK6GWgO2c/9+N+3Xn7Sh6792NHv+x2A1+sGc796+tkFgF/0jAwN9/SsxRYbT4cB5gHYCcDm9Xr9gUtvve4H19590/sXrlyBWr2hPAcmF9iwltLOzuTS3/4sbTWHvvqZEz74X1Pa268si2Lvo3bc/dGjdtx9ca8trl+4aAGmT5tuJtXaXwYwHcDuAL4xCHr0S5f94JQ/zrt5RitJOSFym9aUpZvT0qJsNZGkphPAmcz8xuU3XH1U+7jufZl5dwB2n/O/8v0WcNeq3p6O8eMm2HbgKVi7b1nmH2mr1S4bzHNc8LPvfvz3N/2py2R1RrNJer6c8KPAEBCVdyNwrMi4P/Ce5B4D5GXBw3mzo7TFrFaZL8+tBSXGbw7jjhqh1MlBo95FC1cu45senXceMz/SzJtbDQwN7NOoNdYMAd/LbT52jMna73n2yeyp154/eeHq1baepok1xi07MrFZFSwzkVNlfi4py+p0x6P3jvn3iZN+/NWTz/vRRmbiUFmUp5+z9+F3p+869tMjwB6vLV4AMGjLTTdDA2gA2A3A5lmj8dzX//DzT19z11/ztG1MyjIfYJgkMcPDQ3j3zvucUc9q2WD/+tO62zv6+geHkDZqRsozKXXzBwJKWyo581YO2yrcgfEGAIcsKFk3rrwoLZjHjZRFYUp7zrixYzYfKXNkHe3EbF1Zvl+35I1nKrk0/c3Bw9u6Og5l5lvP+dnXB4gJ1Cx1bSIYQF5Sa2QEIJrQ2d31/vZGY95NT993+LMvPdvxb6d9YsGcmbOXzTn7K5cNFcURq/p70+njJnEKPNZqjezVzJs/GNPR9Uhfq/Xlr17z409c98gtY9OxE5ltSZwFm1ZKCYtCx00AprsjRghUWiC3znG0FrZk1GsN89qbC4p/u+w775l/wNE/+dLJ5xwH4Ph9Z223076ztvvqUNE6bHHPKtPWqNvJY8YlDaRTWkXrGAAnTZsy7cMf/+W3Jtzy0oNHL127oqzV25LSr7OUUjkEl6ei4wOzU/RHMJYF0IOJC5+R8RqRBJdlhn0g1XL42wuZGLlO3qJST70vtOMqj52uojCEYF9QeJ/qPlnMFhncYaCiTyJnQ63+uNojdm3Di9wQ3BgsR6WZ/uagW7w9YSIniIX68lxwnBwVo43h1PjhauDZ2xyicaR/ss5RHX4hKAEsdbH6TNBdeqh9MAg9LT1JRPkywvnJQnLlGbGjPLMQR457sIvCxnSAr5kPKlXm3fdDjosineeIX0KT0biDTReCCb5U2dtiskZR+A1gkCE9xkooHDKpFM2lt8nYgIIxp0t6sAH/y/0BpauVeZ5p1L7x98s6S1TbAQFpyaDEcLPMs/fsfOj6Hx73b/95+tKz2hdMe7B5Ep2Ef3aRd+6YefoFN1z69esfv7Gts9Fte/rW8CG7vCs/c89jTwbQ8/zzz9eIqPVPG3vn+pe/UgBNCAuNBidvy0Q2r2PQSCOIQEc2v/tcLCW9KPqHVLAq39KGpaUByMI7DEI2R/FP2vVrUCKs1ne5tt3AGBBJr4B8yGiGHsg94qxAhkbyeQSKqkDle2jgUpROdPxQUBwc+hH6GwhNHCk8JXKgnosSCcAhOI6+X9FGV26dkDp+ji4Cbu7MQg8uFNGt2mEERYoo0xYpS1FKUQuxc6MOchw1lecomgOWKJ0PCoijZPRNfvyiWNgb6/797BWdgTOmvFNiZDtnZWr23WDPh+LoG/1e5kqyrqokdLJDl+ISVtLnOaJbtVyEYsMHoR9x8+4Zg7Fjx9tamvGNN/yl/PIPvl3WssyXmbnxSxbGnesWtsBPLZK8tMWvb7x2m5/8+arrpk2c/BaAG2dO3nj+J076wF9ajD8//eqLtVqjLWHjBlJrH2cWrl1jv/jLH2374HNPfn7nrba54pSDj1yxSb1tKoClExrtQxM2bjclyhxIjhqydvvr77/z5XnzH/nUXx++d+Ka9evKelt7YvMiOFGRU0zGkG00+Hu//2XX/Y8/8pmj9p374IdPPP2WKWnXdAA940y6ZNzMrSRUPd4CU1cM9D398+uu3Pq2Zx74t2dee7mbs5pNGg2DsnAkK6FnUKW1DEUr7wPwXQDH9Q4ODv7n367Z/I5H7r3vM2ecc8sOG81Ma2n61vRxE3o8pWfAmMZAs/nkrQ/ds/9vbr1u7t2PPdiJrGZNQsZt50qKjzJf1fQuqnMn3CLZDUcEWFti8rjJ3W1Z/eq2rL5i6vgppwyPDHvOCDwIFtiyhpOUr7n31smdpva784497Tezp23aD2CgHVjSzPMVyLLxNk0nJVkdSMlQLYPzlGJODcaGMmmExwwLNgbIavzzG69uPPnS8589dOe97v/QcafdvknXpGkAZjeAJTtsspkXhLIAkkOHUKy77MZrmn+ff++X/v7Yfd1Iam7hn+KiQVlw2d3dnS7tXXszgLvGd42ZsK45eEraSIFhAmdynAeAwsKwxaaTJpVPpu6g+a4x3c5+axXOaZTOE8ApwebAmDHj2rq7xj/WSNKNkSBd1bfu9s6x3YcNF4VFYozjbYeTFsymVjNr1/b2jqt33ACnE3fq7Owq3KY+ha6Fc0DJXKtlyMuRle2NiZcB2P/5l17kn1z18/3fWLEk/eSpZ6/absqmx7SntcUzx01y28AmyexarbFoXdn68Q2P/P3ky+64+vT7Xn6sLam3O1RnuE1P2MuGSQAm1OsNAChqScoAdm1v6wCsdcDgA2pgAhtGYQvUOrvSp1993q5Yv+ZTzy17/ZS5u+/7vZP2Poy7k/rG7Wlt6ewp0/1WuqUBMLa3OfzXK266svbgc0/ccf+rT4zpHx6x9ba2xDZzPU5FUCwurZffRhUHRZcXV6dkR/3tPrNMcoSkBs9EboKOpUhniCL1QVHIEgBR2GKwIDh8ythR5g0UjooRvc8Y7Sap3S1BSfh7gqMoz4cSwg374g8iiQO37Bw4GB8ojZ1PeSkocohFF0SVSPqbhBMRzU8ILIZteMTxEDKKHvJ9VXMpZJqEIqhUsoRAL4Oqu6xKCxLgFfb09oQ/QVizoUJNnVvRjVElDtsIW7k6+rg0VOgPH2jwcq3UVCdfMoLRnLujJhD1yfUvXuYSfmU/tWF+1E4hGauYMKaiEsTecWzBnqxV/c5WeD36xj9v9TaxpeRL4YHqs65q2fNhmvJIa6jYe6vdRvbZZIcDANjNx7dPmUMnvSlrszHquoY5OYmoXDmw5tDJHRM6fnDPVe++/sm/zaoXWTHA/bzHXntmnzns7B/NGDP1ptHPvnP9771oXX//L8d0dj77qe9856Arb7/tPYOtkYKMSUUKlLlGZTbcl6yLwqtRDgRh0SxOJPSIzZFIQiOLWssfAKcExGCOXhErGYEG8v0K2aDwreu/RFMCwFfLXmzAdIhZ5mVe6soRvlNwjAx9AU3Id+KoKCAEnB1NQ9Upftz6cmsrZRUVkPKvNmpCEmT7Su2fVwROuRjZWDWimWvEUlAzXpV6kBOlSppJi520uN+VzKCWdUYGBAmAR33zdk5gH9dPN2cBfGUthzrxapCbmKjQiKQopSgyHExt9grMoEr40E83Yc6okQiq8ccVgCT6TEHJCv8pX4Z7dDo5egEpB7q7KepzPM/GgAwxkaH9dtilb6OuMasZQA6Mu+PpR8cPDAyyMYaoLFzGm/3GKhyUPFsGJYRWnmOL6TMwadyYRwzSsq29vW3qxMnpgjXLt3n4pWezWr3u+IDk1QlKsG0NDJmNJ07BjrNmojXSfHSzKZsmUydOMo2shvWD/Xht6aKsKIsdnnz9RSxdsgymrV6kWT21XMLocQjK3F7I/OgT4ubwEHXU69hn193RZeoLZ240fcWWG29aNzCclyUtWbW8fOLF+W2c0naPv/Qs+kaaqLW3MxsIM/lz5pwMt5pD+fbb7pB9/0MXfPvwXfb+CgD89KZr/+s71/7mo0tXLqM9tt8BM8aMX7XdZrOXzJ66KQGGe/vW87z5jw6v7u3Z56Xli8zKNatR7+hkEEiMjArOVTLR4Rc1ciOrQGUx8Rnx0uLQXffmBPz88EhzsHvchO1ue+b+ruFmy8FEyf7wbn9+qCsDQFGW1jZbZs9tdsTY9jEP7bLFtpgwdmyjVeR4esFL+ctLF+75yuql0BS2zxgra6uh7yWBwueIeNMQQJnhkaERak8S7Ln9ruhC9ta0SVNXbTdzi7S7vZNbZUkLVy7lJ155Nk1T2vGRV59Dz9q1yNo6GYk7ctLxvDeCrGWTJTRn6x0WT+kYt6ywRVnvaNv2zucfGTsw1GLKvGQzg0vLxhLtOWubVVMaXf3WWhSGpt3+1INteauAVlf4I1OQEEq2GNM1FvtvtdPrzebwCs6YV430TXtlxdLNW2UpZ4/DhYa8rilLdLe1j2w7ZdaT6XBJHZ0dbT0j/Vs9/tLzHaZw+QnDjASEkaG+fL/9Dsqu+NQlX5g9afqlzNw45Xufv+aG+289yrYKs8vsbTBtwuRl28/adsXmU6ZTLct45bq19sk3nrc9Q317PLnkZazpW4d6RwdbtmRRuvXEChgO94oix6bjJ5dzZm37FhXEtbb21ktr3trmmdefR5LWwWUJKi2ocLJOll0JaZYiL1olF0Uye/PZ2GziVHR3dz01e6NZNHXcRlyjBIt7V+ChF58YLIty/5dXvYWly5YjrTXKJEuSEmVgZq2XixRWRYblO1T4BhSxvfoepE1WFWzQ04rTMY9StPQC4gwqdAbNLrojkjs5PJxJnof4Fk73R/6IBFGDtAb9XI2AU6UtCZ567RQt0RCdKB4ChUwTw+tyeYdgofQljLN6PIG7h+NN5qJMUdC0Qg/R92HSiH11jU4xCeXD2ONgsMyf6DB5L0mAPspKRTwg45CNV2RXg1FvUkc6XtahrCHvlflGNMfeXhqdsaXod5AcGxLoW738nSRZRXmv2AaIaB/6HpIB/jXK6GLPhI5HuYlRPYx4RPgzeq/QVOyvuI233W9DSBepWQeNBq1ypNhui23S7x/12auOmL3/+zd8eBRVHMGya6+9tjz2qGOPe2Nw+QeO+MFZBy1btKStI2tH0lFLvnPGlx49Z5/3HnnRPRf1XXTgRUxE5f/U7jvXv/71Ng5hsyBDKSLGhReqmA+V/dVLC9pC1wV4KVMFT4juh4IAbyCpEfAzBSElhR/IZh+6TkAyKxTakM/lr9FO4IagDOhCfu2bb42UFF6PiTEf9JuWZDHC+P13ofyRIKsAydetetgERwenhjUCLHYzaDQAcvR+yXxGAFZRjH4+NdIkiCtzFGXoQsSWw/oLhHMVFdgrbb89KAc/y5di+PfLQR9BB4ixrSgLmW3NrcVOIFXXy6khAXGJjad/MEhBo0pEImUnNAzlGYR4AqsR4FgRQ/uEaL43MG4ipzEon1FZYATlpOMEvMHrx26APG8CJnM3lSVMVkMCAmwZspEx37OUw/o+pwZ5q7BZlhiTpeDEoGALW1rU640wFz4S7xkDxiRotVpFOTiApN6WEjNqJoExQMEWeWlRDg6WptGOer2eFGUJOZdLyyRFXuOSKP+VSVNYA9sa6LdIs7Qta6DuWZRLi1ZRYqQ5Ajs8UmQdncakmSlRemcZajS56DXQag3nO269ffa9D37m24fvtOdXmDn5jxuv/skPb/7vjy1dv7ZlR5qE0mYd9RrafTw9zwsMs0VzeBhpva2s1epJUeaVcy856nO8blRi3mogRRwZlL/gnduZtTUygKStAZOmyIeGkdbqSJjApQ2BJB98kP0w3M7LhpvNwbLW6EizJEWSulBWi4C82UItqyPsWBnmUfuukBv4XQNS6jC6m4xJYC3bVn+fRZKmtbSG9oSQJgaWgWFrMZK3wMPDpensQq1eTwpYUDIKc1lQxcKWOSiruU1nW00k9XYYSiB3yIJoLhl2pAnO3ZFI3GrBNNph3HJUj8ukO6RSSihhwbAwWQYif7wFmxDIgQTy5CIApdsMomCUeYlypIUkqTtHy9MiIYPmUF++/74HZb/51Le+sMWEqZcCwNyvfODKx9584YxisGg1+/oNMpO2t7ehkSQwlKCFEsMokTebNuvsRJplpkChykQ3IvJYJHhRlLmjA8l6Uos0awTaWDlixMs6s7vdACZJudlqlsjzJO3qoFqWoJZmSBgY5hy5BfL+QWuyuq2n9bQoc0df6UeFj+GNU0RLGKq/Vw3ggFcEVM5h0zyXPDNKzwZrW7CBgv4zoQWB29hRJHFE4HlOg6JSfeF1ftwTHZcY5NUSRJelEqcvkEMdQ9Er/rOwVs1rbyfqUEUT6TKlpwYFNQwYK6VgBwSJjdYL6qtC3yp8DV1SUdXNvo+j7ToZJ1t1+HR9HUU6WOgYYRpJ32WoCN/pfEF0d7Bt/K5a0CN7JHgaO8Eyvlg/AhHNgk0ket7q3IRgdrhZbKnAPxXn2UWpg0PqdUootfc0iIAktpHEWdU15BHeMikiguCPzQi1vWF8kVzJ42EvhDBpqtnZJ06M22E1sQDbskxTovOPOPf6bx31ydPPu/w8PuTcQ+yJONH+H+wsCmbe90PXf/2O39z8u/a2zvFla2iIPnnYh5b+6MQvbk1EQ/8ow/jO9b/zSqt/ekWMJPpbDBqoEIiBGCsLAAocQRnEZgWCAxI9xvK5NuOVBKqCpT1kWWknMqSWGYLoBOcA5BWlRqjcPbKGLERUBJD8WKWsJAZsS9oflhHKLQHLPM18No+C8U865pATAsJ3zD6OZhw4aY8rESHrTaZAZ0R9EKNUEVjXR4rWcO2F8tNYRVCsg50RFUWuo7yge87/E7b7Dk2Kw+ns9GpEUso2lX1iBWK8IvAgrsECEuXv/mBrfXdJS0rDXAcDvDo2OctJjBfyvBZNNXw5iOFgxCM4kTpXFCvpqrFgpeSDBfyDUo13c4P0u6LN4zYpCIkYPhZopG0sM0ImoZKZYK1mFgmsG1SEtkLmFwTU2+uGiCyM200vMQZs2Ni8CLIkjoTQh3OkhLTW0ekE0Sv2nAAyCWoJQPV6YkuL0pZVfrRiYHjptFZhBJ7GNi9ABNPW1mmI3N5+w+yNMqdtUa+3EdcbaVmUYFs6P8269a7snUIk5HbzTFOX1Vc+o/KH1/8BXJSweYva6rUMpeWyKLnPFp7cBsYkaOvoIjAntszdrLML5WhW2POZnI/FTMHJDWST0VYjwXAGFzGjo94Jy7CcA1mtzcjaLTm+QvhSSuGNGjFMbR2dKYisdadQAgASGKRZ3RTRGrCQcQ5GVTBCBZHilwWeZAbKsgRZNo3OLrdqzzIPwh2FQX7n1FraRtTenpTWorC5+1wOt45MUPdGgzRtMJiZLSHL2o0tGaDC0yqM3TAjyWrMhhnMMI12U/ozktwZsvBHIwQjOTUGxqSWSw0ckXU72kCYmUdJhyOrsbAWCaVI6glZy8RGjGHjeMpmSLIUcrQlESFLsxTGoKhZU5/QmRKDy5K5P88BFDCGkCQGWaPDlKVFYZv+wPfYoBS+8PLAjBpSkCGrYURiU+ZuQ6NQZeBxT+TMCIaVVKtnKbXVASJblBZF6VeHGAMDoN7RaVBaU9rcI48Ct8KOvEe4R/VYFIx073b0tBycbTXEpTV2xy1ZARgxfsNhrBqADPrE0ch4GYvP93U84Hsu2RXth9V7QuDZasIvHCbvxyJ9UfvGRu0HnK6UhUoDgvO8YXAoEBLab2nTsEqeBlbjDKh7n2svZNDI/59HlTp6+0XtBR8EFF5RU4FDMDtEz+NOBjpGQUXRHxWdFr506wRl/JHNaN0Oz1Vd7+mqAU9X3wiCVWfJT0ywC8IMqBMq+snpY9FtoapIeIs3+EzmRWgV7A+2rG2rk05i/3rbSegRy4YnvWX2R13448wwykaMxgA5akTtX4aMqFoNt4ElHdlCYfqcDcThoERD3BoZTD528Dn41lGfPJv8gfH/yIHzG9XZ/mZz+8HBwZ2njBv32ieu++5F195/c3tn+/hiYLgPJ+97bPLN95z/kyeXPYl58+al9M4GMv9PXaMcQtrw/NdRkYhRNjA24Kzo8zgKUsGe+BKBrwiA37hEBVMUU0VVQTWKGPUApHjdxhE2Cs8DYtjBGzyxuWIjBRfooUIp2iR6vTqsAhgci/AoYqlC8RFOyejBP6u2nnxUdVoZ3i4UxRj1X806Bcug9MLQneHs7pWzlYQ2wXgLm+OwKk8B8NH+YxR8VGAUCgh9GGGOxCDVCJ43tMO2NfJqaShyxmJeIXhF4xR9RZ8Rq4IQg4TlvdpA6G+sZL0qdeWWJtBSHiCS3GaI5gZjSdoYzbesNAlOvEA/QQIl8dqOMKuIFKz7zJYlQf+K2Kv6a9BCCBFueGXlSM8G3nGL6QuVidERZfLvt2DAEFmljzsHMsq+IgQdCHhb+de21fhz9Cq5kNkiVfTW0aSQTRTSsC4ptB0zpv/EMqzbEp4A4DvX/M47OAR25XYEEOmaUrAPCIjsyJyooFQoon/pmYQB+VSRK82jzJQffF4UwlR6OAz0WQ74EEfm/e+ltQBgjDWaibMIDqX483FQTQMZckA9BcMGcGWiUQ1AeHViXP8YBCOLtUQQgVLK5WTAWqYVkFDWzwAELq0/eYVRCo3DI8HAd3zqYj6JxwxD3hkMOqBipxeMkgs5eSfQrYLKNpo4hnVBBxPPgDv0PtEjdWAIKA2SLIUxTnUyM3IwkLiMr3Ub3BAlRGSSCLctSo4CgSVH/BVMvpipGAxbWuMq7/x2GeRkrboeO56oCJcY7gxPkhOOPA/YQuUuaKvI6ZN+xp6EKqZR/aT4F46QPPAfUfg+yIDjHcebctxS3CmvwypaIZYtGW60PjHCgcA/8ThYXzF6DGpyC14TqnpQnqOg9IR2cdBS9KiSDMFJ1aoWz+MKzzo8jitoN+hoFRtG0z+8P9wcO4Nh/mRZCBDGEpSVd55Vb4bMqzRNgGZUxUFmG/WV/PcsAazKSlLVmJWBVXhtw8HFYw/fRpgouCFNy/6Zginxk/FnvmMS+I2Ewr+Y1CSWI7Gir7TduGLMkSYkDmIdQpW5DXhQ5fFgQwSFAUfvGC+qJAcDMCUjKQlJkvJwX09x6O6H2K8c/fH3Axj8P3DgmJlpwYIFizfbbLM973z94f/823O3z7GtsrTNnHaduX1yym5Hn9OR1f+61bitdu2e2/2AOJH/pM13rv9Fl+HKwbcYhUG6FVvE+R4ZYgwUA5KcOeyEwmfJAjdDI9CRInKSGT4Xw4D0f0Zr7gH3r0Yyo2iSwm70Ot8l92P8e7yyUtmXaFpEBAEtUVki5QzSswuVFF6BShYjLoOVLJ6CjR9nwGBG2CkzAmgm7ywSLHlaskTxtVe+vWC+OUfR95XIF04FBUskx7WLMnXz40rQRMmK4xueUz1N7sD30Tu8gsgfaC2RNPLvI5CRUi0EbpANFHyfpLRYAY9YTAqdRI0yUvhhdhtzaNsceJOlvE7+RwQ5+0//doRHRFF9xk+Kn5PgSAqPBQUigC5GEFW+D6Pwv6sB4GjG4nhoQMCrD+Ft/7nMiRqsJPwX5EdEiCvvkoBFkKsgIL4tEY0gHcr/LMEO8grQ/4RzmWKhC5fwKin9ItyIbBDPmWq0OPK5lzADbN0ZYMGccY6m3qe8IXLkG/WH1JdlCVu4cwiJiEdaLSrzAshzl1mE8J3IIHTzG8UlJZfIIQSmKlUKTk5HYaOPcgs+Sgfd+aEewzhqR5ncf0fGy5t3gvzxx5V58TzA/lDrEDwO9Ffrxa8rFd6I5wMxDUY/70A0gIeXWysulNKJVY69MwfJCAQnNTibYkCh8hN4mkCuJDgVGiDws4xbI/8MlDZgpasydZ9bb+R6nCYbvcsGxlH5MOR2O/WlqEgATsg7hqhcwyPNXN0wIiAx7hzQxOM3ERgmwj8/34IviPHDSx9F0yJOteA9E+ATnmwj50ADZz4gKroY0gfPKzbi64rmk875eVQ967nBl/SxzKOiRHRphjHwDsdz6fmXGJUzauOMiDogxmcH9TNBaaPvVrwjABTOzFW0MJEOpqCXODLexZNwfBo7g6NlGUr/EKeRdwgG2whPfYAWEqCx4bMgpDrHirHaLz97cSBWZUNulDmJaAcIcYMjx04/uhkwnp4c9K4GWNzYQ2miTIoEEWW+SPui/CDvi/UrRD6F3uR/5Hw+CAQHDiSvy9UGifSTZ0shQUw7JZJkaAngeEMjr4/ICaXHljhIITwN1fUVpBKs4QA/qns9xrg9HhDsD46CcQq3Ec4TtE0ZnEBzcAA5wnmEn8A8wUZkIKEUw729rQP2PDj72CFnfHJS25gFvb290+bOnVtwNS1cuYiIL3/y8nTzzTdf/8CCp9+6dN6v5yxcs7gouwx3Th2ffPHoj7z2/j2O/RURrepu737AP/OOM/j/0GUM0Rj8g7NIJBhGkSAE7a8IFOyY8KemzSOrBWrkRYApaz+kacvu/CXdAEUNIwdgugZRgZAig1P65mq5w1lBBGuDwqcwEIT4nQd6I9/5T6Xk0re1oZKTt/p+yFojL9WiiDT7IIKtqOLJwAJdAkMeeKR9EoePxLYH/DMAojIQr6Qkcqe0DuUJVgBE54f1kG2hPTGBZH2K9J0tmEMW1fg+aLQqcjxkDILkxogScsrY5ZP8vFlA1jsRpEwGCpLk5wHwpoCF8kEwlt3vhly+MVp37+nj/uOcZAtrZX1JmGuIkiHWszjVT4M4aDJE8o6KVX43UYgylDmT6ionT+Kmy3iDMhUjS5UjGUdlkRuvnV2/rDqREvAgw9EURMrVjzBkgjz7VaQmGKPeGnNjlnKeSEG697P3LYJhpYEWuF1cjYEPNATDQxzJ8PZQHmOkX8pzCNji51fKlcToYOOhwO8cSRZuZ1X/Y/MCwyMjdtmaNduuXr9+dt9Af1H4s+vYWn+QNqt9JVgTjE3pPvl1hAF/IrNXZ5qIQ2YZzkgA2OOID9Cw5yUKIQP2JWqGxQB2vCljZw2WAIISFeOAI/kUQ9EDCPkJl+wiI6ahDMkHi2TnZRkXCU3EAgmYITwlsseQGgt4R0omNZhWcnA5EKok4nXkKo1iaElwij1mev4h3y+VCY7mAD6JCajhL5KjjhEZuPKyEAAUeYmDDDq7FspbZavA4MggAGA5L+8Y1zl2UtHKmckQy1rGBC6wYDxvGjE6o2CXAjwFOptAa8E2Q4HfxCa07EKT4ryw3K+A5+afwgQjEFhK6FxJn7U2ZKeFtnKzDzIgmn7FXJYgaOAB3SDHsucR1r44/gvzGo418LhPCIllyx73xND1eCc8B/bGNgMUyhJlrgOPsa9IFbwU/jZCcjdHgiesvQk6O5KzkPVxHZeNIQUv4mUcUMcqwmAvc1LeyZZ0KUo1mOSIoZvUsAk0BmmAfPTu4qJzQ6CcKnKl1UxSRaOqm9URlOAjeVxwvBLep8xD5PW6rOH2bcicka1UagVe9j0K4uw/C/yghPDED2ZVrK9DMMr6sVtIIBEBZ32gXEMiIocsWBz0idqSMl4jwQPpvwQkHe0MmRB08LQ3gPJjXGGkAYmYN2KbKcLJIBf+c3FEEQXegUrljbEEQwmGi8Fiky1m1r9w6IcfO267g/5C1570zLhx4xb7PjDe5mJmYub0vDnn5T3Dw4dd8cj1N/39sfvycdl4MiWnHz3gtNdO2vWI0/786A0dzJwws3m7dt65/ndfaZ7n1wDYkplLb1n5r6Kokxr5COgfrEB36S0BiIKgA1JIHa8HBCgc/QBvwETKS6MzLBAdA0IwIOSjSvliZMDExoADPhOUsX/WDUtAEdD1kHKYsb9RjBUWp1DATiKykYMkz7EVmRYFIWOujpTgHFnZzVDbiu4Oa9mcUhONLFkV+ccQhR05dYIE2KB9V+or7UkIHs2mNC3GVzAu1XgDKb/I8+LEmKjfcodkMiGGMYWsgjpEnogyDgFG4U1tLVLC3n/RmZfopHZLQNnAGST6HjECXHuhLMvPDQlPR0wGuMyDV9RydEdY3yCtkxopqn6U78J7Q+BA3Tknjropg+iMEHWs8G/g9KDopccyR15pQdsJc1KdcUTOQuCbcHfkrMRz4R9050T6T7V/DC0cElmTt0a1UoETGRpbZke0sD65ErvVz3WsDF2nuNGkKTR1woSDAbTGdHdxYJJYAt1/KueKxhgWsaBsCxXWS4USO/bZA5Ur43nCUMTbIu8sp2NEnBWNiyPnQIWLKzQXwodNvyJM5vhdIg+kmEE6LxT9LjzqyeRf5lgwZkRAMysc7lV+4ugfwUvtf9W5de+VnXujQUWlfqjQSAFbbKgIy8JEaVNKB4q6rYMNtIzbE8io6DgL5AWYCDMmz0iYOQEwefONp29851NNmLZGNHBPG+MNZJmJyHnTvmmn5O/493iuQ8mZZFcCT/k7iKqyIHIaSUws7Tqd7HEsDg0ThTq/8AL9R5yjSlk9pENcfU6GK0EsuU8cI+mbOLIsy2ZD2xI8UeCRrjEBfv1ZbGcohhNCRguiRjgEFViwzHGI6Bu3JDkAMCGSYQm+iu6VMcnhxTKF4T+BJxDwwBMfyt2a5RLwDdinOsLfLW0ZxZaYhgL5YcwyP0FXMCINqJiHSrf82zzOqerw+mP0xioAYNU5D7gic+r4JtBM+V90J1RVBZ6UtuQ7Dn2SwSlKxMzNrO+WMeumUmrHehwRnKTwfncfhU6p7hEZ8EdpjIItAZaYXqq/dMjsV/BUpFEHwKwPQWxX5YMwLa4lb2OlZFAWhR0/piv9yCFnPH7U7P0OJ6JeX9bJ+AdXtK6wYOa9L7rjFzf+7u4/1Nrbxtp1zT57+r7vWXnyfkcesGb9+k123HzHDiIa/GeZxneu/71XOnHcuBuY+WIbUj8QhweIFJdeVeF3QhibM+EbYXzVvG/DQlS5u3qLRMI0oTdKEUR4UPFNo0RNZICJ0FP8UkU3p6BEwF1jVoEawXCP+i1KRroVl5NV7oNXhCC4Rc7kwY8VuJ0e8zTgiBrBK3f/2tCHQFYKz4mRTbLjlRsoqfKVeRX6eIXM1dd5SikY+QAgRm9vLXgZq3V1ejluOwZjMSR8VDSej9hxGX1xmEdEClH1CbE/7WgUYMJ55GKo6/2+f3E2T8Ne/pwvtZ99J21o1hl3xhsv/wBuWdonibxGkyeypjzJfg1XmJs46IBY8cYyyDLOwCahdDnwIABUugBEtAr0lO4BYsCFzIMqTg5SFbcP4TelUWhOjp5R2TTCdKgo3shNjGyFePL8N5GRFBhY7gfStJYtX7YCN95716fvePC+RfVGjRatWTVjXf96pFkt40hHSrJCRik2WWwcBOwRB9DTWTag0nGGe60YXxW5Ck4ChadGTav7TEzRAIwcjlrl8EBA2yD/gfYU7Ez5WGRdjOjYgYJsulXti1t3LBg3CsyDoOgzcVIx8Fj0t84jFCOCESRGIIUKErWgBZ2iwWj1iDTMmk0ejSXqAAs2+fHEekPmnEA+28CwhmGytuzV11/HN/7wX1/pTGrn19rq+RMLXuoqE0Opp78aotpboV8gQYW0MiYZC2IZCLKjgTwou4Vp4Ooo9TigUQhA8rDvSGwmVuQ45nkKL4x5WHSLviEymmUWudIwBX1FgqUxVlBoWwU5ZDl5VN9lwoIs+CBlzNuIhkBQLBYel75LIEP1l9pAfiSKvRzRQqwe2ejOY7yMhYMODOWu8PqPdf50xHGAzAYnVD4MjqwXoghTwlyFTyS8FXOSmwbPaz5YIY+O1gvVT/yII6czBDi4qqsYauPEa55lvsWZ1DdUZF9+jYJxJGOJaR76VGlHcZD1b30u0h8wRp3CYLdUGpLJ0v7F/C28F2OxrBF1NPYVQBIIE7qo3iK/q1BFqamobBgeROBjeLvY3+EwEiiNLUsUdOTOBz31lblnH0JEfcyc0D85EkK+n794/vQdp+/Y/tGrvvG5Pz54fb1ha/ngulV87CHH1757wud/tXHHhBUAVmhX3tlZ9P/JK/37E0+MQaVklOEcI+VgH4kMikijwPoIVwCFwkfQTSFiA2sUk8e/CugLiBgtMg86RQTHPeQ7KDIlSiFyRgiSGZRRBSUZg6U6g2q0CFgEZ1KGrmIswAfpZhS5ivpYUZNKU8EaryDZwjBAxvjSQk8Lb2S4ErkIxOXFBI14q1Moc0bReKNyj1jxWR07vMHHkYFBri/+nD85u0sNvFEOXYhOe5pLPzi8D1HXFf6UFr5wliKlCajjKLNGFXSHK9t4Wz6S+6sgGnas8/TQ+ZbvQ4YrUjEhsqiKNuKMWE4kEQYTzaNymWZLwlqMoGTVOFGB8gaKDyboWZTSu6BFdM5DNihiQ6Gd0kf/g2rvdLQQryNOYADQaLySgyViLhlTneYIDMJ45H/BnPE0YAQaBPZWvRwyBFCjQfhGI/3+PkpSDI4M4/tXX95Rq7dtA2bkZYGkVgtGEYXRB6xiF+VWOQvZLZnzGOwik6PCRwQEQ8nfK+VuIn+OpyxsLBvGRLDGyq8B+zyB1dDwDqZ3RANkkpDJ/+4NRCIN+FmWIk+r9/uOKz01+xdH00WMlb8E4KWB+Dvyu96OyjAAmj0UbFKjy7dlBdN0DNKApwnieWHtd7DSpDtUMco1EAOZDx5NhUAK4SgLJFkNK9etwneu/s+uJKt3kYHD5CSFLS1V+R4Rn1QzlirrEWrFvK2BJA58KS6Cfif3IZJrMXJld0dfHiqCKuPUzKcEafzchACQ77qVHUADb5CvIqoarSEzKWOsOgqe1lEAUvtrIj2iIkc+TiGZPoHdEBwQjNYKDb820q3LZtWZOh867/5vY1yuPwokqONntOo18Hsk66Kj3HskjCgujzBNCIqMrl4SGWAItlUDOeH4oUjmEN2gzUXgj0APmbM4RhMfS+ruJUQnyIfgO7mso9NBXGm/Uokg/AD5THSbBNih98R2H0XPKc+zYGiM87EwBYzwbBD6p6wzylIjT1fF38hJ8/QPdhNUb1EALn1vZZ0yQTGd/EMbxMeYQN6srlSMCO7E1XAUz6jMVTzPgmWqfSBOIZhhLCGBsSOtfpxywHvWX3nUpQcSUf8111zzT51B/57y0Tef32jH6dud/ItH/nzoNf8fe/8dqGtW1Yfjaz3n3DudgQGHJkMb6tCZoQxthg4CAnJvRAErxQioGOtXvXdsiSVNo8lgiYmJ0Ttq1CQogl7AiBpBRUCkNwWlw5Rbz7N+f+z1Kfs9AzHfX5JvoueBueec932evdde5bPK3s/ef/DLjz/xiet38nRsP+QBD86vfPCB77nN2Rf87Mdv+PTlF5x1k98fj+ydOfi39dr+5LXXDuG67+zfCPergHVa6jAFRUFjiwhWdZl8DMSxZFLBFpoSOEZguSSXGUXDxYqgJ9mmYyQrugZYgvE2xuHpQlXO0TEcQIQMfALl2nDgAMv2VuQYHUko0LP2wBckVGOWYczoIfmjJNKAjktPBWruXBkesMvkvRPQBhxfB744fyoQ0IIES9S0mK4H14xrryaXgdm43LgfjIFjAnjLKybAm0CNsQzKuStrO0ycMoDgQzrpAI0K9JQKReQafP80O3mNCG5BzozEdN/GiWIBQn+27E7MnCBYBSFym/GI4AYh7aWKzVTHJnq3gpxDQiP312yW89A26NAOL4yUHFmJ5nLe93jMdfFiEMMK65g96m+DS7IiImJh4J/sZ+DKUFcLOKbeJGuvC3NMUBEEOLDwrv5WRCz7t+LMM88tyGL/vq1Y1yYVxY+mebwT2zscV0TkeDdmJE1zdLNGsQjhcxrZYwujOImFCHTaNgO6nfPSpE7uNDNdDCKBB8ay/l78S7QHQTXTWITYWO0ATaTeCxQ1hpYDvkPhbennfHYNMwCS9dRRk9wPYNi5MHBD4DX4mfYQGGB6Ax6k5JMomvXM7fgaCa5CxykKdHdhWEUThg1Vxfb+/bF15pmFwtlameu6tj+aNdh/q4mvrSPG4KRW6HPwHJuDITEedPVxKxZfjsLIanZbop+Y1HJeIqYljwNsbNxolA4hkE4h4E7uVg29Hbfj/f2hU/Pb8cGfOV7JqJIshtckjdV6B9uifkXzAdBVMc3U++sWsrOYzhMddgOVyhgJg0ptC3je7++N5yE/FUzoo1jcM387ZYJBncaeAOQIZIRVSbTX1mHguaTaNK2R3ExHPgo6T77T3zTuB3RJRduM5G7Joy0ZttJRtJM0S8Q7ow+sIiizWf3IUIGsIMvCt+gvKANfFTA2hWueMUYitcGCB3XCjXrz944nFnUL2wWfwE8UIsKbIbY0f9fiPUm+4v1LnO+Z4TAf9rvjTkXoaJYYPnrBhl54NszWtpY6/ulP7hx89LP2/cgXH/rePHMkgwcPHvxcM4P5wQ9+8Mw8e/99P//mt3zQ7773TQ/74f/4o4//zKc+tVPnbNdNzz7v9IHLnvLjT7/HI7/rwJEDW9ccuObdkxPeu/5WXtu7P6KFsgjtTu1zqsRsMwQfAZ7dOy3vwQNy8GnGNZISB6VuHQGGtU0oLu/OxtQOhp8brhCevXrDDiZ/Gjn9Ncaz+Q6Ms6r8Vm7CHKGzseJGQAdBvwGJOZAKP+PHk+3RYS3OcI23ApXAjESW2RAIJ5UNTqxSw702CDKpCAEhaJ/xUxDry02Nu/qH1bd04YnnFK3N1Fg7XoU0aW6QmPYtGR85iZNKyM81Yzn4od1b/WIE1EtXZwfjvyk5StNVT5RDwTmzdDh4BWR81vziJl9u9A9Tcbo1OGLnFRIRsgfJ7GwjLJYHgpmNkadGmPhfSgKi0YsiESqxgx53qBUmkjAtJWlrZdTOmuoF3yM8ycCuGWU0KbDMUMJgFXd6cmPq9GvxX+kfcHXDztne3IZ/htkSWVSMHTPbXvhuLPZBdl0oeweK7UOfDIc3sFQBrz1HM01j/MpAznk3jUHqK/aDkRSoychmK8i/CVCDeEc8dHHkTMakKBPeQ/KzBoFWJJ18hyciaq04Vae9jkGmlXUT1Cd7lt8U75c+2AByA7vKX+aD/Vs062rN93Qbv1BEi+7L7U7GNPFkwypJl/Bh9OuFuA3xWGPjGyyrn9xrt6nZffkAP5Jp9JuBQgM9AOXpBUYVT9wnpo1sFGkqJle8MVb9bnKZTL5GfY+rU1QEJ6+AgJl8BQXMEe/mQjNGR3NKjcDt32dky3/2A2MGtYipUGG3K2m9tTLNkAmvN5N5dao+yF/qSYSWcmsUoG9SBFflqTBVxgzXs40Z4JxvZVG1Zt0l/YvaAZ1ltoExC+9gP7usY9YTg7J5snEDoHijeFW7xm7XZGAZW6cq9i3bcez6T6+Pfuhj933bk170LReeef4/OXT06PbBK6/8rMdL4J3Ba6tucm7Eo971iQ8+6JuP/MNnvOf9H9g5d+u82jpz//bhv/cP3v6SR37J18ejHrV95MCRnb0lon83LiaEO6tXy0OgDyApGJLArswAAYRevQNAOhzgPhq9BwFeZp4uRRPpRp8R2Ixisjskod0X2sByB01kaDzYDGIKhnxmhaA326reN0ClbeXYiV7d1jSLlR1ETYCIiqV4zuAEgFzJ98zGRgxrV2DXWDswnGZnMvq9QwqGS34iemah+Z5lNFBm/kenDggOrLzGmQsOBUkGZqEY2URVvyvHCulckRu0qLqGIEbjssDc9GfQ0EtbC8lyBzoujoiuNqIRfxcANLkeyhGjGj5tAJNwOmL62nxyDW+FAbUBRUaV3nU42t4wEzjG0VVSt7seoyrUEKfTBqpYzzRZxNwzn0tVLhFo+RQpnL/P6tBORkVTs2G6h/zF7CxtW+yZNmsaCiwH2/8ytLA1UUkRCG3SxmB/7HK45U2NKQ6Oz5exVo9BYxp6yXMvOwhHgAu7GLbVer7aUrrqwMQS0FxyvF6SyRVdXtDYMCcOZ7YNBDkbQ02zNXJUn1BfZpUQfxUmmTxkA27rSHZm+ZsNMRBqTLOOdYZq2373n0bMBpmgtv/fdBZmrsd/5WMoyQ+PTu9v25SUipvNH8y4EH5mPMdmVoWBw47Rf44ljih+TMGnoBqAOOkteDE+7uda/9Zui3KItAIbOJbEvVk3YpfsYRTk9qR880W8swRgKgKifUM7yIDI2Ri8ZL9/C/+EsZPAmuKP6b30MHw1vCN2VAZmUWFDOPh+iHaN3MQk6BUZliE9QuHU45oM7CQ9howjbsrY2M/xfugkmoec2hYM6zNK3aDd/QAA5TpJREFU7yc3b5gA8Vk5vczgLBYS4Wz7ct9dWCEcjc+sQxTHMnR2jG/CEbZjkwBm+zaNLb1bsdJifq5iZdGaOmu4BbYUiRpYSh0D8DGWAn+9vzB+jmuhDsSILTM5M+sF2sxeYwZbbSgnuvYrNrVhK5xhLeeFRxvCGvqj5gfH3ni2b9mOY9d+6vR97nav7S+7/BkvuN+t7vKbH77+Yw++9Tm3+IP6HOcDZmYdPXp0+7zMv373X137M9/w89/3/a//099bt29xfpw8fXL7B5/z7Z9+8eXP/urXHfmPW0cOHFn3ksG/O5fNEGK7DAEMwcwBY1INBGxtBimHaq6nlRoWoyDd8EI+r50AgigclaAK+Gh/xS4QFTKcIKTQcc7Vvp7ZKRkcvtChqfLGWXiVObT8qMIOhRdfMGiv4uO3JAAmwZrJh1UNgWOxrKxqYRmGnHdxtgBbOhcOH8uI8APnYzi+0RTkOyLMtZfMit5UQIC+Ek4tOcYl9X4TnkNQP7pXshkVkb0JzsLlPHDLvQyH44TqZeQasWbTt4A3af1BL4vOhTNP5uQkmNGGbyLAn3QaWJ5iTg4OqeQosbxXydLKQBgB8JzeecJoiuoAH203oAP6lxHYEZdJaFpS18/B409L7tiv+piTBiX+vCqmseOUBbhqBdA59TkoSMUgzadFTOkxiPM8oJyZWM16C/5HcDmkUTc5TN/wgbOUPbPpdppQNMi1x2BVrLaBnt+FO80IvaPYtPfj3AHXeEdblwYM3fWkKTowjRpbz/fW9wx6YZerknMVsHIEsLDfGiBI7W4DXdpOFxSJIseKAJwBRuu15YpIWiddlkyhmAm+8LteKibD0DMMvJN0spAGCmy2Ui5G+jWGVBwbPlzHS4aBM0bdsaxpYzFZDFvIiNI7lQiUcbQRRs2F8l6sxOAteudCQ8jYdtMNjA/LAZtGJG1ENPAH2Ns/kz5Lqgom8Z3uHpOCe/mPBboVaZsFqWDUN1JvgzPOfS9XqqBjcBG+RhulDZIbE6OY1GGpv7/Lj79phjXC3gVjgTaweBKUlbA7JNyqXpG/BJZtM0Emw3NjDOO5tTr5aTnIdtGmYURj7ljqP7DCj3kCf5WQcYBh36owkhmF99tM9ydvt+bgqyXdgyQ/rsl4FcL6Mb5mVTYeoW9oeL+3rJlWsHbIbhQ40c+Q8cAh6eL4YjjHhTIH9kEK0DvIH/GI2a8Uyfi4imcRU7KEWCrNdsL0XJjYrfvyzhiyZfHfTLwMU7jfgEYQKChnM9Y3C8KqCRbvUWCEj2rZzXsj9B1yKfqc461Y1oqtrSWOHf/UyTtdfNf9z3vE3/uhL7v/U3/iyw7FElfF+4fsP/v5gEfr6PaVeeXpE1X3/oqf+KbX/frvvTrOP+tm67XHbtj+mqd/9bGXXv7sx2fmf/tcSeXe9bfzWnb/KigcCDGWU2G2ZckcwX0fGqb/tcIDsFN/D1xKzyvk9AnoI5goOsnxDJdjwLfyMYXcEQPcqoGv+lkZvc0sBcAdldYGakOZeWan2Hd2W2t1AlY1zsQzZ4HAa6uNHD4GNOA9wfHdcCTjXYW1j2TMyN7UB/4ZQcMiGIqK6rPvlnHu3tLnl8FxRgVm1waQL933GAzOW1YBGvyoCNtoIhpoBzvTliDB6RTpGY/gDEn0NYaw9jr6EXBu2RMuRaE9nMdOrbHGOF9tqCQSfcz+QKmSMsGafbaHILv6eQQp0DHoaiBgh6TbebQDy9ZHOf2Uc2uaEDQPUtp+qDviiS8Kkhtp3YI1rdJ9BqzU59TwQG/CacABKsGE08O8Bd6XraYV4suNtqo7QaGAASrsDgGGuUK0g5mLCJhYISLhuG1azvpX8MLyEu1ZbnltFqJiHqRsyHhlsqxZ7aFEICDZD2b1WBCJxDF14UFWpGFdTMMJzEzj9zHuYrtZ0ZtY1NirI4tnSs1JC3QRY3E+LVOwooBZTzKpaxvxFQPV70hWv5fK4KbG/iFrv08cCf6pYh5G3wjkMtYV360MbmkXkcJSvNcNXWsbBD7iuyXHsdliRtvXMg7URlERBQaewwYNAq8CyaTshF1R9zqhIYaEFS2G0i/UNgsQS/jHsUS1zaR8WgblopoG8Ann6iWTFxS4ONvU2O8YA7YwJ27Z1TpmuaDrnhSgkOPPI5kbfBI6sViBnTNbV8U36OQoFq4oZAHjsttuUY0z/pSwezqKMyIZ5QfGa/rUPOOqmQCGo6gQ4xy/wox8TjOH8KRV48zFWvv8RsM++L2q6sPFNVIsJl/pQwxniDsknTwr4rzpMDARI4TLrFH4mRSn4wQKbDHdWFLn8rU5cFYw2zape/IapDPCqG6dXv1T0AscMum7HHNqKGw6Ud7A4pmw26UH6wTJwO5WnOZFcOzUdysQ0De1ZBZszte6zRk4zM6qM/JnrbFKqMF1UJiyIeABCjCa1Ru6MYxsJQ3uJ5kI0x9BHB47KCpsNGnairAJBu6r7Tj5mWOnb3neLfb/wMFvfd83Puq5P/aoQ4e263Bl/XeOgzh6dCSDVXWfq17xo6/6xT/6tZuecf6ZO9eux7af8/BnfvpHnvrNj+hkcHsvGfy7d93IO4Sbl5wlL1S1wnVvnQy48OS60toVOCkGmJMzgdWc7oXuudHw06nV03iidrVRG894sIgAE15FyWFGDnvdPPoB40CVkPwyR4+3tSdmlv7t51cGp0Ee46BYAAiWP5CnCHzwWQpEEDwSVChO85pVA+jtnUUClg/SQF1V/v52CrpUBeNSWfqUDM5WAlTVNOWPw13xQbXDrshIVPZZnqzAbl+aoYBDsl87YDNpz87C+szWA09C5HQ0Y6PqZNiyEY9vEJzn9Ll4UYFNC8hTavGmlvtgIGMFwwraEeb3zERoLPwMS6vqRtpH2whMK5X4wVmGeM2NhJpxSIaVhHSbKSG73IsKxFCDlqqdgzbIxLh7aaqCFmfv5/CNJiezHH4iSkLBdYjfZbejiBXlyKPik28+haXKCBJ4bwkDo6SlsH//bgR/qiQrwAh7DnZZSvjNxlSldmQN6nX42FtPh1oIW26cZ0E5xiK8wm6OgElQC51X8GqAwo0bkh9xfNBl9xSCA/JpXu00Y7QXYriE2fvjGI2fG69LSgnEX0I+eTh4OukbZ+bItIjwdjds1rR0QaMoCm1syLMhDZNreOscXE3PoScZiHhher0Lm+a2C0xArGD2Kf6pYKUJWFurM/FTs1Tz6pkNwJ0VuztaAjtMKrPG+FM257FIoBnIoO/BHW3L1Keq0NKRhffpHXxjJLnHQY97SAPoLspNM4IamuwZNl8cGuVgK1O4KZQn4GGfmbZvqHMEfABk2v1qX9WMaXWNnpSfIetRPCnJMWXHad9NF3hhVEJnTaM0AsNHtb7bzqbPSKyxx+7LXTS4n2mpYywJ/BI+7I5rm1rHC8cXA+tlrcjcimM7N+zc9KbnbH/Pc77z/c+6x2Mem5nv/5vM5nWSd7qqLvnx3/m5V/3ob/zEheuyfepEnN73hMse+cmvf/yXPyUz33j06NHtzPys7yDuXX97LyaEm+9V61MAFsIXBb9e9YoIGvXQ4doFcHRqCJwMDw2BAwZCRxYbgKUv5IvTAcECxA381/lfmLEcRCjQQdAyv4MW0ZWmGn1hCQEMfF1xkDmeEd/CHA1moHTwuYaGJYNrb7NNHiSqsOMNeIdrvgSNKipY07eMd+MM4GrqsHmiv+EgKQmLYigi+no5vKU0q7SALohg8tEA35I8sgLboyswKO63M2bD+oRBJIM9TiaAvT6O1epFepAhp+xgC33GH6OAOO5ZbWfdIXueCNc3OzsN8CEazM54QNG/e+zSmhia54B8xHuFg8UEEwzlnFjzAY6a1X9wvDrYnQocSDQyuHTFZU0bL6lzK0FaQIV/IQp+Yh8MnRTfRjNKZjHzRm6U9NwTar+Sei5hKM4Bn9CCP7QYX1of6bzp1icdx5btiSXYqNywEoxgoPtk4CU9cvoLu/lh1mnJub+ALdhREWjDaQ7IeTBAy+2TSbneV2xbQ/LTfJ2TlRTdgXGXnVnmuOMjSms72AbP7ezxDboR2Ff7hVIxEOP3peL4CazL6MULxnvDKe1xU9RhFHFoF50oYylodt/UTWDMhAP4XJ+Bx5qxjVEwTLMw+pGKsYutMM6x/0avqlgTxRUDUvSNsSyQ8bhPetu617qlQmO0buJL51FOxS0jJaAe2jmYaDb5CLmctvAl7Gy9GHhfzj/RFr08O8jngcm9OJNYMRzA8ImZ/c4h5An9kvsNLjetmHQ1A69fyPZAubQhhN0ZnDmOMhm3vuN41UA/kRFrjmWhZEcvQYc8Fud5yneazqFLF4qKJWl4KF1evLgTKA4BPwCfwGowqvpdusaT1iNgfCTUkAZNCpf2MdB+ssl8267EFHo2FT+6MwseypliowrTcyWCbnvmSbqJFSsLWm6eIwNvrXIV2Akcer0AZ5eleQJ+qQ3tomT43zbDex2LhxE27x1zKrIq9q1bcfrEsZ2bnHfu1nc8+xv/8vkPevoVmfm+v0kC58ngv3zdz7/um3/lhy5Yc/+pPH7Dctld7/fRpz74sY++/y0vvvUfv/ePb3r/O97/U5+rrb3rb+/FhDC3koA5Xe1AMcGFSmS5UU6JiMCTmUWZ8UYKTCrNCLs9ztR4BDruKDUhOhmsNl2s8LoBF5M/HtjLUo+CJFT6LZabgiV5FzFHVapxLZmx9hqbXOCAcJeCuFywvX3zAbRWb9ndQ9c7ECGiQCeAlJlDBw8NUAwi4DQIluAV5ITkTD4B9+BdAM4cwOmGPRe7Xi+PZOI6xTCUUWBWrZNoHUEQjCqUVI6xVfOAEF/u+JexrCxzLHvDxh3ozxxmGZX4IMkHkzaDeWwIkHTweGcEbg/8VbA1/kEwjnEiAKHs8VnzeLBZuuLnUfE56pT0iUmAhhQ0vA5MRpul4MHGTx/M4ClEn40LPkzPypnSUqsi0z9B8oG/NE7elXjrqgAN1Ns129IqaNdTwF09fgSbtOvRrlfXgT2cWfJAogeChE9W2/SuCmxY/EEAZJV+SowJuPorFC66XbyftXHXWA5bkj82j6qInojQrG1JcTrIxHPAkaI9UnQ9JhQ6SH/e2D1hAgafLQDyGWSnqWVKvlJ3u4M0njM5yf6oyF/gXjW+sVDE6fiSqo6IiroVTcvggXBOJxON8eh8VeDlkH5l+dB3uccAf6Cf5kM1e5lgbSDA1awoeCZ8A8ZnywUBIv4e/RRnqHQciALxZVnIMyEa7tB78GE4APyKCJ53i7FTthkqSgUKgRm9rxlxR4mijdkOAyf7N/Rr+MHSt1DL1Iz6iDHQjmYUF8MYba4DLXCsgA8L8yv9D7AS0JwR1ckbvstVscJEH2MF83vU+6awIsYGcN32Ig0ZiddG0t42mwv2EQCI+ozmDKwZ5hcwLthJ+wk8gBgBG60IMyb27yo451Aiingkm8I7dx+gk/YMeaR4NR7AxnihzyKEBzDCTqIGHUMn1pYluMliSFVUz9ziHWS3u6FzyTHhvUfago0pIrSxL0gu+Phegk+1X8nDbNpZT4MaUy6SBe8BvyIi12HPx3eOnT7r/DO3v+PA173/Gx/+nEdk5gdrHCz/OZPBo0oG7/uvf/dXX/2t/+EfXnB6f+2cOHXtcsW9H7L1/U972Vc99E4PeEdmvtVEvnf9HbzmdwgxxRMydFTHHZ/h1yKlPdKi7AAJBhmm9MHK37jV6yAhgxqYb++njC/ptkr/KXKBN1FbuFzD9U5dqPHSo8lHURVbgtXIzE7W8B7hKvq84tn9MJrqduR4EdPAcSSBADtbjSqb/zcABAeTg0p/JjoBLby/Qa7Z34xX4MA8VABlq97FdN/cIFYWPCyZ44V0ohnGhGCxiHJ416vjPskwS7RHyOlRvCk6ANaFAkY3RpRdOQOC8WeO9ydvLJmX8wBPHIpbWpV83xLO1O0gy3hYGh9eQrOWelyrhpVw+WxCzrggD1X75eiz+1Nc4rOyQ9ab4zWZsh8r0ITJL9BXUfahv0grH10xQkQkS5Q5yBFwuLNP6qxvSIF2+SODstN4CmxhoLrkwoAF7XsQe2N+jgmf2woT9yKZEaHZBARF+A56JhUYQQeTnQ7iPEGxPqs74StEvEaQvbBNO6+tvyPjozZVu3mnABmDQYKjAsEizBsRUUsRGAtZIYDR7BJ+1CZ/036B6TbWwypXBEQFvcHsj3xARM1LV8wGaPsMphpbC+ObnyOyY+Wg4VBEmV13O5S1dCoTNjVj3e6rcY3fy8KZFKIZ49uQZpG/lIEkIvMC/i14szwn/jJXsWJkRHRiAfrBa+iCmObsK/sFye/0HZMlsBk25DIq2UDLnEE25ZeU37x0MnhfDyKiNzdDu+taluQHE6oVXFkM/0Fj5rCrfkw8a9kPdzJjE3yS612F5ATjzp55io1xtKEtS5ouwZfUdAqVNDVoiyMx8llr03v4gQjjTUSsayRmZ9snYUZaOmODjyLtkx7AMM0EJumYoUCmmglPw8s+HAfxQAp7s/ETuOFMR1rGd0/dkkviNYpnfwU6F9vQjnYKFFpU1MmMWhb6uIqIWmGNa2O22ZfZB9QEqgKcVNEsLGzR8/QLCYyu2F6W2Dl5YufcM87c/vZnvOQ93/TIL3+0JYOf85D4qlqu7GTwZ/7wP/3mN/7b77jFqZO1c+ojN6xXXvLIrR848G3/7qF3esCH3/WRD16UmXXo0KEbXyy4d/2duOZdRuGoHPU219gZRGyuGqIfnz+eb7AgE5bhxcSafm4AkkKx3W3bjGJymYHPG2yCSE0H2ZonEN7DsYfVzlhBthG79ecAFVbLMlhFUqRSEZbQYCZo7UQBQdhc3QUcspasvgHGDYpKYCP4vmHTwt28MrQsD1WuwGyWltTZBG2oqu1qgmCqOeLCNBm6XOcquksZQIplQDZWADiJx8ejNK2DYoM7erFC7oEO2E+u4up+eCyjRQGWcALwMfPnTkvBmPqkKrZejb81w+Ji3PCvFjg1r0o67J9p+RrCh+ZF82uqmxS1P+jc8YU5q5qpUcBCuYlis6gmHbZCrtHxaTlQWF/4wHfIdbfafMUGBA0anKGyvox10tGppU391AZE4DULBcugCcHerMneif3aA+A2+PgOY/Up3JrumKhK8KPvLbQ9R4yaTSA2YxYM8gE+FQnx2aicGGWJFekwfkRY4iVEikgzFwX0I6HBrMeQ2ZgpRiAG8M9e8m36wH4yXLemzbCp6q6H4sv4bC4QmVKMPzGr/lkVyPrZlBIwaUKBzXvMVwhGAsmeZpaSsnaMG6RB83KSY6R0krMNoVkYfIYktCJ4+oGG4IBuKLbKZrywA6mLNZBT9wmaEnS7v+oeQUtsJDZ0LrMtjIZL7xO3k1TSbzqS+mQwehRIQa09PvkF3w5lXi6Y/Azmp/G1OPtP+UHpUsWY3eGrDVPRTryqmUXUeG2i1nLJjFzBa4zD7Ub9Qhdgo/0FZ8HEoqT8oGf+GoRfY2azqXNVTOwLIIZg9cSEvyV/4PEPaNO6WSmqRFHzfc3uTVwnGoC4CQfVoA+Nt/XP9MZSet6VOMkXH0MWmPEFthn2ks5S20addxe0s62ME6dPnD77rO3tr3/yV7//Ox791Y/NzPf+DZeJbh0+fLiq6p4/+/u/9uqX/tS33+JYnNo5ffrEetllD9n3/c/4B794xe0f8Nxjp0/wmauuumpvI5m/w5cSwqr2FmtkbvWHbfQGDA6GAjeodPaBrwI0/ONbELt3vZHiCHoBYRPoZa9dRSJD0/bMBUlhiHa0wd3u2LfMb2z8ZyF4V+Kw297AkiKIcdMNfNf8qKjxzowHR15xSwW+zrtoVwswXqbAALxeG2+XcI7pncTcFbhvvmuk982S8ZWDExynLniO3k66dJ4vK2Id3EzJYQxHMVQFAXJ/t2IjEjgDON0KvGDl74FyNF15hSPrPcH5d0b0clETfmsjK7JE81IAAz3ofjVrOHgb5rxmRyLnSBENImJISzoSZgLFTQ5CTrHgKP0QZyTtK9/j8iBwwbtDaNxl3ctjuDxMhqsKKfjATY8U0LCQgHEiOKfehjn8RPoyxr1iiRGCnorVOIf6SHSAQXrDnHPzDmkaEgjSVTV250tSQx0ZvEdihucMZxq/+A4fEhMu6bOEetZoyncsLXW2466RTBJZKgIhpzZlUJU+Mse7NwV7HbLBOMmzgt0zQpowFAmCVk6AAuhVf5fY5EWJrhbsYuYmkXMY31seaCv0c4VdMIGzBLpwzqCSr6X9xNq8VmCM4lSprVJhjUu+bGmZ5BmSl/OlC2vgQUT1cR69UQkVA/3ALqSnaJ47Cs4ogG5kYTKtwY0yG5LYhX8mI/k38L71KFSgjKYTCbaKAsI0vPPJGZUyqmcQIwkoOKz0Q0j2IRccxKFkn+2V6e1kS4ZRsCuz2AhgRfYtJZsCDrCtEP8reiY+Imqx9/qBXTHsdO3nst/9X1v3p8RAsqfuZgRjHNzvikW5mM+AD0Ay1PHDtGzSMSUbLxgfjQ/HzuNL/zU4iiMMRiKIGT/JePBOyrW5yy6WNnJ2Hbw3GQG18G4x9RVj5ZhX0gQZgZu+7JU6x0JO8wKnsqBf2hrODaUUg69zwBDxbcuFjGxdGN1gjGo7wvg0xUSzb0s267gBXpZNYLSedKFi2BlK7jqOal7aXiF22AwyWFzYWLBiO7aiTp86feYZZ26/6DHP+8D3POklj8jMDx49enT7ys9x8PxoZsweVtWZL/+vv/j6b/6F7z1/51StcXxnfcgDLtv33Qe+6d885Db3/Lb3fexDT7zw/Ate9ZrXvCb/e23uXX/7LyaEsK1ZRe3ySIqgN77CEzIxPGMGCIONmD2n9+bWGEFvDMAdn83AyaQwa6Zio3JLHO8ZLTRDxxu7X8BGBRwp7kqnUwL5DV/qCZjOxop++Xg+b8eD4hGSDx6t+pBB2XAa64aD1sAAJmLleJi9TcDbldsc76dMAUiOQHrx6j0Av3rL7sXGxcC1X5IXgg5wA+iTsEAkRD5VC4izDub8Afqge7H7STAcmSXzqgB3cNSywbtn2W2gFT9PLtPk33z0AJfBqglQnIeuqy3QOEWwcBbQLpqGgimMNkttJMbZY1ur9YYS2QzGjN4YDnc41/au7QingAtqteGuwM1IHRqs5ToIJorFj4gx2+yBl2Yz5fSj7bKwO18ZPdGBrQU2S1TrRLLfjjWiUMH1mMeCAs4IdfuaTLZ3dMifIaclpCcx6VYQdziaFiYP1Z40QzqmUhaSXbFDulXB41YmWwENwNawIHvoDWcIoLsM1A1Le3wF+dMuWqMYxEdELDy8WwGfIHskJsF3bHxn2gxs+OEFsh49MaaMv9KJ8WrxKmwIYQSCtknYjoWZkbkw4RyBdLFfWA6WZskui74CRgyb5swt2jIZpP6Z4tSInHlnPoCa0LMiKGJwSDajxKJWobgx9HSJTVpmu2JPVEfjebU9+VctT/9gStIzmq/SQ62C6DP90PVGciC96QB8reEb+Q65CmyF5KGURKLwFJ00zoXg4D2jkIukycwLZwtk2dZSsg1fBeOxAW2JOI7C2Bp6PQaylC1Vre1HugBKvzB4WTPTW36NoRRTkdfgwEIaGmdxb/8On+EJNBP1El814wf7smLCZFcRu+6indBMYpxB2fbPeCAAEuO5CiZLLBxCT3sTLeotdJh+Cv6jJdT2RZ7R6CoAI1zFlNErgFSgD7NH6V3wO28LvMAGMwG7a4KSM9Er+UPbRYW3r4W0meB7rMsasSxLnFiPnT7zzDO3v+GJX/me73vSS6/MzA8e+hskgxGRnQye//d+5GXf+JvvfN351+2c3tnZPrHe+36X7PvOZ77smsfd7oFfkZlZVa/MvYPn966+tKnM2geBtzOT80Mg5tXnGJ8v8EFaQhIRihL0gZ7Z/A6gbshCPza1EQIUdGF6zEJlojcD2WhjN6+oJxsszXEisGIDU2IamhVh5S8aEHBfJ190fAPoAmA40Z0WTSgNJTeAgd0Wh8VAT8yZFufYzAeDTvJgtfGyVDeJihT0+URYUprdtoLmQdxUSbdAmP4ADo165XIZSUtyOUY1Pqr6GvwpCan9JbCfIQO1BndVPtEGvS5/uJ4p5EyO23uS/rozVGOUGXUZjkx9KLEL0uE/6ZTDq/Dm1M0G09rEYLDUWEFL05KQkyU4DKyhh2LupH9FaUXBXipM7tCxDWdawoZdOylOBSCLKlpPoumDbks3kzJAAOV2CGXznUk5swknzUpL/2STHWxvtEsNYptFvihmWZUIbWDahEqJnQg1JnGmN0DAM4ngDHJQWEY29vg0m6Rucffa7emwZfHHx0vedcMJ7jGplzygP96pEkQkmq0bTNBqU6lsTKEgv/vjKgnXSQR4MVf/OYswU0Q+TRDImUxgcj+R8/18v5UzA6C5+YjNh/B4yBuO21dZRhVxV4fItywXBfcChAjMmAydMj7BitEG/IOL35Ix1xkGylKTQKGJN+RGWy7T8m/QHhmw0Wa0nMwfmLClDzJHkiDk6H+T47JqoeTVejAF/D4GS7KQVI5HDKdrDewHENSN8Qw2HkJCxdlZp671feJRihdTrESZambT2SN8CtktMAD4ERhzKB7p3+H751ahf8ECK8gto8ITcPYbEdhMDX4AfHU5uR5sjMhqotAj+4kCY5ROpso0u0uTlfdolJfkif4U+4XutgIbYTiNRV1893efMSvrcvFhJ+MiXy1jPAnrKGFPYT50dLtdS5w+dfL0OWeftf3CJ3/Zu7/vCS99XGZ+4G+ygcyRI0e2Dl5zMOpI3eXf/Lf/8lu//fbX3ubUsdPrcvzkzl3ucff93/WMF//is+5x5cFjp08sh+pQ7CWDe5dfNkOo7ZOyUUKa4tDan5j/mN4rYfA+eYaprWGPJYNq5wCX4QlRTH8VAXRKBkO0TB+aY2Z1MxB0iLZBUjG5DVQJc4wTO4KhMcVAaY7UAU9QwCCucHDwADksdyy2UkaDBT5gUmdTmGNUMoq7kRCNlhYEMk0fKSrJlslp6auEk+LzxV1Pw3qbwVV/a3lQ0tGHjRLBCWYBMO7N+1AdLndAJac3BQ/QvU0lDbKFgb2Fw8PJI0hopzo2aRBDvKo6hSWqPHDwmDXLhL7JgVbLkMtWPfAmz8XgzUq0Eh45IjjjMTOzOXhVT6f3DCH9DnDL+zM7n1xuO2TdI7ojSjq+8Ty3H0cEWmsfg2Lg0WPjAfbQBwbMKmZUWBGmIjQDGv2y/+DZvFOkYReJy5aF5MSAHu8VTwYPZw8zHEHCmNSAjNBP9w+5GJJxx8iEGJE8ItRcRAcT2jl4MegxrJgDJdg2gEoFvsXWec8lCyYU/Ry+m4zKEzmzPbA00GUg8UkW7pjEIWgyWTEI9K6w5J4Ju0CGgTc+BnaUaaftythrOlo24eY30c0dRQ0joW/cwydistNN1VLSEvSFaK3C3lVL6PLC5GXIugsCq/zcoCknnIAOSB8gkDFOvhmRRDPBtBsEcddKkTwCYTyBVS1V1g+bKNICm6zo2bemF88OWSVlBRkG9Jw8rkgT1Bw4C3dVdME40/QhA8u6wR++S4rEfBHOgc6x0kWsoR8KJY9RNlPYRqh4YdBXS3sL94u9o1FRl5VEEqVaHvKEYi5Sk2FLxbbGcRcphmZaIVN+AIyjzVbrWwT5X7EbR6bcJ6XLQmYpJFZOlcvF7KyMDodYWIrN1U72U8aJOdVKPqcxKobAILjrsuEmsd9awaoAcgPfp/piuLdCR4QP1XqHw7E4a8mCUhBXwE8Ofo3IZYkTp0/snH3Wmdt//7Ff/oEffMLXPyYz33/ob/bO4HL4msNbcU2c/Jp/8z0v+5U3/8ZtPnn8upM7605edI+L93/7F37tL3zpJV/wxSefeWqrjtS6lwzuXZsXE8IV+5t14jG95G8B5djhKxhQeYVLDmYEAa7ro62KTQ2c/QvRM+TGNmKS2Z8IA5aNZkrBjgcbiqvlgCuKW8rDRpalTxrqhAHAyzCznQscrBJhOYXxHgD4U+M9m0pLQpzkMSirJ08JG4IMbPMtbiEq2ADDXVXMEpCVTmKbAoRSkAtnqOVI4L3R144SL7xVJMe/6TQYAHdbTDLpvEtIHaH3QVIzfL70lO9rJkdhKpSUP5wtq3ecRRiMGLLqwKsi+E4ieFwjOEluaJDqh7NkCkyol1C5jWo1QwEmtmPZJ4KZaWngWjarNisMq+AMgOBkEPB0sN0BjZK2jaovkyOTR9my5fRi0GL6BL3ob3tLefrKgkYk/5XDHY4PSVNR7OIn9Wdj1mPXHwzcIrJ6Z9OowNuxwi/wrRMFs91hDz2eUblR0EDomCKDCC43hfatvFfBzezwfav7IM0e7BYTwUq8S7PQ9rIscIy5aNMdBGbjKkF88dm5uGEFpSZgqALsKqbiEFUcTfgoicetD5VM5NCmkjiFdkw6IH+2XwBSgKDJ2MYeKT2nwXWwbC9Hc1kZ6CzTYY7CcJb6ZYFeJuUxYTdn/CBw+ZrauGeMAeetmu3QZoPvP2NZPnwNk1U3glSXwgphMG9jJOorE8oHGpvFFisJSJ9aHkoM5Q99CThtd535Pz5rDE7psjZciWBCDJLpRcYYPZFHXYh2Bq2EOQBj+Bn8Fnje59GtaoN+hnguXwc5Q9eU3I9GB16sEpKJGLtTJpyD+ygUeg3r6feyixjcYMr2/GAMY4OmvJIEqEsl62Di2kvSA0i9tq4l7LPRzZZ2Dl+FJLllyVcDsu3IJhhcFy1RDCSkMHMCIfw0bC5Vx1rD+Cg34Ps5kBdWMcp1A5yjsZcQWMZG+R/EIX5tFiiSfZlc4AsX+Ol5887NhD3XiH21FTs3HDt91tlnbb/0iV/1vu//ghc/LDM/dKRq6+DfYGYwx46jJ7/4J7/he3/pTf/5+dd+/LrTy7FY7ny3i7df9uQX/fxz7/OkL3neXjK4d32OiwnhVm9fPbaBj8lw4MgjLKiIaOAWKKU5qOKMHyprVtdhAMHYiLMrm6AevEdg7nF51sbPBnXFkQ1KHeRgJgN+MZCctSPCkq3V3vaLzF7ipdmvtat0mC3CS8J6RJWuASFyQHQUZSmyvdsgQErSDVoL/fCOiGndRzuYSMkRgZr81BgfPCoDrewglxXQpsWATzGMVbwXBSF6/2dDvi2zXoEqWkzu0ouhV0E5iWd8xwMVc7RjYxmEKQ0Z/axsH/0m5NMDI1+bjzxrMG2XOFRAmVg2Zzr4QGCHpSPQfddFKeooEkBL4L+Ysnnwx2BrNs7a/MWDiCmZczrMV9ZGN/YclqBBIyOKGy/tajusP7ZZZC9/1qJAdyocVMtkTtS4VG9XZyZr0lLUAdgLdGRe1gTMStoUbmQiNYFg6yF1N+noyXom8kWaikT2N4lASBaOLTpEflIXVWprHChJQkLs55hoNSow6SkdXQH6wgsA/RT01rGilsZBk19YY4KrlkdasjQ7EFKeOWwRGN23LW7rMY4R0V80DCoTZy4QYNIuup00zO/HlBgLX4mPG1S7yk3Jhg3fZTC/e7Zx2eeFHZSj+UCf1GPgO5ggegmUcSashhWV0wbZ2YxeQS7Qv9Yj4Gc/hiDfeU086pk04G7H2IIz0ESwBwNzFgBsYCNZGLIZOssEg6ztz7spL1R4kgb5SgfmQiSZF+6nyniuJLXWDfwtIp8KeZRn+fB2Ob2hZePdGn+VAraMpMf1BwxNcwpYRbD5Pv40K0pdUGFprEJaSCDlCJpzEU14ByiiEyiUBVo3ctyfIbzhjtmrcEN43m21DoIn/p36Fl838XxTf/QU0M7l0TIkHps6Tj22LlgRcyo+oE0Wo4DrGlNgnPxN7ZCmHue6rp1QA+cogLFMdNmK4ydvOH3uTc7ZftkXPv9dVz32RY+1ZPBzHi1xtI5uX5lXnq6qB37nf/mRb7n66L8/8JmdE+uJ/Sfr7ne7x76XPfYrr/n6y5/97BedPL5U7SWDe9dnv270zJGBL2aUfbnrxZ2w8z7dxhxTbAQRaEQWzeUftNYbccfJmGX3BacjolmpFdVyDt59RMwOvNtC8BPu4JAcyYpj4YjxsJALm7YwMl2KE6tZCx1DYaNQOGpU1MPAKQHJYe33bwUSMbskMhFYW14l0IOTzOEMM5dpyWGHHxuBjcmUZyjFvDSJETOS7hRtdSPtIbhoZ6BBIhzeGWcoxaBxrYji2Y9GoTmNsXGO703ft0zeIG2GsrzbQTesIsd9CDa0wUxY+8t4t0TevC0EVdTm6BhE8zwVcJRk4c4kAs6obCRyW6JX46uIcdDxIGvizRrO/5avJf2zXFxPxkdrYHmztZBGwFqzHDZ6cydc9j/wC//z58j4KdrqACpkfT6+Eeep6OONuYbzj13YAqc9bHZZNMwhYr6NN1qC6HuWqlitws+ax2Rjc50gbqWPZkif6g7ulQIN2N4mSNJGu1iFZDeBT8Co/o7mB173mDbTfvKdWbdJYjUygT+TrY5VKCiYTAPrJZS7WNXy9wIG7kfGA12dhAnaqvWKqj6PiBpHdbkxvXEs4Ztkk06TJvtm/nrQukkmfViOImOEm5WwXsanh1fysnWgaZfGNX9WsmrMsgHKS5KJMJuODXWCiHxAm74z0vSQ3kd61bLlDBvlWsY6FQ4SAOag40DdMjUVbBoWuxX997hIenGsenT0CdsfvO17bJUFh1jWbY9P5wGDJvgLA0YcTk+BwM7BI5eIyTp1N2QewA882ytgiJNUjl1GFdB83zxrZuUmDWabXghzZxTz95TCLozd9cT0qLlS/r32xGhWTEtJJ/q8T3Fr/D6tICvFCWxrmVoTI1SMydQXtLHcbNdIKRfT+G3tFU1csrxE7NvajhPHrz99wfnnbH/Hs17y7k4G33/o6KHtz5UMVtX2K97xijM6GbzvP/qtn37ly3/n5w9cf/zE6VPX3nD6QXe/777DT3vJNS+9/ODBG77t+FJVtZcM7l2f69q+sQ/N3APK7zMT5XcC2HEvKqbcj71vwxl747aN9lSt5Xe2zAWBOWs5NVEwQYK29hZtEdEH8oYCL1S4YOm1Tvcv2I2x29YKJDlN942Dvuz+4dhVc5p3VazQUlB42x5Xl81HN6vtVjg69K3LVw5eXOBSqFy5+2SxP1T+IZcizaClKANP6gYIc4lgKQjjUsxgky2HUQlf+D7qjEMFGTdN3E2RejVaXBO619uhl1ob/amSCqetFG9l5TWzq7QVgWVPmOUpo3DQPeQxnEaaI4Ds0vqzYkME/+ZZlKYuaiPCtw2vCu6yJwZhOaj0IZL7l8UcjuIldjBfNsAqe2icga29MROMNtPHqyXTQ/7Q+X4OVjsFa55cZzB5bpmtduugt2mGneGdHqpKe9fSzqhYYjpkmZoVKISgrVMI+FIy8Hf+2ipls6CNlfjgOC0OCM4u8ditlltlx38+wymbodTWGKswZo0wTFFyiDtG/5ipg172+JpfSKgZxHQMtAZMVkenVOtf1Ti2JKIM32AX4LGVKBJJXtsZcbQmHMAYoHWYCUZcNuJUe8eP9yuoLgjBKvMai3Rfu+aChdk8G3iy8H5jagrG4Urw7hNWJwyRupSC9CIpFLYNDo6x4KXlmGJqLuUF79jupl31szZOZW6mI1E9ixrB9ywnW185TmyQEZQH7GToaFr1SE+jaBDTc7KZMH+CMYKMgZF4HZfWlf4qQOsoVlZY29BvLnVf5SsWsy8u8U7peYT8CZYx6v1eozNzni2uMn2AjQ95chVUSFcjhM9oB5wCDeskP/gw2NJCOUMOmrlWS6BFfjKE1RnBOItd56RvvOBPTPNkOyrMRiGVmgsnw16qlzQbLa1L47gxFMRGUyrgJPv0yg6OtjDAlY8q+GY01uR1POA4C45Rrxmj6PLRzO/bQx6wV/fD2lmZ+gafRL/h3jUCS3oV+QlzaNfQm4zYWrbi1Mnj8fm3uc32dz71a9//ggc968rUofM3uky0qrYiIj5x7DOXXXm7Kz9SVVsv+8Uf+K8/+up/e+7+7a1TN5y6Lh506YP3f/9Tvv7fP+kOD3vOqWftbNXhvZnBveu/f2nJ6NZWByozFNCUfdlIBzvzNcyCAV2aEWWEXoofdw/bK7cQOolwp0OsM0BLBWqMASIsOGpoBVgR6BxU+6KjXKx/fOw0mWEbZKPGiOVLhHVLAHVEhTaEqeilXADgHI55sG0s1YJThKPVMs3iuyYEtA7wIhDIzLOX4wX81fiLEY3nEGAuTV82rxaCqzvjdn+VSmxR3Y4IvMuCSquCtFBy2440oqgjUTg7DgkKIyPBa4adM4jlVBF6p0HBKg4VH12ulL+Sbk+u6HHoZJTIhZwro4ZuoxO5yZlnLweLGAF3QdfDElA0Pp4D/T4XLI8mp4N34HhO4aaOdeDIs/061tMW671ECEt8wJPowBI0+AzOJKvxXXr/GbuW0A4+rwpenNMo7ligzgJuqlvqY/b4IlT1ZlIwB1JDvCV8saB1nMcI7mt8nNSLiCodKYDnphAJ97UecVQjcuUGVFQX7DycxbGVhMdHkTiNQBbQOBIb/N4Eth0tokNhVAdtKkyxQGUBF/BgShRDxQMkZ8DwKLxDNPQPhaPEsocoypjys58R2Jhkpc0x2PXzOMOTiGE/vpuokonuk3oeveIf45WOrfZKl/yR5OgYuk6BKZDdngskBF5swSDxWW7ozWS95Aff4Tbf5RgarQ+wOb6Tn60DxBjIse0M58w18xffvdT0iBbTdKpGaImxBi+8J4GGEU0TlWWMRjZAbJOmwqeubBs3l6ud+FjZCXgEsbvxS0UhYGzE9E5b2MZw0A3ghxdtI6ZXTwZfl0huECO8H6IUpgHmQUBBV9rW6Fv6Hp3LHBhpRB/ZUJE6OxG8ssIMjrIYMjKfxuJpYKDB4hV0GrwlbhRXjY78unWNODz4vCzOT9f95h2PVdBOnHOcFdQnJb3NzzB7Ao7YjKWM1XAOnrL5BXqZ3MOKWORp2ulTg22NpnHcxRif/GpjN4pEemC0t8r3EsMpc5nFlJ62DLZzq47fcN3pC/afe+qfHvy2tz7r3o9/emZ+qJPBG50ZHJN847uqetub/+I9F/3gq/7Va37+93753H3bZ56+4VOfii941JP3fftTXvKTl9/6kn/0F5/+yMMuPO+C11Nwe9fe9TkuTaR79mUXkioU4yKCS078fiRh6R+7+gHcArit6kluqCr9cuKX/lzeyN31dN8Irkcru6mzbhJgEQ2cc6sIgFf4GYJqWV+pKmV1sNPJFaubKecSgMLszWGiF4fhF2zsE2s/Mx7MzCg/36sZxACMQA7wqvEOQNOmjUosCqJzR6Wy32vhMpdxrTEOna7sujj7k16QoRlcBquAe/BzsSBsyHK8x7iWdAKAXRHqzzP0TQHCoUFp4Kz4XI+FqDyCIzg6VKJrbtjaz6Cm5tKzzCnZ0oGMpUbjHL1lSpYK43E2YVlnRrCiCHLxANiF4VcnYc2cRECi7LdF626aLAoujykEhmrcWCUZUTG7JeibyZVs6s8yUgmbsbCs2UXCBjNavK2jKwdpgZSZeCKUgKw9vYhgktu/IzCpULGG5SQ1CmRSAgXdZhCj2U7weQrYECQhwCyxZuhBB02TbJGg9oqEDb5WdYIZJitIpOn2AJb2OFW1+6G1I7JOYjf2OAhEigz5gDMlDIIt0STLFiI3P8a4AZphy9rBcxWq0pnB5Ke4dF5yyQ7w0a/G57yIQDILvUnaA9/dTKOPYRqKSksIcwVe8jujLU4wJD2atYGRqYwg+4cfrUCpLEwnA7pZ4L80NnFaoJ9nluLQWK+LRLHH3nLUzW4pRbk6ng0xdBLq8EuT3WX83VRy7CGtaDkUZSDbkz+ostZKjxCV+3bybg2+s4j/QbeBFdErkrh60w0lrO3GLKYQWabrSlSIQQt8wiK5GuHCoPGR3pgmN2LGUOMnjU98k72Brw7Ubv/CLbUPGcsvoBiN9jPEszQyWARwfExSQDLZJWlaYnJvhvflcdKUebcV0MeEGnCl2LjkRUCT8Zm+aw0uRa8KLU33NvU8Ix9CtfkDEJZeCvDCcaov4EAqHuGKoZ2I7dqq49d9+vTl93vIvp96/g//7oH7POFBnQzmfycZrKvfcPXZVfXdb//kB7/uxf/u23/9mt/51ZudcerM08ePHdt+9lO/eN8/f9Z3/MKVn3//57/wjS//wIXnXfCHmVnJpU9719712S9bMrphdLDLBiO9BAxn0n8uOT3vZ40h1HYDma5UMCcLbOBKgRUAyGkCQBUAjRFYhj0RTPFqVbUIAMD+ivjJFhANbsyy490zOt7Ja4n+sI+Fz9VNyh3RQTloGtxkIU1MOkV0Ad7qjCwltmJWkK8EaLZfCiIok+BnpNc8tG9IUDETNEhfOJZc7GB1rrEb9y+h6jjbab4GglHt6xzQQXE3oQgigaS5a4AwoIQrH18sEJCTQyOWOKZ4DTHPjtACGAuESaLpQIbztb9j+drCFK8eQ99DAcpoghZmfGknZZY1fZURyFYwDuiT6qrNiR7ftJECK64x6ciG2bm3DjhRjSOiVh1ngqWHbvNoGxtiQB4IJqYt5AP8HswGNozxSe9Hb5I/+aMYgEUVzrabbpkqanJE+2OQkWOjJWvXsFO8FsucXjyDJegaX98DPgTkP9qlbbAdBLKGBeotWEXHcjhOVUmnYDNJ3ej+rGI+MYj6E703F3BL2ObntvFQ7bTAlr30glfoDcwXNGW09lfggPkhB1TqxwdZiX3ChNngiC3Dwy6ixAP4JoiOvFAK2Mg1nml7BF5CH6rHCb7Mm40FV85EDD33XYWp0mHJs0mTelSgJCbeFG/QZ/iwQAuSQdqTdGgqtrB4YTKuz4o0hpeaOQnwlVhoY6mKWJbe3Bzc9X6Ez1oJIVycmGIcLv6SfZuKMONWHhDQ5LYtcWlvy6W/iwBuSfuMYcSJaP4OecjoXY4amIFnAX9iwhkwVHwt0sCnLdkFS8kWgKADT6TGXk6XWtHMp31ThhGbj6CYkEEb9K/nWW+MHfSaPfHJarbID4yPdQf5BB8VXhjx+Ga3rmhG0sZPHy7bnc6pxhJtjtnkHxr37J9z7GZbEftyqWPXXhuXXHzJvu/+gpf+7GMuuvS7oyIravlcyWBExDv/+gMXX3zh7c75479415Uv/Mlvvf8fveuN52ydcdapE0vte/x9Hv2RH3rGt/z0RWd+3retVXn1A19wem+Z6N71P3JZnbgtuHUbsxFW1DZwGbMhBBkGGRG1ruM/rzAlqs0R2sygQoFSA4WBnlcAI4axVyS2JWA7pGsN7sVQkawmjof1fpq6hEdp0ECgoNgtMsdud0smObWuaB8OG0sE2ugVnvQ4RgUy14jMpd9NNBIi559ctifwz8hYOlgey0zdISKoGJ+ta81jRDC1VsslYlT2115GGpODQX8IHBb83QlLAn1zOAtuvd9vfQMfI8Y7FGMmsGJtYM2lN3TxIBDNL1CSCgTuhagmV+oDX/BvZ+u6iRmqMVM35MHqN58d94wNWLpNr6Sj4y5F8/1JIH6RsL5blcVlySm5r9atoQviL2d6OQVUzAlHTtyFC34mBcZ4RzvB8cFe5ehR9Y4YM8FmMRXSk4rgGXQ9dqik56kVMbaNbzumrUUogZLQWh6wTxloVi9hLeEEu8G4q3pH3uqEkS1ajKEAYVqyCh1DAJY15AI+IOyg/inq0jtHwIYeezbKFQIis5fszYcmflVgiffYxr3EjMaEaKxYMjD/YwGS9CHCEgXug7C2bhRnANJ5A750QCXMabxrO87GFfRVraeZNSr9YFJVm4PpVUAPhhyrl0+tZXjAQGrY3RI2OxDWdu9IsxptS+rgbMwdaDYL2NsBO6eNIEfwoAD/Q98mfqrosZBK8UBWDdvX0SKJIlzrw9BBOE/NEJHxhNr2Eq03KE/WumKRCOWX1vfKpSo5URStX6CpMFPInofxoIgUiU2G1BVo4bL4tuuocQwSZvQyF80aEhP1zhSLYQkfUVE40wE4xixF90cGz/8s2HRn6thNdKFxQUC9YzeTwyJN4DNUoEp8AUhSi5EsQ/C9hHE02e1hTNAtFCohzcyInl0GZq9Zvcii2O3gtZWkS+ohu+1Wm6j5zMIeELGucaPg90SnRrHauNBKUkZz6bRiWbSah7OOPdtKbe6YCKRV1ajdoHBX1XGIZlsHbYtoAG9XYYe/r4zYDawbsNk2i1m3HJ8NmC7pD/nZyWCTkMti8SesffDZylTCt4JOxniPlbPzincps8Z7ttNEo3xXFbG1U7FVWceu/cTOoy59WH7nM178tY+9/WXPy8x3RUZ9tmQQvRy+5pp9F194u0f82tt+559+yY/8/cvf+KY3nHP2zjmnq9Z9z73y6Z/6tZf+2OM//4xbfNv6rNoa7NpLBveu/7FLB9OzAmr1PgRUIaMOGC2BXdHa8H8w/vGdb+s77pFDoOOOCC6TDK8oFt9pizZ6GLgShQ4MRB4DcCS4NpyQl+gPMauQNpxQWwjscF7Y+GINnpcUCIoMHTBOecFB6rrabEgQPCKT22j52UZ+JiFnPvq7wZ3kkhhtQADQNGpyOCI+V3A6fTvGB4cd0edQ6oBjG1onDzXxlu9zlOjxai6DhPA19xEbqGoJQk5FQJxXQf0wpXJwrgbhUfWcZ7fgrHQ/ku7e/p9J1/iMyzGzcCxnwI9r8x7TlZATZHAEfTejYpwIXQz7oCKmw5DbyULFxjuWEi7PY/RxYkzQO1Q0q8/dQsAHtaU92t8kssXWvJrHS+lPQTqDQozWbSdSfIFOcwrVEtgoqKCcchm7qvWQ/DVbbx7ClhM87QELftx5YwB4u0sBD+DCQ3RgFXivDZ5snBXTKoSJv1mRtVDXVuptUk8j3U60v+U0I5Swm262eQGsGHgJ5Y1xXmSU+A5cNTlm4wUwrLphx3Kc0rMySYG+gz/G24B+At/JoQmKXe8FxGrbVFJ6Fp3ccbaxOwVfoIUsFKFt2JUwQXwURwp9mYpURPieafgOmIwiBqSEZYbsg3xYqZPuTiNi19JQPxdX/WYv/XWewScNPchmMt/drOp3aaWbmCES73uUS9D/shgiKIncBGEWZ0I/QRaXgmOcGXznEnyJ6OReJo0Qm3u7wh5CRRXHLxZFMoiPvtpiLVuZAEzDc8Eyz5Cd403AFcAmhLXTe7G5SM85kKDPGp83Ey3Zozzox2BPKb6CP81EaUhxphfvyFKHiV8ooqLQ0eNg0iacr/5D3BFLnZbB8Jr0zAvqzRyTW2Na5divoqylDB5pxEUNJX2BPUWMlT3S+bKgKVRgdQiBvgIG4TP5RTDGBOeIJ3SSETi7NjlsNYx3xa2CBQ5HroHCep34zCdOP/MJB/a97Elf/fcffptL/uU/f8U/P+OlT3rpyc+WvFXVcvCaazIzd/Zv7Tu5nP2xx/zk63/hyg9+7H072xeetXN8Xbdf9tQXffwfPe3rH5WZb33FK15xxpOf/OQTN9bW3rV3/feuG9llNCcYmN8/MwMNOBR9QhDsJ8bNqpbKqBGsTHgRQHFhcPJfOtHuk9RsmJE71QkEonRvO6+CBfN+3eMwqOAD79sZcrvDsOeT5xqOm1i7YqCnYNBI0pjAHPi8Hhg+RlU4oqxtNYJgQ4lnyekuwylV2uHdBMe8EXDcZLAF6OR5qv8Iq6j2+PgivPhK4KxQAoRAhiKDg4oRQLPVnH7zAGzomisJWC0HMAX5DF5RzeaoyDfdg6dQGDG9xvi9a7C+m6NDx7KaSBtnhLKgsGDePrMzpdAO7dSjSgYTEl9iF08T6LyBRDC4gd1yiR0cKBN7OO/JAKJ9vRwumZGyRRSVQCtxhN6ZQQqW/XgANobNxgAOEnRX0NN4oS8j+F6VFYyIZbuKNXM1OIEDpHYDB8p+94anxA06i3C3LRBKiSEJPvqHbAa0MMFlgaL5wmA5x9LoWhVUW6Ms2ggiblR/aewxZMJ3+DawmDoC7MBviVq5YQb/rSl41nuxSFREiDaMKNMP6VW6/bn9g59lPU/+QPIq+3susgyEgb2QLGdp2R8Ibhmkez9BfKZsca9LKMXboUbiK2bFE8+HdFcFwv4O76CDF9HYMkkJvG/ddD7YMEk7KCfdKIZBd5KFXbKbCZ3YPvme1HfjzFIkS0gUzI4SIwc+yF9pEjonRi49Ri5PbOZyThVqTjEAM0xGlG0adiNWWvutBPFcgi/6D+HehGqUhOaa0HlyOBE5yUZtS8bEfiZVanUkpwOTODM70Sly3I9zIoBKIG/iyZVJggkqcNl9IZuBmAr6TcGA1d2PKaPJR+f9RqCgNz9sWLfRAHW1bOQohkERWBye2UM7wbmiuD+RtI/G9y9bsXP81M6JYzfE1x188b5ve9rff+Gt9t/k5Yfecmj/193r6058XXxdbF54XxDv/lXVGc/96W/8uZ94w88/8yMf+ejp/afPrJuccda+Q8/9po+8+OHPflxmvvXo0aPbV1555V4yuHf9v76YEOKclwj3aYmoIyZXjuAhigFx2h3ljQDgYctcAweDr+kGb8sb8fACPXlCGf5d2SwiZkkYYKJPzGg5YGTgiPk0EBuA1S6woyS9h2Bg2j/HYwCcnrkxQOGyIT5mvxkIL3BcBKZs9hdR0oPI0TKC+95hk8DsvLMt0+FEcu6fVWEEFBiLoSICW/FgBJ5JXg05Y9dRBn1sK7h8ycp3gcCmeoMWBCpwaPKhChCdLqlVKQDxKm5hXBFr2YGxXCIinYC0oI4ZaQGF2onQ0SSc5YTD5yAixM05OZbDXsyRxgiKbInQ9D5fRWRi91Rzg55cT7KT/qkQsdvS3BmPZ8As3Umb8EQZZp3gG2ju5+jYR5N6dRIJYoVmV0hQRGXnybKWYAC20H5UdkFbWNLseABI605WlLos0WAQuW7QEcGNJtYxO4NZDIxvIwZRpMNmyhvDTar/ZM829nejah59XuhcoSYjLfkbCGYrJKxIkGg3pVNKeAx4ywLcMuxNHCnuAZYNGGRs6FJx1hVPxcTrIjRueJHUELD0jThFXTDeY3jmGObjfTCLE6O4lEV7UrAIKJVOYYZbuJMbZLpiN76m96fZEE+4gS3cITRcLhHchGIRNqN/7t5stjq66rJbYzF9FfgTvdEJ+dLyhCPvglWt4hjdj2O/zY6ggMfgmmhSLL5kjtcvfPZl03fL5RbpXqtfwZiqpcHQpGhGpr/8c3y2QhKQScksgJHE17CZQbS7K0bAn7sTKS8QYrffYXtJuoZ+tMwhvvLCZ7/f7n7DacppmH5LDwp4nzpaqVb6liWp2UwYcayXcGuR7QE/wJ+WzdC1Pj6GCgb77McWLoafZAxuEytsiwHwdV55pWdWiSO063F/0LJitAidSsQfsvkI9GE0NQYjLmIjfZ+Wh2NES0N5kSf0P5GxvW9fHD92/c7Nzj9/66oXHI6XPPTA8zPzJ69+wxv2vfBel56MG7mqasnM9ZV/8spzHn/fx1/0sdOfucs3/OoPXP1Lb37VrdatrfXkmWve9Q533v6hZ3zLR592z0c+PjP/FIfT31h7e9fe9Te9mBAui631j6BjUEARQQfOgJqezdytB+eq2ClQU1PzZaFpRehl+/4OMUdadTqS692FR3LiA5f1pTu+Yd/0vIC5qFhGiElgGc9pW3xVZQc2wImXdiCrCJyDBMeedEzutRpgEwCyWLAgoF9tHFUj2MjcisAOWjFm+/Q+YwerEYG1XQzhdlVYizErkh0kScNzKrxbEvTa+DPInZXJ68ogJ8jPPhdKbGT1XGCMxAB9rr2ULnmmU07sS/ETjrL7Hw4NycJwHAB7eNS1zykk7aajk3raH+6kcLbloHuxbdGnGIK6Jf2Rc1WVFTran9HOsNOkVfBDwcMKDpjjZDi2Bj0tbEE2Vpo16HeDhsm2YJB8ZNGGB38HJUg6EOCNu5eIZQ5cN4P8aiECD4AY0/IxH0ll5NJ3T3qL+LBlgRahY1OBo9oGFmLXfFxKjmC1I6pBC47MQFOw72BSSJEmjnxp2WU0xiAASQWgWOMdC8ezYGOujfGF/74iUU5bHQB4Bo5FYGWAn7HJJBu2Wmu/V2eVcMMDKa4FPxZ4Qd8WnCVomE/ZrNhHcyF9PquOAWKjEthOxtLLmkv66gln83bCbOC5Fc9W4ujSOi2fxfc5gWnVywjXphe+AYNPBY4gx2cfqSOQWSAKDf9Q+gI0hk5kWIIaNhbzYZ1AgPdzMdNKimUYzbMexTYi0Sqbi2ydbm83dLePI7Lng0MSTsJhrZPtbvrZ1ttNmTUTeBwM71+sH8MzokWTKYaKn02TXiNBfxLUvLIJ2Ak8wN9wcp3IegGbfByfLaYb/o2bEedTYcOm0zrSyPrFSPvYEGCPdjEHydD9mSbwR4nTQO1Id+vm76C3OI4IuNVLPBUvuUAsuVK1hG1xl3AoHzEfGoGOhZM6BkR0hz0JfKaw14Ey02qAdSVN9FK+m3cEj6PJzv5x3M1aq2YqW1+1IrUY49DGwwqY0KPM2KqM7dyKYx/96In73PPSM77qyi/+9Zc89MA/ve74dacPHTq03Ow977nRXT97ZnB924ffe4d73vqO73vtu//4mT/06p/4rle++bX7l60zTp649lP5xMsev+85j3jWtzztbo/884995mPHjx49un1FXPG53j/cu/auv9HFhDBjazhggGpiA5MwxxNaK40LyUYGjW/T9AlK/hz7RSAjoI0AgNHN4f+hd9HsuQj2yMPY6Sy64mnGCgcBVwpjB61allHBl2U4dWmBsFWrRe8MdmxT7LKkIhXjhD7TeBSsaHkZaMHSFHlr3FOdoBL9I4I76JmckIyOgHFEqlw2CY6m0uF2fwR60I2gjcFKeoCmgBgHxTNADbKwGaMAZgo6NgIpizwsSGjnJMXq95tsFpsBkDspOFpzhN6XBw1eRWUMUfpsMxhgshLcjTeRKIQS8cDzqb64FLPMYTMK8NlSBeh0ztNYeozQQYzbAwUED6CW/JE/x/PjcfWpKvwYuz0aEb3xgz0XgaVoHRTVLEMXIAo4SOpYzDAyq/XMsQF2wsOqM9G6aMOsjAetVhme7ARBBGw2gwkgxMyCDnUJ9puSL+5tu8TMxbo2VdABBPwOtOC5JYPoH99F23OtI7AJqdS0/FRBZGmcKADgoPAyOTfhlAPbgfwR4IPnSVnxoPbYfB5AWzcy6xjSf+KpoSvHAkwzmtqHZDsMzW7uclvSrcA5i7FBZ5rcEG1Cx+QD4D/goyLxtwqilCGLSG6KwOymFwmgyZl+pGLa+tHlr0KptdU24WH2wCsPwGFM5iuIU4n/y59F47nZM4og0ThPmeNX4B2KdT4mGVxotnEwaCpSmD6SF4ZP9BlmO5z7pY0EZeL2xeFEcqM0PL3Tv5Hjq/R8YJB9RwxUAU/0DQpWJqCtP6m20A592UaSVL3zLnwOEhnooxcuzAW1bffNiwpxQV4n+0axJaL9VaghrLTiwsylYw0m4DHZmpZ4iz8BX0bCISP7aDZ/+ab+KXKhnyiGy4eYZe4mrO1Nes6WeRv9DYsuNZulgzr+rIilltiKrGPXfyq+8NFfeMa3Pf4Fv/Xgi+79rMy84chb3rL/qquu2pUMVk9x5uHD+fHPfPzyC8674In/9g3/5eZf8i9e/KV/9bGP7T9r64xTp848vv9rnvzl8eKHfdn3XPJ5t//B54zntq688sq9ZHDv+p9yze8Q7rbbyM0nADDtUDfqgnx4QeDR9y1Y2jXHOMqBHLimTlcGbfMNRt0EaGrbx1D9TyLQqQGuHl7ROTHRkmsB7aCZ45+CJgQ0mAnrt3ZqOKlMHO8mgJ83XzAnLBKsuik+rQ186Nf8DfsUuyr0DtYsVYC5b3UdU2DR4ZqBH4LIwr+ldnNDDnBISAAQSNDnRsw8bhp9O3Ymdf35WILmmMowpYNcO14T/WUwaOU4U3oCniqdgGwRGPYDrTegmu+itLx9rEF6NUYPFCAm6IaxEaGFeA5ZJUlXkJbQbwx6DpjciKuUkI1nJVsF19KV4fRHo5QBRTqKJpXJ5c1m3lPnbS7MwbF8Z/DT+GxPkibrVTNMPRdmAYAu20oeQSts/kZgA6HfrI+scUtmkDl1xKgtUcvxUclEmQL+iIXJbXWclmwKOoailM8GSTsMU9kHBtUJekQwMQEH266gP5glq7AZdbbVT61D3tCR8dUEOBOvoB+uETnxHPhqeJXNC+O1eilrAEOBPAT/qhV6C47PK41F0kvyJHKWETCHN+M93KqoxdnuBqiEzMc+2D02JCPGoLgHOn0caKtxaMWXK2wWibhv7kPmd/trxJLB2fEAXbInKB0lb02hOIrAmLtxM0gO0lQBfIJRga8yNB5zQXkEC88cL+SQoDbJQxYsyxO/edbJmsJTs4McgiCtjgNKZmWL42gKx+z+yaTNOrSELIDBxm0NBOOp9hceSVkDxJvaoHM0rtTbinTpmt9cSSQ0owEsESXXaERmlxmavTT2pfPA2jZLC2Awpv6B2TGNRboX6jp05I8BNld0GBE28s3emW9CQJXT9z4kbNQ0noOuzfqtglAxUYwUXdUzi8vWEqdOndw5FbX1BQ94/PEffsa3/MjFN//8Q5l5/OjRo9tX3uteN7pMNCKWw9cc3rrh277lR84646z9/88v/5M7/uKbfuOKD3/ir2Nne+vk9vln7H/2pU99yw8/+Zv+1Tn7z/qxF1z9gn1Xv+DqnfzcO5PuXXvX/9C1+xzCjeCqwnwdqv1EuRF4MOCtKUQSCFYEDzwHEFdxi/yI4LEOdOjKJIZR0wE2qDQ9RceArgx0J1CA25grcSB0oyBtFTsADqrOachjiU0D1OYOZuoDqaI5/eY3nI0vqQnM9gTEslH1Be+SVETWvBsbaPf3AwftHWwuc+A0+kLwXBG58CWmMr6seJ7gWaRlimxaHtlJh1cyPRCJDI0J/S+orq+SPwIKhhFwGGgjImtRkruAD6q4Km4DkFd4vGd+xnRwBMt6Xsoyuw855gAtNnbIGlVh6jH1qh0r7KU29Hd4r+7Pd4mAKSZnHel6e8pOu891Q5MzVoA5aFJw5QeYo0LK1ZHR46Atl92bqo63XukWBC2DFtgE7SWAMQhMYBMhulnUmevPoyu/Z8xboVBAk8JKQrQgA+CMf1R0wmuVd+4uDN77d1AC2QY13TCDhbRFWJQZYydG2FRuBZJ9GA6WsQ56bA6kKnA0CmdrMAvNe9B0UgaorlfB/njiaXCTDuhNQqqtGdmtW1JLJGmeDzVDcSRpO/IN0JOgLmbFOA4GlNdkroEiHdBc6IfgvOSqmndlAtC7RKYxuI/FnaSesxxhCRDer4bscIbhwP9SAbO0o6WKRK1Tm5+hn2mmxfwBqLXgdcgBdj0XU2hLGLuNRTqAoc9FlwguPKaMR+yb5DuhKHLCT3bOG2r6KKLfcaXLGFg0ZLwq6Wz5cCzE6eaZ403rerqMQ89DyQd89Ce04xSfeSwJxlGcCfO4o2hk0e84LsLdGrzT2EZ/2EEzGlOL+BKkCwW8jF6maoVjzMk5RiDuGqasAqX8AoqZK1kFXdY76sJs93mVyV3RgQfDMlCg6FjDYhThlArlwMepzOPYiASLxSEVPzdya3wjWimrlTSxiIBxNG8U33mLdKf8W3ghXs22sxjv1VRGxhnrdhz79LU7Nz3/Jltf97Sv+uQ3PfmFX3xu7vvNIfrKzPxs7/hlJ3Y7X3v9y/7swD9/2Rf/zjtf/9BjHz92aiuW5fZ3ut3+Fz7mS//smx/95Vdk5sePHDmydfDgwVMvf+HLP0tze9fe9f/uUkJoAbmCMrvTjMYTFXjqwuf92Sju2Hs4CFz4nANAmnWHUGC6q/ufiNLthW2600ADTpKBnbXWwSUSD4QYw6H08smlUzgDJy6hmEBiADUDfwuMMjPWPr9q+OEkT6rK6AYfit5zgNrC4E+7OopXS2RwiWgHBtEOsyyIxBIN+BNuXgDHDJ/BxHT0N5Y4CWDHGnvxjAluhTXU48fnhsGU3iqu48Xw4WQi+A5iBPUCjokBKCTfDprVUy7VW/lsRimwJPdaEziTOvpXsaObp0Nx5wxtsVlS6FlC38bNSyJ9tcDSo1yOZNZrBjdOI2Rc4/1HBR39DJXdqsX4SeevXUoZxahXzaCjv9ZhT+YhWkYw4Atxoc+wwy2hrhioIThikQnficuB4MOCYG3VDxyCvK2AkiE8ybGEB0stCVmwf7BgCs6RXGlmkHSJEYEz+Th71zt5LrTRkmZ5EcEr0s0v2h6wKYrsxLatHfIIN1v3N2cEGMRrNBLN2ji3IY+E3hDnoFN675IbgnWw5HpXpfesGHSarmAoa84+gNPGBv9hy121kyOjNPExjIkl+xpBp9EbNQfcVhgp538EcYSkladkkEtOJpwhnzitZgl79wy6hYQ/gjpGdkRQByFNLt8ETmNJL9qazVe6zR2Fs7EwWr7JQVb/z+sZ86yqZrxJI4oY5IHwMg3y8fGMauMTbpjS16p1peLrOmydmG3iHz5HfB08X6hoXCpuWDiyMPlh8WPoBfyY3l4s8sALIsxV+53eJWwGrPtfSk+DA0sPAnEBsA23YU0D5DYnKrkhl1VhDuW46vYwv7CR8OnXGq+XG11JvjXmqxP6MeIPm1/pI2nD6DfhO8p7DRS8o/vw2e4IQGUahoEmfT7NGlPG+D5Mz0NtU0Fz9vMRjMOA9yzIBvwAgGEuAOayIE6qG67/1HrRbe6w9X3P+db3POf+T/iBzPzNo+89euaj7/To45srp3D1zqCnq+pRb/r4ux/59ddc9d2veuOrY99yxulT+9etB97lvvkPv/ibX/e4ix/8RZn58be85S377/XZZxn3rr3r/69r49gJeMII4BZrdFY5moM2BTXjDwQ/FqD59+MPBmQAGCUiDjtTN+GIpvwRlhnT/Vqi4KChIAXmnwxqN8ApcAIAHM+8Y9to09syfgBUGVBoaRcdVZ+X4+8Tkg42CvCDG4TDtKVsE18RcGgMU5xFB4EAX/ye2Nv3aeY3GPSyGtoPaLYoAjuZcXaix6CKd059LL2MScc9MCyYnUyKD+bnA9Vd9tnPMDC0Suj0/hnHalGGx1ZF5Y80mqYZJdDRwQ2XlWUwYOJQEeFAXq2betdSgSCq25Z3hAe404ZOAfJLzhKVb9DtvIpBhzaQwLxCscPpeAckY6X+EAyQCwUHajrRzKw0eUxqCqLA+8YLsl+V++j+NpPJtKhE8yN+sIL4E+Ads5zxjx9iUhivk8nWDGPAD5E3yXyw0o1CrdHeaFfJ8U9omhFIlJDIA6U8CUe/1REtzRtaYxgIfmfUtGvlgIOaxr1UB3oxz441i4WdxmcUTMr6g00IYhF0ArfMZpkIORZy0JuSsgDQ7jHYdHyO8JvFz2Q7GXyfjhgBe5z1n7od8HGwh5ZXjHGKDiuOkRL5NhXFIjrDaBJFBbnR2A+ekUXlvAqtUqlioWSIf072nBc0Q1EXngjDXxhcmv5JJ2ZNirC3zUabsEOSLBubZVbtIzouoMojkdL4GXJEKNmH72GxxvQmgNkNUoXC00LZwZYqI2Jd9RyxoNvUVLTkYuRBdrBd4itsHy2iUIDCBolNYg64BE2MNL9RGbGgqInie4Yne4J6LyKR/WbrPos+PmehBIW8iGlmLxgLOaZHIKmzp8Q/OInAj9oFmwpvMIbu0/0rRsgYgcqg8Tk42EciCfzv+ypdbfRABm00loplWWI9ta6njl+7fNFjv3Dryx504KeeesnDXviJaz/xkBrv25zYjNGqKpdlqV/4hV/YunIkg/v+xdFfevh/fNt//u7f/uPf3tm+ybnr9ddfu/X8xz1v+cpHP+e5D73N3f8dnsvMvWRw7/pfdu1+h9CNKM1g8ZlVZyK9etKmZtUgN3zCMZIfA3C6vvR71N+mjyE4gWb+rRtrunnzGQCPA3n/mupvrYpYo3fsw/j6u+xlNCHkRxKDe3kIeDpdmrGb+Ba2xbw5Ou7ayCC//4eKt4G02K9AgBlNAzMD+0yymctWltIYSIAGLRZvONfub56RNPl0vziSgnRiVjRUIMjAjp+Doaw/NKNcjtzavYLPwxNrSV1YBIPf5/mUKdgznZcQJJPIMeNLJ5Liqc8mkP+r6SYcpifGtJNgEjsF/U0TUzjzddXjHO1iPqD9GQsO6lu61u0neD4XFlAVZfgzOWvsLCl9p5xbEMkPJrYRN7x+LsHYzA56LlWjjRuTTg+aWN/euDG0sjjK6K2u2KsqDbGITgVam/TinbvI0PKi1kXJBc3aQfCmg4pFSniAsWSQLo43LOAKs1lwdNXAEaNOlfYWJILraRmVY6dBLylAX5nY92mKr5AoMAh2nSCYuX6ZjI2z3jGKSTqGoTnleOBKjf6VOdDWA7oxJYiyIX1os7ITVRiw6V26nm8wzWc8SV6qjY1mR3EhjRvGF5tKnl7VoF9tWzWekcN8dO534jqe28BrJoD9ocMnf0PyTGV3XhiOwde1neQqeQCfNl8RERxtJLMTHsumODoDHE9PM4PL2onXzVPPTXyny+mijrU91NrL6WHwY5xpthtRu3lLUTiiuGw6UfUsF/Iw1dE4YU0WowSOFoGNDU6UYXMFeBGSIbFhDSRdo+8KvHsr+6N0SLN8AvhUEuSk9rbaYZkLEr5XwSb/d4WCGzqAz5TYij6phSW3sDtiU+uY+XHg1qa0conYt+yLG45de+om552/7wsvf9KH/uEXvezldzjvtledrp2MiN+NG7mqj5SIiDh48OBOVd31x37nmv/8g7/+o3f5649+9PSZ69lx7hln7vt/vupb4yUPf+6Xbmf+3KGjh7YPX3F4Jz/L4fV71971P+uyYye2YljTSmOtFZX6mMCBiEB/nObE3QEn/5y+ig586kbtnmDFniwitBiHDmgyeQMCBTrFwHks4Qw5jAY+nz1kEMjAMwLvHKBJbG8/VS979zeCpi1ZAvjib85lmPPAUhp3vukBRIOf/GxyFgbnGI3ZthTt/YDVzShHLq9CwGUOTxtcOAwiAJmdCPgOLF97idLSu5ppps4C/XbyCRlE9qYuPZ4wGacr25gR5Pd9LYr8yVf61EKc5jNjcBzYQbUdJ6ejNmZtIibngCAGjo/8pEdUq4gKpx3XuKMqEvzxbmZFcSzzbHyBuRaA1bS1DngPbQ5zdpwVMlvNiGHjsOHWA5AMTkkDEBiA6W4zwIZQQaFCyYnzDxVsbmM8eI7jNUYb2uxbNFiCCtsv8QnfbeYEsINGsIAe6WiUCEwHaGlRSo7Vu1A6zpW2n1Drpr8Y1tK2VxbUtc2u3adXtj2XQLBfwLjKmN8dne3aVzdAwCxQqMUmPoXdZf01bzXT3nJtpur9Hw+2FET7u094hvoIjHVUyZryCJ895PtSGaFF18D2AkDGOGIGOC9MHiwCbRuzLhK52BkpHlYGNxWyAk4Gt/uRbcMeEm1gPCp0Qc+nHTxhxmxAOsXtfVJjAS8Ge7SBVS4oE2p32Wpb4uYhTce0SQi46avIgWXgRySTGsyOCruDuE/dboMj7qBAFync4nE3mu0X0pk/hb0RcR36BlMWG44wRslMoLDla7S9gOpygVyB6xEcr3TZjHgdY0GCRzcF/WvbhwHi3d+VcYvpjfMPBWgsc6+ROEEFphm+0islGM/SAoUdZa/qWYg18mGekO/CD7bYuEMB4B59S/lgk+KCbtls5YZHiU2+oeXUOFUht5ggInrtO+lA8/7OrqjvzqyIDvsgMgDf0JzeoWEbxIEaEcgNn/nEzj3veb99L33Ul37ohQ951hWZ+c44EFtxTex44oerZ/jWN/zln9/igbe525e89+Mf+vOv/Ilv/Zn/+JbfvvUN1193+mSc2nrwvR6Qz77sab/6dQ9/zssy8z1x6NBy1ZVXnb4qroq9a+/6X33ZO4QIlFJgYo5QF8Az7SMBnPlGWS8dAv8UUE8hjRlwhpYcRXTCgyAHNzh5+BQOpTac1Bgjockc9fjanb9VmNKW8BFkNRuDrgn84cstrNZr7F1XPZgNsglQqupAO20syVlK9kfeZuedSkbI2Rrj0gxEg15Z4BTmdMLlXr2MpoHVZvO4ox3ORmvnRdmChpqdRdAVKFBkIMzqZbXzTNYB0uUKvpbEOrdpVdCWQ9EBFAPalCaEb/PuuhVRXHos+UYgmVMSJSfEuIO0WhgLGVQGzwfMPtuoaaBcWp7zjCqc1RQaU6bUX8pA+qE8dYxXjtN+0NbQhKXPILt5Q91vIdGy6KQ76HUAIQ3gt4QIe6Q+rCtlQN4hmKBRJXdARQDFWUW0ZMFfhAc9Hpzj/rDAsGRbYUGrPQ+m8PeWX0JHSucTrgjiKBcwpEO2DMb4uPTeTky6AVuvVjRu2uI67VGWKSTEjox1qjcRwkp6TV2YxNjvXsfMzyoVpJpXHEHrD7Ald3WKxksrMuAv4CuwIsALNi13FSPDdB/yNA/TthClmaHRJrSkGNBKR5y+mDYOU7AIRCijt/UICQTu5gZqMiRgIU4G8GIQxVAYU7QxGjbQPyZvNO8z2ik8F9bvoBcb42AmGe8wwzti11UmcUBamiNQWJiqs3t75K0P3Eyuwl6ryODKDbpCzJ4DC6wAlUpUoe/C/Yjh9zaOMeJqCjTX3y3aWHzYuq2/pi0s0okw3Yycl+j20MbjS8wreeg1Wk2LxSU/4iNAm0bUSSFFSbmk84wq2pgATM0weYbJP4csINcI2Y6AQj4xoGeut8Ck0OUTWcWuxAT7bmrHsQKfWsUG4wRV0nfwUDpT5shoB+Yb+B34QrPIaSw+ttyp2N7ailM7J3dOX3dDPvMRX7D17Ed/0bc+6y5X/tX7PvKRa99Sb9l/SVxyqicZJjTPzLjmrW/d97HrPnXFzc85/2G/9bbX3/1fvubn/vkv/8FvRO3bOrlvZ93/1Msef/K7nvX111x64V2v+vCnP3bzo0ePfuCKK65Y86qrYu/au/53XLZkVMZKUJ9daV+eDCIgckBAMBBtx3NAxpfuEaBsgOi4LQkWDAJ3AUqxv/FDBu4zhrWmAZSSWQ8CR/KjgICzKWvobT0kRJgZ7OciAKZFMvSuklB68cpZjrOYCHJN4wDuLTnYivBd5xLjU3xBB6mlI/iuvSpnwKJbxU6FERG9QUymJTAhXiOImyKi5OFHCCIYQvd9iwcq1maFAlVULYMBRidrtTSNCAYG8Wsfnk5OW9Ca+rSdhvhO/c3mXSkpHJ8vFJMffO7Btc9okl465aQOgO/VQQ+WXfJA87DAgg5MtVMxHDqvAChYucfMTc56R5mb/Oj46WGlPy7RDf1FQChLrz5z3vls/BGbAqatJFSuvlWONzEoi9CSuY3ZeWiediaETsxJOgoGFH2q3BAdcNH5k0WeKND6A++STWqSqUEFhpzkL/XH+IrDSVTwWU3WOWFrBWZV+n4Gn+PnFHPVmKVaaOzZ5z0qeJs3oCrRCAZxBl2FPBXgVOwI64PTnE43kjvs9JeYZc0YxynIOoFfGLH0090HdgmOjuGcF217DOKA48ligAo/bJBJlgeqDnXgnL6lcY6/gIGp+6n6KfkNnFJLOnIm2gQJ2sO2U3yWfZSSncVKZim+DfYCG4bM1+iixZS5u4+0BLf1hMUV3Nt4zPeiTVvBFi5fhzrErA9uh2uEVr00XbAAFkhBXYq/U+AeFVk4xgm+OAw/kWi2btns/tobi7mto2DBlRTT1H30e3jtzzD8pQtUrsk4wD2iZ7KN1/CNQEuK3DAmqmOTlilxeUgzJA61RXybi57TSiYgE/VNSFNoD1ibwQ2rtBzU8ZEurce56vfmtWTdifSmPo262KQh8hUonoQSYugGGIdPTUSR8MUzRE1Fe1NtPOPazAIHcISS6QJJ40hGROxULLXEvnWpYx//TNz0wptufcOXf/36okd98bfecv9NfiAOxNYbjtRyad7yVNzIdaSObO3/3duc/fR73evaqtr3va+4+r4/8+qfe9r7PvKhk1tbW3HLC265/6uuPHjtCx7zvCd+/v7zX//Aq1+w7w0vuHr7Nlde+dl2Jd279q7/JZcSQhhhGYykfWXORWAdk0P3c4qAaAzIaKHY6Ws3WI2rF8uYXwv/vhOyucrsDt0NHP2rWks3lxFZCwGWQISnJudqgQSTnZV/VxWX5oz3BntsGXQUwMfxMvsC2GewEwxyyqqjQQeMIHvpZIJBL4KWbmPtRYRpPAYCF0CbfmjplWMIACJQVVVluwyMsZzYAjWcicWgt/vK0RdxHgOIiuLGNALesXudz0htzI71+V3Sv1k7htNQ2NBKMV1D1jquwhNDrkAL023oSffAxLGJ8mQU/gvLfNA5gkAuJ8W4Sk5oBAPD/ShAL49fW97aPGfsaGm63ELVTPAaOENyUGOFEDpjfeMOM6umBAO0DNG6ncAe+nnEVhj5VGUu3Y9KvdQeHA4mimx/6XdKuw84fMjKprhUPZbN6VpYSMnVJFxia0ujx6Az+VqBycuhF60JipDIO1CA88MlI9uJk/omO2MOUhVrYufDDqAYZBqPUOyBToTtVkgb7xFgBtqCMTDak98xE8GQuEUz64hbCuSu80mEpTxtDziCZYQM5oq0Ue83Ek6e1dhM4xJIjCVK5AT0S7iaWbKTiuC7k03+7uKOlZYyzE9pdOjXv1GbBHrqjgpAFtWactIrZURgoy33OeV3iv3JL7OXAwYTHo7Pn0/MhNk70GirlY9wDelvzGJG04YNWVSgg18wSmmrrhvZO6VGwC83l4KFyppjBGKLszjhI9mhMG0wpguTw5bofhbIq3GyzPidZ8RN8G78hh2L0U4PXrrbfWf5URPGu+Yzd0Klf++CVe/SHal36TXrzr1Ex71L2jiC/M/SDCfsgz5iBBEzOKL41rZAXlcXODCGRRuWDZzE2PolB7QJuTpdgQJv27rjJXAvzXyCQnaIBVSKdBgECg4bw8L43YZIEXXMnqcyje+3KmI7tuPEieM7p08e23rUQ66Ir37Us17/nIc+9Usz831H6sjWweXgzqU3ch5gVeU1cc1yMA/uVNVT3v6pD533lS//9h95xdtfc8bHj396Z9/Nz9p/n9vcJb7hic9/xRff94n/KDNff+jooe2rrrzqVL7w5TeaXO5de9f/ysuWjOK/lCEGrVP3xO6/NwMxD6AGEPc3ZVUkIA4qnYpODBg6uIigs9j9npKCFnxOEuG47bwvfBZw0Cs+xqwL6Ec/ZfR2ZRHBT6MUK9fs20AIrIBXQ1UwlXot/X7A2gCKQEMV0GAAulrQgbgjO6EYzF4I8InggI5WAoRsxzs/azsNVV97XgKhSoPxCM4Z9NnsI5b0IuhNyIYBbRJ7hy+t/n0khWsnS5HJzWJCHw1+MK7oYKT5OGYNOqDEPdBhd9LZAWYnX4pp1d/Q2XaQ8KQxdJWpWsUsa3M8DKdaZkhyxzv5Hb6U6IMe+YxGgQZ+BDtERRWBlOytYFvU2RE+mGGrutz9g3/gKWd4Qg4UMwW+IQGTiQolKggiUtbMd1vIl04KMOvduqvn5Jix2xuCMySzzrMx1hQbrKvkTQigyh9yTisaCeDKasFmWwJxaY6YmFz3bE7G0rMHsJ0yG0awl72iNENLA2Ejwru1bOyLDmqFPAoHZlsQlZBZhelu/7eOWbyCrTcGFoLK7MR7BXcGrzCT70f3kL98BxUfjgCbhSraGCgEH3uUbWKOoQVbAw+tILD2xlRIjNF5SdHGd0v0tvqYIZrlaUpC/Se9aB+yw18bmEuttplz3LAi0M8ghnKjDdgYeRO0i0gl5/JDjmM9olJhJrNY2AusggiMI9jmKMXZTKjZAZf/A98abzlfRtwHVRrbYJ/bZY/Blgww/8h16D39a1IXUKAiSHYbSg6SwKRZ02L/g+akzKVjwB3xkbm5FDeiVi5XxvJQJGJACO7wbcVkbIxCXxvQRaa5LJr4kvQSpYYV0f5ktMdXOAwXNeuMYsv4PVO6CBvgsRiEOfjJRckXiiegqruDSQ0+rD3TJ18CO0aBAEviQedoRwWRCBs79KNBHgkky71NMLEuswsq+Aw2sBo2yaQRO5HDWdF75YjvmAnEu+yU4fh9WbYil6zj112bn3/hrbee96iD1//9L3jOD9z2jJudevMH3vzpq99w9b4DceD05H8Kni0yM3eq6lFVtfMvX3fkWf/l3a975n9506sq9u07efObnrP/iZdc8VcvufJ5P/rg29zr3330Ux+9+ZE6snUgDqx77wvuXf9fXUwIR8DRAT6CwdWMaQqAx2yOUH6uEtLkCgElOgHQMWTErXA77MdnlOgMwvBbMSmDs/Fr6vHQDQBLuOcuqGo8kxPBPQr+uYynBN+kLYL8mBwTgsZSFQ+ANFWBgUVGn8aYtokBZo0GbzzRlUNG0BF08JRXg271Og7N7mgmCeOPTpoSTqQixg6igHQ4tZbTAv7hHEI4g17+sigIg9NjgJ9WeS2NoVxu5qHWaOeAYASOJpW8QkYLghp2avoQU7NNmztmJchDFtBR0FlTwAInmR1QQP/D7ICOsNmGTWXcoQd0N8D7oX9rO0QETnjHjDMloe9gMzwOoBPubB1RoUZFGxZXUn+PM5YyxoxZBN8fBj9ah6bZ3Obn2jIhz8P6mAKECA+NKJhI9jdthsHxRmy+e5NNm/Q47D7vbfy14B1Ea9xxRbPImzJX836Y9trm1GmzkmUWjNTXKLgTBSJzp9sVwDH5KNFfqXPIykaTkz4E+S5iPYiGjeP+hbYOHfWCFGSiSjulRR8BncbgWKQBlhfsdSUvIBvoJejVygfjD3RkFUbDPig0FBYKGkXpkfOgQupgRY+erUTRIo2HmqVCUQTL3mfcGh9p5QASLN2ipI/vS0rhTLFgX+HQRWzje9uZ1r6KJ1jih0qacMLbiYkrhKfSmKGSg724W7yV7Qm3QANbJV0ZXR1rmIL/xHNr/95YAXY0hiKJAfYAr4d/WUhLWXsREV1JbT7mWMpYFXzXEEkpbKlltaKx2hxT+9ExNWbjLhZOGJNgrOY/4FuxGzR4PPtOyL+lq+lX8bw0njVCS44ZrwX92Wiubdan3RZnmOwuKsnnsYke4hvYhwipTnY3C3awF7SqfQ7Ml9AGBVXAJ/kNKRtsyjsizmawOI0GKypiRVFcxQrYi3xPDH3Yitja2opTN5w4vXNqZ/vK+z785Fc8+lm/8NxLn/KKG44ff+mHP/2xr7v3Rff+9L0vunek7fzZm8YAqKOqzvzTj77nTr/yxt/4iR9/9c/EX1/3qeNb2/u273bz2+9/0WO/7I9f8tCDXx6nT19wxeErPvSPD7/mwwfz4K5Zxr1r7/rfeWmX0Wmd97hUwVSVbPKjfZX/lhutsEoN14B2NHsBJ5TeNhC5HcO06oRgD7CCa9t9OTkM7nl3KshpZwOcXPmcV7hC9IaAROOSIyGslg0lGkT1BrvGAb+w2Lb+kRG10+f1gV8M/ccd7aGyzw1TYgHgrWb1ysBEVbZeYIYZhSkALFbLY8VsU4T2v0OE0DRZwIuEm/KKJO2a5PMX/q2qmQpUUI0cwQTeB4G+SLAL7wmr6M/h37KMpVjj1Y/kc3KOYwOQhYGCK1EpVmOL/ftSpEuzaC2rljlmYajLqTYRcHqCqz6KFd8ovJtpgYbpzy7tb53mTpjYIh3S636xd6McImrVDgjdJ85FweyssYdO3QKRwbSVs0oVwYN8FXhAf4KOmuSz9zTjhV5DbyF7BZBKRFJ8hEj6GaglN7K0ajt4Xh15TLOmmMUxtlQFl6VlqiBCLtAGFLDgW9d1zkWlgjjqPxKN1onIiErN+GD8JhVi7VgS60kvvqveSTpozpsQPuxB/FABfbS20P7FDGCLV9tjKa7GIB9CvJDGC6Mqko9N+IpWYV/8G7aiBb/cfbRMDpPwhm45r4nTpc6GLukMzzmVMjnDxPtrt4Zs3UpiXHEnVZ9Zx+wHIRSzmyVL19gkD3mjlUsSqQVlsgCf5BBDSVo/kdKfiIq0xMUv4N7ELPIsDO/MFmPpI46EYOD95F2ZYDPdNZlFf4fkSnxFL6OMhXf+Bx0ooilhyPDzS3kOnaiIyLGaZ524DFqCuyOnwZQXFTE+wRf41HrRMcg6XtSOUA+tm5CbbK5Mbjz3NDK04ZmXUqSbESiu4Z1f2YDd7lbFBpZM0kOOYbzYIyGAsVDLav4JI9hqCfunYhDtUepDv1Pm01JYNamxs529jbZ91jAl6HEtg7f7YquOf/IzO7e/7e23Dz7oKZ/8ooc/9ckPvdVdf/95EfGXf/mXv3bb2972hti4qncVfdv733abu1909wsj4kPX/Omrf+tH//PV9/rdP/uj0/vO2l/nnHvemU9/0BPjC+7y8Jc++9In/YvMrPd+8r03fe1Vrz196VU3Ylx71971v/nSktHFPt2FBRYl4EV34UHQyRrGGgzKqbRjRRhI7x7BQDB4r1VU3eoToCxnLCcb1iubEtYIa+mwGBr1LEzYLnlZy3gxvYGHO24iOOIbO8lEA0EtRjmAsHieYBorwQ8PgKIQ/LWjyrGccgnMatoh7BUMYBgkM3DrceUSycOMPeAae2aLUxvPRfSCfGu/HYkaSv49O6nibCc2bZEcoDHd7qIAKEIJBZaejc+kLKyOlwVQ/Rw1yzJ7OiU4psV4UKjmRn+y8e5KeVAgRzItD15tJgXqt0CXIpAQwRlJc1fSq+AhyE/24RX5KupLtew3Qipqv/Ocs6N8XskPz3x0HiqmI88DIui1eEys6blXJmcRaXsVLEbXOo5vyOSMMhOcDf2j/q8ZueiAB4lH6AIZgETJE+NunevBESeQ2HagDdlrgzgEIf1syk5nmdnVRyBMgaknxCRk9JsdbPoRGLOdNj9jVP1ZAYcZampF448IX3rK8VGbhZlIACKCAaLOZkSRTGOmXfVghIDVdbtB44L3JXH/2oEidKpxjqPD2Mv1bW0MTfbPY136nqXphd4uOTalou/AeZwG/G6FKAS6KhPXU9iDZXXa+bX/tYLnoEozJdyR05IC8Z7aGVGYTZdfHc2bI+ZxQu1PSG9GlmbcpuJQgtviKXUzu0046xBNwK2VSXCQD7TCAi+D/pEBQGgjH8wscQl437d6vaCEQ9iAC+/UUW6ZZMeSsj1PGPSGu16FIBtBPQqlRTQPzNaNcQiLCB8RlpSDt5AV7HvY6opiT9tXtm7CBjNXox3foaAEjcCy1Pavhh7C/rZrtrEQD+jzaNu+sVJIFwyfdZyRM1ZJdkVyY52RF2pVEWblsYus4yLnz5rnxM5V3UAXhxxMttBj0zfamWeMutGgIV0dWwfDW+S4UfzZH1tx6tSJ9fhyYrniAY/c/sZnvOhVT7njg78zM//gwJEjW0cOHFgz84baOFKiZwbXT37mk1900/Nu+r53fPwDX/kjr/qZA//+lUc+79rjx3a2zly2b/V5t4xnPvyZf/AdT/6af33z3H/1lxw6tDQ2fCr2rr3r/5CLCeG6rgwXpgv5Bw3XrIruPSYAHfZry4LoZRDpCNzVlJyhFzPVX/JLBX0C1TKHM1VGHVg6eLCQLhDtLZFWJ4R3qInOMaYGajjjFDhprfu4W0mt34+AoALvKg3gbcAszG6gGq4KZ+XC4NFnbAGUw5HJcWUunV8sHHv2OAY1ClrIc0t2cA83wki4pOBzCnLgaJWkZNSu4w20eYQcb0aNRG2N3qRmDGfF8LAMxhUMgXTLw88s07xJ+hPsd1dBg2IGn/oLdEWNabWwSMS3/Z7EYRzEzyF7eEItYfHYb9rMhER64GJJIPlivSBRbXZUyKnTKaeNqcKW/sjB4wfuc1n3aMxG5YMR/HhwVvxXidsIAuWwYW9VxbOrFAAnE4alzM7Yp4L6MUzolsakWMdsEYCBUcIWiA4doJbzJ7mkTcGS+F+JT6qDQehk27MthQBfXP6c6SavdLC9536cda6a1SR7Mm4zW/VZpravKbey4HHYPB/UTI9UQ0v5NhKhKSFBBSygk8Buw5hduo13giJ2zx6P++eijQeIahOYhHGujcvALxbfnPXwXan3u7khzAYtznOlSVaoQiKEJItj4qjUJrheoSV12vtqbtt1OCO4KVnbygL6gQMxkjEW+vAOJg12A3+av46eC3wc/GfCHltn3F9gFqg0NgeHDDYe9qWSibUolyXH52sVExb4BekvyhHAHni4lYUcJG7TJjSwcNpcauWCFRx0b3C83BG1MuZZr8YE4KCZwZC/jrYCf7WSJ2wWujEsrU8kfsCOplt4VnOHwMXc0JuoKZmb3jd1e8bMKWQ36VAz1VZt0QYS6mD6F94H7KPCgUirOaA3ZZJyV4MXaBzAYmZ4kijaltzVArUPvEaxNfZGWI9f/5m6+c1vvnXgYU957//z1K/9t7c75/MOR0QcOXJk6+DBgzvmYz0Z3H7NW996ZlVdGRG3/Gev/tmv+enf+NnHvPmv3hlReerMM7f2PeTuDzz2Dw58w9EvuNOD33r99df/RR80X7lxNMXetXf9f33NM4R0/DCyTmo6YQGoboI8rzbEAW7jIxiyV4pkqOouva1CUDUa9aRrejYMWMIbFEZOZNJBeIhfDJLGa26LnGF1pRuOqsGL1cS+R9uLm2OMUCIVmu0Z72U2KLbzUvU0NRQs00JiiAFMy/VsxqD/XmZXNAKoGGPGYtSMPgQ+N14fID/aaWWNQK/Ao+pgaeY3N8aopgC0IsGKUV105x0me3xA4C5bnNPZIWep4Vyhj7at2PzekfXEoFMq0lwh36AgugeOGoGDYTeSftNdl2dQ9u64mirqMpxz0qE6RU432Qn7awXwJBmBnz3cul89udA8QCBjvSEYi0rjAJuZMKFgVDLowJmKE39QZGi5sH84/ALd2d9TiAqIMPoOuDjXCGyhLeLMsw7WkNR5YFKywX6aK2AHplRvQtIyMtl3A5GR3DkUvGS65jiG5Dkx89EWU6APNCffUSJ+NGApCUQCh9kbdGQ4QqKqN+yISJNPBWyj+V8Va67UPdqxNLnNuUzOFnKW2Qiwr4ddhGPTD6oFAlsl4D7jV+04MlJ8QqIJvYUcDfdla5AjbLdpXTZsswNmFpVaD6oHlsBVY3cUAlQF57QK5x39Xus3dNsSy+L71iiuOU29k6P2AxMet60MXiaxd9rh0fS9TWcUOsnnZCUGH0mTxszdUK8lsFmX4JEOmjoqXIDshG2j1tL+BoE8Z86ifZMVOoiDtrLG9Qc0uB2FbHVVI7Sxal5UVCzYcIa8stU2KRwVRnSv8DndfaNv2x4Rmn4yu+1K8WAsfW6sp/yDWCmeAR9bNi33ZeJFEa/5HJkBS2jfwexetib/GCwQTBv7VARmJgeGWckDegfeAKfLqLMCHmOm8OcIlvSNKgCtNq4g9tPCzPdkxJjhM12EfCZ9JeaaTfcKnWXZqlM3XL9zxhlnbD/qvg+PFz3hub974L6Pe2VEvP5Rhw5t/+PDh/PSzF07flZVHjx4cMnM02du7b/udz/45q/80d/46af98uv/03LtJ64/lacjL7z1zfd99VOe96nnPvzgF93tprd648c+/bGLP3n+Ld5y+IrD614yuHf9n3htT3/Vxre18RHAIgEE4wbYb5aegeGzkIu/3TCDeLKbDAT3nZQyIHI6RothcV/IxY/PuMMyv4/J8QJERmOLAVA7JTiMJqkIvnALFjSif1Sx7RtMNvqnA7yWDaAEDxEE4aFk1RCYuGbPw7AiPihQoGKd258RepdiBcijG461VHzks0PQw++1w1gQqMx8QGOs87W+4IBuRTvjWulRMFMDuhXIuZzJ75T/dmftz/H5XeQh6Wwl9pkb9NOBqAI9+ZeKwMrb/s55BkHFbDd0X7OsGQyU6NX3weCZuzyyebyLqaAu4VhjCVTMEUhjVnXmj5g3s93rtDPTGeR24LAEknYPN2IOrlKBEMN3BKYl/uG56bzIwvJENhXYHXP3DnPzc3gAwc/ALNcRJHpIIjeSa/AjJ465uWrMpRluBHzEi4R1jqfW0KwRgqvJ7nxL/GiemRFoyeXGWGO+Z/ySWl7qhm084BgJn5oJGjahAXPbfKcLhlOjuLZSeSETrA4wHlRMBYOROAm/0d/4dbXCWNPR/oFjzRRuYvYeKzoUDU7NTzzbSDZIAtvsNpyHGRMoZOuSRI0BbDi+jDDnI0e1gVO6yohoH4HTePpaobvcAbrRqDF1s4AB6dJeYbbMDIVYm3zzHJTDm9hifAf9IYRS9oFELGy1gmQ6ycl1wpajcsbaxosVP6BtLFf35AMF15w6UNFrjGHcYzL35ZLwl7FZyIJA+tzDsO9Ks4Bzu3hQ2IQ4YkhjNcMzGkKFKi/qGggNUloegwzbgZqJ4spHIT9IDDENCgRK5lvDzBFP4uZ4YAOb8oTeWceLCn3uDmf/6tin4qM+CdOJsBn38cFWbkWc2FlPXnftcpc73Wn7YZc85Pe+5snPu/pBF97137/9Q2+/6U3Ou02+9qqrTj/w8OGJ3KrKa665ZslxzMTOsTr12B9+5U9+zQt/6puf/oY/+aPTZ+b+9ezzz933lIc9Ib7ofk/8hQMPfNxXZ+Z1/fgbY+/au/4PvmxTmZ4ihKOKCHoMs8rNnfJQAdQeMeN7P8XLQVx4RfTTdzTy/tf9Z0X4+y21+HP205eywMHQUXv9UsNjglII7GIEULwTKNppYpUFMTamDhY2A+LpvagOAnTUQy/haARbAkFyzwwC4CCWElV6AxBpagZKy5xTSYmFe4JUsUqJGUdUIVfyvSLWERCimj8cJSqH3fcave22Vw/LHPagL1OD4HMpgFZC0WPG7CQ4lx0MtfzXrnIvuXD8WnQCpwCZKYCiumWwCk4ae7wo3fl7iiyAgKLS31H8VHTAiTEJsSpm64wCfDuqw3TUqyVS87L3mHApcKceRs+aVTCx8neBlZLimfEXD5+Hc2fwW+FB5lrgAQoyqDRvBEtpvCdPhCWUNe2k02VlhsINn4hcMdu6WYjArrythxYUFHYTNFDBO5Ur8KfGiGSz0sm1j5NgoOR8g9x6+NxoAuDV/WqJ+xg3DhRf0rEJGNY63O8duR1OhRCYRgQ3OWLAmbpBvM6YkmaOxwsAbRWF4kxErmkBu8H5qE4xvmz14wikuz0iAFJpiyric5rAIm31Q/Ok5na0/LGEW2F0Jgp4FVheCuzyzaN8p1jOljBWTY0zUuYAmZlKUd+sAqiiGJ7beFeZYjChgicYS0nf02h0nzigpLGGdmczyZlme0EsDSRUjpVIVuBvowfKPwYuzDlH9WHr/V13VFXc3AVVY6IPxdTjhL5St5JMrcg+OgW4Ajn18lAcsRDQHfmXxA6kJVyoMhx3+8/mayYNCwl1um1hB5Nlka5nxDgHcMh4WZStZxSxmWY28X8wBLOoXLGRwGWJLLsdxAnaaMXexWv+oNjFu2p8huIsVg24/5GgU2M3WYwC9LgXM9QYG4r4kYYmMEHqTzflxWquIAhhJm+lMRF9qrEgs/VuuqHfY0dBq5V0a1li2Yk6cd11O+edd972wy57+Kf+/pO//DeedZ9Hf3lmnuhGPsZ+M6vaqb0mXrOVmacjYqeqzn/du//omuf/+Dc99tXv+P38q4//9fEzP++mZ97y7JvFUx7y5N/8/gPfcugmERe+/I0vP3HkyJGtAwcOdE1gb2Zw7/o/99I7hMsa8z5aHoyWzaaMT2TpDb+5O5gY+GtOlCGELtm8nkGVd7pvo9vpwwjkoeHvpgWdXjsA0IlpiQg6zkaXQGM8ywvwUyM9GUtre5ZswvWks/NAaFHHDMjT6EIFEFU67I7tbVbp/imp7MizOsCCr4HzZzDW93deElEVK5dwKmiAHEkvk2u6WJMUBJIjOAe5C2ZHoRdN61psyfm24NwnNpm20cwalWPJ6hrFM5WogxObJGeShgDXHUOPVrGXBQR9jy/BYphe4ECPOUPLt0iG5OnfDF3sI4WRFNNhKiEfLnxlYCMvKtkprUSlvzqAyWkL8zSHT71ZNJM7Bef01El2SHjt7E2nQROHWBg9Cggmpm7Gz+/DxiMcY1rAFQgCJ+FylpYo0/Y+ggGITgGrmz9nbIBRBRzgEBnVLon7gF9Dp9dSIuPnBQbGXKlFB6Blo5/ZzsLsOmInSmMoK46YrUvtW4tlqoH38iAO6PC0UQjG7zbe4+RGHWT75ktsSdqScoMhJ5Mc4PckPwTanoyvK/sft1nSEurD5TZCcMl/NAf7lNwipC+YSfHiALTVhxtRdBWkv32en+sonXJ+KZGQjwELIfMSjX0vSed0XVG3xu2ySy23DdOn1jE/5gQ0U27UFhWnqEcy++4lMENNVvS73Z6rJmVuz0/MHDdvLCS3RLrVfg2zR+hF8MxN7F6qAgm2MIJuI9nCcRODiLUMrQxKkeRljPOEZ2yxHagtoaV9Mf6xFJsVa/Wnd+9wnq4VSn02GO4K8oC/prtp+4cPAW4Aejvhq/aXYDuKAaCP8U6ivdYtfwOCnJM9Tl5motPkYfopSq3FSb/xDeyy2yAbzZ9EyD/FZ7ukf8TVCXfcC43YYTuXOHHixFoZy33vcu/t5z/u773jSx/1hT90szzrJyMij9SRrT5EXq4r05d3nq6qC/7wA29/3tf/++/96t9822suedtfv+dU7N+/dfuL73jmZXd4wNue/7CDv/r4iy878rGPfeyv8/M+7/cPHTq0vPCqF64bRO1de9f/kZeWjOo12f7h3nP3sgrXbQQV/A4OLQSqgeCEdtvBIYDQgs8k5DYoTN0RMee+3bMB/EOOEt8hiKgGFIJv36NDH3rc7ADLSS3Q46jpfqZPMsaBwaO6p+VO2mVOFfCx9BK0hwWFaQeyj0CaFe+I4IRMqWpHWhoxMaOAtsdymqYllwblBnjXg9TMnXjS7SP5kJ+IKG3greC4DPDhHHvLa9cRBpMaA/siP8ZYlszeTVCzCwoZIyy+omSoiUyIPDz3ALE33GGFfZlkit3gCmNJzBh6cCS9ZfjQkcWUKlYzroObggaSGRAzHLBki7Gk6SSe4T4oEXx3E8Nf6ZwVLNGeEsHURqU2oaepYJBUVfPaaIE83fF7YFEhehEsRTDAGIGpeI6gkaTWTBM+81VHTCJANzQ+LcBjW8ELm1Oh0o7iDzREu8om8SD7WJdYhSkeIKYaZ2JJ/THskzU03zmWRNREPcoBnmM7fASrq+GozdBADNxIUIylPkG2ytuBfaaIiRk9oJsXv5ZOCrt/bmAJWaFbzZADCwmy5UUM44YdAr4A/4DjPaaizgE3wXvFYjXvRmL3hC2Fc12GIJMz+Ehsob6YwaJlU5fNjCunGbfBZ8eqTnZW2ZcBBNCc48R7YVqCKBug+hArlJBolaFsTnomPwRd5VG6zQPF26V/ITpANnkJRQJOQufl/yiDtRth8RMvUFJRAomEawY3IOIjQtc53de77PhmYdIUUaTJeD4dB4Jdk9Wmb06WxlfoO99NxXPECw4iIrT505htXHi/op9mjRVPuNPspM7G1yj1azrMBF4WP/rKpN34JHDmeH8QiiqykWhCPjazDDwop80KFO6o8HfF/B2KYXafryrhwCdJtx2Cf60LS1Tksl3rzs567Ppr8/a3vuPymLs/+M3f8LTnv/Zet7zDK48dO/apI285sv/AJQdO9zLQSL2AXe/95Htvev7Wze97s/POe/NffuYTX/GPX/0zX/tLb3jFHd/4F2+Jk8c/c/LcW95q/31uepeTz3zok773Gx/+vDMj4sNvfd9bP3zOHc751OZupHvX3vV/+mWbymDZooEGK6P+iABGkZ2Zefr9AOwZZaqwy6VViK38iKUcuwrNvNeAEsFjVrBanAoihVl6SZpBJD4WaZZ8OhgJ3NrjRSQ2WxkvcWj1jQPv0lxYFWRhiSNYkgiAAHBrL7tBe4jiEIgyyggNosgrTwZAuDbCCG2zbBJQ4GyC9iCDrnQGZs1iYOFXTZgOKgNDqJx3P+ygHoxnVbTER7XV+khV0TsQhQ7KzizryJ8Vc74k7y6x+YZKtbXDmTexqoOxfs6rvaEAD/eqDSRSVpiAE57aVsEkso8aoUJGhAU7mte5EZmHfs8IzthOiUhk76CEv30kvYQIfMKgLbFQsGeD3eXo52BgqgJz2E3DHCMhNI2Isp1Idw/S6XTcmScve2E1m1RiO9WfdUCmqXEFNnyozpbSaPNeLATUx5GRLH6IznJ2ZQTeDYWaB2Z8Woecs3pXaHy2Vr8nTSwc30BtkOBy5oM2b1Iwm+DIDI8dD8c7e+NOLVlHcmPyQD9QGmKcFWJsppWFwIRNK9gb9qxEUdS0jhh/cKkgIbzV43PB0VV49KfkrLzNiOAMn1kN7XrCT3zSmAbLcxmUq3RG5Bo4DCiaPzy6o+QrYILFMz4ruEyUs12dtgObN8kjkJLKtm9p24yz4ruW1DcfWHRBWwBAJfJpdjzNzvdgyMO07lL04U8uS6SD8bKEdJJScZ0srGxWMUOH3cuvWSY/ZFUoUgZbH4kfjhgRveoKvsoLEzpeha33EKua8o1Xb6AgzCn9nm6F+agVnCivxhYQBrHP7zquPWHvVtTj3WUDjQPhLDLbrhL70L6tXIEvR4KPtj1h3PUeZpgeG/N8HCAGSJaVsWxlnN7Z2VmPXbd103NutvXMxz09Lr3Dvf/B11x54EOnTp24y5vf854/vM+d7/zX1QfKH6paDkfk4cOH68UvfvE5cfa+u97i7PNvGhGf90t/8uoj//p1/+HC3/7z34tj137qVGzv23rQJQ/b/7h7PeK3vvYRX/raW59zs1/55Gc+ecc3ffBNv33lva68Lvauvev/wstmCDcLGTcW3ME5uw+dw8kpaJscRCioZLSSBIhAwOhxFuJOj+dIGRyRB0AIss3R971wJAwsC3+ib33cT0yVLTnhCGz3HhHc4Q/vQLh7ZbrLJBiOtnjQrbOKjofg3WPk+1IYWsqpNc1MRFk1XrWbWfO1ovpAYAun2HYFEl1WKOmsFKKx4hsDjKsTzCTF5TGF+a2hQJxx9JnM0Pi01KvBfU2+M0L5twzoN6floqp8Z8tb8kBQEgz+9I4J+CTlpm5GcKnl0OEMRjgFvaupcQXkLSsMqwMQbe5iAY2fgRnatp4MLQt1kChYZRhb5EPnyPdQ0L+Y04feyHZbD6P4vO+IqiVIitu0AQijONmAfYakpaa7EMj08Jqv07tOi98U4QEDHmQxpseLYGP0sxnQYlywff1tN4Vpm/pChb+mlqjD5GsFX9itiLaRoTJ8/3OXfYT02XQCDVKDucYqRy2K/VubFiSjXRUxrLCAvirEQ9y/S/6wPfFDvCibeSURQbnHRrEJ56xFTrobPf5q4yMNTa9jPxOahq2wZZMo5PiMEI8Poa7ATl2KoecyrHBGSI7gET6wmdYUzG63HsM2gQ2yIiRw43GQVT34tN+nhKj9jHbnRdv9XOOEvO0QKnUNsjdFJ64LciVb+jJgPYbreml0m6Q0vBIs+9RTd6hCHhuaZngSdt9gw11tHZOhw6Sv2zFc86LKUv2xKr+aCY2IzV16II/sc4Sh71iWWav+zljGfXhVLyJ0xAOWYJPDM0sm2XhyLTeTtAvxkKskmpdJX2Yz/BvFKNp0RmClktKtnO5Vu+nf0geLuGkw4TCwa6Us3AlbVKGjuRlTY4QZ6Dh4TimZH+r3NjPq5LWfPn3+zT9v333u9IBTz3no049+1SO/8Be3trb+8t0f/Yt3Xnzh7f5DRMSRqi3MDF6VuV4VEX/yJ39y4S1ucYu7RsRF//oPfuVJv/p7v/603/nz37vJJz7y18dj/1lnXnTRXfc947InXvfUh3zBc5965wf9yveefPEt3vie95y69M53fnPsXXvX/8WXEkJGMR4EyaqTfwlIkYRFfzIC+gZ5ehB/woKCBKCFvil9BYwRROonwRH9w5kEApkNVAokTuYMvT36HAHlfMdq4zI/bUEdYTk3AlIAsGEcl/w7yK5rTO9OVWj2kMBtTiNL7w96FdzFBxaUwH76OneHvSu2Y2ZA2KPjkBAgqMbOwIHO2PrrsQ8HNbxD9m4nTGKcJrJdgxBt4HEyceQSP8hAa94ic2MesVJL0nJiUwfsknll9k57kBMUGeekpc06NCdW6QEdKXjuQT1klaHXUMBTC/gknejJ9mFXWMLrFV2+Ewq5eNUmvS2b6a3opGhh4DAtE6RCDQYl9AEH0yNwDnP8JnufluF5WAH7xpxC9exYtW0hEjFDQ1PBIUhO/VM8R2jj85EbwQ5oKATUFnYlkgjxilX9WmLJGrNkiGg2bGhd157ZDVGBqlbzjzv0huSf/QmSoSic5ZjcHX/MDpgVMmhGYQ2fpwVczjDpnSr/hncleUD+oJHjNMxmrNngzzNYWdhqPAbtLjNPqqIT5bLNVpaFM5FDf0ZHek9WeAMN4LJhJvqlZbLlM5O4DxgnpQAODLUw+zM73MRCb9v9nFY+ZszJmpiH5BOc2cRN5wGTmLLkHnKpUFKIoki05pvbpX6XJUJl+F0oXizk+SBEOuQ/+ClwpoCtmzM6shd91s/AZol9ocKgFbkkDVfC/sR8yfAtuHmjqEaRAUMrxuxc+1srLg4eUAMDM4rhGAVHYzYEg04xxr5q3EVbJn/wZLAKZYXuOcGHxnf4HSbUwEkhonZohZ4Pv4BnM9KSV9jLwC9hUfeJGDBTokT8UWgN7W5c0M2s4Fm/GElpHMSusDYbW1iMMz5DT8Cnpc8TPH38WESsyxMe9sR9F93sdj/xvV/4kt+58JybvPtj1177iWf943/8rtdeddXpo0ePbl9xxRU7mblTVfsOHz688zUve8mDbnHWTe+/tW/r11719t9/0b957S8967++/ffO+OD7PxDriZ3TF97uTmdeef+Hf/JFj3/Oa664/X1/ODNfHwdiKzM/1vzdWyK6d/1ffdmxE1wI0j/lSICtBcABHtNYQ/85HLCKqsCCcGFLOPUMQG2DyoypWf5auz9j8jX5cW8Q0OVh3Gbo5N5OjmSeDWn+1FhGhQCPPUwRWvAdB92UGz07CzTrAee0OYMBcGSCYcNBcCBnX8O5hRxR2vl96t6DaHSNRBUzUGV0S15KxvjxCHz5XoOCIgUvoZk3E1g1f/RZWr+bCTfOuBJvQDsq0AgC58AG988OlaSkdvOkioLupgMOk7OX03ln474RkJbJ0+SUFqR2B9wpz5dkpmZYMmK3zbBB4z34I9drf8fEwyB/jE6e5ebjndmGgHY8B16If8CIqXqPMU22pOGohoPxV9BmM5h0jz+1pSeXJqp7BTTepunHoA1BWfE50MOdW/v+MWTNtjrEQI9zkktYUBZW8DEjYYIjPBmJSfGjxVg2q9HocZxR1jsbQqymr7PN9rXa7BgewE/IsXUvrcfccBNe2ScvzFIH9sO+avzdm0al6xtwD7JjEu7Y1m2gBwsmqSc04w0nQqhve0hJT4W5TmTFJPWLy2UVTewGpECvHOHlMmAQa0x+ZLJHW02S6EI2M82wsLK0buhXcwRy3ly90uOY8R4KuJhvQYuGaSFSmeSm3U1Dgn9Y535IJgYyF7gmXskCKD8UM5QAGowwyXatBX6Y3NCf28vq5Ckh8qQ6U8tMN3kdvF9FD1IBe05tNsMVKWEzXBhLhiXFbQ8OlTYOrDrxpLsm7FrVsCVczlPrXeezukPcMCe1Lb9SxiNxZJou3d194umwLwiEjD0iydVIW4ocUbHVynzy2PVr7N/auuSiu8YTLnnEB170pOf+wl1udptXZuZvvfJPXnnOE+73hOurKuPw4czM01W1HDp6aCv7nMHDhw9vve8zH330v/pPP/vPf/lNr9z3zve8q+KGUyfPOv+8/Q+7y6XbX3LlgZ/9ioc85bsj4vzffNNv/rnvHtrj3ksG967/qy8mhLTDjUu4oRmhCR82gHiziYEryVsFUzZTYd8y8PPKqBqyP+YQR/SYw7OAD1GOEkYtKFJMKqdLKn22xO+np046KQ6V1WC1NwNhWgCdu4bK3vF4yTmBNfN6fzHACpJyVajaNl1jGeYSyZmKrtAR0F0ui4Lr3OQRDpFV8OBLDBGwBemVDEYMK94ghhg/EXhgwOCTM0qBHd4coVMODpmOClVWBJXgI4LlscsiAhg5VridiQbzyPDDGh70ZHyrIMkqwYnBus7XFPAjcZfjVEI+8aA7VwG/QjOCGAPZJQWx5XAb00uDeps9GTOP4EOZtMkdtsnd9VRaN7pcR/zZ3TTIovX5tGmGB1GKumjXXoV23pcFhmnYQJtq2jeTA9c/Sm0CNNHmerhrZqXbwswHk6XA7OmywYPxfbU+AgadvvHVvCRd4jae2/jGmMtYjbYsOZ7E4nLAF+NeTxZKzfcwoAt4HuMe1ikI5QOj6dXmeU13IPciLcYDyDeMPvJc2CsbMPzFCKEbFVH9zpcn9XBPaFCkmW6k9cwkrj/xjJ06F/SfasBxE9qBEZgvbt5ZDK4hUqwVeKVgyokCtKc+Tyw7NJ1suvlcmkjN17iusASBMRhszf33cS5hjeTo2Wtig5W7ZU2knbBz47kIm2ErjlseQ9O+4PD0Lm6l6Y8xISGf/mZaLg16mweUmvG5Zt8yXeVygW4Zphj2obgSkf1CccvPxije5vRnTG1rLPgLdgr/ryIodDpn+8DTJNVlZp9jVJxRBs+kuOS5jMrGMrAyM+vk9dfuxJLb977zJVtX3uOhb/+KK571u/e79Z2vzsz/9s6P/8XtDh06tHQyuGTmOhLBozhCYq2qh7z70x/52u999U9/4c///q+e99Z3vKViXY/tP/essx50/4fuf+p9H/emr77iwL+8YOvs/X/1ib8689Y3v/Ubqyrzfu5E96696//+S8dOdDG0rTTCTNx9zbhFjgngNPmfCDlCfGoegw6zLHD1pzv42U2Az5No6cM0/YLDnK30rCA9Y9r7YWMp3aBNoM5vMTOWvbslEqt2QjymgEGCAq1dgG9APznInklLLi/DkkTNPBScEyMR3KpZizUwKxd8PklfL9PrbfQHA8fRDnQ7oD/M44cCMQasNRZwajMICGDRzmlSBi5pnBJk7voHB2NJdI40b2XVOm0sGXZaoJxewOnrPRBXJap2P+OBFGcbuh8krQz+MhgAbM64eLzDzXBq1i1uXmCB4WDHfI4i9Mxil/kq6SYGNwWf0HUkiqQx2UsgkkQwaWPgd9CZKO24FwjCFI8o+oceFJnh76rAAuXgPYgwT28xD9u3QC2i/O6NSrjNelVGchbG+uDYZZzCI/XBnSZp1hjwGqsn993vvEvy4M+ygOfgU8vOYjTJAQHQ2rONNkYSYTYKHiWSV4dMvbsH3ZKdSXM1u1dBlOmdQk1FTDsNHzX0SHs/SsmddDiZZBO2SNMgy3C2QXUKnyvUNikO6ll6opD2BW9orRkVINoCMHbCf9pvRMYa2OCMBJjkKiMyFzvEXTaOZB/jHdzoBDPYQdPd/NXNpsfSfM3qlwoU9GUul5x1FrocCO9lT0Nfy1wofsEuu8H35DbvCPu4svSepksPPgs4yxELZzkumCCx0c7UbcXH2afYPCwnMvDqxGYCj4IKaNNoRtuw5/FznLGKgabuk0HErtghu4DpRaQoLfWOeeyonExhDmGsvGZBnsvrVPivpLNCu60SR5M2mz0ziWKjnrfiGWCKujn+3dxVFF9OS7I3k1qTzWbBdmrJ2hXLG6OptcLWZWuJWqtO33DdTuzk9r3uet/tKy958Pue+aDH//gVd7zfT0XE8fd95H03OVJHtu6Sn/9BI2VpnqwxEsF7/dlfvffw9/3GT3zhf/zTV2+/8W1/FHHqxMl9Nzlv/33udO+znnivK/78yx998PDF+y+oiPjlTiCjpsN2966962/PpYPpI2h4U/BUencLH3plXO+L6RpGDpej4IuTG+345kpkAxqfm6uaE4p3AMXOUmCR7BpOpxiwoRpfYeAGJ5NzEEjKsCPqot0KFVMtfA4YD4I2wqaxfTMhvfhuCCrEAmUFQqhODm6Mk/jSA1m7X+dXpTYOSa1Iy3S+BIMXJJiQwzoGG5aGhg2OSYKSQDzXyWJUZKzj97J+4DQmL2d1aJdtBwMZSQqG6KB0QyORSmXGSFqWvju3FJhyZgRHaDQPEDTsevcCMuzxWlIFHU58zu8syOBge1zJuZBdkVSVzRRjnEvrHHU/Sa+7VVRoo4PoqZKMgFJRASwsgpsKQZe7DStisMCTTXnvxKAzPnMjQEjSqRy/Wo/GLQttNCUTctkYDI3WLcpzeaaY9EXc7p/4YKngmSzVGkp+MvSYdLIMz7ygonkSvONmQV1TrJnIZJBEjSpIrmezuXxMSiUsVFEAsiOmCUpZ5FJmLtuMiPH+IQLggp4Yf9IDtTH4UdhSUq/7UcCqWKbkFz3jEBvIwmbSGyyZFC5IAhazfRUKtCvtSl4RPlJ2AvzhO8pgR+OQeFZcnSkbisB7a/Ibwu0yXtFkuStvSPehI9jwJWAXUE4tS3Sbi1RSqnfZ8JXh0IYeFc56NLyC/tEeMPDubsEmOMQo0RaNYRwomqy0sQC3VOgSnfCboCHpZ6eNyzLlRxPexnxKWNLdtA8bWiYeShFaXo1PWlLspUGjN6GGzQHqUesKZoHT7DlZyhF9vvqDm68p+R5drBqf2SD0nAOobD8H9hqmEftGq5Cp51sufxcfZmPHGMs3+CQDcV/FgMgM36l01i9RvEALo8g9o4HFJTUi/JBtiZpBGD1aC0mH2kck46uKWCK2lq3YWXfWU8evq6hl6+53uMf2I+7yoI8/+5Ff8P1X3ukBP5WZnxZBcUPzabkmrsmDeXAnM08vkbFT6z1f//63fPO3/dI//bLffPPr4o/e+eY1dk6eOuMWN913rzs8cP+j7vzgDzzpfo/6vsfe8QE/iWWgR48e3UYiuLc0dO/623pphrADQXfrcyUbV238lpzNr9JDfPnYK2lprQH/fNY9FVwR0CO0pt3wdGEb7slEr4AaUVTFiqQwwsC1HbaonMfakaE2HIHzCDoEgZueHwlSB2N+/lOMSjB4tmYpNKoIHo8Q7bwtkJmWZplctCOc7Z7v9JMrTZfJiCNlggq/hRmWBTHVNEC4hczobWiSTlXOPk2HFhNi8B4FMNILBIbDh2rGDMlcJpLBDkiihn8OS/xd/tQVOB/0N1eSXX/JMQ+4EVx5kH4jWjP+tsBu+tx4kqLTeYLPVnpUOXCaUVCtERehBQVsHchbjspfmCCCdFSR+x/ETwpsWjd3JYNkFBMuJc2SK2PkRACefFybgXSAALPDxMuUgDV/KhR8GgrQbhSN8FwGycIxZp6NJab1+GCDCIq0wYwsUg964I17JgHpVgvyZh3VTcLQUGKA5Aw4grY6aNZOxTNSq4CDrhXwcaRTEQGbjuC8TxQdXOYYc/RMyKw3XuhBb1n6royOQdsSLiNgYgRwax6TF+AW4w+/g01A0R3vzK5wP90Tkx2NEwise5O3OQy4DrpezXgAmzBbILnAvdadEk5XLGPhw3DWw7+YyLrRSVd8mTVp2yjIzDM7Nf2W9rvPSGrjoaCPYvFW7LARL/aJCmEqHATHWmRD9S7DdArj+SViVM6EtDrOY92g24BkEkcx8Sl9FFw2DmlX6R3e1GsM2iQMyW/34wXEiZtoZAxuTsRFsWoJJR4YVqJRyX38Ap5FBH0qC7omK47ZVJzQajTDRpdI4vJou6YVDABu/R3gioYXu6/ZNkY7GSNect3ayozIpXZqp05d98l1Oeu87Qfc5YHxmLs96K+uuO8jrn7yXR/0w5l5XUTEgSNHto6Md/oiIvKauCaxg2hVnR0Rz//Z3/21+7z4333P81715tdvv+MdbzkdOyd3zv68W51x6T0euTzmPpe/8/GXXnH1Qy64+Mcz81hEBN4TxOzg3rV3/W2+bFOZhtYU+NCPWuCjem00INeGYYcBBMIHgBLQLq21CbqD0LOBJPwMP+jshGwMWgw8s1sGnb4U3ccDJ55Tn/pcicmoXDNpgo/kzzTa1ToSSJ8JHJ2U0dvfpDnfGEvPODsxsz8iK5bQLm3lLWGWiRHG7KzkBbK/s3CmIjDLpwAIBOj5CuxImjaDF5OzZ7WTkb4kn90PllQq6cBMQkuiLMhqmguFOuhhhsl/wyFhJtSnnSAhBuwWzUQiIxu6lqklXeS9Oz67t39KDh4cFYMBJDlzCKbxTd8xuCVz0d3mI9QpBl5gR0I/Zyduce80C8N/PPhQiELeDdLU5jwb4xILFiNqF7vZImXP72JOQhO8MJ6K90ooZ7Y6eOhXLmuFrsYUnwmyzIaEZQjwhHacW7fASIlbzm0Tw6QrwqmKLax8LpsFgb5WTDN12mXRBki2GL3222TNHWGqgAeZl8lnQ0Mx82S4WnpwLrrZuJyWzWREkygoMMQGbjkFEabOkqcF9UFdFO80riQvhdWGwW7siMDBp6iwM1Hsuw2eamRtj91gic/ze4IYf+uyDyU1Plso0oZlulTQvNrgVnCZq/obCQ2Sj7gRXZn5bvzZ1GXyIYyH5hOgBxuYBd8CPYMc59tat3cNPGI6egH3RPvsyOBSUkAAsanpJBYbD4ojNXuOwPFS5aSE4UgAmeDPIqal64lCjs34Tf1B3dLadLlEww76ohRpBPS7kLeGxO9IrTuBMj2lfciukmN2bkO2s7aoTRSIw/qt6Vac8kF2dF/L1lacOHX8dNS6ffbZ5+Yj7v3E5eEXP+AtT77vI3/+Abe9+09l5l9FRBw6emj78BWHdzJzJ6qWl7/xjVsvvPTSUy2XC45HPPs//OErv/FVf/q6O776Ta+LD77vXWvs3x83vfDC7Yfe87LtJ973kW962oMf/4N3OOsWH4mIt2TmsTe84Q37LrvsslMHDx7cib1r7/o7cmnJ6KjEjD+mGZSczRyAPW7UkrYMVY6AyeMWOTV8MAGng6cBELrrYIcOhYBWE5YxflvY4qjcAcDokDQOBysEFBk9G1YO2O5QlvDlqgRFkNcgKPRDJRwA3A4daM1BJMe3wvvHGgsCqe4AZ9b7O2JTotbv+PG9RgbpntBoXsWdrhy6pI5YCEELNgDAgbfLgncqVzp0JerGiwQNqaBzQezoGjZOaKwWPpJRONJJhnB08JkeTAacOYaMtjaSrEIRYW43Imy2sR1hylm6lianJ4YcRuCXTCgHD7v/2nieutDqAL0Dz6vYqgYsnYGuK7aADVl6b+wduj0McgpoOPbSDGiY7rLfNB6I1+wRhrT0kiqoZeIrvefjQEHuM2hQyOGBEYKYzVA3exRQcTzhWOW886eVlDWO+fKtcB5b4JbB93Cpd1G2mqH8sEmzWQTg3SrPMcWDSX6tZE/zIcFnCRa8woHUPKqmiSTtpkuAniC2ppnpolkbQ1jtxNm24DyLnJPDQFtzG1JSfcxW0SeS+hhEug3aA9QzPR82I21FCwuOh4GhSCabR5OrBar0fMR6SwIS7qPYh4o8Edqoxsi25D1CvmUqDjW7EGQTnycdY4O08DnBYKktInDuJWbD4kautubib2ZLQ67O+GkW35aTcsUncD60UmCMpTh+n20CM5lo7KrmBLfZ1cZ1QkTaY9sSaJOfkz0jPiE2YNkm/ajviAkT6zaxDtwqxvQxDjRezEq3E5Mj7SWMmuZ5G2dVDb/SPPMCgieTxXWnEvBCewbGrz15mbQPiV/6Pf6ETbReuu+gbprj4Ljd13kXtiKG+jB7USw/qhw7e2/HVhw7cex0nD61feGtbrt9r1ve6dP3uvDinzv8FS/73ZvFWV+Qmd8XEXH1G96w74WXXnrq8BWH14jYiojT9n7ghW//yAe+4kd+62e/8tff8Xt3PfrH/zVOfOSvjsVy5v7Pv9vdtu56yzt95pIL7/gfvvF5X/efbh83eU1mXh8RcejQoSUi4tJOKPeuvevv0mUzhL67XcgxBf5sEPApNmVMuIMgyNmDSgY17oTZCf5lZVMtog8FiDGd78okjxgucOM5dRkTkPJg6H4U7XA5lC2/9GqzgkFEnO1k1+AyClRE0Wf28sKoRHzMYcux9b3BNCiwsTcOcVdAWHRies8PDjjokEknAwMgMkBegZMJIBD4Va2aWYL7hpP0Sjl45BwujQn8raiINS0pGEtl5+QIhBfHkJSdV7u9cjm5yA4oTLUSQYuCQvoueydo3FJGi/Rx4oJ/jbaonz1qRkH4sCwIUGCEBhB0gse+hM2GgZsDsxM+i4d2yXN8AX0IyE6+vGxskmBzoLqYglHhuVRQhX48+dCgioQtretj2TF0uawCjrYVJCE41ABReEIxwbVag+TxA7QHFHGU0KBdyRVBL2y1DOKy1UT2gnP1HKvGGKTfZHhF8B0iLpFznlcsJT5wrVMSyaJMYCyMwE4gnOiCHiNhzOBY2kyRzMu5Ev0nuUPOToUuFCpM/uMay6jxjnQv/Iqc9LHEQsgB9siZIenk2LxLGAxqGqFDf874x1ke/j3dPI0FWIGxkOcYK829U6TGm+IB8S58E3zOvJvC/taRWXtr4oFfvrHMagUZeA9arWFGmq6bKLXRlxfVEnrSvoR+bp4Dorxah2DuhBnYCxKeiik5V8IXM1dwS6gtFDyHBmEXa8lVhpeUTgSWFCfHJLmU8iXX+6mt4O/ZvKrAypd+JxB0IvknHoCvNkMqibNgymSUs5etJeY/vBDHviLN3coSojFy8j+LLblOYDjoNX1aNVs9YRhio3UUeAduIREPOgItSSflESF8Qv9Bag1zqSv9cSe+W5lRp3Pn1MkTcer4DXmLz7/99qPv8ZBPPvHeD/+5L37QE/7yrH1nfDgz//2R17/+l3tGcL0mYj1w4AAOll/P2X9WXHfihif89rv/8HEv/jfffeCNH33bRW98z5/GqU9/8mTE/n23u9u9z7rs8+99/IoHPPJfvOBhz7z6nNx6249+2XdFBJeGVkTUVVddFXvX3vV38VJCuPjHgiXad38zBZj9UxNUAtzNB7U1sn2GfwFc4U5Dv3iVHInbgqfN12vZUvJxxEmctCOGlR5kyRgAtURGv41QCkK4nBHjDlXGhzezPqOMtlWzisZfcgHOQaOUo80lCstFm+l+yIJvbIKKYBgP6BAI6nNQiOdwYWc3kqdMwCqfllR7AuTj4okUeEajX8HDchmV5MJYAuGDWo9IkufPMUzKiOkYCtxbGGqPtzeh8cjGCyCKFTxx988HkTVHhpI53yfRss1NvaadUekpPOl+aCZgqoyT9xuVeCsgaLwbxCO411DJUIzN9YsyRDFicxit+xNIGD7k5v0Yn2OEs9FYMYECg03N8qA72A8TDpExUer6ztnfxgUdSK7+NsnwIJYwEgriUOTgbpW7+APwW3sGQD34TOPAC75EGVK8GZehPN7/SNAwxmTwSB7Zb9Ap8bxm+2YXAwe0CZKNLUQi+JPz14GVErJ504qMXfyiFqf3jw/t0YkW69PXWfoXJbm7bpY/VqEE3uxQzBgU0mRz5osv3YxJTsDSDVonCynDZn2nGWT73BiNxMFxhIUhb8nsYzfnZu2oXXSSxA3SZTDuOmgVLBpWyG+SQD3vUBURfGUBwwX7PhsPN6ZRp+Lkpp7iR23g+6b/mLoo0sOYxPBV4nEaxt94flqlA9zpR7jXdwqLbnxWF94qxdsceoP3zjlmwxytyljsO5MWKzIh4TfeqpV5HlnvUvqSYUhxo3hJhsg2MrPWkzvrzg3XrstZ5+676MLbxZPvf0U8/j4P//ln3O+R/zUzf+yxH/jAWTv79t3ySNXWwcxjR44c2fKNXarq9tfHzmN/8tU/d/DLf/pbH/+H739z/PmH3hXrqetObt3kZvvvdc8H7X/0nR+6PvCO9/up5z34Cd+bme9/aUTEoViOHK48ELHiXcO9a+/6u3wxISRu5Azq00vfEQouiB0KxOCAZt/h7iEiDeHooDb80gzrIU8QJZxiAAJA1MPZ93kSpkPGBeJliQm/a7DCzqqZvfIPQeQC4LRlejEgGEGPNkSJEDhj7EjGmubERhVafivmo18EwJgJ8+ClAzgKsLeN54zkhhTkuylzVhIhj0B1VA5G52f3RjM5+KCECAGByakq0pbbYrdD3O+6wRkjS3AzOrAFzS2saYUMxgI1QkDMr3TGVPQSKM6OlQ6eZlMY5xQOSA6Qjy8LM/dvDNYjXnVnH21r8zlxaC95kxccJM9Aw5pdCPGh+nkcETLNthmtTDUrODuQsAs3wFSwyeVeGzzYlAtmh/obEVjk4sS1sdQLwQb0qL9fjGeBMVojU5SXFsSrh3W1/L/8OwvaXKDAMvK07XATb3hh18FZh2nPjQcjxu3Clh8ODztmECsscUwRT2VvsvCeVeklWLmrnc1EVf3i4lI20oLxpOHwrHeiIKdNQCZ+Yszd3lRcaoEwsARudmCpBM4kWtavJxY+W5YVhZUJEeJHTiGq+asxRtmo5D8H3iAlG0uE515wtMekd8Bz6xc0ZEgH+P4bcJM4IN4UMcEwghwz3KQH2rBZGwt84bC9psgTL4d5cIs+R3NFYfoEuBqyslkmAnCyEJNwtub/tFtrN4SVAo17XG6a1r6YOeTdfFqLK09j7ARcwrOaHmufoXHKx2BnWty9hN5tjkARcJKsxU/EnUlXDLfAV/ZclLvkJnxwEdfatuf+h7ZQxg/Rq0m8me/GCN7kPgZ+eMIdFAFRUUETtPnuf7AtYqfWnRtu2Il1Z9/5N73F1kPuf8XW/e94zzddfKvb/6OveshT3h0R57/3wx9+5wuuvnrfRRdddCwi3nfgyIGtiIiDBw/uVNVWRDz0v/zhbz/lu37lx778v/3Fn97yD//sD+MTn/7o6Thj3/Y555wXD7zrg/Y/4KL7/MHD7335d3/RPR/23sx825dFRBw4sHXoyJG6KnM9eNUuIN+79q6/s9f0DiGWZbkTJkYoA5u+LQPWAVqIWDaCK64ZQYBzI9QYkMv/GNDnHPzS8fvjqG53W1Ow0MFAIDAqW/JhMy0MHjoaWBgY5ADesAp2BMfPgH/1hjwsjdASFAswWD0OJZOYbiyNbg1M5OLZ5oGDeX+eKxynSWxjfDNwz8DPJUbWl17SL9KVC6q41IgY4ePKAEviLyZu4yd4nrHWarObEVEI3Mgx+wxjUSKnqrEHvQoq2bIFxNSVNMoZuAV1WAEpkpaIqlWzjdQfU0YGLTHRTTeKg7fteV0mIfSH5825F3lQlq9mLAsKB0XZYDmPq5RybcmVQYcrd3gc54mfeFke5HRSAPrQTKkGbna9wRdyALbeMnO2TGXzGasQzPFdGIKJAigKyPUYy4oxBug9bYdfQKQMuMJ650dOZ4aWXhEbCmdxRIS99wN+mH3AjhNCI25EcOa+MiJXU/XGuh5QrT1jDd0HkR1EZoxZLj92Am0pxGs++cw98WojruR5N+gPJTbxxJeralZtYLK/s+gUE/OJ7Y5N0qDBYh+v/km2Ab6hMKNZP+l36yvf57J3FkyTIJqEgRFHRNGyWNHU8SHsOdzN95Ilf86yRoyDg7PxJ5N9+iwVoA9Laefz6WSF5TyhcAbyugTAH638mBPrgK+B7hWWd6cNZdA7sAkdChMjMwpn1k6wbTpZZqPKbsmOHq75KmjP8J54F26shoEKIxEzLJ38gfAM8svqM0mJaa4bfY9Vr8Dbwv1kbevgGrJ9CY+Ltzafj9SS0oiiSojulaspSNOEtoZhjoMYUX9FMaT6FM4pgZWe6hnct+Q4w/nU6VM767HjS+zbt9zjTvdcHnzHe3/6Dje/7b9+4dO+7PdvtXXuL2bmzldHRByKJa6K9dChQ4xRrzl4zU5V3fa/vfftD3v5a3/xJX/wvjc//OibXx/v/cv3Rtxw7ak454x9d7nL3bdvfe6t/uKZ93/cX15xyUN+8LLbXvLL/6zGBqFXX331vhe84AWnM3PnqhsNQPeuvevv9rU9/2kIzE82UkNW4C2cKzkqJSkTViuoA1oHMWhXT3wEn1fZDFh/gUC6gypUngNfbQxpuDeA9+b25qpUhgXunOXiOP28rbHBi2jVuNiCZRcTqJac8Boaud5rSC49CwSPFbYblwJJ+K4R2yBZqeEMImfAZxCFZ33GA6nmKrlFbbxDUHSmPKvMEsfqAZb1h5iCyZYHbBAPxmIBmwQdLZ/SwccMHO1uC1Ka8mAwD7Up8cJnYyiPqfkiL9mLJZrkfokvPBfRSSclFjC6rEMyiyUn/mha1mc5clpqREqyUy+pxsRnkYuEg9ZoRQisDkjO9ExxFxMGSVwBJuKDcU/FRoKMoCql0hiLWYwtBqAx9eMqotBGQRM4MRUFPKYtEYjknKpVE7+cqxkIaKzcg9VWCGpnpCIzppm+sjaxwkCKELGuQ9RL6D0ojkERViEAq5j7dVo6I88FiaICP+pNBnklESHQM+uzGUwsR0e4GGZ7U3ALsiyhyRjvGCJYLSuezHE+bDz1CeijrMcAht5szNCE0Qudot8Jsw/gl2hcGotHf26XzVa+4Cm5hvFKFATAWEUU6rz7N+kUfRvgP4qbgNSk1yOwHhsIgeKkGsnZ1XgPLDU+c0+UNXGatiTPMIGVrKGfjQjyUGJn38Qm9YeCx9ApQ7613ydnK2Ns0AfHLiR8UP+lCYZdTIW8xtfizkwqnKGvzIU+fZ6FbhnTL4g/665XAUpjEdIHvUHBDymOYlKJcXULSxJlOF55FHtdRRROzGGqmCYv4B30HnJO9TPYiOhI91CHY/B0xEBp7SN5ZgSjglr768ysWGM9dfxUxInr66yb32L7/nd/YFx09i2OfvUTvvi1j7nLZT+7lfmew/HiiIi8+g1X74uI+Ln/9KF6bVy1XnXVVadrVGHuduRPfvvF/+DnfviFr/qz12+95+Pvj+s+9METEVt5wW1uv//Od77/vivv/ZAb7ny7O//QCy5/+tGI+Ehmvi0OPWr7wCUX1pEDRyozT73whS+MvWvv2rtu/JoSQlXhDM5z90MqA226w/465kfRpAAQbXgQNT+fgeZr+lBtq/rrTkO3NkD5LE7Yz0oGxQI2gLgaY7DcLDGsZCDFRCNDN4QlstUvy5NlaQ2NgSLJm2cnBp9YLe13EMbyVJsZCtC3Mrio1CZBXhdEAo/giWBv8uGVTmLT1Mv3lDA1DxYd/O5Dg0CmyZQIzdROA7Dgj5GrAlCXh7jPX3vcTQD1JenMGGAm3TFly10SW8jKzUGnEmPIakoWWBXf5J05yWi+8TYPNsoCcAWADCImOW+oWkxD1gdTEEgOzdJJ6dOk36GKu3gsm9MXNY/L+02LzYz3bb0+QDcbI1YzZIPV+lLzQcZc0wOMs2xQXEoKOU78mRmmZd8lwghV0hEv/MwyGEGcSkgaO5JQJH1lbUIhKQfM/ID35Lnpr9nKgLsiBY5XDNgoP2Ev+WE4J2NUv8Cv8amdmWp2auUhvfflcvVCDPpj0QxKV2Q5bGC07C+7d8DdRUrXfwbAxn/qAkko0lWbz5keFJ5t+lLCtCedT2mE4OPkv7j4GgP0yL91jDLDIOs8obWCjgxmYvjUbrQPGKol3UTBYFotYknf3A6KhHyIwprsqqILXTM1Tp2SFi30r/580LBQjkWbd5kQCUbi3mc1chMas9W5SN20FFo2sRXarMD5mJohhKYKeyqF0a5UKrYBjQx77Xf/dDRh+Gb4Mx1FEcBd07cAFqHdFD7Qni3pIx6MX6Rqpm8bNkI6J2ejm0fosdSpEyfWOHFqa/vss7duf+vbxaPu/aC4/C4PePUT7/+Yf3b7M27yysTZfgdi68g3vH7/wcsvP/7CS1/I3T2r6tG/8qevudMP//q/+c5XvOm1F3zw0x8+911//ien4qz9W3nWOXHXu116xkMvvn/c986X/Noj7/fIf/jAm3/+ezPzr698xztucv2+65ejR49uX3HFFTuZWZNt7V171951o5cOpgccAjim+EQgJKfdP3ml/cbIiyCzGfA5+PknEzAmHPns2KdADx+zko1uUwOICESj85p/BQTBmUYfkQIb7u8Ah4Uko/k1HAt4V4HDcHdt4+xOE0EJHZxmIRn25JhHRDUVLopLN8Y2jmPJZS67Zmz8HT/5dtUr03i56ZQI8CGHngj8EMSlntcEzXCiUSsDncnZRoa2EO8wLytWm9Wc9cUiw24anzv9c1ClAGEOrDwwrFb53UnddPAwf1LQgaAqozg7K8Up6gLHjhlVsCcsgQJXLL6LCAU0FIWcOQJCJTlupxLfFIpZMDh9iAQEQUiRS9TbZhyDiiKhqaZ7TCugxHiOZ7m0FLMo1MNScBNjliDQBXSL4+77MwLZhuND9XeQJ4I78ElkIfCXPJngBWYAGDeRb8aGfk7DXNr+aV2orG/wQVSM/oCufJL6DVWtmDTc7dWxj/aAwCztXs027YbvKYUmjMloc5IDA+EGM854mR1W1jRcf2/QxzLtCrqxSnFGZGN8BfnOlQIZM+3Qg4nxsyBq6iPtU9CsfilzLNNFy7BLMlWzP5H4HIVD4I/ZlNvVNPwNOzUbQVcVEbkiObNRQp4oVKzAOjSHgmUFz9Wd5MMuyQjwWaShsLLh41j0ypmH3W9kmM3I/82JrdGxrl1Q7X40XUs5YMYWu0enrbYg7vIpjKE/TfADN2vWVn4IPguKBx8yF5bLaCOfqIPL7vx6E98wLsqR3ZAnsi+z98BQurGAXpbJp3XAGKKVO2CJAQtsHeOPEOYS/4N9LLnEyVMnT8fpUxlRW7e8xW237nSz29QTL3/0n9z/tvf4lade8rDfOmf/mb/7olMnIiKWIx94/VkHL7r8WFwTOwevufzY+WefG5+6/tr7/faf/f7T//RD73jswR/7xof9+SfeG29+51sGLVv747LLH7vvzJ3l+idf9uh33vWWd/qJZ97rEX+yZL4eZF79hqv33fWud/1M7F171971P3wxISz/19CTwZC5SgULckSAf/dzERGb5xjxRyEAwt22rCEEjHCmYYEMXMB8GX0MHtFlcZnruooAVc+GU42uUmLJ22aQymAAAUEh8O8ZD/qZ0t/2vJ8VxmCYwVERZLNiVFXpgADGJXng3Rd6imWDX+b+ciFNXinFGKYiAB2xBTyQrsmCMxGd/LjD5fb9LWcrt5M/UByMfo3VlvNs8DxKS6gWhJGamUAQoaVzHQhpSmoaj6JahhLT0rVJRzM4PgYPJf1Byyw4RGiHVc8UMie99FkqBhbdKeKSiRgu5VWiZiMKHklSFTjuJHusk6WQJ2WBWZlofUkY2u1ec25Lu9Yh2B39L5uJAH/vJIF6hoStmCiCPlebaYapG5uTcyhC655FnEvZc/ZLhYouvmQvuw0EVpydzuASXpyl6dLhPcS07sXOEiMmYewF+8ipIdjEwC0PXtX6xOFphtAS0OolblToJI1SMrUnu1Jf1VhkEeS4p2XEpYDEASBSF8QI3RlKBCN0HmX3ju9y2Hk2Pmlpt61sAJ8W6F3ZeDDG3lwL8gvYxuAXZ8cmvUPC3BgHHiSkogJXmJ4tTPTQjkmx343mO8CZoU1i6LGCs2RAMMizcJylAArvjALzVuIleLzG2qsNYF/Qz5G0c90zkyBaBVRJmWMAK7LH57a9MV9LDZ78hd1PVS5rM7OX5Jbp4dyuisyG8XaHihKg2AqtGUOmq91PGUpukCt0ECo/9miCVY+iMqp54hvkQ0DXrGFBa4tynzAiM6LWUfZFEhdoMol9hO3kCMa96dxvXXEbakZrnQx0PPgsdRT0JnQ/29cBgvR3LsswmZ115/TJU8vpkyfygtvcevv2518Yj7rHQz7+6Pte/l+vvNtl/+Jm+8999eniJp7bcSAqromdgxddfqyqzoqIC/70g+/4jl/7o6N3ftHPfffjfuuNr4sPXffRuOFTf70uF9x8uffF94yLz7vNZy6/y6UfvPs97/1PnnKny96ylfnfKM4DB7YOHblnHY7DlZmnQjXovWvv2rv+By4tGf0c5uMHvLPSbeGwOwjaoVcNFflMMRzj3QL2yinzgFpU2PsmALCqfIS4XaGSHAacxRoWUYZlIONAewBeAyi2bsd4WB20aTglRpp5yUw6FD8yIlEtRt9w9vSMGhKCF0z6rFF03lwiQsBHwAU+WvCFWdZGdE9iRkChwIwk8I+clhHReW/cMydX4kFURiwKfPGeXER0clzsD2OiLvUL8VheB+pIvyV72jhmVmLXS7Tts0ks8tfmk/0xAruWMe8x/mvtTVAvOFEczYP0uR880gFFwUaCgegG5Ua3Au5p+sb65bgrpCcyMAZhLJbgJ792S4pObi188W6jLXoj50A7ZXaPYFSxqdlh6Hk7gE7EIsRrDLJpnxgzYeQKm9KGQU0NAzjor8yYo0Vf1rXe46pdKibd6v77fSgwQnba1gZ9CgXz5CuaZuLX/3BzFhhiDqzSrYa9sUt/NNvjGhjWv/CThLBB9AmKJ5hqmTS95cyBQcFf2FMyrIl26hVh3XQwQSPvnvpwbIClud0bWynHzd2R8TtmQNLa2CC5x9t9e5Tez2CZMHCZZFDfpHx8P3AjAcsIew8Ts3nCo0GDZMwCi9RP/ZoM/H1TLC02GJRJrs4nYbMBdMwcKemAJUVTnzU/JiwTjbN+gcd2E8wQZKXbcTm3WQxRMmlNISG1gsMupXRsRBySZi2LMyVY1Ej2lXFjS243uDZB4Oir+ZUbpPBG8VfiMB8wYarNNhb0fzBu6tmgVla8YdPLEplLLFHrzs5OnL7hujWW7e2bnHeT7Vvf4oK4/K4PiItud/ufeNb9HvOOe9364h8/c9/+G06cPhUXv+SJZ7zrR3/jRDd/ev8v74/jdeLBr3zXGx/+Xb929Ve+5UNvv9PbP/b+M9/9gXfFiY9+6PTZt7rt9gXn3yye/tAnLBfuv/lvPOOBj33rI+/2wH8cER/lMtOIJQ4diiOHD+fBzJ2rMuKquArD2XTne9fetXf9DS4lhFP1LGbwnEKJ+VIwq3vHsx7wjZ9ISmyey7uL2gAyksO/fcbuxui6seqiAx+OeJhHwH4Q9E8zWkVnS3Iy+/0P3acdOPtAVzr8mAI/dyDj+5pG4fT7BFf24cFqwschOocjWYD+NkPXCfGaLOsu2EgGMt4IkpzUNOe5WZHkuU2+lIfJdtJpj+J1xSwizWoqoSnL1cHn1puu6CcdM2rBcLY9s2qzWQrKoKTSPy3B6sDfWp0ITfVd4Ct4hdlBfBfBGRO0tGuZZrfpm/xg9HNAhUBuCCpxD/gawWSHLdAey5sIm56cozsPcti/d2/26smwNTHdXxuz2ykJEg+aeO6yy0KDySwVMBcfbVqsmLArV/OiBZ+fA/zRxPydaRn1HLwcOtnyFPlkK+6pyj7eQvZPGcXok8vzwc/CiMGnDixLJQBhjete6FmIEjM4xurdIvoc8ZIXOKJIHo8EgW7QoKuxXcHu4L30TOpkM4LT59mvb6uIQLYAexvbNgsitHyYFHHQZkOiTF/C/FVqqGk2Sh1tWsmznEzTixBuf5Mu8hMiAT8beoEOYSdY+TDfB5/i95jiyd+S4epT79GLbw4vXmj0ZdFRUyuSBfAAPMNA0rE2JrqDY+pku21rhQnQrxhsra0Ljk0mGogQ72IWsCDnJFB6tyFaS+Bsro+rhVwHxv9Xtgsdh69SDIDvNm1M9kFMcgmzQEji+FwBAKemUODu52hDrtZpr8JA0EkbcWwAZkQEN68bMJ2RyxJLLnXq1Ol154br1ti3ve/sM8+KB933wcst9930k4+534N+/w43u+XPPO6ej/qjzHzXVRsjf9eP/saJqrrzZ+L6u33/kZff8Vie+IaHfu/BW1938sTZb3nbH0ecURHnnhv3uegecY/7Pn77Hhfd5RUPvvg+v//Eezzk5yLiPWlBW78XuGbmGlddFQf3DpHfu/au/2nXfDD9QFV66snFGTACq2rj64qwGcS5heEYAH5BENZZgTUFTnPpDxHf5IKduimY9N7T/0C7DbJIllB9ZWKBIIugXZwlm4JNozedPwbwnBUMBIcr/Sddq8dYTUskd+8P41YgqGa4k/N7CdPZc3y0bCZSznFt+iqGZ86lAywG2R1IMQLWkqsIHMdRXBqDpakIDPydLM7QMEhcKE+MF8oz+8PRHpc+7ZI7QkI5OVTMsfRHlWM43J59da/MexCQhRxmwSyML654pV+Z/ILXGbbkVAHl7uMRlO7vaqt5M4IP9F1RofMg0U5lypQ9CGEAOhjjBQ4PDvUdEmTIw63JiiyduSMRYsDP2LRs3NRC9j0lXkYvgxrb1RN6DptILm9tPUgEhaa3geddV9oWs3fuoxyhj0mZE3d8ZoVBOQpIYIsC0XUDq8RR3a9jDbQigu8gppJBBnCGPxlYCga9h7Im+c9Vhrmpb30P8C8Goz0wBs8EUkq8g6wVF6qchFnfCzzj6wDqA99FL8NNpw16EzYY/eB3yUSgE1bYaG3KSH4Ms2u12qAomrRZcSVDYIbrK62i9JxruJfNpIMRlY3J9CPCGAiPyQHv6f5jU7ZI5sgULfkryQ5sdIPXDt7oR5io5K9IA/nQBTLHGNqLdVHGg0zJynniDfh70w7Ps59NvlJBGrpIq9ilJO7IGEuIPeltPyAHEEg+J8lbEhv8PEZhNVTaxqC0kiYoK2ct+Veya9gz9Q6Fx9Dvc7acMWP+aHPt1ypi4ulq2DVRREzx8VZmbOUSy/Z2rLWzc/rUyYpTO9uxHXnrm996614X3X3rtv+/9r4tRq/rOu9b5587Z4YccoZXkRJlkaJEWVQ9lh0khiPZjoO0zqV1qD61fqpTNM+NgRaGJKMN8pA+1H1oFaBFihZNQaVXxwmStJWc1IkT0DDSWmqtxHYpm5Ys6kLxTs78Z/dhr2+tb59/5D4lcJP/COL8/3/O2Wftdf3W3uvsvbz35Q+c3PzGiYfe/akP7j75f8zsNfLm1p1bn56fnf+nALauAAdf/Pr/+PTvfO38xt/8Zz935rLdOPCFF7+EK5cvAeixf+Mu/NWP/jQOL+x9+/0PbL66f/Xgz//oyb/0dTP7IuQ4f/787Obm5raZlccff3wb02N6TI8/laPdmL4JinnEimYmjpFgX67OUUoE8FbnFCBLRiEz/5P5G4K6aFjLr4jdYpUXjR9BG89xxLABmwQ7DN0EcrGZu9/j+xTlSGL2raCPJIeAuEnseIel06+AM1GWTfCweGmoRU1/NOYgNYMFOV5CRjXB4cIsPumrQA1ALIfd+zLTTOC8/KUYF7UhHO0cUESnIsDUPgeazkDblwjIwVTqgt+TW1lE15uZgKb+MYjPZKUuFC8FYlGa6RCAo6WljwBddTI2awogldpTMkBSL11ZIpEK/bEKJiEAmEBRRosrj/2vpcx0/jLfDwQQgGCyDMwfFjYQ+iOGlNpVmRCLSgSbLYCW6TNl9FiUJeTLpKWhyYRO1Qex8WgoRs+zBNNgwf8OsZ96AOpKo4WvwSC5p08icCsu9+J2Es+3HNtXXGteDmsl6TBnVokv2afgRc+bU/ZVlxKAcrDBWDINoLhVUVkMJfc1NTbpAzNFbMi4tmblQV+8Pwag+NYL4Ew39SX/AnXBh0zcSr4vFHoYu336c4B815eyzsSP/omePAZXxEf0oi+9vwbQAzHwlNogekfXTRsN0Er7Tl2vD09/l7+5zsdAFXzVSQfT/NdY25B0Z2xgJ0VpjOaXuq3rXw55Tp9dnL8oSXpeK5E34pUmmtRz+pZmKCL9TV+iHF+6kzExfqhyYGJUt6sVe6a/c9nlAF5qdi5BR/ugDgxijPC5NlYoHuRWCPX3+l5eh85lHTGOPAs6nRd9XUQtYinUzlxX1JUZt3UobgvwvRzdx3TU5GRXDtb4ic7QLIrlBTFMyCovBESEj0oWAC4n+tAwcdEXo8f1tqXaIAcXkfcz/AnO2emVgEpOn3bWVwZ17jvQdWW8vd1vb90eob+DxbW10dEDx7Axu9K//9TDF4/tvevfffwDH3vx+MLGrwAYjcfjTwB4tJTybwBsvQF0//2lL6/916/9/pOvvfndj7xx8/Kp89/8Kl578xLuvPEasDiHM6ffhzMPfrh/9OQjN2cX537hZ37g41cB/PbCaPbF233N9X74uSdnfvbS6fLC2bPlKaC+Fzg9psf0+FM/ZiZ+sXQ47c8ZXtJp2vCqej68PtyR13MNAC+YuBvAxCwQDy0p0WfVphhsrPmVV+VeQBnAtIxFF1EJl8rg1Vs43PqzOfCzrNcvABOxpIgIQyObAKwgLskNIIIMMpFXWzKzmZ8oiL8KVSpYCdgQYIfBpQabuiBCw/HYN9ADemnb1L8yZ+I39ShZexxnErQzoWPkJmDMGQVIXzLhYNJD6JngREfym3dYNCGxuDoCfPQp+meNfpnyUnQyE91sXjnEx1EtoltG1ktwN+Gv6KTqjy7Aw2tMegPAgTlBOZ9MgE6e+H0xCi/9QaiFiCDba8pvLWkBxQRAN50PLJ3G1AAUJsjRAClmsmvkuciTClwALnxDO02vZIrds/2h3oeu5JWV973oAsGnt2vqm6yuXms5Yzvhd5z9SY/MuGqyEzY0YKsmEz35R+Y5cBcWZRmaOhV2XVMYUtNcIE0xcfZ+06tFGZ0mK8iDCi3yC3dW5LnBdqWfCWoR8NsKsilzi6y+hB9OtaefzOeHVdHmnKAmmvFxls+M73qZXB58UlUqeT/Nb8IfSPd5Q23L+dtDfCYg1oioqIlnlZR9ZrOt//Prqsz4SoP/3Ccv1P80g6DCD+0vNaR+yWiQg6Q64GlgUtzqGOL+6idKhgAyin4IaVemPsE4X26ua9musAfhKUpp3wkNRSXfLOl0Raf9N3pv6adzVelMepNLndNcxLe51JsyT9pQa62cPXdKJhWJ/EyhZPuWZ8UNciCj9ONx2d7aMty41WPUjfYePDDat7i8/YPveXQ8P5r9jSc++FNXH9m478a+xT1/AuC7AJ4zs2uzo1nc3L5z+Q9e/drDzz73+b+3uDjztz7/lefHb25f23vlypt4641XgKV57F1bxyP3PIgf+tDfwAMbd//Jx973I//t0Oq+XwHwFTN7+29LT86eO9edO3sWZrb9Bf/xaUyP6TE9/qyOSAi13CKdpwAkCdY8IjGRn41osLmuOrsmXdvhGvV0bWlDkVIg/zWAYHtHYQeadjNYtnAJNZgQQ/gocr6s3wHmiV4RPy2Ou/cA1LwnaDnzJpHNQcAQBjQQK0FdAL+kUcFJlNo5HQT6w8SgJlSWwVcBSwEyOJF3DLTOqw6N3OrpHtz7K0berQNnpDKABrEwY3kjZ2P6NlhJEKyr4wkwEFBlQbgHO8uvMWsswEbfewxQLwCoqAxKypHAK8Ac5RlD18mqAJ2Bo7LE0AAHrNl2zDKUKr8iOpRYg+ABobcJtpOGVIjUreYdWycsk7tWB1pLCyVwENLH97jFWjCXIJS2w+t1Ns//LdXuRcWQi2qQ/6lo5je1Cwgp44lq0z8MGJPJLNVf9T30IQGT1LryBtSZNUudDlfpPomzHQJ/C5M4rvbYWbjFYUID6bPivSKEM4lWP5ng0JAlnSVRcJKoBp66hBKSZXdIQFtqLQ3EAAP/5IwOO9Li1XoP9Se2S3Gehn4ESDfUgSUygbYq9IWvrLYd1RlBQ9EbUrZqT8rnIrMxAHSBnCJ8oxzqo9sgE1YUwB3N3xAV+6PPslI3UJc4QqnkoCP11rXMOrTvKaf+J/Wtg1LbN5RG99mnJimUfrYJeusb+VnfZS7cB7Ck/2V7bTLMXomcw64t7C10PJjpRki/IH6ytIJqB8GcCUEvWUL7Jj0hXtGjVrEBWJ3RHPqKvMPbyWWGZA5e2kpy6z2DBE94rT629fv0o9Juh7oSaJdVDv3WuGxfuzke37xVMDOanV9YtLs29uPUPadGjx59N+46cPA3f/qH/sqP7ptf+SyAzwN4AMAlAOsvXXntxDcufv3Hf/n8r5069zuf237k7//k0Rs3r69feOVbGF9+HVjfg9n5BZw59gDe/chHsW9x7Xc/9v4P98f3Hr10bG3jMwBeMbPXSd7Zc2dHnzp7rtsExmbWP/vEE2Mlf3pMj+nxZ3vIPoT+JrFBShX1fSRInNXI4jBFogNBTlNyFAFTni6Bt3HEhav1WQQ83Zcv/2SZiAK02raAOu9TBCIHpg0QkhHZnMnMkcRojoCm2dfJouCKgIbgvg8/ncGWMxy9M1ZB4eTiFzoTWIOiAU0lZs/4KLMlxf9lQO063WvKcvNeF2qAMUEu7eqdmkwbyMxIXr3PxOUs/ckkRAGGAlaRgz83Ek3hATO/AsQeU7XZAV2ibjpHmmjMS/yCXifYv1eQ2efAtCTlQPEqYgsZxjUDMBWDJQrOGbwFmIb8ySezujpeJESdnEvxBQ8pThObAyFP9tlK1ZnYxDv65DRx5tuiOFFk75DNOLMwtBMEH4sndlVFBLBFv3NGtjZJuWZSpV3jNZnIyWALyFoCLZlpAmVHWbnO+uHrVWjehDRoB5FplDHwEPMdpNss9dtqP3MmCiidDzhxEIViDxDJ57vNhtikDyGK5EF2nrOZRXQ5/UkDQCVpJs2ZPphXInjK0feaK7i4krehjASvETPIR86mZJ+T01mxka8WUH8QSUMySP1QCEv8ljBSbC+eyKRA/D9tiDYXzcZMVz0fA1/S7dxeg4lD6lUaaagSOKffcdaZT5ARhhDdO85QiX2zLJGxARwqsEq/iRxL2q5RZeAraEfspixSPuHjIx5km41LVSXR+81fOrC0lfARogP6njntzNDJjJhl/0Svyf+mZBten6JJYiRsaZ+UU+OLoVUofehBQS0LljG28Jd8amVXCVbpjBz43atjcpaSrCqp3pRPyXtBnXHeWphYyZJVelQzdKMO6DqgM/TbW9vjO3dQOszAxkBfsDSzYCdOnJp5+PAJrI2W3/iB05tvv/f46csPHHnXl7qKCp4F8J9fuXZl4dKV1z/7xZdfeOk//d6v3xhfv/mhl7/98sbXX70wGo9uGzDG/MoeHFo/jI+854N46NhJbKysX3j0XWe6w/sO/ONT60f+94x1n//FxjbifcAxgGJm42dhY0yP6TE9vi+OnCGEO654vyMPI5p0d6cJk8A9CfrF/W+WOnCRBV4SQIUBConXdPS1Oj9jjOSVUaKRo70evPymSLIcCGQlEYNAOu0AFB5MO6e0IBMDJn4MPBHogEziIiYLyIp+EfRIeUnG1hbsGWLUmy/OE2AV9kuCdhfAJJnGd/8AJIhj8OXtBAMEznBgyWcIAMgFVboALub8ZOJYUHz/KwFxRvFZDhCY6EDwV4GSk0eVA7xd5Ds/AdTIZ0qxhE6kwhnxgCfy3ueQnQGdL4hTqAfkUxvQCAJj5jHopf41cy7gQirkRRcL7whIyitqMhp8oW5T+fukSZJvoC6xnmWfO4xDR6JUHJwocLUEnGy/AFwpNmfACR4FNIadiVo6uAz8JjIPnSgi6zCEHACiXJk4WccVcYNTwuPU62rantyWtL+iUgm/EWiQ8DQlyCRioE9axulsbRINjl1UOjrfQ64OF+noPums4JP6ILRRv4g92TiQPEFBKdz00sLv9VLlEMmRyz4nQEsMIhUl3kep6O9EvNixnJ+Am/InB0tXZ5jTDfk1MqNiyXPIFgG5YnPlYc4SkUwLmiNhg+g3gIHj9sdZCir4GmEiBvzq94wfUJm1mhS+PJIp9w1VvsmvcFXh552OPl1U+KgwGtKZ9ko/nTppFEP2uTRPbXS6mhbtmjxh/KbR8rq0jxCtzqCXIjSUsE2LJjgkV/IaZauxuaq/zQx86fKhpYTMSa/SxW0yi8iD96YmiQK5z6lsdl/S8JHk0iZ9Frr0SYN4fHg7ZqWueNqTn4O2g7SSN5r5u8xCtveDmtLM1XtbXde59ff9qHRd3/c2vr2N8XgbwG2gjLGyfmBmz9oBLGyjnDx27+t/+T0fKif23XX1roNH/uUDG8c7AP8CwFuXt2/93L/+w1/f+t0X/qDbPb/rs9+58tqh//KV3996/fVXd891drqbn8Xi0iIOrxzAxz74Izi0dmDrzPGHi/X9b91z6OiX3nvizGjf7OLl1cXlz/alx/XbNyutZzH64QeftJ89fbqcPXu2as/0fcDpMT2+b49cVKZDHVlqXoquRwAGSHwNh5bf09knkIj4bO1tGSGZdCRoRro/0Kkn6Nag2TrR+oOAoZL0Z1GKAC/NOCDgzmnICU539AJGI1nqpV3EqQZwJCgL6mHKICKCUl+U7yMIdc2sSdNZqf/J84reBnwp7/CV1znSjWTcmHjlZ0PJ/hlBlI6nZ19ixidwjaBCmNwvYCIAQdPRyi8HWjqblWclYYkytEw4BBIGRIokQUbZBflmshG8Uv1U3smVlJU+MdCet0XQVALy+e/C++BdEs/rNYFMRUsQmudaNajqbq1pu4Cif3JDbiMgz2vk2HKnOQhWBfhE05yVIFFuZDYkOGgSBCm/N4vAoL2vJhVpVs1oiXzUvtAqg4YAphZyqgMHlaac+fe2SvoPgmEmqukzkDNpQYs19/NL0b8wRK2GPnDQp2hWeT6cwSnZl9AN+qEgNe8JdhUILRAgX0+mydqO/BywNchpHJHov/rPiY7GA6xtjPbIQcDwJwMbRl5b++W8EHtz6kWXkXoKQMsgm9+1S2pPqvNA+qmB7DJZTm/VMCpuUl8o8qUsBi6t6EMa72bhXFqvp5KcfD5n/BsLojjUNnm9aV/kGbHHgYhE+suqjfqlr+MGndIlN4sNqm8Oj1M4I40wuKg+8P7DchBGz6VCimMpgDWjFWixj5he23fOFkJsHBEreX3XVX2wrs5S9qWvCzX1Y4xv3AJmRzY7Pz/aunYdszaDw2v7cGTtAI4fOo4Td92DO/32L//1D/zE3N3rhz/++vjGP3rlyqXbX7vw4vIff+PiEz//W7+0/c1XL3zi4uVXF5aWFg9ZB9y5dhuXL1/B/uU9eN9DD+KutY/g9KH7sWd++eKB1b3PHz/yru7gvo2ygpl/COCNXfOL371x5xaGx7lz50YbGxv2+OOPb38BT+MLE1dMj+kxPb4fj3aGsDOgGwGlrytwFY76QZBXhCIAiPPVERsmrmr8rzrOeo0G03qCQGAIH/Q6lo0N4Xc00QSzADxgmM9RU2vu6jLR8EY6fX4khfUCBr8S5zJ2GEtmil9T6yAFSHiayMQrqLbY79ZQaomiB8Uoo5FZOaAGjFL6yU3uS/Y0YqrUHib+kdKpkvs6CQuDQlgfsuPMcYM5fcbA0HtC62VBBGcB9liGV/sSK8YJJqxIxgOsJnzRvyKXph7Gh1LQlAbXztVZxtLOCeXCGwKMg1wZZAj9aMslCc46Q5ZkNuzLBDlnzr1vxaKNmLnT37w7WQKbCWOMf/PaIjSLFWipF6Tn7QwKAU0+PxF9vZlbS+SiK5Ig8PmwzOP4T8lrBhKBECZ0C9iVMr7Uez2yp9m6tik9HgDStpXkR2s3nDWS34q3KMCSjeRWGj6z4YC7Qyf+IJ2FyTM5m0dTycEtL3EOGizaqnKRcl5Qz4TXXpZZu6MeR2RMWXFGxHIWXFcYDX4aKY4fJX8XPa2G3ADfKOPkAAETb39e2EdKHvQP4WNdMizuy7igs/K8O69iJ3ILFqGO5p9dCtaQP63+pvyic9SnZmDLogvw/tV+MDFs/XR4Zs5AGvWNZKo8qZOuWyi+arRYk/iFruNK02kOBovqiXZwlv0afDDeBegK2yozDowYgNKzxJPnnI+hs/QR6ttaP9YKouq3wbz6iPaX/Y04q7rCy7ou7Qx1tYTOfQv1EEh2RJmwVHjojGqdcezSJzMmdIkylK5msNqAWCTK+9yXgn67lnliewyUHjaawe6ZOWysrJcTp07Y3MzMy3tXV174a+//sUeP7D+658VLFz69MDd39dju9U+8dfv6I+e++Gv7/s4//9T8rrml0SvXLv/Cm3fextVb19Chxz0bR7C2uoYffOC9OLiygZkef3R6475rD9/90Nzq4vIX79176N8iF3/+jpl9Czscz5w/P7sJYHNzs5hvGv/EE09My0Cnx/T4//CQdwgJ2MYZcaFAvF7HgBr+P+J2Qc7CIQOIApaITBHu0EQdcfYJTvScN108UQvsLmAYyOCaFyCQhGm/WnCrINIRePaDMdLMkzT5mS/yERwYUDeBz44poPKGAqJwHJOjw5VMDzIMnJBZLSBmjwpBI0EOZyUaAnvkewikqEyMwJeSwI1AsY8ElsCvOM4SmNYEt449TigXpCSYMAdvkUyh1ADt5xT1dYHOCPAYUXPmNlaNrMoReyx26GJgNyFmEhV9ggT/AAYlV1f0G2OAIPbBSvDApBDm1znftMKJwD2SSSDkQCCksmvobaaRkIDd6oAApE0T4eYAi5pROxugZtcAzAEIqxflSLvlT4jBiCK/m15EYkrcEyes1BV9dQDAAeUEveKLcnDAgof8UGLQo0kppJEEn+3+YaoXkhinmUVbxllX5R9lrG0gbZYJsvHdOSPwzU5FNzqVcSYBun2eFnVQyl2+Zuam0uqbuPj0s+LrSG/y3Bo+xt8YVfI+00+i9olqaVzqH3BlkblTSSiizK5wuxu21NpqJA9OQpcNDPQ2q0Di/St2yZnAXtUYkoNtMgba8suSCemrlP4J64pWMkSR4X00ZvEksVLKke+sq83484qV1EFNSEMK1tpFr364bSvbLq1cBq1Sn4qeNPJMBr+cpnRbHCjNqg7GAjIyBkol0SvsK+n2Dve9xNwCsPQYhjwX9yd7uRFN/amWdtN9q3+u28IAfA+Z9h10dgUxHNH0M31pPtt8rCIdO2nytV9hNXxhtpvF6vIebOxew4lDd+O+/Xfj6IHDmFuaL6tLu7f2L611X335pbf+/Zd/84//w1d++9TVrevrf/TN//UPLr39Znflxtu2e3UZ6xsHfnzPwhpsbg73rx/DkbUDr57YuNuO7T9aRrOznzl95P5rx9f2k9R/ZaYa3x7PPPPM7MlPniwrX16xz21+bvwUnvKwNC0BnR7T48/LEQnhuK+jUOhrWUaO0KEBeDKPgnD8SDCVcxrt7F2+JO6H1OE0o/da22/5zFiQgW2I4y2QgKigIb5WpBLJGBBALQK9gI9o1cF+lOPFyL3M6kVCIAFS+sJgUBR0xcuSvNRH4SVq9Ua+MFT4BQ2N9Zk9xvIuTdLAGVqVnMk5gQvI6CQJjABvor26R2KO7PcDNBz7M5JfbEORoiESGAUyfXwU2gIIe3sOBkojkwYNR4IWPaU44CABiFdlAMiH5FzKqv7C1WQTJFmca2FyicS+KeWirE2e5/qkG5aI5JLOUvla75PNr8jLEJQgjAAtOWvI2+I5cVmgpBYxDz/LjEPDKyBsZMi7MElFzSKvZhjGBnLklWyS5eDWWGkMnmSjJWeohNKWw+2My8SgBZ+H9gJaI/+WJKR9iiFnLorvLxoyqS+O5eyYyoG8cz+gSRn1jeISsbdPl30KvXH2mDbGkr/2KOhjwKIkQNbHk0NUvwHfaLmaRLN8VuUad2gfwlcb4sWqsK4S9+jsGNuKyS2hrSB9icYSKL/Clkv4Fz03ZNEw9qDhAU/lIFfYmGdIUuk/bJVvx0vDqYs9dUXMNPo78POAsM4kzqGo0aPZBD6EYdJvlVHaptZW8DdeneW3EjeCJ1WvwlPGC7nJd4qDi7SVgok9Amvbol8SW5orRf8xTJqt6UH4rZ667w3oZDN7mM+WQU8Y4rVHadfcx1X/WP/zSonSF6+p6oG+H9dnWYetfozZ+a4sLM+X8cwY33rzO7jw6gW7+vblcvv2zZl+FnNXcAfLG2tn9q/vP3P+21/FcpnDo+96eHRs4xg2ltZv3dy6/k8eOnrf1r377unvP3zv7AzwhwA+B2CEuqrnZCJ3FiM8+GQ5e/q0na3fcRZnq6jMtvAzeenT0w0hpsf0+HN3MCHsMRqhKwUzpZab9N0IRASDeOCHACx3egwCiXdboLvzlx1A8/CqQZ2+Ik5NRuP5imACQ6vzF5qjyQJw+2duSF9801ZBBgpSk8CSEdgbb0BCkM/ykT6AA7GINpgLuOQ12Tl4QMsVNOtmuBaD4TGjxgjYLBVLuSSAi9Fcp8DX7/ARV032E+RyVcuaKE3C7kpb14CLKo7O36PK/QrNDL3zutIvAmV3DajD5f5HEITJHpAmYsgyPpG986TjAIU/i8Dd/LcAXSKXeIoB4AxGQqDEH/HFnFe10YkZWf93pGBWzhkIQYQJFtTufCj6HRrToO3QaR1Aof4FqB4MhpAvRqxXEvCSX0X5bsETgi4jgx3oRSnxYA/LpilSblqHULxV4UjwveS7QMN+y9RZ8oLfvRQMJZLxXtrtRC+TxTnwU0kk7bX1SOgdGDKhiYWZSJvoCf2e9VkCSNOvPE8+kM3BPa6Y6zzuVPHkYw4k+B9nSwfk4iV6X6Pbzme+z6WO102/xO/p46KiQShQ3c8yPLUsobbANxiXM33OzJCf+QTxC6gDBa27tejThJ5E4pT9yjfegEwIaCltbDD2u64sJMmp6wUbLbSzdoZJZ3UR9ua9MgteFvMVbIswu3EQXcSNWCCOhA4ciQ0+MIFuyqVdT2PZF63IyRvRlCyTx24XtcJHqkP4LDB5Ggw+lfTL9AM5kEk+KPGZtkYSxgW7sgup+/5hFPdFN6r/ZsUBZGazZBuCREAR931ftu/cHqOU+gpO36Nmf9vAjI1s13LHLZtm5kZYnJ3D0twcds0vYPf8InbNLmJ1eTd2LSxiaWkX7t1/DLh55yo6PHf3oXu79d1r24c3jvS7F1bevnd5/TMixi0zu4idjy0AePK5J2cee+wxPIbH+PvYzMbA03gWdanR6TE9psdfrGNmo/7dtX3nFm5evoKbN28CI6tekN5/IkpodoFEiHEZo5eCp9J64GivBSU7HoqaJr5LEKqRq6U5PL+fj49O40T2CMQKHpC2AvAMImgDunk924b02fL+GP2G/O7t5Es4A6QoTGrOkaQG6cnfCRTn5wYzTRM3K9363X8jXcN9SWzQVMO7At/YcAceDvSg6bPQYHqR9qu094X8Sv5GvjaykOa6AQ8bdR3osj7fyuTPTXt+71D/FbnqdZltebuDhomgh3xUObH/Ks5hN3bSiwnZ5COzC0N65POQB6aw7h34Rn3ayRcMn9c8a9C5CZsYtqOd2YFm2sTQn8VFtGs+T+TUqOEEExCymLClMniWDfqsfVcfNey36L+O7gjpk8qAfL6i2zK4Vz8M7ZLtxUzKTn1/hzZ2iiPRn0Ezwz6oDTQz8bQh5HV81gQpOxkRWl5qF7TtotdKG0M9oJyasgvbQT4D3R+SVjDIRknPOxhsc5000tjAkMnvdN87nNvJDdNGvtehsmgqTEorw2Hjats72bmuTKoE7simQSyZ8D/ii+N+sS0DRtZhhJo+cqCoQxfLns7PL9jGgbtnZkYzWFpYxPL8EpYWFnFkbT/mS4crN6//z32re211dU9Z37WGteXd2LOyu79v40j3xq3rv7SysvLCfXsOjhYwM5ZOXTSzl743g4FPPvPM7OYmsIlNYHMTm0BvZmN4vvv0409vT2f5psf0mB56zADYBvAfP/7hj/7dh+9/EG+9+VYtG4KWKtUZobpRO8BSQd1n0AzoRiN0XZfvcwAyIsvSPQf/Bcj3i6qjHQLGjMN8/6QFhkVn/syf1bftdJ3BbBSjjn4pSvEXt0v+Fk811JW9ODsagKuWA/K9tNp/eTMfVnnVmcRui21pkx/53mDsTWS1lqPJA7JV/84SNZbEMX7mex09S5/8/+gPupx5M8oh5VMcDOd2BFXWdSaQbbRHzpymrErM/LWIJqgNPUDoRQMxoz2nvbPQpzrQ6iutwTevNu4T5X/9na5Seoz7el28qmXWzN4EJA8d4Ai41cUk2c94folZwmbU28FA5NbeET4v+558Z3+acRcurCEAv8GVchQgVqNNGae2UP592BuBDHXTeWYG60Q3+PyQIOffEmAFrHX7K65PpZcZGOfbyBfxgeU7xAV1exJNajp5V6zaZt/4C3NZh84ZLWhoftaAfRZ5JcavfVYfhYLkU9wJ2erC8w/6vFBYIynBt8KS5GZGtZEMinGbHVIX5EsZaPUr/WBwyrou30/1vqafbFgaTy3UfeSFLGMjT9Q/9cov+hsUlJKzJDEvSznEDErdAqVHia05Wmrg/gf+Lpv6T8RMaNJjTd7fWV1yP/S4y37kjG86Ky3p43Ozt33kpOkH3EfRF8DQWSdjo2kc3EYkyW9ttulY4+XyY+90h8yiuqMyv6BUP9bnYEXVgQ4jEtVZa79KkTOvd3rSHwDtnJZzSQRknfMaqT9pn0X4LbT79x6Qao0iW7MjKnbIrb5QwwDOMoYvJsvMGhqoFAbuWYxQpYzl8G206v3xRLIy7EUcHpzvJa+hc+24gFpXsc6uhSUszy9hZjSDmZkRrDOMisG6Ub+wsNT1KBcvvHHxFw+u7rV9q3vLnsVV7FrcVY6vbhiAb892M7/adR0QMc1tD9/7+OQzn5w9dPJQeeWlw7a5CZy8erI8//zzPZ4CnsJTlMXO7/bZ/7P56TE9psdf0OP/Apc4c7t1FW4DAAAAAElFTkSuQmCC";

    setTimeout(() => {
        try {
            const { jsPDF } = window.jspdf;
            const COL = [20, 22, 32, 26, 20, 22, 22, 23, 33, 14, 26, 25]; // sums to 285mm
            const pageW = 297;
            const pageH = 210;
            const mL = 6;
            const mR = 6;

            const NAVY = [21, 35, 75];
            const DARK_GREEN = [27, 94, 45];
            const MID_GREEN = [58, 140, 90];
            const LIGHT_GREEN = [223, 242, 232];
            const GRAY_TXT = [110, 118, 128];

            const headerTopY = 8;
            const brandH = 22;
            const brandW = 95;
            let badgeCx;
            const badgeCy = headerTopY + brandH / 2 + 1;
            const thinLineY = headerTopY + brandH + 6;
            const infoTopY = thinLineY + 6;
            const infoLabelY = infoTopY + 8.5;
            const infoValueY = infoTopY + 13.5;
            const infoBottomY = infoTopY + 17;
            const tableStartY = infoBottomY + 5;

            const footerRuleY = pageH - 30;
            const footerTitleY = footerRuleY + 5;
            const contactRuleY = pageH - 12;
            const contactY = pageH - 7;

            const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
            const logoDataUrl = (typeof LOGO !== 'undefined' && LOGO) || LOGO_DATA_URL;

            function drawGradientLine(y, x1, x2, weight) {
                const mid = x1 + (x2 - x1) * 0.72;
                doc.setLineWidth(weight);
                doc.setDrawColor(NAVY[0], NAVY[1], NAVY[2]);
                doc.line(x1, y, mid, y);
                doc.setDrawColor(MID_GREEN[0], MID_GREEN[1], MID_GREEN[2]);
                doc.line(mid, y, x2 - 1.4, y);
                doc.setFillColor(DARK_GREEN[0], DARK_GREEN[1], DARK_GREEN[2]);
                doc.circle(x2 - 1, y, 0.6, 'F');
            }

            function drawBrandTextFallback() {
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(15);
                doc.setTextColor(DARK_GREEN[0], DARK_GREEN[1], DARK_GREEN[2]);
                doc.text('Medi Elves', mL, headerTopY + brandH * 0.5);
                doc.setFont('helvetica', 'normal');
                doc.setFontSize(7);
                doc.text('Keep it simple', mL, headerTopY + brandH * 0.72);
            }

            function drawHeader() {
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(19);
                const titleTextForWidth = 'ADJUSTMENT REPORT';
                const titleWidth = doc.getTextWidth(titleTextForWidth);
                badgeCx = pageW - mR - titleWidth - 10;

                if (logoDataUrl) {
                    try {
                        const brandDrawnW = Math.min(brandW, brandH * LOGO_ASPECT);
                        doc.addImage(logoDataUrl, 'PNG', mL, headerTopY, brandDrawnW, brandH);
                    } catch (e) {
                        drawBrandTextFallback();
                    }
                } else {
                    drawBrandTextFallback();
                }

                doc.setFillColor(LIGHT_GREEN[0], LIGHT_GREEN[1], LIGHT_GREEN[2]);
                doc.circle(badgeCx, badgeCy, 8.2, 'F');
                doc.setDrawColor(DARK_GREEN[0], DARK_GREEN[1], DARK_GREEN[2]);
                doc.setLineWidth(0.35);
                doc.roundedRect(badgeCx - 3.8, badgeCy - 4.8, 7.6, 9.6, 1, 1, 'S');
                doc.setLineWidth(0.25);
                doc.line(badgeCx - 2.2, badgeCy - 2.5, badgeCx + 2.2, badgeCy - 2.5);
                doc.line(badgeCx - 2.2, badgeCy - 0.3, badgeCx + 2.2, badgeCy - 0.3);
                doc.setFillColor(DARK_GREEN[0], DARK_GREEN[1], DARK_GREEN[2]);
                doc.circle(badgeCx, badgeCy + 2.6, 1.9, 'F');
                doc.setDrawColor(255, 255, 255);
                doc.setLineWidth(0.3);
                doc.line(badgeCx - 1, badgeCy + 2.6, badgeCx + 1, badgeCy + 2.6);

                const titleX = badgeCx + 10;
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(19);
                doc.setTextColor(NAVY[0], NAVY[1], NAVY[2]);
                const titleDims = typeof doc.getTextDimensions === 'function'
                    ? doc.getTextDimensions(titleTextForWidth)
                    : { h: 7.5 };
                const titleY = badgeCy + (titleDims.h / 2);
                doc.text(titleTextForWidth, titleX, titleY, { align: 'left' });

                drawGradientLine(thinLineY, mL, pageW - mR, 0.6);

                const meta = getReportMeta();
                const cols = [
                    { icon: iconDoctor, label: 'DOCTOR', value: meta.doctorName },
                    { icon: iconHospital, label: 'HOSPITAL', value: meta.hospitalName },
                    { icon: iconCalendar, label: 'REPORT PERIOD', value: meta.period },
                    { icon: iconClock, label: 'GENERATED ON', value: meta.generatedOn }
                ];
                const usableW = pageW - mL - mR;
                const colW = usableW / cols.length;

                cols.forEach((c, i) => {
                    const colX = mL + i * colW;
                    const iconCx = colX + 5;
                    const iconCy = (infoLabelY + infoValueY) / 2 + 0.5;
                    const textX = colX + 10;

                    c.icon(doc, iconCx, iconCy, 7.5, DARK_GREEN);

                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(6.4);
                    doc.setTextColor(58, 90, 138);
                    doc.text(c.label, textX, infoLabelY);

                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(9);
                    doc.setTextColor(35, 40, 48);
                    const valLines = doc.splitTextToSize(String(c.value), colW - (i === cols.length - 1 ? 8 : 12));
                    doc.text(valLines[0], textX, infoValueY);

                    if (i > 0) {
                        doc.setDrawColor(224, 227, 232);
                        doc.setLineWidth(0.25);
                        doc.line(colX, infoTopY - 1.5, colX, infoBottomY - 3.5);
                    }
                });
                drawGradientLine(infoBottomY, mL, pageW - mR, 1.1);
            }

            function drawFooter(pageNumber, pageCount) {
                doc.setDrawColor(210, 214, 220);
                doc.setLineWidth(0.4);
                doc.line(mL, footerRuleY, pageW - mR, footerRuleY);

                iconShield(doc, mL + 4, footerTitleY + 2.5, 8.5, DARK_GREEN);

                const textX = mL + 12;
                const textW = pageW - mR - textX - 26;
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(7.6);
                doc.setTextColor(NAVY[0], NAVY[1], NAVY[2]);
                doc.text(REPORT_FOOTER_LINES[0], textX, footerTitleY);

                doc.setFont('helvetica', 'normal');
                doc.setFontSize(7.8);
                doc.setTextColor(GRAY_TXT[0], GRAY_TXT[1], GRAY_TXT[2]);
                const wrapped = doc.splitTextToSize(REPORT_FOOTER_LINES[1], textW);
                doc.text(wrapped, textX, footerTitleY + 4, { lineHeightFactor: 1.35, maxWidth: textW });

                const pageBlockX = pageW - mR - 20;
                doc.setDrawColor(210, 214, 220);
                doc.setLineWidth(0.3);
                doc.line(pageBlockX, footerTitleY - 4, pageBlockX, footerTitleY + 6);
                doc.setFont('helvetica', 'bold');
                doc.setFontSize(7);
                doc.setTextColor(60, 68, 80);
                doc.text('Page ' + pageNumber + ' of ' + pageCount, pageW - mR, footerTitleY + 1, { align: 'right' });

                doc.setDrawColor(224, 227, 232);
                doc.setLineWidth(0.25);
                doc.line(mL, contactRuleY, pageW - mR, contactRuleY);

                doc.setFont('helvetica', 'normal');
                doc.setFontSize(8.10);
                doc.setTextColor(70, 90, 75);

                const contactWidth = pageW - mL - mR;
                const contactItems = [
                    { icon: iconPhone, text: '1800 956 692' },
                    { icon: iconEmail, text: 'admin@medielves.com.au' },
                    { icon: iconGlobe, text: 'www.medielves.com.au' }
                ];

                contactItems.forEach((item, index) => {
                    const colCenter = mL + contactWidth * ((index * 2 + 1) / 6);
                    const tw = doc.getTextWidth(item.text);
                    const tx = colCenter - tw / 2;
                    const iconX = tx - 6;

                    item.icon(doc, iconX, contactY - 1, 3.8, MID_GREEN);
                    doc.text(item.text, tx, contactY);
                });
            }

            function drawGrandSummaryCard(startY) {
                const data = getDisplayData();
                const s = computeGrandSummaryCard(data);
                const boxX = mL;
                const boxW = pageW - mL - mR;
                const boxH = 26;
                const y = startY;

                doc.setFillColor(248, 249, 251);
                doc.setDrawColor(210, 214, 220);
                doc.setLineWidth(0.35);
                doc.roundedRect(boxX, y, boxW, boxH, 2, 2, 'FD');

                doc.setDrawColor(NAVY[0], NAVY[1], NAVY[2]);
                doc.setLineWidth(0.8);
                doc.line(boxX, y, boxX + boxW, y);

                doc.setFont('helvetica', 'bold');
                doc.setFontSize(10);
                doc.setTextColor(NAVY[0], NAVY[1], NAVY[2]);
                doc.text('GRAND SUBMISSION SUMMARY', boxX + boxW / 2, y + 6.5, { align: 'center' });

                doc.setDrawColor(224, 227, 232);
                doc.setLineWidth(0.25);
                doc.line(boxX + 4, y + 9, boxX + boxW - 4, y + 9);

                const fmt = v => (v < 0 ? '- $' : '$') + Math.abs(v).toFixed(2);
                const stats = [
                    { label: 'HOSPITALS', value: String(s.hospitals) },
                    { label: 'PATIENTS', value: String(s.patients) },
                    { label: 'CLAIMS', value: String(s.claims) },
                    { label: 'TOTAL ORIGINAL AMOUNT', value: '$' + s.originalAmountTotal.toFixed(2) },
                    { label: 'TOTAL ALLOCATED AMOUNT', value: fmt(s.allocatedAmountTotal) },
                    { label: 'TOTAL ADJUSTMENT AMOUNT', value: fmt(s.adjAmountTotal) }
                ];
                const colW = boxW / stats.length;
                stats.forEach((st, i) => {
                    const cx = boxX + colW * i + colW / 2;
                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(6.4);
                    doc.setTextColor(110, 118, 128);
                    doc.text(st.label, cx, y + 15, { align: 'center' });

                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(12.5);
                    doc.setTextColor(DARK_GREEN[0], DARK_GREEN[1], DARK_GREEN[2]);
                    doc.text(st.value, cx, y + 22, { align: 'center' });

                    if (i > 0) {
                        doc.setDrawColor(224, 227, 232);
                        doc.setLineWidth(0.25);
                        doc.line(boxX + colW * i, y + 11, boxX + colW * i, y + boxH - 3);
                    }
                });

                return y + boxH;
            }

            drawHeader();

            const data = getDisplayData();
            doc.autoTable({
                startY: tableStartY,
                tableWidth: 285,
                showHead: 'everyPage',   // sticky table header repeated on every PDF page

                head: [[
                    'Claim ID', 'Date', 'Hospital', 'Doctor', 'Staff', 'Patient',
                    'Adjustment Type', 'Adjustment Amount', 'Notes', 'Item Number', 'Original Amount', 'Allocated Amount'
                ]],

                body: (() => {
                    const rows = [];
                    data.forEach(r => {
                        r.lines.forEach((line, li) => {
                            const first = li === 0;
                            rows.push([
                                first ? r.claimId : '',
                                first ? formatDateDisplay(r.date) : '',
                                first ? (r.hospital || '—') : '',
                                first ? (r.doctor || '—') : '',
                                first ? (r.staff || '—') : '',
                                first ? (r.patientName || '—') : '',
                                first ? (r.type || '—') : '',
                                first ? ((r.adjAmount < 0 ? '- $' : '$') + Math.abs(r.adjAmount).toFixed(2)) : '',
                                first ? (r.notes || '—') : '',
                                line.itemNumber,
                                '$' + line.originalAmount.toFixed(2),
                                (line.adjustmentAmount < 0 ? '- $' : '$') + Math.abs(line.adjustmentAmount).toFixed(2)
                            ]);
                        });
                    });

                    const grand = computeGrandTotals(data);
                    rows.push([
                        'GRAND SUMMARY', '', '', '', '', '', '',
                        (grand.adjAmountTotal < 0 ? '- $' : '$') + Math.abs(grand.adjAmountTotal).toFixed(2),
                        '',
                        '',
                        '$' + grand.originalAmountTotal.toFixed(2),
                        (grand.allocatedAmountTotal < 0 ? '- $' : '$') + Math.abs(grand.allocatedAmountTotal).toFixed(2)
                    ]);
                    return rows;
                })(),

                styles: {
                    fontSize: 6.5,
                    cellPadding: { top: 2.2, right: 1.8, bottom: 2.2, left: 1.8 },
                    overflow: 'linebreak',
                    valign: 'middle',
                    halign: 'left',
                    textColor: [0, 0, 0],
                    fillColor: [255, 255, 255],
                    lineColor: [210, 215, 220],
                    lineWidth: 0.15
                },

                headStyles: {
                    fillColor: [58, 90, 138],
                    textColor: [255, 255, 255],
                    fontStyle: 'bold',
                    fontSize: 7,
                    halign: 'center',
                    valign: 'middle',
                    cellPadding: { top: 2.6, right: 1.8, bottom: 2.6, left: 1.8 },
                    minCellHeight: 7
                },

                columnStyles: {
                    0: { cellWidth: COL[0], halign: 'left', fontStyle: 'bold', fontSize: 6.5 },
                    1: { cellWidth: COL[1], halign: 'center' },
                    2: { cellWidth: COL[2], halign: 'left' },
                    3: { cellWidth: COL[3], halign: 'left' },
                    4: { cellWidth: COL[4], halign: 'left' },
                    5: { cellWidth: COL[5], halign: 'left' },
                    6: { cellWidth: COL[6], halign: 'center' },
                    7: { cellWidth: COL[7], halign: 'right' },
                    8: { cellWidth: COL[8], halign: 'left' },
                    9: { cellWidth: COL[9], halign: 'center' },
                    10: { cellWidth: COL[10], halign: 'right' },
                    11: { cellWidth: COL[11], halign: 'right' }
                },

                didParseCell(d) {
                    const isSummaryRow = Array.isArray(d.row.raw) && d.row.raw[0] === 'GRAND SUMMARY';

                    if (d.section === 'body' && isSummaryRow) {
                        d.cell.styles.fillColor = [230, 236, 245];
                        d.cell.styles.fontStyle = 'bold';
                        d.cell.styles.lineWidth = 0.3;
                        d.cell.styles.lineColor = [58, 90, 138];
                    }

                    if (d.section === 'body' && (d.column.index === 7 || d.column.index === 11)) {
                        const isNeg = String(d.cell.raw).startsWith('- $');
                        d.cell.styles.textColor = isNeg ? [176, 48, 48] : (isSummaryRow ? [21, 94, 45] : [30, 126, 58]);
                        d.cell.styles.fontStyle = 'bold';
                    }
                },

                margin: { top: tableStartY, left: mL, right: mR, bottom: 34 },

                didDrawPage(d) {
                    if (d.pageNumber > 1) drawHeader();
                }
            });

            let summaryY = doc.lastAutoTable.finalY + 6;
            const cardHeight = 26;
            if (summaryY + cardHeight > footerRuleY - 4) {
                doc.addPage();
                drawHeader();
                summaryY = tableStartY;
            }
            drawGrandSummaryCard(summaryY);

            const pageCount = doc.internal.getNumberOfPages();
            for (let p = 1; p <= pageCount; p++) {
                doc.setPage(p);
                drawFooter(p, pageCount);
            }

            // Desktop → download; iPhone/Android → preview + share sheet
            const fileName = 'Adjustment_Report_' + exportDateStamp() + '.pdf';
            if (!isMobileDevice()) {
                try {
                    doc.save(fileName);
                } catch (saveErr) {
                    deliverFile(doc.output('blob'), fileName);
                }
            } else {
                deliverFile(doc.output('blob'), fileName);
            }

            hideLoading();
            showToast(isMobileDevice() ? '✓ PDF ready' : '✓ PDF exported successfully');
        } catch (e) { hideLoading(); showToast('Export failed: ' + e.message); }
    }, 80);
}

/* ─────────────────────────────────────────────────────────────────────
   PDF ICON HELPERS
   ───────────────────────────────────────────────────────────────────── */
function _iconColor(doc, color, fillToo) {
    doc.setDrawColor(color[0], color[1], color[2]);
    if (fillToo) doc.setFillColor(color[0], color[1], color[2]);
}

function iconDoctor(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(0.28);
    doc.circle(cx, cy - s * 0.20, s * 0.16, 'S');
    doc.ellipse(cx, cy + s * 0.18, s * 0.26, s * 0.16, 'S');
}

function iconHospital(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(0.28);
    const w = s * 0.62, h = s * 0.72;
    doc.roundedRect(cx - w / 2, cy - h / 2, w, h, 0.4, 0.4, 'S');
    doc.setLineWidth(0.22);
    doc.line(cx, cy - h * 0.22, cx, cy + h * 0.02);
    doc.line(cx - w * 0.16, cy - h * 0.10, cx + w * 0.16, cy - h * 0.10);
    doc.rect(cx - w * 0.30, cy + h * 0.14, w * 0.22, h * 0.18, 'S');
    doc.rect(cx + w * 0.08, cy + h * 0.14, w * 0.22, h * 0.18, 'S');
}

function iconCalendar(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(0.28);
    const w = s * 0.66, h = s * 0.58;
    doc.roundedRect(cx - w / 2, cy - h / 2, w, h, 0.5, 0.5, 'S');
    doc.line(cx - w / 2, cy - h / 2 + h * 0.32, cx + w / 2, cy - h / 2 + h * 0.32);
    doc.setLineWidth(0.4);
    doc.line(cx - w * 0.22, cy - h / 2 - 0.5, cx - w * 0.22, cy - h / 2 + 0.8);
    doc.line(cx + w * 0.22, cy - h / 2 - 0.5, cx + w * 0.22, cy - h / 2 + 0.8);
}

function iconClock(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(0.28);
    doc.circle(cx, cy, s * 0.32, 'S');
    doc.setLineWidth(0.32);
    doc.line(cx, cy, cx, cy - s * 0.18);
    doc.line(cx, cy, cx + s * 0.15, cy + s * 0.03);
}

const ICON_KAPPA = 0.5523;

function iconLock(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(s * 0.045);
    const shackleR = s * 0.16;
    const shackleCy = cy - s * 0.12;
    const bodyW = s * 0.44;
    const bodyH = s * 0.34;
    const bodyTopY = cy - s * 0.02;
    const bodyR = s * 0.06;
    doc.circle(cx, shackleCy, shackleR, 'S');
    doc.setFillColor(color[0], color[1], color[2]);
    doc.roundedRect(cx - bodyW / 2, bodyTopY, bodyW, bodyH, bodyR, bodyR, 'F');
}

function iconShield(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(s * 0.05);
    const halfW = s * 0.32;
    const r = s * 0.10;
    const topY = cy - s * 0.44;
    const shoulderY = topY + r;
    const taperY = cy + s * 0.04;
    const botY = cy + s * 0.46;
    const k = ICON_KAPPA;

    doc.lines(
        [
            [2 * (halfW - r), 0],
            [k * r, 0, r, r - k * r, r, r],
            [0, taperY - shoulderY],
            [0, (botY - taperY) * 0.6, -halfW * 0.75, botY - taperY, -halfW, botY - taperY],
            [-halfW * 0.25, 0, -halfW, -(botY - taperY) * 0.4, -halfW, -(botY - taperY)],
            [0, -(taperY - shoulderY)],
            [0, -k * r, r - k * r, -r, r, -r]
        ],
        cx - halfW + r, topY,
        [1, 1], 'S', true
    );

    iconLock(doc, cx, cy + s * 0.02, s * 0.62, color);
}

function iconPhone(doc, cx, cy, s, color) {
    _iconColor(doc, color, true);
    doc.setLineWidth(0.28);
    doc.roundedRect(cx - s * 0.16, cy - s * 0.28, s * 0.32, s * 0.56, 0.5, 0.5, 'S');
    doc.setLineWidth(0.16);
    doc.line(cx - s * 0.08, cy + s * 0.16, cx + s * 0.08, cy + s * 0.16);
}

function iconEmail(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(0.28);
    const w = s * 0.56, h = s * 0.4;
    doc.rect(cx - w / 2, cy - h / 2, w, h, 'S');
    doc.line(cx - w / 2, cy - h / 2, cx, cy + h * 0.08);
    doc.line(cx + w / 2, cy - h / 2, cx, cy + h * 0.08);
}

function iconGlobe(doc, cx, cy, s, color) {
    _iconColor(doc, color);
    doc.setLineWidth(0.28);
    const r = s * 0.3;
    doc.circle(cx, cy, r, 'S');
    doc.ellipse(cx, cy, r * 0.42, r, 'S');
    doc.line(cx - r, cy, cx + r, cy);
}

function getReportMeta() {
    const practiceLabelEl = document.querySelector('#ss-practice .ss-label');
    const docLabelEl = document.querySelector('#ss-doctor .ss-label');
    const hospLabelEl = document.querySelector('#ss-location .ss-label');
    const fromEl = document.getElementById('filter-from');
    const toEl = document.getElementById('filter-to');

    const practiceName = (practiceLabelEl && practiceLabelEl.textContent.trim()) || 'All Practices';
    const doctorName = (docLabelEl && docLabelEl.textContent.trim()) || 'All Doctors';
    const hospitalName = (hospLabelEl && hospLabelEl.textContent.trim()) || 'All Locations';

    const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
        'August', 'September', 'October', 'November', 'December'];

    const fmtShort = (iso) => {
        const m = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (!m) return '';
        return `${parseInt(m[3], 10)} ${MONTHS[parseInt(m[2], 10) - 1]}`;
    };

    const fmtLong = (iso) => {
        const m = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (!m) return '';
        return `${parseInt(m[3], 10)} ${MONTHS[parseInt(m[2], 10) - 1]} ${m[1]}`;
    };

    const fromStr = fromEl && fromEl.value ? fmtShort(fromEl.value) : '';
    const toStr = toEl && toEl.value ? fmtLong(toEl.value) : '';

    let period;
    if (fromStr && toStr) period = `${fromStr} – ${toStr}`;
    else if (fromStr) period = `From ${fmtLong(fromEl.value)}`;
    else if (toStr) period = `Up to ${toStr}`;
    else period = 'All Dates';

    const now = new Date();
    let hh = now.getHours();
    const ampm = hh >= 12 ? 'PM' : 'AM';
    hh = hh % 12 || 12;
    const mm = String(now.getMinutes()).padStart(2, '0');
    const generatedOn = `${now.getDate()} ${MONTHS[now.getMonth()]} ${now.getFullYear()} at ${hh}:${mm} ${ampm}`;

    return { practiceName, doctorName, hospitalName, period, generatedOn };
}


/* ─────────────────────────────────────────────────────────────────────
   UTILS
   ───────────────────────────────────────────────────────────────────── */
function showLoading(msg) {
    document.getElementById('loading-msg').textContent = msg || 'Processing';
    document.getElementById('loading-overlay').classList.add('show');
}
function hideLoading() { document.getElementById('loading-overlay').classList.remove('show'); }
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
}